﻿Imports System.Data.SqlClient
Imports System.Drawing.Drawing2D
Imports System.Runtime.InteropServices

Public Class ForgotPasswordPage
    Private borderRadius As Integer = 6
    Private borderSize As Integer = 4
    Private borderColor As Color = Color.SeaGreen

    'Constractor
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Private Function GetRoundedPath(rect As Rectangle, radius As Single) As GraphicsPath
        Dim path As GraphicsPath = New GraphicsPath()
        Dim curveSize As Single = radius * 2.0F
        path.StartFigure()
        path.AddArc(rect.X, rect.Y, curveSize, curveSize, 180, 90)
        path.AddArc(rect.Right - curveSize, rect.Y, curveSize, curveSize, 270, 90)
        path.AddArc(rect.Right - curveSize, rect.Bottom - curveSize, curveSize, curveSize, 0, 90)
        path.AddArc(rect.X, rect.Bottom - curveSize, curveSize, curveSize, 90, 90)
        path.CloseFigure()
        Return path
    End Function

    Private Sub FormRegionAndBorder(form As Form, radius As Single, graph As Graphics, borderColor As Color, borderSize As Single)
        If Me.WindowState <> FormWindowState.Minimized Then
            Using roundPath As GraphicsPath = GetRoundedPath(form.ClientRectangle, radius)
                Using penBorder As Pen = New Pen(borderColor, borderSize)
                    Using transform As Matrix = New Matrix()

                        graph.SmoothingMode = SmoothingMode.AntiAlias
                        form.Region = New Region(roundPath)
                        If borderSize >= 1 Then
                            Dim rect As Rectangle = form.ClientRectangle
                            Dim scaleX As Single = 1.0F - ((borderSize + 1) / rect.Width)
                            Dim scaleY As Single = 1.0F - ((borderSize + 1) / rect.Height)
                            transform.Scale(scaleX, scaleY)
                            transform.Translate(borderSize / 1.6F, borderSize / 1.6F)
                            graph.Transform = transform
                            graph.DrawPath(penBorder, roundPath)
                        End If
                    End Using
                End Using
            End Using

        End If
    End Sub



    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Me.Hide()
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        If (txtOldPassword.PasswordChar = "*") Then
            txtOldPassword.PasswordChar = ""
        Else
            txtOldPassword.PasswordChar = "*"
        End If
    End Sub

    Private Sub IconButton3_Click(sender As Object, e As EventArgs) Handles IconButton3.Click
        If (txtNewPassword.PasswordChar = "*") Then
            txtNewPassword.PasswordChar = ""
        Else
            txtNewPassword.PasswordChar = "*"
        End If
    End Sub

    Private Sub IconButton6_Click(sender As Object, e As EventArgs) Handles IconButton6.Click
        If (txtConfirmNewPassword.PasswordChar = "*") Then
            txtConfirmNewPassword.PasswordChar = ""
        Else
            txtConfirmNewPassword.PasswordChar = "*"
        End If
    End Sub

    Dim aa As Integer = 0
    Private Sub btnChangePassword_Click(sender As Object, e As EventArgs) Handles btnChangePassword.Click
        Dim encryptOldPassword = Encrypt(txtOldPassword.Text)
        'Dim encryptAdminStaffID = Encrypt(txtStaffID.Text)
        If (txtOldPassword.Text = "") Then
            MsgBox("Enter the 'Old Password'")
        ElseIf (txtNewPassword.Text = "") Then
            MsgBox("Enter the 'New Password'")
        ElseIf (txtConfirmNewPassword.Text = "") Then
            MsgBox("Enter the 'Confirm New Password'")
        ElseIf (txtNewPassword.Text.Length < 6) Then
            MsgBox("The password length must be 6 or more", MsgBoxStyle.Exclamation)
        Else


            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from AdminTbl where Staff_ID='" & AStaffID & "' and Password='" & encryptOldPassword & "'"
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa = ds.Tables(0).Rows.Count
            Catch ex As Exception
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try

            If (aa <> 0) Then
                If (txtNewPassword.Text <> txtConfirmNewPassword.Text) Then
                    MsgBox("Password does not match", MsgBoxStyle.Exclamation)
                Else
                    Try
                        Con.Open()
                        Dim query As String
                        query = "Update AdminTbl set Password='" & Encrypt(txtNewPassword.Text) & "'"
                        cmd = New SqlCommand(query, Con)
                        cmd.ExecuteNonQuery()
                        AdminEditAccountPage.txtUserPassword.Text = txtNewPassword.Text
                        MsgBox("Password changed successfully", MsgBoxStyle.Information)
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try

                    txtConfirmNewPassword.Text = ""
                    txtNewPassword.Text = ""
                    txtOldPassword.Text = ""
                    Me.Hide()
                End If
            Else
                MsgBox("Wrong password", MsgBoxStyle.Exclamation)
            End If

        End If

    End Sub

    Private Sub ForgotPasswordPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AcceptButton = btnChangePassword
    End Sub

    Private Sub ForgotPasswordPage_Paint(sender As Object, e As PaintEventArgs) Handles MyBase.Paint
        FormRegionAndBorder(Me, borderRadius, e.Graphics, borderColor, borderSize)
    End Sub
    'Drag Form

    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub
    Private Sub PanelTitleBar_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseDown
        ReleaseCapture()
        SendMessage(Me.Handle, &H112, &HF012, 0)
        '   btnMaximize.Visible = True
        '  btnNormal.Visible = False
    End Sub
    Protected Overrides ReadOnly Property CreateParams As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            cp.Style = cp.Style Or &H20000
            Return cp
        End Get
    End Property
End Class