﻿Imports System.Data.SqlClient
Imports Microsoft.Reporting.WinForms
Public Class MembersPage
    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Hometown,Birth_Date,Registration_Date,Operator from MembersTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Surname  like '%' +@parm1+ '%' "
            query &= " or Staff_ID like '%' +@parm1+ '%' "
            query &= " or Phone like '%' +@parm1+ '%' "
            query &= " or Marital_Status like '%' +@parm1+ '%' "
            query &= " or Other_Names like '%' +@parm1+ '%' "
            query &= " or Birth_Date like '%' +@parm1+ '%' "
            query &= " or Sex like '%' +@parm1+ '%' "
            query &= " or Registration_Date like '%' +@parm1+ '%' "
            query &= " or Operator like '%' +@parm1+ '%' "
            query &= " or Hometown like '%' +@parm1+ '%' "
            query &= " or House_No like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using

            '  End Using
            Dim deleteButtonColumn As New DataGridViewButtonColumn()
            deleteButtonColumn.HeaderText = ""
            deleteButtonColumn.Text = "Delete"
            deleteButtonColumn.Name = "DeleteBtn"
            deleteButtonColumn.UseColumnTextForButtonValue = True

            Dim EditButtonColumn2 As New DataGridViewButtonColumn()
            EditButtonColumn2.HeaderText = ""
            EditButtonColumn2.Text = "Edit"
            EditButtonColumn2.Name = "EditBtn"
            EditButtonColumn2.UseColumnTextForButtonValue = True

            membersDataGridView.Columns.Add(deleteButtonColumn)
            membersDataGridView.Columns.Add(EditButtonColumn2)

        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function

    ' Public Event ShowAddMembersPage1Requested As EventHandler
    Sub switchPages(ByVal pageSwitch1 As Form)

        Try

            Dim Pane As Panel = Form1.pageSwitch


            Pane.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill

            Pane.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        ' Dim nwAddMemberPage1 = New AddMemberPage1
        resetAllMemberFormsAdmin()
        resetAllMemberFormsAdmin()
        switchPages(AddMemberPage1)




    End Sub
    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Hometown,Birth_Date,Registration_Date,Operator from MembersTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            membersDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
        Dim deleteButtonColumn As New DataGridViewButtonColumn()
        deleteButtonColumn.HeaderText = ""
        deleteButtonColumn.Text = "Delete"
        deleteButtonColumn.Name = "DeleteBtn"
        deleteButtonColumn.UseColumnTextForButtonValue = True

        Dim EditButtonColumn2 As New DataGridViewButtonColumn()
        EditButtonColumn2.HeaderText = ""
        EditButtonColumn2.Text = "Edit"
        EditButtonColumn2.Name = "EditBtn"
        EditButtonColumn2.UseColumnTextForButtonValue = True

        ' deleteButtonColumn.Image = My.Resources.approve
        'deleteButtonColumn.Name = "Delete"
        ' deleteButtonColumn.ImageLayout = DataGridViewImageCellLayout.Zoom
        membersDataGridView.Columns.Add(deleteButtonColumn)
        membersDataGridView.Columns.Add(EditButtonColumn2)
    End Sub

    Private Sub PopulateRefresh()
        Try
            Con.Open()
            Dim query = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Hometown,Birth_Date,Registration_Date,Operator from MembersTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            membersDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

    End Sub
    Private Sub MembersPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
    End Sub

    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        membersDataGridView.DataSource = Me.SearchItem
    End Sub

    Private Sub PopulateChild()
        Try
            Con.Open()
            Dim query = "select Id,Name,Birth_Date from ChildrenTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            EditMemberProfile.childrenDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub membersDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles membersDataGridView.CellContentClick
        Try
            If e.RowIndex >= 0 AndAlso e.ColumnIndex = membersDataGridView.Columns("DeleteBtn").Index Then

                Dim rowID As Integer = Convert.ToInt32(membersDataGridView.Rows(e.RowIndex).Cells("Id").Value)

                Dim row As DataGridViewRow = membersDataGridView.Rows(e.RowIndex)

                getStaffIDToEdit = row.Cells(3).Value.ToString
                theMemberNam = row.Cells(4).Value.ToString
                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Staff_ID='" & getStaffIDToEdit & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUserStaffID = myReader("Staff_ID")
                    memberUserSurname = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")
                    profilePicture = CType(myReader("Picture"), Byte())
                    memberRegistrationDate = myReader("Registration_Date")
                    memberUserOperator = myReader("Operator")

                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                Dim deleteDialog As DialogResult = MessageBox.Show("Remove " + theMemberNam + " with Staff ID " + "(" + getStaffIDToEdit + ")" + " from the Welfare Scheme", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If (deleteDialog = DialogResult.Yes) Then

                    removeMember(getStaffIDToEdit, Aname, AStaffID)

                    PopulateRefresh()

                End If

            ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = membersDataGridView.Columns("EditBtn").Index) Then

                Dim rowID As Integer = Convert.ToInt32(membersDataGridView.Rows(e.RowIndex).Cells("Id").Value)
                Dim row As DataGridViewRow = membersDataGridView.Rows(e.RowIndex)

                theMemberNam = row.Cells(4).Value.ToString
                getStaffIDToEdit = row.Cells(3).Value.ToString
                ''Read member Info
                '  MsgBox(getStaffIDToEdit + " " + theMemberNam)


                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Staff_ID='" & getStaffIDToEdit & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUniqueId = myReader("Id")
                    memberUserStaffID = myReader("Staff_ID")
                    memberUserSurname1 = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")
                    profilePicture = CType(myReader("Picture"), Byte())
                    memberUserSurname = memberUserSurname1
                    ' memberRegistrationDate = myReader("Registration_Date")
                    'memberUserOperator = myReader("Operator")
                    EditMemberProfile.txtMemberSurname.Text = memberUserSurname.ToUpper
                    EditMemberProfile.txtMemberOthername.Text = memberUserOthername.ToUpper
                    EditMemberProfile.txtMemberSex.Text = memberUserSex
                    EditMemberProfile.txtMemberPhone.Text = memberUserPhone
                    EditMemberProfile.txtMemberHouseNo.Text = memberUserHouseNo
                    EditMemberProfile.txtMemberPostalAddress.Text = memberUserPostalAddress.ToUpper
                    EditMemberProfile.txtMaritalStatus.Text = memberUserMaritalStatus
                    EditMemberProfile.txtTypeOfMarriage.Text = memberUserTypeOfMarriage
                    EditMemberProfile.txtMemberHometown.Text = memberUserHomeTown.ToUpper
                    EditMemberProfile.txtMemberDoB1.Text = memberUserDoB
                    EditMemberProfile.txtMemberStaffID.Text = memberUserStaffID.ToUpper
                    EditMemberProfile.txtImageName.Text = ""



                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try


                'Check if member is Married
                Try
                    Cursor = Cursors.WaitCursor
                    Con.Open()
                    Dim query22 As String = "select * from SpouseTbl where Member_ID='" & getStaffIDToEdit & "'"
                    cmd = New SqlCommand(query22, Con)
                    adaptor = New SqlDataAdapter(cmd)
                    ds = New DataSet()
                    adaptor.Fill(ds)
                    checkNoSpouse = ds.Tables(0).Rows.Count
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Cursor = Cursors.Default
                    Con.Close()
                End Try
                '
                '
                '   MsgBox(checkNoSpouse)

                If (checkNoSpouse <> 0) Then
                    'Read member Spouse Info
                    Try
                        Con.Open()
                        Dim query = "select * from SpouseTbl where Member_ID='" & getStaffIDToEdit & "'"
                        cmd = New SqlCommand(query, Con)
                        myReader = cmd.ExecuteReader
                        myReader.Read()
                        memberSpouseUniqueId = myReader("Id")
                        memberUserSpouseName = myReader("Name")
                        memberUserSpousePhone = myReader("Phone")
                        memberUserSpouseAddress = myReader("Contact_Address")

                        'Spouse Info
                        EditMemberProfile.txtSpouseName.Text = memberUserSpouseName.ToUpper
                        EditMemberProfile.txtSpousePhone.Text = memberUserSpousePhone
                        EditMemberProfile.txtSpouseAddress.Text = memberUserSpouseAddress.ToUpper

                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try
                Else
                    EditMemberProfile.txtSpouseName.Text = ""
                    EditMemberProfile.txtSpousePhone.Text = ""
                    EditMemberProfile.txtSpouseAddress.Text = ""
                    memberUserSpouseName = ""
                    memberUserSpousePhone = ""
                    memberUserSpouseAddress = ""
                End If

                'Read member Father Info
                Try
                    Con.Open()
                    Dim query = "select * from ParentsTbl where Member_ID='" & getStaffIDToEdit & "' and Parent_Type ='" & AFather & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberFatherUniqueId = myReader("Id")
                    memberUserFathername = myReader("Name")
                    memberUserFatherPhone = myReader("Phone")
                    memberUserFatherLiveStatus = myReader("Live_Status")

                    If (memberUserFatherLiveStatus = "Dead") Then
                        EditMemberProfile2.txtFatherDead.Checked = True
                    Else
                        EditMemberProfile2.txtFatherAlive.Checked = True
                    End If
                    EditMemberProfile2.txtFatherName.Text = memberUserFathername.ToUpper
                    EditMemberProfile2.txtFatherPhone.Text = memberUserFatherPhone
                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                'Read member Mother Info
                Try
                    Con.Open()
                    Dim query = "select * from ParentsTbl where Member_ID='" & getStaffIDToEdit & "' and Parent_Type ='" & AMother & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberMotherUniqueId = myReader("Id")
                    memberUserMothername = myReader("Name")
                    memberUserMotherPhone = myReader("Phone")
                    memberUserMotherLiveStatus = myReader("Live_Status")

                    If (memberUserMotherLiveStatus = "Dead") Then
                        EditMemberProfile2.txtMotherDead.Checked = True

                    Else
                        EditMemberProfile2.txtMotherAlive.Checked = True
                    End If
                    EditMemberProfile2.txtMotherName.Text = memberUserMothername.ToUpper
                    EditMemberProfile2.txtMotherPhone.Text = memberUserMotherPhone


                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try
                'Children Info
                PopulateChild()

                switchPages(EditMemberProfile)

            End If
        Catch ex As Exception

        End Try
    End Sub

    'Members report Sub
    Sub LoadMembersReport()
        Cursor = Cursors.WaitCursor

        Dim rptDS As ReportDataSource
        Print_Members.MembersReport.RefreshReport()
        Try

            With Print_Members.MembersReport.LocalReport
                .ReportPath = Application.StartupPath & "\Reports\MembersReport1.rdlc"
                .DataSources.Clear()
            End With
            Dim dss As New MembersDataSet2
            Dim da As New SqlDataAdapter

            Con.Open()
            Dim Queryy As String = "SELECT Staff_ID, Surname, Other_Names, Phone, Sex, House_No, Postal_Address, Marital_Status, Marriage_Type, Hometown, Birth_Date FROM MembersTbl"

            da.SelectCommand = New SqlCommand(Queryy, Con)
            'da.SelectCommand.Parameters.AddWithValue("@StartDate", fromDateTimePicker.Value)
            ' da.SelectCommand.Parameters.AddWithValue("@EndDate", toDateTimePicker2.Value)
            da.Fill(dss.Tables("MembersTbl"))
            Con.Close()
            rptDS = New ReportDataSource("DataSet1", dss.Tables("MembersTbl"))
            Print_Members.MembersReport.LocalReport.DataSources.Add(rptDS)
            Print_Members.MembersReport.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Print_Members.MembersReport.ZoomMode = ZoomMode.Percent
            Print_Members.MembersReport.ZoomPercent = 100
        Catch ex As SqlException
            Con.Close()
            MsgBox(ex.Message)
        End Try

        Print_Members.Show()

        Cursor = Cursors.Default
    End Sub
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        LoadMembersReport()
    End Sub
End Class