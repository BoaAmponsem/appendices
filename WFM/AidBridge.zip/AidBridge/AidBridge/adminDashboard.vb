﻿Imports System.Data.SqlClient
Imports FontAwesome.Sharp
Imports System.Windows.Forms.DataVisualization
Public Class adminDashboard
    Private currentBtn As IconButton

    Private Sub ActivationButton(senderBtn As Object, customColor As Color)

        Try
            If senderBtn IsNot Nothing Then
                DisableButton()
                'Button'
                currentBtn = CType(senderBtn, IconButton)
                currentBtn.BackColor = Color.FromArgb(37, 36, 81)
                currentBtn.ForeColor = customColor

            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub DisableButton()
        Try
            If currentBtn IsNot Nothing Then

                currentBtn.BackColor = Color.WhiteSmoke
                currentBtn.ForeColor = Color.FromArgb(37, 36, 81)

            End If
        Catch ex As Exception

        End Try
    End Sub
    Sub switchPages(ByVal pageSwitch1 As Form)
        Try
            Form1.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            Form1.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub IconButton3_Click(sender As Object, e As EventArgs) Handles dashboardBtnContributions.Click
        Form1.btnContribution.PerformClick()
    End Sub

    Private Sub dashBoardBtnMembers_Click(sender As Object, e As EventArgs) Handles dashBoardBtnMembers.Click
        Form1.btnMembers.PerformClick()
    End Sub

    Private Sub dashBoardBtnClaims_Click(sender As Object, e As EventArgs) Handles dashBoardBtnClaims.Click
        Form1.btnClaims.PerformClick()
    End Sub

    Private Sub adminDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            txtTotalClaims.Text = "Ghc " + totalMoneyGivenOut.ToString
            txtTotalMembers.Text = totalMembers.ToString
            txtTotalContributions.Text = "Ghc " + totalContributions.ToString
            txtTotalWithdrawal.Text = "Ghc " + totalWithdrawal.ToString
            txtAccountBalance.Text = "Ghc " + (SumOfAllDeposits - SumOfAllWithdrawals).ToString

            txtYear.Text = currentYear
            txtYear2.Text = currentYear
        Catch ex As Exception

        End Try


        Try
            Dim dataTable As New DataTable()
            dataTable.Columns.Add("Description", GetType(String))
            dataTable.Columns.Add("Amount", GetType(Integer))

            dataTable.Rows.Add("Contributions", totalContributions)
            dataTable.Rows.Add("All Deposits", totalDeposits)
            dataTable.Rows.Add("Withdrawals", totalWithdrawal)
            dataTable.Rows.Add("Account Balance", (SumOfAllDeposits - SumOfAllWithdrawals))
            dataTable.Rows.Add("Claims", totalMoneyGivenOut)


            Me.Chart1.DataSource = dataTable

            Chart1.Series("Series1").XValueMember = "Description"
            Chart1.Series("Series1").YValueMembers = "Amount"
            Me.Chart1.DataBind()
        Catch ex As Exception

        End Try


        Try
            'Doughnut Chart
            Dim dataTable2 As New DataTable()

            dataTable2.Columns.Add("Description", GetType(String))
            dataTable2.Columns.Add("Value", GetType(Integer))

            dataTable2.Rows.Add("No. Of Claims", totalClaims)
            dataTable2.Rows.Add("Members", totalMembers)
            ' dataTable2.Rows.Add("Contributions", totalContributions)
            'dataTable2.Rows.Add("Withdrawals", totalWithdrawal)
            'dataTable2.Rows.Add("Account Balance", (totalDeposits - totalWithdrawal))
            'dataTable2.Rows.Add("Claims", totalMoneyGivenOut)

            Me.Chart2.DataSource = dataTable2

            Chart2.Series("Series1").XValueMember = "Description"
            Chart2.Series("Series1").YValueMembers = "Value"
            Me.Chart2.DataBind()
        Catch ex As Exception

        End Try


    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Form1.btnContribution.PerformClick()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Form1.btnMembers.PerformClick()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Form1.btnClaims.PerformClick()
    End Sub

    Private Sub FromDateTimePicker_ValueChanged(sender As Object, e As EventArgs) Handles FromDateTimePicker.ValueChanged
        fromLabel.Text = FromDateTimePicker.Value
        newChartValues()
    End Sub
    Private Sub newChartValues()
        Try
            SumAllDeposits()
            SumAllWithdrawal()
        Catch ex As Exception

        End Try

        Try
            If (btnCheck.Visible = True) Then
                '' Get the total Deposits check

                Try
                    '  Cursor = Cursors.WaitCursor
                    Con.Open()
                    Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Deposit' And Date Between @StartDate And @EndDate"
                    cmd = New SqlCommand(query22, Con)
                    adaptor = New SqlDataAdapter(cmd)
                    adaptor.SelectCommand.Parameters.AddWithValue("@StartDate", FromDateTimePicker.Value)
                    adaptor.SelectCommand.Parameters.AddWithValue("@EndDate", ToDateTimePicker.Value)
                    ds = New DataSet()
                    adaptor.Fill(ds)
                    checkNullDeposits = ds.Tables(0).Rows.Count

                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    '  Cursor = Cursors.Default
                    Con.Close()
                End Try

                '' Get the total withdrawal check
                Try
                    '  Cursor = Cursors.WaitCursor
                    Con.Open()
                    Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Withdrawal' And Date Between @StartDate And @EndDate"
                    cmd = New SqlCommand(query22, Con)
                    adaptor = New SqlDataAdapter(cmd)
                    adaptor.SelectCommand.Parameters.AddWithValue("@StartDate", FromDateTimePicker.Value)
                    adaptor.SelectCommand.Parameters.AddWithValue("@EndDate", ToDateTimePicker.Value)
                    ds = New DataSet()
                    adaptor.Fill(ds)
                    Withdrawals = ds.Tables(0).Rows.Count

                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    '  Cursor = Cursors.Default
                    Con.Close()
                End Try

                'Total Deposits
                If (checkNullDeposits <> 0) Then
                    Try
                        Con.Open()
                        Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Deposit' And Date Between @StartDate And @EndDate"
                        cmd = New SqlCommand(queryYearly, Con)
                        cmd.Parameters.AddWithValue("@StartDate", FromDateTimePicker.Value)
                        cmd.Parameters.AddWithValue("@EndDate", ToDateTimePicker.Value)
                        ' Assuming connection is your SqlConnection object
                        '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                        Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                        If (IsDBNull(toTotal) = True) Then
                            totalDeposits = 0
                        Else
                            totalDeposits = toTotal
                        End If
                        ' Process or display yearly sum for the current year here
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try
                Else
                    totalDeposits = "0"
                End If

                'Total Withdrawals
                If (Withdrawals <> 0) Then
                    Try
                        Con.Open()
                        Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Withdrawal' And Date Between @StartDate And @EndDate"
                        cmd = New SqlCommand(queryYearly, Con)
                        cmd.Parameters.AddWithValue("@StartDate", FromDateTimePicker.Value)
                        cmd.Parameters.AddWithValue("@EndDate", ToDateTimePicker.Value)
                        ' Assuming connection is your SqlConnection object
                        '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                        Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                        If (IsDBNull(toTotal) = True) Then
                            totalWithdrawal = 0
                        Else
                            totalWithdrawal = toTotal
                        End If
                        ' Process or display yearly sum for the current year here
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try
                Else
                    totalWithdrawal = "0"
                End If



                Dim checknul1 As Integer = 0, checknull2 As Integer = 0
                '' Get the total contribtions check
                Try
                    Cursor = Cursors.WaitCursor
                    Con.Open()
                    Dim query22 As String = "select * from ContributionsTbl WHERE Month_Of_Payment Between @StartDate And @EndDate"
                    cmd = New SqlCommand(query22, Con)
                    adaptor = New SqlDataAdapter(cmd)
                    adaptor.SelectCommand.Parameters.AddWithValue("@StartDate", FromDateTimePicker.Value)
                    adaptor.SelectCommand.Parameters.AddWithValue("@EndDate", ToDateTimePicker.Value)
                    ds = New DataSet()
                    adaptor.Fill(ds)
                    checknul1 = ds.Tables(0).Rows.Count

                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Cursor = Cursors.Default
                    Con.Close()
                End Try

                'Total Contributions
                If (checknul1 <> 0) Then
                    Try
                        Con.Open()
                        Dim queryYearly As String = "SELECT sum(Amount) FROM ContributionsTbl WHERE Month_Of_Payment Between @StartDate And @EndDate"
                        cmd = New SqlCommand(queryYearly, Con)
                        ' Assuming connection is your SqlConnection object
                        cmd.Parameters.AddWithValue("@StartDate", FromDateTimePicker.Value)
                        cmd.Parameters.AddWithValue("@EndDate", ToDateTimePicker.Value)

                        Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                        If (IsDBNull(toTotal) = True) Then
                            totalContributions = 0
                        Else
                            totalContributions = toTotal
                        End If
                        ' Process or display yearly sum for the current year here
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try

                ElseIf (checknul1 = 0) Then
                    totalContributions = 0
                End If

                '' Get the total claims amount check
                Try
                    Cursor = Cursors.WaitCursor
                    Con.Open()
                    Dim query22 As String = "select * from ClaimsTbl WHERE  Claim_Date Between @StartDate And @EndDate"
                    cmd = New SqlCommand(query22, Con)
                    adaptor = New SqlDataAdapter(cmd)
                    adaptor.SelectCommand.Parameters.AddWithValue("@StartDate", FromDateTimePicker.Value)
                    adaptor.SelectCommand.Parameters.AddWithValue("@EndDate", ToDateTimePicker.Value)
                    ds = New DataSet()
                    adaptor.Fill(ds)
                    checknull2 = ds.Tables(0).Rows.Count

                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Cursor = Cursors.Default
                    Con.Close()
                End Try

                If (checknull2 <> 0) Then
                    'Total Amount Claimed
                    Try
                        Cursor = Cursors.WaitCursor
                        Con.Open()
                        Dim queryYearly As String = "SELECT sum(Amount_Given) Where Claim_Date Between @StartDate And @EndDate"
                        cmd = New SqlCommand(queryYearly, Con)
                        '   Dim toTotal = cmd.ExecuteScalar
                        cmd.Parameters.AddWithValue("@StartDate", FromDateTimePicker.Value)
                        cmd.Parameters.AddWithValue("@EndDate", ToDateTimePicker.Value)
                        Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                        If (IsDBNull(toTotal) = True) Then
                            totalMoneyGivenOut = 0
                        Else
                            totalMoneyGivenOut = toTotal
                        End If
                    Catch ex As Exception
                        '   MsgBox(ex.Message)
                    Finally
                        Cursor = Cursors.Default
                        Con.Close()
                    End Try
                ElseIf (checknull2 = 0) Then
                    totalMoneyGivenOut = 0
                End If


                Try
                    txtTotalClaims.Text = "Ghc " + totalMoneyGivenOut.ToString
                    txtTotalMembers.Text = totalMembers.ToString
                    txtTotalContributions.Text = "Ghc " + totalContributions.ToString
                    txtTotalWithdrawal.Text = "Ghc " + totalWithdrawal.ToString
                    txtAccountBalance.Text = "Ghc " + (SumOfAllDeposits - SumOfAllWithdrawals).ToString

                    txtYear.Visible = False
                    txtYear2.Visible = False
                Catch ex As Exception

                End Try






                ' Me.Chart2.DataBind()
                Try
                    Dim dataTable As New DataTable()
                    dataTable.Columns.Add("Description", GetType(String))
                    dataTable.Columns.Add("Amount", GetType(Integer))

                    dataTable.Rows.Add("Contributions", totalContributions)
                    dataTable.Rows.Add("All Deposits", totalDeposits)
                    dataTable.Rows.Add("Withdrawals", totalWithdrawal)
                    dataTable.Rows.Add("Account Balance", (SumOfAllDeposits - SumOfAllWithdrawals))
                    dataTable.Rows.Add("Claims", totalMoneyGivenOut)
                    ' dataTable.Rows.Add("Deposits", totalDeposits)

                    Me.Chart1.DataSource = dataTable

                    Chart1.Series("Series1").XValueMember = "Description"
                    Chart1.Series("Series1").YValueMembers = "Amount"
                    Me.Chart1.DataBind()
                Catch ex As Exception

                End Try

                'Doughnut Chart
                Try

                    Dim dataTable2 As New DataTable()

                    dataTable2.Columns.Add("Description", GetType(String))
                    dataTable2.Columns.Add("Value", GetType(Integer))

                    dataTable2.Rows.Add("No. Of Claims", totalClaims)
                    dataTable2.Rows.Add("Members", totalMembers)
                    ' dataTable2.Rows.Add("Contributions", totalContributions)
                    'dataTable2.Rows.Add("Withdrawals", totalWithdrawal)
                    'dataTable2.Rows.Add("Account Balance", (totalDeposits - totalWithdrawal))
                    'dataTable2.Rows.Add("Claims", totalMoneyGivenOut)

                    Me.Chart2.DataSource = dataTable2

                    Chart2.Series("Series1").XValueMember = "Description"
                    Chart2.Series("Series1").YValueMembers = "Value"
                    Me.Chart2.DataBind()
                Catch ex As Exception

                End Try
            Else
                MsgBox("Click on the 'Custom' button and set the date", MsgBoxStyle.Exclamation)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ToDateTimePicker_ValueChanged(sender As Object, e As EventArgs) Handles ToDateTimePicker.ValueChanged
        toLabel.Text = ToDateTimePicker.Value
        newChartValues()
    End Sub

    Private Sub fromLabel_Click(sender As Object, e As EventArgs) Handles fromLabel.Click
        FromDateTimePicker.Select()
        SendKeys.Send("%{DOWN}")
    End Sub

    Private Sub toLabel_Click(sender As Object, e As EventArgs) Handles toLabel.Click
        ToDateTimePicker.Select()
        SendKeys.Send("%{DOWN}")
    End Sub

    Private Sub IconButton4_Click(sender As Object, e As EventArgs) Handles btnYear.Click
        ActivationButton(sender, Color.White)
        btnCheck.Visible = False

        Try
            SumAllWithdrawal()
        Catch ex As Exception

        End Try
        Try
            SumAllDeposits()
        Catch ex As Exception

        End Try
        'Deposit
        'Withdrawal


        '' Get the total Deposits check
        Try
            '  Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Deposit' And YEAR(Date) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checkNullDeposits = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            '  Cursor = Cursors.Default
            Con.Close()
        End Try

        '' Get the total withdrawal check
        Try
            '  Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Withdrawal' And YEAR(Date) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            Withdrawals = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            '  Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Deposits
        If (checkNullDeposits <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Deposit' And YEAR(Date) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalDeposits = 0
                Else
                    totalDeposits = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            totalDeposits = "0"
        End If

        'Total Withdrawals
        If (Withdrawals <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Withdrawal' And YEAR(Date) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalWithdrawal = 0
                Else
                    totalWithdrawal = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            totalWithdrawal = "0"
        End If



        Dim checknul1 As Integer = 0, checknull2 As Integer = 0
        '' Get the total contribtions check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknul1 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Contributions
        If (checknul1 <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) AS YearlyContributionSum FROM ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)

                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalContributions = 0
                Else
                    totalContributions = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        End If

        '' Get the total claims amount check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknull2 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        If (checknull2 <> 0) Then
            'Total Amount Claimed
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount_Given) AS YearlyContributionSum FROM ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                '   Dim toTotal = cmd.ExecuteScalar
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalMoneyGivenOut = 0
                Else
                    totalMoneyGivenOut = toTotal
                End If
            Catch ex As Exception
                '   MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
        End If


        Try
            txtTotalClaims.Text = "Ghc " + totalMoneyGivenOut.ToString
            txtTotalMembers.Text = totalMembers.ToString
            txtTotalContributions.Text = "Ghc " + totalContributions.ToString
            txtTotalWithdrawal.Text = "Ghc " + totalWithdrawal.ToString
            txtAccountBalance.Text = "Ghc " + (SumOfAllDeposits - SumOfAllWithdrawals).ToString
            ' txtTotalMembers.Text = totalMembers.ToString
        Catch ex As Exception

        End Try



        txtYear.Visible = True
        txtYear2.Visible = True


        ' Me.Chart2.DataBind()

        Try
            Dim dataTable As New DataTable()

            dataTable.Columns.Add("Description", GetType(String))
            dataTable.Columns.Add("Amount", GetType(Integer))

            dataTable.Rows.Add("Contributions", totalContributions)
            dataTable.Rows.Add("All Deposits", totalDeposits)
            dataTable.Rows.Add("Withdrawals", totalWithdrawal)
            dataTable.Rows.Add("Account Balance", (SumOfAllDeposits - SumOfAllWithdrawals))
            dataTable.Rows.Add("Claims", totalMoneyGivenOut)


            Me.Chart1.DataSource = dataTable

            Chart1.Series("Series1").XValueMember = "Description"
            Chart1.Series("Series1").YValueMembers = "Amount"
            Me.Chart1.DataBind()
        Catch ex As Exception

        End Try

        'Doughnut Chart
        Try
            Dim dataTable2 As New DataTable()

            dataTable2.Columns.Add("Description", GetType(String))
            dataTable2.Columns.Add("Value", GetType(Integer))

            dataTable2.Rows.Add("No. Of Claims", totalClaims)
            dataTable2.Rows.Add("Members", totalMembers)
            ' dataTable2.Rows.Add("Contributions", totalContributions)
            '  dataTable2.Rows.Add("Withdrawals", totalWithdrawal)
            ' dataTable2.Rows.Add("Account Balance", (totalDeposits - totalWithdrawal))
            ' dataTable2.Rows.Add("Claims", totalMoneyGivenOut)

            Me.Chart2.DataSource = dataTable2

            Chart2.Series("Series1").XValueMember = "Description"
            Chart2.Series("Series1").YValueMembers = "Value"
            Me.Chart2.DataBind()
        Catch ex As Exception

        End Try



    End Sub

    Private Sub btnThisMonth_Click(sender As Object, e As EventArgs) Handles btnThisMonth.Click
        ActivationButton(sender, Color.White)
        btnCheck.Visible = False

        Try
            SumAllWithdrawal()
        Catch ex As Exception

        End Try
        Try
            SumAllDeposits()
        Catch ex As Exception

        End Try


        'Deposit
        'Withdrawal
        '' Get the total Deposits check

        Try
            '  Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Deposit' And Year(Date) = '" & currentYear & "' And Month(Date)='" & currentDatea & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checkNullDeposits = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            '  Cursor = Cursors.Default
            Con.Close()
        End Try

        '' Get the total withdrawal check
        Try
            '  Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Withdrawal' And Year(Date) = '" & currentYear & "' And Month(Date)='" & currentDatea & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            Withdrawals = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            '  Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Deposits
        If (checkNullDeposits <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Deposit' And Year(Date) = '" & currentYear & "' And Month(Date)='" & currentDatea & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalDeposits = 0
                Else
                    totalDeposits = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            totalDeposits = "0"
        End If

        'Total Withdrawals
        If (Withdrawals <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Withdrawal' And Year(Date) = '" & currentYear & "' And Month(Date)='" & currentDatea & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalWithdrawal = 0
                Else
                    totalWithdrawal = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            totalWithdrawal = "0"
        End If



        Dim checknul1 As Integer = 0, checknull2 As Integer = 0
        '' Get the total contribtions check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl WHERE Year(Month_Of_Payment) = '" & currentYear & "' And Month(Month_Of_Payment) = '" & currentDatea & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknul1 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Contributions
        If (checknul1 <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) AS YearlyContributionSum FROM ContributionsTbl WHERE Year(Month_Of_Payment) = '" & currentYear & "' And Month(Month_Of_Payment) = '" & currentDatea & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)

                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalContributions = 0
                Else
                    totalContributions = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try

        ElseIf (checknul1 = 0) Then
            totalContributions = 0
        End If

        '' Get the total claims amount check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl WHERE Year(Claim_Date) = '" & currentYear & "' And Month(Claim_Date) = '" & currentDatea & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknull2 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        If (checknull2 <> 0) Then
            'Total Amount Claimed
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount_Given) AS YearlyContributionSum FROM ClaimsTbl WHERE Year(Claim_Date) = '" & currentYear & "' And Month(Claim_Date) = '" & currentDatea & "'"
                cmd = New SqlCommand(queryYearly, Con)
                '   Dim toTotal = cmd.ExecuteScalar
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalMoneyGivenOut = 0
                Else
                    totalMoneyGivenOut = toTotal
                End If
            Catch ex As Exception
                '   MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
        ElseIf (checknull2 = 0) Then
            totalMoneyGivenOut = 0
        End If

        Try

            txtTotalClaims.Text = "Ghc " + totalMoneyGivenOut.ToString
            txtTotalMembers.Text = totalMembers.ToString
            txtTotalContributions.Text = "Ghc " + totalContributions.ToString
            txtTotalWithdrawal.Text = "Ghc " + totalWithdrawal.ToString
            txtAccountBalance.Text = "Ghc " + (SumOfAllDeposits - SumOfAllWithdrawals).ToString

            txtYear.Visible = True
            txtYear2.Visible = True

        Catch ex As Exception

        End Try



        ' Me.Chart2.DataBind()
        Try
            Dim dataTable As New DataTable()
            dataTable.Columns.Add("Description", GetType(String))
            dataTable.Columns.Add("Amount", GetType(Integer))

            dataTable.Rows.Add("Contributions", totalContributions)
            dataTable.Rows.Add("All Deposits", totalDeposits)
            dataTable.Rows.Add("Withdrawals", totalWithdrawal)
            dataTable.Rows.Add("Account Balance", (SumOfAllDeposits - SumOfAllWithdrawals))
            dataTable.Rows.Add("Claims", totalMoneyGivenOut)


            Me.Chart1.DataSource = dataTable

            Chart1.Series("Series1").XValueMember = "Description"
            Chart1.Series("Series1").YValueMembers = "Amount"
            Me.Chart1.DataBind()
        Catch ex As Exception

        End Try

        'Doughnut Chart
        Try

            Dim dataTable2 As New DataTable()

            dataTable2.Columns.Add("Description", GetType(String))
            dataTable2.Columns.Add("Value", GetType(Integer))

            dataTable2.Rows.Add("No. Of Claims", totalClaims)
            dataTable2.Rows.Add("Members", totalMembers)
            ' dataTable2.Rows.Add("Contributions", totalContributions)
            'dataTable2.Rows.Add("Withdrawals", totalWithdrawal)
            'dataTable2.Rows.Add("Account Balance", (totalDeposits - totalWithdrawal))
            'dataTable2.Rows.Add("Claims", totalMoneyGivenOut)

            Me.Chart2.DataSource = dataTable2

            Chart2.Series("Series1").XValueMember = "Description"
            Chart2.Series("Series1").YValueMembers = "Value"
            Me.Chart2.DataBind()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub btnCustom_Click(sender As Object, e As EventArgs) Handles btnCustom.Click
        ActivationButton(sender, Color.White)
        btnCheck.Visible = True
        newChartValues()
    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        ActivationButton(sender, Color.White)
        btnCheck.Visible = False

        Try
            SumAllWithdrawal()
        Catch ex As Exception

        End Try
        Try
            SumAllDeposits()
        Catch ex As Exception

        End Try


        Try
            SumOfDepositsAndWithdrawals()
        Catch ex As Exception

        End Try

        Dim checknul1 As Integer = 0, checknull2 As Integer = 0
        '' Get the total contribtions check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknul1 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Contributions
        If (checknul1 <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) AS YearlyContributionSum FROM ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalContributions = 0
                Else
                    totalContributions = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        End If

        '' Get the total claims amount check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknull2 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        If (checknull2 <> 0) Then
            'Total Amount Claimed
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount_Given) AS YearlyContributionSum FROM ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                '   Dim toTotal = cmd.ExecuteScalar
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalMoneyGivenOut = 0
                Else
                    totalMoneyGivenOut = toTotal
                End If
            Catch ex As Exception
                '   MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
        End If

        '' Get the total members 
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from MembersTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            totalMembers = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            totalClaims = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try



        Try
            txtTotalClaims.Text = "Ghc " + totalMoneyGivenOut.ToString
            '  txtTotalMembers.Text = totalMembers.ToString
            txtTotalContributions.Text = "Ghc " + totalContributions.ToString
            txtTotalWithdrawal.Text = "Ghc " + totalWithdrawal.ToString
            txtAccountBalance.Text = "Ghc " + (SumOfAllDeposits - SumOfAllWithdrawals).ToString

            txtYear.Text = currentYear
            txtYear2.Text = currentYear
            txtYear.Visible = True
            txtYear2.Visible = True
        Catch ex As Exception

        End Try


        Try
            Dim dataTable As New DataTable()
            dataTable.Columns.Add("Description", GetType(String))
            dataTable.Columns.Add("Amount", GetType(Integer))

            dataTable.Rows.Add("Contributions", totalContributions)
            dataTable.Rows.Add("All Deposits", totalDeposits)
            dataTable.Rows.Add("Withdrawals", totalWithdrawal)
            dataTable.Rows.Add("Account Balance", (SumOfAllDeposits - SumOfAllWithdrawals))
            dataTable.Rows.Add("Claims", totalMoneyGivenOut)


            Me.Chart1.DataSource = dataTable

            Chart1.Series("Series1").XValueMember = "Description"
            Chart1.Series("Series1").YValueMembers = "Amount"
            Me.Chart1.DataBind()
        Catch ex As Exception

        End Try


        Try
            'Doughnut Chart
            Dim dataTable2 As New DataTable()

            dataTable2.Columns.Add("Description", GetType(String))
            dataTable2.Columns.Add("Value", GetType(Integer))

            dataTable2.Rows.Add("No. Of Claims", totalClaims)
            dataTable2.Rows.Add("Members", totalMembers)
            ' dataTable2.Rows.Add("Contributions", totalContributions)
            'dataTable2.Rows.Add("Withdrawals", totalWithdrawal)
            'dataTable2.Rows.Add("Account Balance", (totalDeposits - totalWithdrawal))
            'dataTable2.Rows.Add("Claims", totalMoneyGivenOut)

            Me.Chart2.DataSource = dataTable2

            Chart2.Series("Series1").XValueMember = "Description"
            Chart2.Series("Series1").YValueMembers = "Value"
            Me.Chart2.DataBind()
        Catch ex As Exception

        End Try

    End Sub
End Class