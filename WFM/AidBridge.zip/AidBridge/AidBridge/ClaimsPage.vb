﻿Imports System.Data.SqlClient
Imports System.Net
Imports System.IO
Imports System.Drawing.Imaging

Public Class ClaimsPage
    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select * from ClaimsTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Member_Name  like '%' +@parm1+ '%' "
            query &= " or Member_ID like '%' +@parm1+ '%' "
            query &= " or Amount_Given like '%' +@parm1+ '%' "
            query &= " or Reason like '%' +@parm1+ '%' "
            query &= " or Claimer like '%' +@parm1+ '%' "
            query &= " or Beneficiary_Name like '%' +@parm1+ '%' "
            query &= " or Claim_Date like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using
            '  End Using
        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function
    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select * from ClaimsTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ClaimsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try


    End Sub

    Private Function SearchItemApproval() As DataTable
        Try
            Dim query As String = "select Id,Member_Name,Member_ID,Amount,Reason,Claimer,Beneficiary_Name,Request_Date,Operator from ApprovalTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Member_Name  like '%' +@parm1+ '%' "
            query &= " or Member_ID like '%' +@parm1+ '%' "
            query &= " or Amount like '%' +@parm1+ '%' "
            query &= " or Reason like '%' +@parm1+ '%' "
            query &= " or Claimer like '%' +@parm1+ '%' "
            'query &= " or Approval_Status NOT like '%' +@parm1+ '%' "
            ' query &= " or Not Approval_Status ='Pending...' "
            query &= " or Beneficiary_Name like '%' +@parm1+ '%' "
            query &= " or Request_Date like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchApproval.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using
            '  End Using

            '  End Using
            Dim cancelButtonColumn As New DataGridViewButtonColumn()
            cancelButtonColumn.HeaderText = ""
            cancelButtonColumn.Text = "Cancel"
            cancelButtonColumn.Name = "cancelBtn"
            cancelButtonColumn.UseColumnTextForButtonValue = True

            Dim approveButtonColumn As New DataGridViewButtonColumn()
            approveButtonColumn.HeaderText = ""
            approveButtonColumn.Text = "Approve"
            approveButtonColumn.Name = "ApproveBtn"
            approveButtonColumn.UseColumnTextForButtonValue = True

            approvalsDataGridView.Columns.Add(cancelButtonColumn)
            approvalsDataGridView.Columns.Add(approveButtonColumn)

        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function
    Private Sub PopulateApproval()
        Try
            Con.Open()
            Dim query = "select Id,Member_Name,Member_ID,Amount,Reason,Claimer,Beneficiary_Name,Request_Date,Operator from ApprovalTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            approvalsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        '  End Using
        Dim cancelButtonColumn As New DataGridViewButtonColumn()
        cancelButtonColumn.HeaderText = ""
        cancelButtonColumn.Text = "Cancel"
        cancelButtonColumn.Name = "cancelBtn"
        cancelButtonColumn.UseColumnTextForButtonValue = True

        Dim approveButtonColumn As New DataGridViewButtonColumn()
        approveButtonColumn.HeaderText = ""
        approveButtonColumn.Text = "Approve"
        approveButtonColumn.Name = "ApproveBtn"
        approveButtonColumn.UseColumnTextForButtonValue = True

        approvalsDataGridView.Columns.Add(cancelButtonColumn)
        approvalsDataGridView.Columns.Add(approveButtonColumn)

    End Sub

    Private Sub PopulateApprovalAfAction()
        Try
            Con.Open()
            Dim query = "select Id,Member_Name,Member_ID,Amount,Reason,Claimer,Beneficiary_Name,Request_Date,Operator from ApprovalTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            approvalsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try



    End Sub
    Private Sub PopulateApprovalNull()
        Try
            Con.Open()
            Dim query = "select Id,Member_Name,Member_ID,Amount,Reason,Claimer,Beneficiary_Name,Request_Date from ApprovalTbl Where Not Approval_Status = 'Pending...'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            approvalsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub ClaimPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
        PopulateApproval()
        AcceptButton = QueryBtn
    End Sub
    Dim aa4 As Integer = 0, numberOFContribution As Integer = 0
    Private Sub IconButton3_Click(sender As Object, e As EventArgs) Handles ClaimStatusBtn.Click
        ' ClaimStatus.Hide()
        ShowProfilePage.Hide()
        Dim getCurrentDate = New DateTimePicker
        Dim currentDate = getCurrentDate.Value
        'Check if member has already made payment for the payment date selected
        Dim getMonth = getCurrentDate.Value.Month
            Dim getYear As Integer = getCurrentDate.Value.Year
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "SELECT DATEDIFF(MONTH, MAX(Month_Of_Payment), GETDATE()) AS MonthsSinceLastPayment FROM ContributionsTbl WHERE Member_ID = '" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query22, Con)
            monthsSinceLastPayment = Convert.ToInt32(cmd.ExecuteScalar())

        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
        '' Get the total claims by the user
        ' MsgBox(monthsSinceLastPayment)
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl where Member_ID='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            memberTotalClaim = ds.Tables(0).Rows.Count

        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        '' Get number Of Contributions
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl where Member_ID='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            numberOFContribution = ds.Tables(0).Rows.Count
        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try



        If (monthsSinceLastPayment > 2 Or numberOFContribution < 6) Then
            ClaimStatus.txtQualification.Text = "Not Qualified"
            ClaimStatus.txtQualification.IconChar = FontAwesome.Sharp.IconChar.Times
            ClaimStatus.txtQualification.BackColor = Color.Red
            ClaimStatus.txtQualification.ForeColor = Color.White
            ClaimStatus.txtQualification.FlatAppearance.MouseDownBackColor = Color.Red
            ClaimStatus.txtQualification.FlatAppearance.MouseOverBackColor = Color.Red
            ClaimStatus.btnProceed.Visible = False


            Try
                ClaimStatus.txtFullName.Text = memberUserSurname.ToUpper
                ClaimStatus.txtPhone.Text = memberUserPhone
                ClaimStatus.txtMemberId.Text = memberUserStaffID.ToUpper
                ClaimStatus.txtSex.Text = memberUserSex
                ClaimStatus.txtDoB.Text = memberUserDoB
                ClaimStatus.txtTotalClaims.Text = memberTotalClaim

                If (monthsSinceLastPayment > 0) Then
                    ClaimStatus.txtArreass.Text = "-" + monthsSinceLastPayment.ToString
                ElseIf (monthsSinceLastPayment < 0) Then
                    ClaimStatus.txtArreass.Text = (-1 * Convert.ToInt32(monthsSinceLastPayment)).ToString
                ElseIf (monthsSinceLastPayment = 0) Then
                    ClaimStatus.txtArreass.Text = "0"
                End If
                ClaimStatus.numOfContributions.Text = numberOFContribution
                ClaimStatus.monthAreasLabel.Visible = True
                ClaimStatus.txtArreass.Visible = True

                ' Convert the byte array to an image
                Using ms As New MemoryStream(profilePicture)
                    ClaimStatus.MemberProfile.Image = Image.FromStream(ms)

                    'ImageLocation = proFPic
                End Using
                ClaimStatus.Show()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try


        Else
            ClaimStatus.txtQualification.Text = "Qualified"
            ClaimStatus.txtQualification.IconChar = FontAwesome.Sharp.IconChar.Check
            ClaimStatus.txtQualification.BackColor = Color.SeaGreen
            ClaimStatus.txtQualification.ForeColor = Color.White
            ClaimStatus.txtQualification.FlatAppearance.MouseDownBackColor = Color.SeaGreen
            ClaimStatus.txtQualification.FlatAppearance.MouseOverBackColor = Color.SeaGreen
            ClaimStatus.btnProceed.Visible = False


            Try
                ClaimStatus.txtFullName.Text = memberUserSurname.ToUpper
                ClaimStatus.txtPhone.Text = memberUserPhone
                ClaimStatus.txtMemberId.Text = memberUserStaffID.ToUpper
                ClaimStatus.txtSex.Text = memberUserSex
                ClaimStatus.txtDoB.Text = memberUserDoB
                ClaimStatus.txtTotalClaims.Text = memberTotalClaim

                If (monthsSinceLastPayment > 0) Then
                    ClaimStatus.txtArreass.Text = "-" + monthsSinceLastPayment.ToString
                ElseIf (monthsSinceLastPayment < 0) Then
                    ClaimStatus.txtArreass.Text = (-1 * Convert.ToInt32(monthsSinceLastPayment)).ToString
                End If

                ' ClaimStatus.txtArreass.Text = monthsSinceLastPayment
                ClaimStatus.numOfContributions.Text = numberOFContribution

                ' Convert the byte array to an image
                Using ms As New MemoryStream(profilePicture)
                    ClaimStatus.MemberProfile.Image = Image.FromStream(ms)
                End Using
                ClaimStatus.Show()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If


    End Sub
    ''Function to show member' Details  on Profile Page
    Private Function MemberDetails(theMemberID)
        Try
            Con.Open()
            Dim query = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Marriage_Type,Hometown,Birth_Date,Registration_Date,Operator from MembersTbl where Staff_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.personalInfoDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

            Con.Close()
        End Try
    End Function
    ''Function to show member children on Profile Page
    Private Function ChildrenByMember(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ChildrenTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.childrenDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    ''Function to show member Parents on Profile Page
    Private Function MemberParents(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ParentsTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.parentsDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    ''Function to show member Spouse on Profile Page
    Private Function MemberSpouse(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from SpouseTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.spouseDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    ''Function to show member Beneficiaries on Profile Page
    Private Function MemberBeneficiaries(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function
    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles showProfileBtn.Click
        'Dim nwShowProfilePage = New ShowProfilePage
        ClaimStatus.Hide()
        ' Convert the byte array to an image
        Using ms As New MemoryStream(profilePicture)
            ShowProfilePage.MemberProfile.Image = Image.FromStream(ms)
        End Using


        MemberDetails(memberUserStaffID)
        MemberParents(memberUserStaffID)
        ChildrenByMember(memberUserStaffID)
        MemberSpouse(memberUserStaffID)
        MemberBeneficiaries(memberUserStaffID)

        ShowProfilePage.Show()
    End Sub

    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        ClaimsDataGridView.DataSource = Me.SearchItem
    End Sub
    Dim aa2 As Integer
    Private Function ClaimsByMember(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ClaimsTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            MemberClaimsDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Function

    Private Function ClaimsByMemberPhone(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ClaimsTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            MemberClaimsDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Function
    Dim MemberSurnamePrivate

    Private Sub QueryBtn_Click(sender As Object, e As EventArgs) Handles QueryBtn.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
        If (searchBox.Text = "") Then

            InformationTab.Visible = False
            ClaimsTab.Visible = False
            showProfileBtn.Visible = False
            ClaimStatusBtn.Visible = False

            MessageBox.Show("Enter the member's ID", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

        ElseIf (selectIDType.Text = "") Then

            InformationTab.Visible = False
            ClaimsTab.Visible = False
            showProfileBtn.Visible = False
            ClaimStatusBtn.Visible = False

            MessageBox.Show("Select the ID Type", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

        ElseIf (selectIDType.Text = "Staff ID") Then
            '
            '
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from MembersTbl where Staff_ID ='" & searchBox.Text & "' "
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count

                ' If aa2 <> "" Then
                ' memberUserPicture = Application.StartupPath & "\Profile pictures\" & dt.Rows(0).Item("Picture")
                'End If

            Catch ex As Exception
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
            '
            '
            'When member exist
            If ((aa2 = 0) = False) Then
                memberUserSurname = ""
                memberUserOthername = ""
                MemberSurnamePrivate = ""
                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Staff_ID='" & searchBox.Text & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUserStaffID = myReader("Staff_ID")
                    MemberSurnamePrivate = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")
                    profilePicture = CType(myReader("Picture"), Byte())

                    memberUserSurname = MemberSurnamePrivate + " " + memberUserOthername

                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                Try
                    txtSurname.Text = MemberSurnamePrivate.ToUpper
                    txtMemberOtherName.Text = memberUserOthername.ToUpper
                    txtBirthDate.Text = memberUserDoB
                    txtSex.Text = memberUserSex
                    txtHomeTown.Text = memberUserHomeTown.ToUpper
                    txtMaritalStatus.Text = memberUserMaritalStatus
                    txtMarriageType.Text = memberUserTypeOfMarriage
                    txtHouseNo.Text = memberUserHouseNo.ToUpper
                    txtPostalAddress.Text = memberUserPostalAddress.ToUpper
                    txtPhone.Text = memberUserPhone
                    txtStaffID.Text = memberUserStaffID.ToUpper

                    memberNotFoundFeedback.Visible = False

                    ClaimsByMember(txtStaffID.Text)

                    InformationTab.Visible = True
                    ClaimsTab.Visible = True
                    showProfileBtn.Visible = True
                    ClaimStatusBtn.Visible = True


                Catch ex As Exception

                End Try

            Else
                'When member doesn't exist
                InformationTab.Visible = False
                ClaimsTab.Visible = False
                showProfileBtn.Visible = False
                ClaimStatusBtn.Visible = False

                memberNotFoundFeedback.Visible = True
                Timer1.Start()
            End If

        ElseIf (selectIDType.Text = "Phone") Then
            '
            'Check if member with Phone number entered exist
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from MembersTbl where Phone ='" & searchBox.Text & "' "
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count

            Catch ex As Exception
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try

            'When member exist
            If ((aa2 = 0) = False) Then
                memberUserSurname = ""
                memberUserOthername = ""
                MemberSurnamePrivate = ""
                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Phone='" & searchBox.Text & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUserStaffID = myReader("Staff_ID")
                    MemberSurnamePrivate = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")
                    profilePicture = CType(myReader("Picture"), Byte())

                    memberUserSurname = MemberSurnamePrivate + " " + memberUserOthername

                    '     memberUserPicture = myReader("Picture")
                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                Try
                    txtSurname.Text = MemberSurnamePrivate.ToUpper
                    txtMemberOtherName.Text = memberUserOthername.ToUpper
                    txtBirthDate.Text = memberUserDoB
                    txtSex.Text = memberUserSex
                    txtHomeTown.Text = memberUserHomeTown.ToUpper
                    txtMaritalStatus.Text = memberUserMaritalStatus
                    txtMarriageType.Text = memberUserTypeOfMarriage
                    txtHouseNo.Text = memberUserHouseNo.ToUpper
                    txtPostalAddress.Text = memberUserPostalAddress.ToUpper
                    txtPhone.Text = memberUserPhone
                    txtStaffID.Text = memberUserStaffID.ToUpper

                    memberNotFoundFeedback.Visible = False

                    ClaimsByMember(txtStaffID.Text)

                    InformationTab.Visible = True
                    ClaimsTab.Visible = True
                    showProfileBtn.Visible = True
                    ClaimStatusBtn.Visible = True
                Catch ex As Exception

                End Try
            Else
                ''Member doesn't exist message
                InformationTab.Visible = False
                ClaimsTab.Visible = False
                showProfileBtn.Visible = False
                ClaimStatusBtn.Visible = False

                memberNotFoundFeedback.Visible = True
                Timer1.Start()
                ''member with Phone number exist End If
            End If


            'Main If
        End If

    End Sub

    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click
        memberNotFoundFeedback.Visible = False
    End Sub

    Private Sub selectIDType_KeyUp(sender As Object, e As KeyEventArgs) Handles selectIDType.KeyUp
        selectIDType.Text = ""
    End Sub
    Dim counterr As Integer = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        counterr = counterr + 1
        If (counterr = 3) Then
            memberNotFoundFeedback.Visible = False
            counterr = 0
            Timer1.Stop()
        End If
    End Sub

    Private Sub TabControl1_Click(sender As Object, e As EventArgs) Handles TabControl1.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub TabPage2_Click(sender As Object, e As EventArgs) Handles TabPage2.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub InformationTab_MouseHover(sender As Object, e As EventArgs) Handles InformationTab.MouseHover
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub ClaimsTab_MouseHover(sender As Object, e As EventArgs) Handles ClaimsTab.MouseHover
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub MemberClaimsDataGridView_MouseHover(sender As Object, e As EventArgs) Handles MemberClaimsDataGridView.MouseHover
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub searchBox_Click(sender As Object, e As EventArgs) Handles searchBox.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub
    Private Sub txtSearchApproval_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchApproval.KeyUp
        '  If (txtSearchApproval.Text = "") Then
        ' PopulateApprovalNull()
        'Else
        approvalsDataGridView.DataSource = Me.SearchItemApproval
        'End If

    End Sub
    'Private sub to insert to ClaimsTbl if claim is successfull
    Private Sub InsertIntoClaimsTbl(Id, Name, Amount, Reason, Claimer, Beneficiary)
        Dim theDate = New MonthCalendar
        Dim ClaimDate = theDate.TodayDate
        Try
            Con.Open()
            Dim query3 As String
            query3 = "insert into ApprovalTbl values('" & Id & "','" & Name & "','" & Amount & "','" & Reason & "','" & Claimer & "','" & Beneficiary & "','" & ClaimDate & "','" & setAdminName & "','" & AStaffID & "','Pending...','')"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()
            '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    Private Sub UpdateApprovalStatusCancelled(memberID)
        Dim getDat = New DateTimePicker
        Dim theDated = getDat.Value
        Try
            Con.Open()
            Dim query = "update ApprovalStatusTbl set Approval_Status = 'Cancelled',Approval_Date ='" & theDated & "' where Member_ID = '" & memberID & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim query = "delete from ApprovalTbl where Member_ID = '" & memberID & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            MsgBox("Claim request cancelled")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    Private Sub UpdateApprovalStatusApproved(memberID)
        Dim getDat = New DateTimePicker
        Dim theDated = getDat.Value
        Try
            Con.Open()
            Dim query = "update ApprovalStatusTbl set Approval_Status = 'Approved',Approval_Date ='" & theDated & "' where Member_ID = '" & memberID & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim query = "delete from ApprovalTbl where Member_ID = '" & memberID & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            MsgBox("Claim request approved")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    Private Sub TheNoOfApproval()
        'The number requested Claims
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ApprovalTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            theNumberOfApprovals = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
        Form1.txtNoApprovals.Text = theNumberOfApprovals
        If (Convert.ToInt32(theNumberOfApprovals) = 0) Then
            Form1.txtNoApprovals.Visible = False
            TabPage3.Text = "Approvals"
        Else
            Form1.txtNoApprovals.Visible = True
            TabPage3.Text = "Approvals" + " " + Form1.txtNoApprovals.Text
        End If
    End Sub
    Dim ClaimReaso As String, AmountGiven As String, membContact
    Private Sub sendClaimApprovalSMS(memberName, memberStaffID, ClaimReason, amountt, recipient)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). Good news! Your claim request for your '" & ClaimReason & "' has been approved.You are entitled to an amount of Ghc" & amountt & ". Please see the treasurer at your earliest convenience. Thank You!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()


        Try
            Dim response As String = client.DownloadString(baseURL)
            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)
            ' MsgBox(getTheResponse & getTheResponse2)

            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. Alert not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse2 = "Successfully Sent") Then
                MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                ' MsgBox("Alert not sent! Check if the number is correct", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            End If

        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                resendClaimApprovalSMS(theMemberNam, getStaffIDToEdit, ClaimReaso, AmountGiven, membContact)
            End If
        Finally
            Cursor = Cursors.Default
        End Try

    End Sub
    Private Sub resendClaimApprovalSMS(memberName, memberStaffID, ClaimReason, amountt, recipient)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). Good news! Your claim request for your '" & ClaimReason & "' has been approved.You are entitled to an amount of Ghc" & amountt & ". Please see the treasurer at your earliest convenience. Thank You!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()


        Try
            Dim response As String = client.DownloadString(baseURL)
            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)
            '  MsgBox(getTheResponse & getTheResponse2)

            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. Alert not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse2 = "Successfully Sent") Then
                MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                ' MsgBox("Alert not sent! Check if the number is correct", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            End If

        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                sendClaimApprovalSMS(theMemberNam, getStaffIDToEdit, ClaimReaso, AmountGiven, membContact)
            End If
        Finally
            Cursor = Cursors.Default
        End Try

    End Sub

    Private Sub sendClaimCancelledSMS(memberName, memberStaffID, ClaimReason, amountt, recipient)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). We are sorry to inform you that your claim request for your '" & ClaimReason & "' has been cancelled. Please see the treasurer for further explanation and assistance. Thank You!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()


        Try
            Dim response As String = client.DownloadString(baseURL)
            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)
            ' MsgBox(getTheResponse & getTheResponse2)

            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. Alert not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse2 = "Successfully Sent") Then
                MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                ' MsgBox("Alert not sent! Check if the number is correct", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            End If

        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                resendClaimCancelledSMS(theMemberNam, getStaffIDToEdit, ClaimReaso, AmountGiven, membContact)
            End If
        Finally
            Cursor = Cursors.Default
        End Try

    End Sub
    Private Sub resendClaimCancelledSMS(memberName, memberStaffID, ClaimReason, amountt, recipient)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). We are sorry to inform you that your claim request for your '" & ClaimReason & "' has been cancelled. Please see the treasurer for further explanation and assistance. Thank You!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()


        Try
            Dim response As String = client.DownloadString(baseURL)
            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)
            '  MsgBox(getTheResponse & getTheResponse2)

            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. Alert not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse2 = "Successfully Sent") Then
                MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                ' MsgBox("Alert not sent! Check if the number is correct", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            End If

        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                sendClaimCancelledSMS(theMemberNam, getStaffIDToEdit, ClaimReaso, AmountGiven, membContact)
            End If
        Finally
            Cursor = Cursors.Default
        End Try

    End Sub

    Private Sub getMemberPhone(memberID)
        Try
            Con.Open()

            ' Query to select the latest payment month for a specific member ID and reason
            Dim query As String = "SELECT * FROM MembersTbl WHERE Staff_ID = @Member_ID"

            ' Create a command object with a parameterized query
            cmd = New SqlCommand(query, Con)
            cmd.Parameters.AddWithValue("@Member_ID", memberID)

            ' Execute the reader
            myReader = cmd.ExecuteReader()
            ' Check if the reader has any rows
            If myReader.HasRows Then
                ' Read the data
                myReader.Read()
                ' Safely assign the date
                If Not IsDBNull(myReader("Phone")) Then
                    membContact = myReader("Phone")
                Else
                    ' Handle the case where the date is null
                    membContact = Nothing
                End If

            End If


        Catch ex As SqlException
            MsgBox("An error occurred: " & ex.Message)
        Finally
            ' Ensure the connection is closed
            If Con.State = ConnectionState.Open Then
                Con.Close()
            End If
        End Try
    End Sub
    Private Sub approvalsDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles approvalsDataGridView.CellContentClick
        Try
            If e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("cancelBtn").Index Then
                Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)

                theMemberNam = row.Cells(3).Value.ToString
                getStaffIDToEdit = row.Cells(4).Value.ToString
                ClaimReaso = row.Cells(6).Value.ToString
                AmountGiven = row.Cells(5).Value.ToString
                getMemberPhone(getStaffIDToEdit)
                '  membContact = row.Cells(7).Value.ToString
                ' MsgBox(ClaimReaso + "  Amount " + AmountGiven + " Contact " + membContact)

                Dim cancelDialog As DialogResult = MessageBox.Show("Cancel '" + theMemberNam + "' Claim Request", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                Try
                    If (cancelDialog = DialogResult.Yes) Then
                        UpdateApprovalStatusCancelled(getStaffIDToEdit)
                        TheNoOfApproval()
                        PopulateApprovalAfAction()
                        sendClaimCancelledSMS(theMemberNam, getStaffIDToEdit, ClaimReaso, AmountGiven, membContact)
                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
                'Dim ClaimReaso As String, Amount As String, membContact
            ElseIf e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("ApproveBtn").Index Then
                Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)

                theMemberNam = row.Cells(3).Value.ToString
                getStaffIDToEdit = row.Cells(4).Value.ToString
                ClaimReaso = row.Cells(6).Value.ToString
                AmountGiven = row.Cells(5).Value.ToString
                getMemberPhone(getStaffIDToEdit)

                ' MsgBox(theMemberNam + "  " + ClaimReaso + "  Amount" + AmountGiven + " Contact" + membContact)

                Dim approveDialog As DialogResult = MessageBox.Show("Approve '" + theMemberNam + "' Claim Request", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                Try
                    If (approveDialog = DialogResult.Yes) Then
                        UpdateApprovalStatusApproved(getStaffIDToEdit)
                        TheNoOfApproval()
                        PopulateApprovalAfAction()
                        sendClaimApprovalSMS(theMemberNam, getStaffIDToEdit, ClaimReaso, AmountGiven, membContact)
                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub selectIDType_Click(sender As Object, e As EventArgs) Handles selectIDType.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub
End Class