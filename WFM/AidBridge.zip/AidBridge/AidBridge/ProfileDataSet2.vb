﻿Partial Class ProfileDataSet2
    Partial Public Class ProfileTblDataTable

    End Class
End Class


