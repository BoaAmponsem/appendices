﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AddNewChild
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.txtChildID = New System.Windows.Forms.TextBox()
        Me.IconButton8 = New FontAwesome.Sharp.IconButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.childrenDataGridView = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.addBtn = New FontAwesome.Sharp.IconButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtChild1DoBA = New System.Windows.Forms.MaskedTextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtChild1Name = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.GroupBox4.SuspendLayout()
        CType(Me.childrenDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton1.BackColor = System.Drawing.Color.DarkGreen
        Me.IconButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton1.ForeColor = System.Drawing.Color.White
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton1.IconColor = System.Drawing.Color.White
        Me.IconButton1.IconSize = 16
        Me.IconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton1.Location = New System.Drawing.Point(226, 116)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(87, 26)
        Me.IconButton1.TabIndex = 35
        Me.IconButton1.Text = "Refresh"
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'txtChildID
        '
        Me.txtChildID.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtChildID.Location = New System.Drawing.Point(526, 118)
        Me.txtChildID.Name = "txtChildID"
        Me.txtChildID.Size = New System.Drawing.Size(100, 20)
        Me.txtChildID.TabIndex = 34
        Me.txtChildID.Visible = False
        '
        'IconButton8
        '
        Me.IconButton8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton8.BackColor = System.Drawing.Color.SaddleBrown
        Me.IconButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton8.FlatAppearance.BorderSize = 0
        Me.IconButton8.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton8.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton8.ForeColor = System.Drawing.Color.White
        Me.IconButton8.IconChar = FontAwesome.Sharp.IconChar.Upload
        Me.IconButton8.IconColor = System.Drawing.Color.White
        Me.IconButton8.IconSize = 16
        Me.IconButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton8.Location = New System.Drawing.Point(138, 115)
        Me.IconButton8.Name = "IconButton8"
        Me.IconButton8.Rotation = 0R
        Me.IconButton8.Size = New System.Drawing.Size(82, 27)
        Me.IconButton8.TabIndex = 33
        Me.IconButton8.Text = "Update"
        Me.IconButton8.UseVisualStyleBackColor = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.BackColor = System.Drawing.Color.White
        Me.GroupBox4.Controls.Add(Me.childrenDataGridView)
        Me.GroupBox4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(21, 157)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(507, 170)
        Me.GroupBox4.TabIndex = 32
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "CHILDREN"
        '
        'childrenDataGridView
        '
        Me.childrenDataGridView.AllowUserToAddRows = False
        Me.childrenDataGridView.AllowUserToDeleteRows = False
        Me.childrenDataGridView.AllowUserToResizeRows = False
        Me.childrenDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.childrenDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.childrenDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.childrenDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.childrenDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.childrenDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.childrenDataGridView.DefaultCellStyle = DataGridViewCellStyle1
        Me.childrenDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.childrenDataGridView.Location = New System.Drawing.Point(3, 17)
        Me.childrenDataGridView.Name = "childrenDataGridView"
        Me.childrenDataGridView.ReadOnly = True
        Me.childrenDataGridView.RowHeadersVisible = False
        Me.childrenDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.childrenDataGridView.Size = New System.Drawing.Size(501, 150)
        Me.childrenDataGridView.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(516, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(15, 14)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "X"
        '
        'addBtn
        '
        Me.addBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.addBtn.BackColor = System.Drawing.Color.SeaGreen
        Me.addBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.addBtn.FlatAppearance.BorderSize = 0
        Me.addBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.addBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addBtn.ForeColor = System.Drawing.Color.White
        Me.addBtn.IconChar = FontAwesome.Sharp.IconChar.PlusCircle
        Me.addBtn.IconColor = System.Drawing.Color.White
        Me.addBtn.IconSize = 16
        Me.addBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.addBtn.Location = New System.Drawing.Point(319, 116)
        Me.addBtn.Name = "addBtn"
        Me.addBtn.Rotation = 0R
        Me.addBtn.Size = New System.Drawing.Size(87, 26)
        Me.addBtn.TabIndex = 30
        Me.addBtn.Text = "Add"
        Me.addBtn.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.txtChild1DoBA)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.txtChild1Name)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(20, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(510, 76)
        Me.GroupBox1.TabIndex = 29
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "EDIT/ADD CHILD"
        '
        'txtChild1DoBA
        '
        Me.txtChild1DoBA.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild1DoBA.Location = New System.Drawing.Point(325, 40)
        Me.txtChild1DoBA.Name = "txtChild1DoBA"
        Me.txtChild1DoBA.Size = New System.Drawing.Size(127, 21)
        Me.txtChild1DoBA.TabIndex = 32
        '
        'Label18
        '
        Me.Label18.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(324, 23)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(102, 15)
        Me.Label18.TabIndex = 31
        Me.Label18.Text = "DoB(mm/dd/yyyy)"
        '
        'txtChild1Name
        '
        Me.txtChild1Name.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild1Name.Location = New System.Drawing.Point(35, 39)
        Me.txtChild1Name.Multiline = True
        Me.txtChild1Name.Name = "txtChild1Name"
        Me.txtChild1Name.Size = New System.Drawing.Size(248, 22)
        Me.txtChild1Name.TabIndex = 30
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(36, 22)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 15)
        Me.Label17.TabIndex = 29
        Me.Label17.Text = "Name:"
        '
        'AddNewChild
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(549, 345)
        Me.Controls.Add(Me.IconButton1)
        Me.Controls.Add(Me.txtChildID)
        Me.Controls.Add(Me.IconButton8)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.addBtn)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "AddNewChild"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AddNewChild"
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.childrenDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtChildID As TextBox
    Friend WithEvents IconButton8 As FontAwesome.Sharp.IconButton
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents childrenDataGridView As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents addBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtChild1DoBA As MaskedTextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents txtChild1Name As TextBox
    Friend WithEvents Label17 As Label
End Class
