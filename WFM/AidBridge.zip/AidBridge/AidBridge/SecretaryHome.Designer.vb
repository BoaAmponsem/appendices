﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SecretaryHome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim ChartArea3 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend3 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series3 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea4 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend4 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series4 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.Chart2 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.txtYear2 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.txtTotalClaims = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dashBoardBtnClaims = New FontAwesome.Sharp.IconButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtTotalMembers = New System.Windows.Forms.Label()
        Me.txtYear = New System.Windows.Forms.Label()
        Me.dashBoardBtnMembers = New FontAwesome.Sharp.IconButton()
        Me.txtTotalContributions = New System.Windows.Forms.Label()
        Me.btnUserDashboardContributions = New FontAwesome.Sharp.IconButton()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Chart2
        '
        Me.Chart2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        ChartArea3.Name = "ChartArea1"
        Me.Chart2.ChartAreas.Add(ChartArea3)
        Legend3.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top
        Legend3.Name = "Legend1"
        Legend3.Title = "TURNOUTS"
        Legend3.TitleAlignment = System.Drawing.StringAlignment.Near
        Legend3.TitleFont = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend3.TitleForeColor = System.Drawing.Color.DarkGreen
        Me.Chart2.Legends.Add(Legend3)
        Me.Chart2.Location = New System.Drawing.Point(670, 238)
        Me.Chart2.Name = "Chart2"
        Me.Chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Series3.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom
        Series3.BackSecondaryColor = System.Drawing.Color.DarkGreen
        Series3.BorderColor = System.Drawing.Color.White
        Series3.BorderWidth = 10
        Series3.ChartArea = "ChartArea1"
        Series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut
        Series3.Color = System.Drawing.Color.Transparent
        Series3.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Series3.IsValueShownAsLabel = True
        Series3.LabelForeColor = System.Drawing.Color.White
        Series3.Legend = "Legend1"
        Series3.Name = "Series1"
        Series3.ShadowColor = System.Drawing.Color.White
        Me.Chart2.Series.Add(Series3)
        Me.Chart2.Size = New System.Drawing.Size(312, 287)
        Me.Chart2.TabIndex = 71
        Me.Chart2.Text = "Chart2"
        '
        'Chart1
        '
        Me.Chart1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        ChartArea4.AxisX.IsLabelAutoFit = False
        ChartArea4.AxisX.IsMarginVisible = False
        ChartArea4.AxisX.LabelStyle.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ChartArea4.AxisX.LabelStyle.ForeColor = System.Drawing.Color.DarkSlateGray
        ChartArea4.AxisX.LineColor = System.Drawing.Color.Maroon
        ChartArea4.AxisX.LineWidth = 0
        ChartArea4.AxisX.MajorGrid.LineColor = System.Drawing.Color.White
        ChartArea4.AxisX.MajorGrid.LineWidth = 0
        ChartArea4.AxisX.MajorTickMark.LineColor = System.Drawing.Color.DarkSlateGray
        ChartArea4.AxisX.MajorTickMark.LineWidth = 2
        ChartArea4.AxisX.MajorTickMark.Size = 3.0!
        ChartArea4.AxisY.IsLabelAutoFit = False
        ChartArea4.AxisY.LabelStyle.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ChartArea4.AxisY.LabelStyle.ForeColor = System.Drawing.Color.DarkSlateGray
        ChartArea4.AxisY.LabelStyle.Format = "Ghc(0.0.)"
        ChartArea4.AxisY.MajorGrid.LineColor = System.Drawing.Color.DarkSlateGray
        ChartArea4.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDotDot
        ChartArea4.AxisY.MajorTickMark.LineColor = System.Drawing.Color.DarkSlateGray
        ChartArea4.AxisY.MajorTickMark.LineWidth = 2
        ChartArea4.BackColor = System.Drawing.Color.White
        ChartArea4.BackSecondaryColor = System.Drawing.Color.White
        ChartArea4.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea4)
        Legend4.Name = "Legend1"
        Legend4.Title = "TRANSACTIONS"
        Legend4.TitleFont = New System.Drawing.Font("Times", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend4.TitleForeColor = System.Drawing.Color.DarkGreen
        Me.Chart1.Legends.Add(Legend4)
        Me.Chart1.Location = New System.Drawing.Point(15, 238)
        Me.Chart1.Name = "Chart1"
        Series4.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.LeftRight
        Series4.BackSecondaryColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Series4.BorderColor = System.Drawing.Color.Purple
        Series4.BorderWidth = 2
        Series4.ChartArea = "ChartArea1"
        Series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.SplineArea
        Series4.Color = System.Drawing.Color.SeaGreen
        Series4.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Series4.IsValueShownAsLabel = True
        Series4.Legend = "Legend1"
        Series4.MarkerColor = System.Drawing.Color.DarkSlateGray
        Series4.MarkerSize = 4
        Series4.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle
        Series4.Name = "Series1"
        Me.Chart1.Series.Add(Series4)
        Me.Chart1.Size = New System.Drawing.Size(649, 287)
        Me.Chart1.TabIndex = 70
        Me.Chart1.Text = "Chart1"
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.White
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label10.Location = New System.Drawing.Point(678, 145)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 19)
        Me.Label10.TabIndex = 69
        Me.Label10.Text = "Year"
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.BackColor = System.Drawing.Color.White
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox3.Image = Global.AidBridge.My.Resources.Resources.images
        Me.PictureBox3.Location = New System.Drawing.Point(803, 29)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(172, 188)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 68
        Me.PictureBox3.TabStop = False
        '
        'txtYear2
        '
        Me.txtYear2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtYear2.AutoSize = True
        Me.txtYear2.BackColor = System.Drawing.Color.White
        Me.txtYear2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYear2.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtYear2.Location = New System.Drawing.Point(717, 146)
        Me.txtYear2.Name = "txtYear2"
        Me.txtYear2.Size = New System.Drawing.Size(25, 19)
        Me.txtYear2.TabIndex = 64
        Me.txtYear2.Text = "56"
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.BackColor = System.Drawing.Color.White
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.Image = Global.AidBridge.My.Resources.Resources._6543820
        Me.PictureBox2.Location = New System.Drawing.Point(449, 25)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(206, 198)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 67
        Me.PictureBox2.TabStop = False
        '
        'txtTotalClaims
        '
        Me.txtTotalClaims.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalClaims.AutoSize = True
        Me.txtTotalClaims.BackColor = System.Drawing.Color.White
        Me.txtTotalClaims.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalClaims.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtTotalClaims.Location = New System.Drawing.Point(681, 95)
        Me.txtTotalClaims.Name = "txtTotalClaims"
        Me.txtTotalClaims.Size = New System.Drawing.Size(25, 19)
        Me.txtTotalClaims.TabIndex = 60
        Me.txtTotalClaims.Text = "34"
        '
        'Label8
        '
        Me.Label8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label8.Location = New System.Drawing.Point(23, 145)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 19)
        Me.Label8.TabIndex = 66
        Me.Label8.Text = "Year"
        '
        'dashBoardBtnClaims
        '
        Me.dashBoardBtnClaims.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dashBoardBtnClaims.BackColor = System.Drawing.Color.White
        Me.dashBoardBtnClaims.Cursor = System.Windows.Forms.Cursors.Default
        Me.dashBoardBtnClaims.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.dashBoardBtnClaims.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.dashBoardBtnClaims.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.dashBoardBtnClaims.Font = New System.Drawing.Font("Times New Roman", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dashBoardBtnClaims.ForeColor = System.Drawing.Color.DarkGreen
        Me.dashBoardBtnClaims.IconChar = FontAwesome.Sharp.IconChar.None
        Me.dashBoardBtnClaims.IconColor = System.Drawing.Color.SeaGreen
        Me.dashBoardBtnClaims.IconSize = 120
        Me.dashBoardBtnClaims.Location = New System.Drawing.Point(670, 6)
        Me.dashBoardBtnClaims.Name = "dashBoardBtnClaims"
        Me.dashBoardBtnClaims.Rotation = 0R
        Me.dashBoardBtnClaims.Size = New System.Drawing.Size(312, 224)
        Me.dashBoardBtnClaims.TabIndex = 57
        Me.dashBoardBtnClaims.Text = "CLAIMS"
        Me.dashBoardBtnClaims.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.dashBoardBtnClaims.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox1.Image = Global.AidBridge.My.Resources.Resources._5520944
        Me.PictureBox1.Location = New System.Drawing.Point(137, 45)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(172, 177)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 65
        Me.PictureBox1.TabStop = False
        '
        'txtTotalMembers
        '
        Me.txtTotalMembers.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalMembers.AutoSize = True
        Me.txtTotalMembers.BackColor = System.Drawing.Color.White
        Me.txtTotalMembers.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalMembers.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtTotalMembers.Location = New System.Drawing.Point(355, 96)
        Me.txtTotalMembers.Name = "txtTotalMembers"
        Me.txtTotalMembers.Size = New System.Drawing.Size(17, 19)
        Me.txtTotalMembers.TabIndex = 61
        Me.txtTotalMembers.Text = "7"
        '
        'txtYear
        '
        Me.txtYear.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtYear.AutoSize = True
        Me.txtYear.BackColor = System.Drawing.Color.White
        Me.txtYear.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYear.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtYear.Location = New System.Drawing.Point(60, 146)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(25, 19)
        Me.txtYear.TabIndex = 63
        Me.txtYear.Text = "34"
        '
        'dashBoardBtnMembers
        '
        Me.dashBoardBtnMembers.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dashBoardBtnMembers.BackColor = System.Drawing.Color.White
        Me.dashBoardBtnMembers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.dashBoardBtnMembers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.dashBoardBtnMembers.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.dashBoardBtnMembers.Font = New System.Drawing.Font("Times New Roman", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dashBoardBtnMembers.ForeColor = System.Drawing.Color.DarkGreen
        Me.dashBoardBtnMembers.IconChar = FontAwesome.Sharp.IconChar.None
        Me.dashBoardBtnMembers.IconColor = System.Drawing.Color.White
        Me.dashBoardBtnMembers.IconSize = 120
        Me.dashBoardBtnMembers.Location = New System.Drawing.Point(323, 5)
        Me.dashBoardBtnMembers.Name = "dashBoardBtnMembers"
        Me.dashBoardBtnMembers.Rotation = 0R
        Me.dashBoardBtnMembers.Size = New System.Drawing.Size(341, 226)
        Me.dashBoardBtnMembers.TabIndex = 58
        Me.dashBoardBtnMembers.Text = "MEMBERS"
        Me.dashBoardBtnMembers.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.dashBoardBtnMembers.UseVisualStyleBackColor = False
        '
        'txtTotalContributions
        '
        Me.txtTotalContributions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalContributions.AutoSize = True
        Me.txtTotalContributions.BackColor = System.Drawing.Color.White
        Me.txtTotalContributions.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalContributions.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtTotalContributions.Location = New System.Drawing.Point(26, 97)
        Me.txtTotalContributions.Name = "txtTotalContributions"
        Me.txtTotalContributions.Size = New System.Drawing.Size(25, 19)
        Me.txtTotalContributions.TabIndex = 62
        Me.txtTotalContributions.Text = "56"
        '
        'btnUserDashboardContributions
        '
        Me.btnUserDashboardContributions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUserDashboardContributions.BackColor = System.Drawing.Color.White
        Me.btnUserDashboardContributions.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnUserDashboardContributions.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.btnUserDashboardContributions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.btnUserDashboardContributions.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnUserDashboardContributions.Font = New System.Drawing.Font("Times New Roman", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUserDashboardContributions.ForeColor = System.Drawing.Color.DarkGreen
        Me.btnUserDashboardContributions.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnUserDashboardContributions.IconColor = System.Drawing.Color.White
        Me.btnUserDashboardContributions.IconSize = 120
        Me.btnUserDashboardContributions.Location = New System.Drawing.Point(16, 6)
        Me.btnUserDashboardContributions.Name = "btnUserDashboardContributions"
        Me.btnUserDashboardContributions.Rotation = 0R
        Me.btnUserDashboardContributions.Size = New System.Drawing.Size(301, 225)
        Me.btnUserDashboardContributions.TabIndex = 59
        Me.btnUserDashboardContributions.Text = "CONTRIBUTIONS"
        Me.btnUserDashboardContributions.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnUserDashboardContributions.UseVisualStyleBackColor = False
        '
        'SecretaryHome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(996, 531)
        Me.Controls.Add(Me.Chart2)
        Me.Controls.Add(Me.Chart1)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.txtYear2)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.txtTotalClaims)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.dashBoardBtnClaims)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtTotalMembers)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.dashBoardBtnMembers)
        Me.Controls.Add(Me.txtTotalContributions)
        Me.Controls.Add(Me.btnUserDashboardContributions)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "SecretaryHome"
        Me.Text = "SecretaryHome"
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Chart2 As DataVisualization.Charting.Chart
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents txtYear2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents txtTotalClaims As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents dashBoardBtnClaims As FontAwesome.Sharp.IconButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtTotalMembers As Label
    Friend WithEvents txtYear As Label
    Friend WithEvents dashBoardBtnMembers As FontAwesome.Sharp.IconButton
    Friend WithEvents txtTotalContributions As Label
    Friend WithEvents btnUserDashboardContributions As FontAwesome.Sharp.IconButton
End Class
