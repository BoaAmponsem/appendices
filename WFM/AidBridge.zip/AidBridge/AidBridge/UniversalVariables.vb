﻿Imports System.Data.SqlClient
Imports System.Text
Module UniversalVariables
    '' Database operations variables
    Public Con As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\AidBridge\AidBridge.mdf;Integrated Security=True;Connect Timeout=30")
    ' Public Con As New SqlConnection("Data Source=;Initial Catalog=AidBridge2023;User ID=AidBridge2023;Password=AidBridge")
    Public dt As DataTable
    Public cmd As SqlCommand
    Public adaptor As SqlDataAdapter
    Public builder As SqlCommandBuilder
    Public ds As DataSet
    Public myReader As SqlDataReader

    Public totalDeposits As Double
    Public totalWithdrawal As Double

    Public checkNullDeposits As Integer = 0, Withdrawals As Integer = 0
    Public AllDeposits
    Public totalDebtors As String

    Public profilePicture As Byte()


    Public CheckAllDeposits As Integer = 0, CheckAllWithdrawals As Integer = 0, SumOfAllDeposits As Double, SumOfAllWithdrawals As Double


    Public Sub SumAllDeposits()
        '' Get the total Deposits check
        Try
            '  Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Deposit'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            CheckAllDeposits = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            '  Cursor = Cursors.Default
            Con.Close()
        End Try


        'Total Deposits
        If (CheckAllDeposits <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Deposit'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    SumOfAllDeposits = 0
                Else
                    SumOfAllDeposits = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            SumOfAllDeposits = "0"
        End If

    End Sub
    Public Sub SumAllWithdrawal()
        '' Get the total withdrawal check
        Try
            '  Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Withdrawal'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            CheckAllWithdrawals = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            '  Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Withdrawals
        If (CheckAllWithdrawals <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Withdrawal'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    SumOfAllWithdrawals = 0
                Else
                    SumOfAllWithdrawals = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            SumOfAllWithdrawals = "0"
        End If
    End Sub

    'Deposit
    'Withdrawal
    Public Sub SumOfDepositsAndWithdrawals()
        '' Get the total Deposits check
        Try
            '  Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Deposit'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checkNullDeposits = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            '  Cursor = Cursors.Default
            Con.Close()
        End Try

        '' Get the total withdrawal check
        Try
            '  Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from DepositsTbl WHERE Transaction_Type = 'Withdrawal'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            Withdrawals = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            '  Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Deposits
        If (checkNullDeposits <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Deposit'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalDeposits = 0
                Else
                    totalDeposits = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            totalDeposits = "0"
        End If

        'Total Withdrawals
        If (Withdrawals <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) FROM DepositsTbl WHERE Transaction_Type = 'Withdrawal'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                '  cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalWithdrawal = 0
                Else
                    totalWithdrawal = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            totalWithdrawal = "0"
        End If
    End Sub

    Public monthsSinceLastPayment As Integer

    Public currentYear As Integer = DateTime.Now.Year
    Public currentDatea As Integer = DateTime.Now.Month

    Public txtRetirement As String = "Retirement"
    Public txtDeparture As String = "Departure"
    Public txtTreasurer As String = "TREASURER"
    Public txtSecretary As String = "SECRETARY"
    Public theUsRealID As String

    Public DuesAmount As Double
    Public GiftAmount As Double
    Public P1 As Double
    Public P2 As Double
    Public DuesPaidBeforeNwRate As Integer = 0
    Public InitialDues As Double

    Public Function checkDuesBeforeNwRate(Id)
        Try
            ' Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl where Not Amount='" & DuesAmount & "' And Member_Id = '" & id & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            DuesPaidBeforeNwRate = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'Cursor = Cursors.Default
            Con.Close()
        End Try
    End Function

    Public Function GetGiftAmount()
        Try
            Con.Open()
            Dim query = "select * from SetValuesTbl"
            cmd = New SqlCommand(query, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            GiftAmount = myReader("Gift")
            DuesAmount = myReader("Dues")
            P1 = myReader("Claim_Proportion")
            P2 = myReader("Null_Claim_Proportion")
            InitialDues = myReader("Initial_Dues")
            '  UserContributions.txtAmount.Text = GiftAmount.ToString
        Catch ex As SqlException
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function
    'Populate Deposit Slips
    Public Function PopulateDepositSlips()
        Try
            Con.Open()
            Dim query = "select Id,Transaction_Type,Amount,Purpose,Ref_No,Bank,Teller,Date from DepositsTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            UserContributions.depositDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    Public theNumberOfApprovals


    Public Amount As Double
    Public Reason As String
    Public Claimer As String
    Public BeneficiaryName As String


    'Variable for members Profile Edit/Removal
    Public getStaffIDToEdit As String
    Public theMemberNam As String
    Public theMemberOthernames As String
    Public theMemberPhone As String
    Public theMemberSex As String
    Public nullValues As String = ""

    '' UserLogin variables
    Public UserLoginSwitch As Integer
    Public theUsername As String
    Public Uname As String
    Public Uname2 As String
    Public Ugmail As String
    Public Upassword As String
    Public UStaffID As String
    Public Uphone As String
    Public lognullDate As String

    'Public nwForm1 As Form
    Public txtClaimByBeneficiary As String = "Beneficiary"
    Public maxDate
    Public maxDateYear As Integer
    Public maxDateMonth As Integer
    Public memberTotalClaim As Integer = 0
    Public memberTotalClaim2 As Integer = 0
    Public memberNoChildren As Integer = 0
    Public membertTotalDues As Decimal = 0.0
    Public totalClaims As Integer = 0
    Public totalMoneyGivenOut As Integer = 0
    Public totalContributions As Integer = 0
    Public totalMembers As Integer = 0

    Public memberUniqueId
    Public memberSpouseUniqueId
    Public memberMotherUniqueId
    Public memberFatherUniqueId
    Public checkNoSpouse As Integer = 0

    '' AdminLogin variables
    Public AdminLoginSwitch As Integer


    '' Password to be sent to the user
    Public VerificationPassword As String
    Public Aname As String
    Public Aname2 As String
    Public Agmail As String
    Public Apassword As String
    Public AStaffID As String
    Public Aphone As String
    Public AlognullDate As String
    Public theMemberSingle As String = "Single"
    Public theMemberMarried As String = "Married"

    '' Password to be sent to the Admin
    Public AdminVerificationPassword As String

    'Encryption
    Public Function Encrypt(Encryption As String) As String
        Try
            Dim msg As String = String.Empty
            Dim encode As Byte() = New Byte(Encryption.Length - 1) {}
            encode = Encoding.UTF8.GetBytes(Encryption)
            msg = Convert.ToBase64String(encode)
            Return msg
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Function


    'Decryption
    Public Function Decrypt(Decryption As String) As String
        Try
            Dim decryptText As String = String.Empty
            Dim encodeText As New UTF8Encoding()
            Dim decode As Decoder = encodeText.GetDecoder()
            Dim codeByte As Byte() = Convert.FromBase64String(Decryption)
            Dim charcount As Integer = decode.GetCharCount(codeByte, 0, codeByte.Length)
            Dim decodeChar As Char() = New Char(charcount - 1) {}
            decode.GetChars(codeByte, 0, codeByte.Length, decodeChar, 0)
            decryptText = New String(decodeChar)
            Return decryptText
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function

    'Delete Member Function
    Public Function removeMember(memberID, operatorsName, Id)
        Dim datess = New DateTimePicker
        Dim removalDate = datess.Value
        'Insert removed members to exclusionTbl
        Try
            Con.Open()
            Dim query As String
            query = "INSERT INTO ExclusionTbl (Staff_ID, Surname, Other_Names, Phone, Sex, House_No, Postal_Address, Marital_Status, Marriage_Type, Hometown, Birth_Date, Picture, Registration_Date, Removal_Date, Operator1, Removed_By, Operator2_ID) " &
                    "VALUES (@Staff_ID, @Surname, @Other_Names, @Phone, @Sex, @House_No, @Postal_Address, @Marital_Status, @Marriage_Type, @Hometown, @Birth_Date, @ProfilePicture, @Registration_Date, @Removal_Date, @User_Operator, @Operator_Name, @Id)"

            cmd = New SqlCommand(query, Con)

            cmd.Parameters.AddWithValue("@Staff_ID", getStaffIDToEdit)
            cmd.Parameters.AddWithValue("@Surname", memberUserSurname)
            cmd.Parameters.AddWithValue("@Other_Names", memberUserOthername)
            cmd.Parameters.AddWithValue("@Phone", memberUserPhone)
            cmd.Parameters.AddWithValue("@Sex", memberUserSex)
            cmd.Parameters.AddWithValue("@House_No", memberUserHouseNo)
            cmd.Parameters.AddWithValue("@Postal_Address", memberUserPostalAddress)
            cmd.Parameters.AddWithValue("@Marital_Status", memberUserMaritalStatus)
            cmd.Parameters.AddWithValue("@Marriage_Type", memberUserTypeOfMarriage)
            cmd.Parameters.AddWithValue("@Hometown", memberUserHomeTown)
            cmd.Parameters.AddWithValue("@Birth_Date", memberUserDoB)
            cmd.Parameters.AddWithValue("@ProfilePicture", profilePicture)
            cmd.Parameters.AddWithValue("@Registration_Date", memberRegistrationDate)
            cmd.Parameters.AddWithValue("@Removal_Date", removalDate)
            cmd.Parameters.AddWithValue("@User_Operator", memberUserOperator)
            cmd.Parameters.AddWithValue("@Operator_Name", operatorsName)
            cmd.Parameters.AddWithValue("@Id", Id)

            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        'Finally Remove the member
        Try

            Con.Open()
            Dim queryy = "delete from MembersTbl where Staff_ID = '" & memberID & "'"
            cmd = New SqlCommand(queryy, Con)
            cmd.ExecuteNonQuery()
            MsgBox("Member removed successfully", MsgBoxStyle.Information)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

    End Function

    '
    'Variaables to be used at User Add-Members Page
    Public memberUserSurname As String
    Public memberUserSurname1 As String
    Public memberUserOthername As String
    Public memberUserSex As String
    Public memberUserPhone As String
    Public memberUserHouseNo As String
    Public memberRegistrationDate As String
    Public memberUserOperator As String
    Public memberUserPostalAddress As String
    Public memberUserMaritalStatus As String
    Public memberUserTypeOfMarriage As String
    Public memberUserHomeTown As String
    Public memberUserDoB As String
    Public memberUserStaffID As String
    Public memberUserPicture As String = "G:\GOSPEL\Others"
    'Public image As Byte()

    Public memberUserSpouseName As String
    Public memberUserSpousePhone As String
    Public memberUserSpouseAddress As String

    Public memberUserChild1name As String
    Public memberUserChild1DoB As String
    Public memberUserChild2name As String
    Public memberUserChild2DoB As String
    Public memberUserChild3name As String
    Public memberUserChild3DoB As String
    Public memberUserChild4name As String
    Public memberUserChild4DoB As String
    Public memberUserChild5name As String
    Public memberUserChild5DoB As String
    Public memberUserChild6name As String
    Public memberUserChild6DoB As String
    Public memberUserChild7name As String
    Public memberUserChild7DoB As String
    Public memberUserChild8name As String
    Public memberUserChild8DoB As String


    Public memberUserMothername As String
    Public memberUserMotherPhone As String
    Public memberUserMotherLiveStatus As String

    Public memberUserFathername As String
    Public memberUserFatherPhone As String
    Public memberUserFatherLiveStatus As String

    Public memberUserBeneficiary1 As String
    Public memberUserBeneficiary2 As String
    Public memberUserBeneficiary3 As String
    Public memberUserBeneficiary4 As String

    Public memberUserBeneficiary1Phone As String
    Public memberUserBeneficiary2Phone As String
    Public memberUserBeneficiary3Phone As String
    Public memberUserBeneficiary4Phone As String

    Public memberUserBeneficiary1DoB As String
    Public memberUserBeneficiary2DoD As String
    Public memberUserBeneficiary3DoB As String
    Public memberUserBeneficiary4DoB As String

    Public memberUserBeneficiary1Relation As String
    Public memberUserBeneficiary2Relation As String
    Public memberUserBeneficiary3Relation As String
    Public memberUserBeneficiary4Relation As String

    Public memberUserBeneficiary1Proportion As String
    Public memberUserBeneficiary2Proportion As String
    Public memberUserBeneficiary3Proportion As String
    Public memberUserBeneficiary4Proportion As String

    Public memberUserBeneficiary1Address As String
    Public memberUserBeneficiary2Address As String
    Public memberUserBeneficiary3Address As String
    Public memberUserBeneficiary4Address As String



    '
    'Variables to be used at admin Add-Members Page
    Public memberASurname As String
    Public memberAOthername As String
    Public memberASex As String
    Public memberAPhone As String
    Public memberAHouseNo As String
    Public memberAPostalAddress As String
    Public memberAMaritalStatus As String
    Public memberATypeOfMarriage As String = "-"
    Public memberAHomeTown As String
    Public memberADoB As String
    Public memberAStaffID As String
    Public memberAPicture As String = "G:\GOSPEL\Others"

    Public setAdminName As String = "Administrator"

    Public memberASpouseName As String
    Public memberASpousePhone As String
    Public memberASpouseAddress As String
    Public nullSpouseClaimDate As String = ""
    Public nullSpouseStatus As String = ""

    Public memberAChild1name As String
    Public memberAChild1DoB As String
    Public nullChildOneClaimDate As String = ""
    Public nullChildOneStatus As String = ""

    Public memberAChild2name As String
    Public memberAChild2DoB As String
    Public nullChildTwoClaimDate As String = ""
    Public nullChildTwoStatus As String = ""

    Public memberAChild3name As String
    Public memberAChild3DoB As String
    Public nullChildThreeClaimDate As String = ""
    Public nullChildThreeStatus As String = ""

    Public memberAChild4name As String
    Public memberAChild4DoB As String
    Public nullChildFourClaimDate As String = ""
    Public nullChildFourStatus As String = ""

    Public memberAChild5name As String
    Public memberAChild5DoB As String
    Public nullChildFiveClaimDate As String = ""
    Public nullChildFiveStatus As String = ""

    Public memberAChild6name As String
    Public memberAChild6DoB As String
    Public nullChildSixClaimDate As String = ""
    Public nullChildSixStatus As String = ""

    Public memberAChild7name As String
    Public memberAChild7DoB As String
    Public nullChildSevenClaimDate As String = ""
    Public nullChildSevenStatus As String = ""

    Public memberAChild8name As String
    Public memberAChild8DoB As String
    Public nullChildEightClaimDate As String = ""
    Public nullChildEightStatus As String = ""


    Public memberAMothername As String
    Public memberAMotherPhone As String
    Public memberAMotherLiveStatus As String
    Public nullMotherClaimDate As String = ""
    Public nullMotherStatus As String = ""
    Public AMother As String = "Mother"
    Public AMotherLiveStatus As String = "Alive"
    Public AMotherDeadStatus As String = "Dead"

    Public memberAFathername As String
    Public memberAFatherPhone As String
    Public memberAFatherLiveStatus As String
    Public nullFatherClaimDate As String = ""
    Public nullFatherStatus As String = ""
    Public nullMarriageStatus As String = ""
    Public AFather As String = "Father"
    Public AFatherLiveStatus As String = "Alive"
    Public AFatherDeadStatus As String = "Dead"
    Public AMotherOrFatherID As String

    Public memberABeneficiary1 As String
    Public memberABeneficiary2 As String
    Public memberABeneficiary3 As String
    Public memberABeneficiary4 As String

    Public memberABeneficiary1Phone As String
    Public memberABeneficiary2Phone As String
    Public memberABeneficiary3Phone As String
    Public memberABeneficiary4Phone As String

    Public memberABeneficiary1DoB As String
    'Public memberABeneficiary2DoD As String
    Public memberABeneficiary2DoB As String
    Public memberABeneficiary3DoB As String
    Public memberABeneficiary4DoB As String

    Public memberABeneficiary1Relation As String
    Public memberABeneficiary2Relation As String
    Public memberABeneficiary3Relation As String
    Public memberABeneficiary4Relation As String

    Public memberABeneficiary1Proportion As String
    Public memberABeneficiary2Proportion As String
    Public memberABeneficiary3Proportion As String
    Public memberABeneficiary4Proportion As String

    Public memberABeneficiary1Address As String
    Public memberABeneficiary2Address As String
    Public memberABeneficiary3Address As String
    Public memberABeneficiary4Address As String
    'Public memberUserSurname As String
    'Public memberUserOthername As String
    'Public memberUserSurname As String
    'Public memberUserOthername As String
    'Public memberUserSurname As String
    'Public memberUserOthername As String
    Public Sub resetAllMemberFormsAdmin()
        ''Reset Add member forms 1  Personal Details
        AddMemberPage1.txtMemberSurname.Text = ""
        AddMemberPage1.txtMemberOthername.Text = ""
        AddMemberPage1.txtMemberSex.Text = ""
        AddMemberPage1.txtMemberPhone.Text = ""
        AddMemberPage1.txtMemberHouseNo.Text = ""
        AddMemberPage1.txtMemberPostalAddress.Text = ""
        AddMemberPage1.txtMaritalStatus.Text = ""
        AddMemberPage1.txtTypeOfMarriage.Text = ""
        AddMemberPage1.txtMemberHometown.Text = ""
        AddMemberPage1.txtMemberDoB1.Text = ""
        AddMemberPage1.txtMemberStaffID.Text = ""
        AddMemberPage1.txtImageName.Text = ""
        AddMemberPage1.noProfilePic.Checked = False
        AddMemberPage1.txtTypeOfMarriage.Visible = False
        AddMemberPage1.typeOfMarriageText.Visible = False

        'Spouse Details
        AddMemberPage1.txtSpouseName.Text = ""
        AddMemberPage1.txtSpousePhone.Text = ""
        AddMemberPage1.txtSpouseAddress.Text = ""

        'Children Check to Default
        AddMemberPage1.noChild.Checked = True
        AddMemberPage1.oneChild.Checked = False
        AddMemberPage1.twoChildren.Checked = False
        AddMemberPage1.threeChildren.Checked = False
        AddMemberPage1.fourChildren.Checked = False
        AddMemberPage1.fiveChildren.Checked = False
        AddMemberPage1.sixChildren.Checked = False
        AddMemberPage1.sevenChildren.Checked = False
        AddMemberPage1.eightChildren.Checked = False

        ''Reset Children Details
        AddMemberPage1.txtChild1Name.Text = ""
        AddMemberPage1.txtChild1DoBA.Text = ""

        AddMemberPage1.txtChild2Name.Text = ""
        AddMemberPage1.txtChild2DoBB.Text = ""

        AddMemberPage1.txtChild3Name.Text = ""
        AddMemberPage1.txtChild3DoBC.Text = ""

        AddMemberPage1.txtChild4Name.Text = ""
        AddMemberPage1.txtChild4DoBD.Text = ""

        AddMemberPage1.txtChild5Name.Text = ""
        AddMemberPage1.txtChild5DoBE.Text = ""

        AddMemberPage1.txtChild6Name.Text = ""
        AddMemberPage1.txtChild6DoBF.Text = ""

        AddMemberPage1.txtChild7Name.Text = ""
        AddMemberPage1.txtChild7DoBG.Text = ""

        AddMemberPage1.txtChild8Name.Text = ""
        AddMemberPage1.txtChild8DoBH.Text = ""



        ''Reset Add member forms 2
        AddMemberPage2.txtMotherName.Text = ""
        AddMemberPage2.txtMotherPhone.Text = ""
        AddMemberPage2.txtMotherAlive.Checked = False
        AddMemberPage2.txtMotherDead.Checked = False

        AddMemberPage2.txtFatherName.Text = ""
        AddMemberPage2.txtFatherPhone.Text = ""
        AddMemberPage2.txtFatherAlive.Checked = False
        AddMemberPage2.txtFatherDead.Checked = False

        'Check Beneficiary to default
        AddMemberPage2.txtNoBeneficiary.Checked = True
        AddMemberPage2.oneBeneficiary.Checked = False
        AddMemberPage2.twoBeneficiary.Checked = False
        AddMemberPage2.threeBeneficiary.Checked = False
        AddMemberPage2.fourBeneficiary.Checked = False

        'Reset beneficiaries
        AddMemberPage2.txtBeneficiaryOneName.Text = ""
        AddMemberPage2.txtBeneficiaryOneDoB.Text = ""
        AddMemberPage2.txtBeneficiaryOnePhone.Text = ""
        AddMemberPage2.txtBeneficiaryOneAddress.Text = ""
        AddMemberPage2.txtBeneficiaryOneRelation.Text = ""
        AddMemberPage2.txtBeneficiaryOneProportion.Text = ""


        AddMemberPage2.txtBeneficiaryTwoName.Text = ""
        AddMemberPage2.txtBeneficiaryTwoDoB.Text = ""
        AddMemberPage2.txtBeneficiaryTwoPhone.Text = ""
        AddMemberPage2.txtBeneficiaryTwoAddress.Text = ""
        AddMemberPage2.txtBeneficiaryTwoRelation.Text = ""
        AddMemberPage2.txtBeneficiaryTwoProportion.Text = ""


        AddMemberPage2.txtBeneficiaryThreeName.Text = ""
        AddMemberPage2.txtBeneficiaryThreeDoB.Text = ""
        AddMemberPage2.txtBeneficiaryThreePhone.Text = ""
        AddMemberPage2.txtBeneficiaryThreeAddress.Text = ""
        AddMemberPage2.txtBeneficiaryThreeRelation.Text = ""
        AddMemberPage2.txtBeneficiaryThreeProportion.Text = ""

        AddMemberPage2.txtBeneficiaryFourName.Text = ""
        AddMemberPage2.txtBeneficiaryFourDoB.Text = ""
        AddMemberPage2.txtBeneficiaryFourPhone.Text = ""
        AddMemberPage2.txtBeneficiaryFourAddress.Text = ""
        AddMemberPage2.txtBeneficiaryFourRelation.Text = ""
        AddMemberPage2.txtBeneficiaryFourProportion.Text = ""
        AddMemberPage2.txtAcceptAgreement.Checked = False
    End Sub


    Public Sub resetAllMemberFormsUser()
        ''Reset Add member forms 1  Personal Details
        UserAddMemberPage1.txtMemberSurname.Text = ""
        UserAddMemberPage1.txtMemberOthername.Text = ""
        UserAddMemberPage1.txtMemberSex.Text = ""
        UserAddMemberPage1.txtMemberPhone.Text = ""
        UserAddMemberPage1.txtMemberHouseNo.Text = ""
        UserAddMemberPage1.txtMemberPostalAddress.Text = ""
        UserAddMemberPage1.txtMaritalStatus.Text = ""
        UserAddMemberPage1.txtTypeOfMarriage.Text = ""
        UserAddMemberPage1.txtMemberHomeTown.Text = ""
        UserAddMemberPage1.txtMemberDoB1.Text = ""
        UserAddMemberPage1.txtMemberStaffID.Text = ""
        UserAddMemberPage1.txtImageName.Text = ""
        UserAddMemberPage1.noProfilePic.Checked = False
        UserAddMemberPage1.txtTypeOfMarriage.Visible = False
        UserAddMemberPage1.typeOfMarriageText.Visible = False

        'Spouse Details
        UserAddMemberPage1.txtSpouseName.Text = ""
        UserAddMemberPage1.txtSpousePhone.Text = ""
        UserAddMemberPage1.txtSpouseAddress.Text = ""


        'Children Check to Default
        UserAddMemberPage1.noChild.Checked = True
        UserAddMemberPage1.oneChild.Checked = False
        UserAddMemberPage1.twoChildren.Checked = False
        UserAddMemberPage1.threeChildren.Checked = False
        UserAddMemberPage1.fourChildren.Checked = False
        UserAddMemberPage1.fiveChildren.Checked = False
        UserAddMemberPage1.sixchildren.Checked = False
        UserAddMemberPage1.sevenChildren.Checked = False
        UserAddMemberPage1.eightChildren.Checked = False

        ''Reset Children Details
        UserAddMemberPage1.txtChild1Name.Text = ""
        UserAddMemberPage1.txtChild1DoBA.Text = ""

        UserAddMemberPage1.txtChild2Name.Text = ""
        UserAddMemberPage1.txtChild2DoBB.Text = ""

        UserAddMemberPage1.txtChild3Name.Text = ""
        UserAddMemberPage1.txtChild3DoBC.Text = ""

        UserAddMemberPage1.txtChild4Name.Text = ""
        UserAddMemberPage1.txtChild4DoBD.Text = ""

        UserAddMemberPage1.txtChild5Name.Text = ""
        UserAddMemberPage1.txtChild5DoBE.Text = ""

        UserAddMemberPage1.txtChild6Name.Text = ""
        UserAddMemberPage1.txtChild6DoBF.Text = ""

        UserAddMemberPage1.txtChild7Name.Text = ""
        UserAddMemberPage1.txtChild7DoBG.Text = ""

        UserAddMemberPage1.txtChild8Name.Text = ""
        UserAddMemberPage1.txtChild8DoBH.Text = ""



        ''Reset Add member forms 2
        UserAddMemberPage2.txtMotherName.Text = ""
        UserAddMemberPage2.txtMotherPhone.Text = ""
        UserAddMemberPage2.txtMotherAlive.Checked = False
        UserAddMemberPage2.txtMotherDead.Checked = False

        UserAddMemberPage2.txtFatherName.Text = ""
        UserAddMemberPage2.txtFatherPhone.Text = ""
        UserAddMemberPage2.txtFatherAlive.Checked = False
        UserAddMemberPage2.txtFatherDead.Checked = False

        'Check Beneficiary to default
        UserAddMemberPage2.txtNoBeneficiary.Checked = True
        UserAddMemberPage2.oneBeneficiary.Checked = False
        UserAddMemberPage2.twoBeneficiary.Checked = False
        UserAddMemberPage2.threeBeneficiary.Checked = False
        UserAddMemberPage2.fourBeneficiary.Checked = False

        'Reset beneficiaries
        UserAddMemberPage2.txtBeneficiaryOneName.Text = ""
        UserAddMemberPage2.txtBeneficiaryOneDoB.Text = ""
        UserAddMemberPage2.txtBeneficiaryOnePhone.Text = ""
        UserAddMemberPage2.txtBeneficiaryOneAddress.Text = ""
        UserAddMemberPage2.txtBeneficiaryOneRelation.Text = ""
        UserAddMemberPage2.txtBeneficiaryOneProportion.Text = ""


        UserAddMemberPage2.txtBeneficiaryTwoName.Text = ""
        UserAddMemberPage2.txtBeneficiaryTwoDoB.Text = ""
        UserAddMemberPage2.txtBeneficiaryTwoPhone.Text = ""
        UserAddMemberPage2.txtBeneficiaryTwoAddress.Text = ""
        UserAddMemberPage2.txtBeneficiaryTwoRelation.Text = ""
        UserAddMemberPage2.txtBeneficiaryTwoProportion.Text = ""


        UserAddMemberPage2.txtBeneficiaryThreeName.Text = ""
        UserAddMemberPage2.txtBeneficiaryThreeDoB.Text = ""
        UserAddMemberPage2.txtBeneficiaryThreePhone.Text = ""
        UserAddMemberPage2.txtBeneficiaryThreeAddress.Text = ""
        UserAddMemberPage2.txtBeneficiaryThreeRelation.Text = ""
        UserAddMemberPage2.txtBeneficiaryThreeProportion.Text = ""

        UserAddMemberPage2.txtBeneficiaryFourName.Text = ""
        UserAddMemberPage2.txtBeneficiaryFourDoB.Text = ""
        UserAddMemberPage2.txtBeneficiaryFourPhone.Text = ""
        UserAddMemberPage2.txtBeneficiaryFourAddress.Text = ""
        UserAddMemberPage2.txtBeneficiaryFourRelation.Text = ""
        UserAddMemberPage2.txtBeneficiaryFourProportion.Text = ""

        UserAddMemberPage2.txtAcceptAgreement.Checked = False

    End Sub


    Public Sub resetAllMemberFormsSec()
        ''Reset Add member forms 1  Personal Details
        SecAddMemberPage1.txtMemberSurname.Text = ""
        SecAddMemberPage1.txtMemberOthername.Text = ""
        SecAddMemberPage1.txtMemberSex.Text = ""
        SecAddMemberPage1.txtMemberPhone.Text = ""
        SecAddMemberPage1.txtMemberHouseNo.Text = ""
        SecAddMemberPage1.txtMemberPostalAddress.Text = ""
        SecAddMemberPage1.txtMaritalStatus.Text = ""
        SecAddMemberPage1.txtTypeOfMarriage.Text = ""
        SecAddMemberPage1.txtMemberHometown.Text = ""
        SecAddMemberPage1.txtMemberDoB1.Text = ""
        SecAddMemberPage1.txtMemberStaffID.Text = ""
        SecAddMemberPage1.txtImageName.Text = ""
        SecAddMemberPage1.noProfilePic.Checked = False
        SecAddMemberPage1.txtTypeOfMarriage.Visible = False
        SecAddMemberPage1.typeOfMarriageText.Visible = False

        'Spouse Details
        SecAddMemberPage1.txtSpouseName.Text = ""
        SecAddMemberPage1.txtSpousePhone.Text = ""
        SecAddMemberPage1.txtSpouseAddress.Text = ""


        'Children Check to Default
        SecAddMemberPage1.noChild.Checked = True
        SecAddMemberPage1.oneChild.Checked = False
        SecAddMemberPage1.twoChildren.Checked = False
        SecAddMemberPage1.threeChildren.Checked = False
        SecAddMemberPage1.fourChildren.Checked = False
        SecAddMemberPage1.fiveChildren.Checked = False
        SecAddMemberPage1.sixChildren.Checked = False
        SecAddMemberPage1.sevenChildren.Checked = False
        SecAddMemberPage1.eightChildren.Checked = False

        ''Reset Children Details
        SecAddMemberPage1.txtChild1Name.Text = ""
        SecAddMemberPage1.txtChild1DoBA.Text = ""

        SecAddMemberPage1.txtChild2Name.Text = ""
        SecAddMemberPage1.txtChild2DoBB.Text = ""

        SecAddMemberPage1.txtChild3Name.Text = ""
        SecAddMemberPage1.txtChild3DoBC.Text = ""

        SecAddMemberPage1.txtChild4Name.Text = ""
        SecAddMemberPage1.txtChild4DoBD.Text = ""

        SecAddMemberPage1.txtChild5Name.Text = ""
        SecAddMemberPage1.txtChild5DoBE.Text = ""

        SecAddMemberPage1.txtChild6Name.Text = ""
        SecAddMemberPage1.txtChild6DoBF.Text = ""

        SecAddMemberPage1.txtChild7Name.Text = ""
        SecAddMemberPage1.txtChild7DoBG.Text = ""

        SecAddMemberPage1.txtChild8Name.Text = ""
        SecAddMemberPage1.txtChild8DoBH.Text = ""



        ''Reset Add member forms 2
        SecAddMemberPage2.txtMotherName.Text = ""
        SecAddMemberPage2.txtMotherPhone.Text = ""
        SecAddMemberPage2.txtMotherAlive.Checked = False
        SecAddMemberPage2.txtMotherDead.Checked = False

        SecAddMemberPage2.txtFatherName.Text = ""
        SecAddMemberPage2.txtFatherPhone.Text = ""
        SecAddMemberPage2.txtFatherAlive.Checked = False
        SecAddMemberPage2.txtFatherDead.Checked = False

        'Check Beneficiary to default
        SecAddMemberPage2.txtNoBeneficiary.Checked = True
        SecAddMemberPage2.oneBeneficiary.Checked = False
        SecAddMemberPage2.twoBeneficiary.Checked = False
        SecAddMemberPage2.threeBeneficiary.Checked = False
        SecAddMemberPage2.fourBeneficiary.Checked = False

        'Reset beneficiaries
        SecAddMemberPage2.txtBeneficiaryOneName.Text = ""
        SecAddMemberPage2.txtBeneficiaryOneDoB.Text = ""
        SecAddMemberPage2.txtBeneficiaryOnePhone.Text = ""
        SecAddMemberPage2.txtBeneficiaryOneAddress.Text = ""
        SecAddMemberPage2.txtBeneficiaryOneRelation.Text = ""
        SecAddMemberPage2.txtBeneficiaryOneProportion.Text = ""


        SecAddMemberPage2.txtBeneficiaryTwoName.Text = ""
        SecAddMemberPage2.txtBeneficiaryTwoDoB.Text = ""
        SecAddMemberPage2.txtBeneficiaryTwoPhone.Text = ""
        SecAddMemberPage2.txtBeneficiaryTwoAddress.Text = ""
        SecAddMemberPage2.txtBeneficiaryTwoRelation.Text = ""
        SecAddMemberPage2.txtBeneficiaryTwoProportion.Text = ""


        SecAddMemberPage2.txtBeneficiaryThreeName.Text = ""
        SecAddMemberPage2.txtBeneficiaryThreeDoB.Text = ""
        SecAddMemberPage2.txtBeneficiaryThreePhone.Text = ""
        SecAddMemberPage2.txtBeneficiaryThreeAddress.Text = ""
        SecAddMemberPage2.txtBeneficiaryThreeRelation.Text = ""
        SecAddMemberPage2.txtBeneficiaryThreeProportion.Text = ""

        SecAddMemberPage2.txtBeneficiaryFourName.Text = ""
        SecAddMemberPage2.txtBeneficiaryFourDoB.Text = ""
        SecAddMemberPage2.txtBeneficiaryFourPhone.Text = ""
        SecAddMemberPage2.txtBeneficiaryFourAddress.Text = ""
        SecAddMemberPage2.txtBeneficiaryFourRelation.Text = ""
        SecAddMemberPage2.txtBeneficiaryFourProportion.Text = ""

        SecAddMemberPage2.txtAcceptAgreement.Checked = False

    End Sub

    'NewChart Values

    'Variaables to be used at User Add Members Page

    'Debtor Tab functions

    Public Sub debtorsCount()
        ' Get the current month and year
        Dim currentMonth As Integer = DateTime.Now.Month
        Dim currentYear As Integer = DateTime.Now.Year

        Dim count As Integer = 0

        Try
            Con.Open()
            ' Query to find and count members who have not paid for the current month and year
            Dim query As String = "
        SELECT COUNT(DISTINCT Member_ID) AS DebtorCount
        FROM ContributionsTbl c1
        WHERE NOT EXISTS (
            SELECT 1
            FROM ContributionsTbl c2
            WHERE c2.Member_ID = c1.Member_ID
            AND MONTH(c2.Month_Of_Payment) = @Month
            AND YEAR(c2.Month_Of_Payment) = @Year
        )"

            ' Create a new SqlCommand with a parameterized query
            Using cmd As New SqlCommand(query, Con)
                ' Add parameters to the query
                cmd.Parameters.AddWithValue("@Month", currentMonth)
                cmd.Parameters.AddWithValue("@Year", currentYear)

                ' Execute the query and get the count
                count = Convert.ToInt32(cmd.ExecuteScalar())
                totalDebtors = count.ToString
                If (Convert.ToInt32(totalDebtors) < 1) Then
                    UserPage.txtNoDebtors.Visible = False
                    UserPage.txtNoDebtors.Text = totalDebtors
                Else
                    UserPage.txtNoDebtors.Visible = True
                    UserPage.txtNoDebtors.Text = totalDebtors
                    UserContributions.TabPage5.Text = "Debtors " + totalDebtors
                End If

            End Using
        Catch ex As Exception
            ' Handle any errors that may have occurred
            MsgBox("An error occurred: " & ex.Message)
        Finally
            ' Ensure the connection is closed
            Con.Close()
        End Try

    End Sub

End Module
