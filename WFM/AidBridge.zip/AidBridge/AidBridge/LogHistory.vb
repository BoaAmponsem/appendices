﻿Imports System.Data.SqlClient
Public Class LogHistory
    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select * from ViewlogsTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Username  like '%' +@parm1+ '%' "
            query &= " or Staff_ID like '%' +@parm1+ '%' "
            query &= " or Phone like '%' +@parm1+ '%' "
            query &= " or Gmail like '%' +@parm1+ '%' "
            query &= " or Login_Date like '%' +@parm1+ '%' "
            query &= " or Logout_Date like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using
            '  End Using
        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function

    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select * from ViewlogsTbl"
            cmd = New SqlCommand(query, Con)
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            LogDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        LogDataGridView.DataSource = Me.SearchItem
    End Sub

    Private Sub LogHistory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
    End Sub
End Class