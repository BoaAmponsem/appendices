﻿Imports System.Net.Mail
Imports System.Data.SqlClient
Imports System.Runtime.InteropServices
Imports System.Drawing.Drawing2D

Public Class UserForgotPasswordAuthentication

    Private borderRadius As Integer = 6
    Private borderSize As Integer = 4
    Private borderColor As Color = Color.SeaGreen

    'Constractor
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Private Function GetRoundedPath(rect As Rectangle, radius As Single) As GraphicsPath
        Dim path As GraphicsPath = New GraphicsPath()
        Dim curveSize As Single = radius * 2.0F
        path.StartFigure()
        path.AddArc(rect.X, rect.Y, curveSize, curveSize, 180, 90)
        path.AddArc(rect.Right - curveSize, rect.Y, curveSize, curveSize, 270, 90)
        path.AddArc(rect.Right - curveSize, rect.Bottom - curveSize, curveSize, curveSize, 0, 90)
        path.AddArc(rect.X, rect.Bottom - curveSize, curveSize, curveSize, 90, 90)
        path.CloseFigure()
        Return path
    End Function

    Private Sub FormRegionAndBorder(form As Form, radius As Single, graph As Graphics, borderColor As Color, borderSize As Single)
        If Me.WindowState <> FormWindowState.Minimized Then
            Using roundPath As GraphicsPath = GetRoundedPath(form.ClientRectangle, radius)
                Using penBorder As Pen = New Pen(borderColor, borderSize)
                    Using transform As Matrix = New Matrix()

                        graph.SmoothingMode = SmoothingMode.AntiAlias
                        form.Region = New Region(roundPath)
                        If borderSize >= 1 Then
                            Dim rect As Rectangle = form.ClientRectangle
                            Dim scaleX As Single = 1.0F - ((borderSize + 1) / rect.Width)
                            Dim scaleY As Single = 1.0F - ((borderSize + 1) / rect.Height)
                            transform.Scale(scaleX, scaleY)
                            transform.Translate(borderSize / 1.6F, borderSize / 1.6F)
                            graph.Transform = transform
                            graph.DrawPath(penBorder, roundPath)
                        End If
                    End Using
                End Using
            End Using

        End If
    End Sub


    Private Function SendPasswordToMail(userPassword)
        Try
            Cursor = Cursors.WaitCursor
            Dim Setup_Server As New SmtpClient("smtp.gmail.com")
            Dim E_Mail As New MailMessage
            Setup_Server.UseDefaultCredentials = False
            Setup_Server.Credentials = New Net.NetworkCredential("AidBridge2023@gmail.com", "lqzcboofibwodjfx")
            Setup_Server.Port = 587
            Setup_Server.EnableSsl = True
            ' Setup_Server.Host = "setup.gmail.com"
            E_Mail = New MailMessage()
            E_Mail.From = New MailAddress("AidBridge2023@gmail.com")
            E_Mail.To.Add(txtGmail.Text)
            E_Mail.Subject = "Password Verification"
            E_Mail.IsBodyHtml = False
            E_Mail.Body = "Your password is " + userPassword
            Setup_Server.Send(E_Mail)
            MsgBox("Password sent to your G-mail")

            ' Refresh Page
            txtGmail.Text = ""
            txtPhone.Text = ""
            txtStaffID.Text = ""
            txtUsername.Text = ""
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
        End Try
    End Function
    Dim aa As Integer
    Private Sub IconButton3_Click(sender As Object, e As EventArgs) Handles btnVerify.Click
        If (txtGmail.Text = "" Or txtPhone.Text = "" Or txtStaffID.Text = "" Or txtUsername.Text = "") Then
            MsgBox("Empty field(s)")
        Else
            ' Dim encryptUserName = Encrypt(txtUsername.Text)
            Dim encryptUserGmail = Encrypt(txtGmail.Text)
            Dim encryptUserPhone = Encrypt(txtPhone.Text)
            ' Dim encryptUserStaffID = Encrypt(txtStaffID.Text)
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from UsersTbl where Staff_ID='" & txtStaffID.Text & "' and Username='" & txtUsername.Text & "' and Phone='" & encryptUserPhone & "' and Gmail='" & encryptUserGmail & "'"
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa = ds.Tables(0).Rows.Count
            Catch ex As Exception
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try

            If ((aa = 0) = True) Then
                MsgBox("Incorrect Info")
            Else
                MsgBox("Correct Info")
                Try
                    Con.Open()
                    Dim query = "select * from UsersTbl where Staff_ID='" & txtStaffID.Text & "' and Username='" & txtUsername.Text & "' and Phone='" & encryptUserPhone & "' and Gmail='" & encryptUserGmail & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    VerificationPassword = myReader("Password")
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try
                SendPasswordToMail(Decrypt(VerificationPassword))
            End If


        End If


    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Me.Hide()
        Dim nwUserLogin = New LoginFormPage
        nwUserLogin.Show()
    End Sub

    Private Sub UserForgotPasswordAuthentication_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AcceptButton = btnVerify
    End Sub

    'Drag Form

    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub
    Private Sub PanelTitleBar_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseDown
        ReleaseCapture()
        SendMessage(Me.Handle, &H112, &HF012, 0)
        '   btnMaximize.Visible = True
        '  btnNormal.Visible = False
    End Sub
    Protected Overrides ReadOnly Property CreateParams As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            cp.Style = cp.Style Or &H20000
            Return cp
        End Get
    End Property

    Private Sub UserForgotPasswordAuthentication_Paint(sender As Object, e As PaintEventArgs) Handles MyBase.Paint
        FormRegionAndBorder(Me, borderRadius, e.Graphics, borderColor, borderSize)
    End Sub
End Class