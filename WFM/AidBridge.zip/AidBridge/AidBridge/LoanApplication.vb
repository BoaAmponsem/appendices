﻿Imports System.Data.SqlClient
Public Class LoanApplication
    Sub switchPages(ByVal pageSwitch1 As Form)
        Try

            UserPage.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            UserPage.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub BackBtn_Click(sender As Object, e As EventArgs) Handles BackBtn.Click
        switchPages(LoansPage)
    End Sub
End Class