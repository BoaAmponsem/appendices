﻿Imports System.Data.SqlClient
Public Class SecAddMemberPage1
    Sub switchPages(ByVal pageSwitch1 As Form)
        Try

            SecretryForm.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            SecretryForm.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub

    Dim aa2 As Integer = 0
    Private Sub checkIfMemberIsRemoved()
        'Check if member is Already registered
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from ExclusionTbl where Staff_ID ='" & txtMemberStaffID.Text & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa2 = ds.Tables(0).Rows.Count
        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

    End Sub

    Dim first4 As String
    Dim last3 As String

    Dim containsNumber As Boolean, containsNumber2 As Boolean, containsNumber3 As Boolean, containsNumber4 As Boolean, containsNumber5 As Boolean, containsNumber6 As Boolean, containsNumber7 As Boolean
    Dim containsNumber8 As Boolean, containsNumber9 As Boolean, containsNumber10 As Boolean
    Private Sub NextBtn_Click(sender As Object, e As EventArgs) Handles NextBtn.Click
        checkIfMemberIsRemoved()

        Dim getTheYearOfBirth As Integer = Convert.ToInt32(txtMemberDoB.Value.Year)

        Try
            If (txtMemberStaffID.Text.Length = 4) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(0, 4)
            ElseIf (txtMemberStaffID.Text.Length = 5) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 1)
            ElseIf (txtMemberStaffID.Text.Length = 6) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 2)
            ElseIf (txtMemberStaffID.Text.Length = 7) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 3)
            ElseIf (txtMemberStaffID.Text.Length = 8) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 4)
            ElseIf (txtMemberStaffID.Text.Length = 9) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 5)
            ElseIf (txtMemberStaffID.Text.Length = 10) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 6)
            ElseIf (txtMemberStaffID.Text.Length = 11) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 7)
            ElseIf (txtMemberStaffID.Text.Length = 12) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 8)
            ElseIf (txtMemberStaffID.Text.Length = 13) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 9)
            ElseIf (txtMemberStaffID.Text.Length = 14) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 10)
            ElseIf (txtMemberStaffID.Text.Length = 15) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 11)
            ElseIf (txtMemberStaffID.Text.Length = 16) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 12)
            ElseIf (txtMemberStaffID.Text.Length = 17) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 13)
            ElseIf (txtMemberStaffID.Text.Length = 18) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 14)
            ElseIf (txtMemberStaffID.Text.Length = 19) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 15)
            End If
        Catch ex As Exception

        End Try


        If (txtMemberSurname.Text IsNot "") Then
            containsNumber = txtMemberSurname.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtMemberOthername.Text IsNot "") Then

            containsNumber2 = txtMemberOthername.Text.Any(Function(c) Char.IsDigit(c))

        End If


        ''Children Name
        If (txtChild1Name.Text IsNot "") Then
            containsNumber3 = txtChild1Name.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtChild2Name.Text IsNot "") Then

            containsNumber4 = txtChild2Name.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtChild3Name.Text IsNot "") Then
            containsNumber5 = txtChild3Name.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtChild4Name.Text IsNot "") Then

            containsNumber6 = txtChild4Name.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtChild5Name.Text IsNot "") Then
            containsNumber7 = txtChild5Name.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtChild6Name.Text IsNot "") Then

            containsNumber8 = txtChild6Name.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtChild7Name.Text IsNot "") Then
            containsNumber9 = txtChild7Name.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtChild8Name.Text IsNot "") Then

            containsNumber10 = txtChild8Name.Text.Any(Function(c) Char.IsDigit(c))

        End If






        ' Storing the member's details in the public variables to insert it to the database
        If (txtMemberSurname.Text = "") Then
            MessageBox.Show("Enter the member's 'Surname'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberSurname.Focus()
        ElseIf (IsNumeric(txtMemberSurname.Text) = True Or containsNumber) Then
            MessageBox.Show("Invalid member's 'Surname'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberSurname.Focus()
        ElseIf (txtMemberOthername.Text = "") Then
            MessageBox.Show("Enter the member's 'Other Names'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberOthername.Focus()
        ElseIf (IsNumeric(txtMemberOthername.Text) = True Or containsNumber2) Then
            MessageBox.Show("Invalid member's 'Other Names'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberOthername.Focus()
        ElseIf (txtMemberPostalAddress.Text = "") Then
            MessageBox.Show("Enter the member's 'Postal Address'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberPostalAddress.Focus()
        ElseIf (txtMemberHouseNo.Text = "") Then
            MessageBox.Show("Enter the member's 'House'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberHouseNo.Focus()
        ElseIf (txtMemberSex.Text = "") Then
            MessageBox.Show("Select the member's 'Sex'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberSex.Focus()
        ElseIf (txtMemberHometown.Text = "") Then
            MessageBox.Show("Enter the member's 'Hometown'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberHometown.Focus()
        ElseIf (txtMaritalStatus.Text = "") Then
            MessageBox.Show(" Set the member's 'Marital Status'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMaritalStatus.Focus()
        ElseIf (txtMemberDoB1.Text.Length < 7) Then
            MessageBox.Show("Set the member's 'Date Of Birth'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberDoB.Focus()
        ElseIf (getTheYearOfBirth > 2006) Then
            MessageBox.Show("The minimum age should be '18 years'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberDoB.Focus()
        ElseIf (txtMemberStaffID.Text = "") Then
            MessageBox.Show("Enter the member's Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length > 19 Or txtMemberStaffID.Text.Length < 4) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 4 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 5 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 6 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 7 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 8 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 9 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 10 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 11 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 12 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 13 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 14 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 15 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 16 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 17 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 18 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberStaffID.Text.Length = 19 And IsNumeric(last3) = False) Then
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMemberStaffID.Focus()
        ElseIf (txtMemberPhone.Text = "") Then
            MsgBox("Enter the member's Phone number")
            txtMemberPhone.Focus()
        ElseIf (txtMemberPhone.Text.Length < 10 Or txtMemberPhone.Text.Length > 10 Or IsNumeric(txtMemberPhone.Text) = False) Then
            MsgBox("Invalid member's Phone number")
            txtMemberPhone.Focus()
        ElseIf (txtMaritalStatus.Text = "") Then
            MsgBox("Select the member's 'Marital Status'")
            txtMaritalStatus.Focus()
        ElseIf (noProfilePic.Checked = False And txtImageName.Text = "") Then
            MessageBox.Show("Add the member's 'Profile Picture'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtImageName.Focus()
        ElseIf (aa2 <> 0) Then
            MessageBox.Show("Staff-ID is in the 'Exclution List'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        ElseIf (txtMaritalStatus.Text = "Single" And first4.ToLower = "sno-" Or first4.ToLower = "gov-" Or first4.ToLower = "adb-") Then
            ' Member Personal Details When Single
            memberASurname = txtMemberSurname.Text.ToUpper
            memberAOthername = txtMemberOthername.Text.ToUpper
            memberASex = txtMemberSex.Text
            memberAPhone = txtMemberPhone.Text
            memberAHouseNo = txtMemberHouseNo.Text.ToUpper
            memberAPostalAddress = txtMemberPostalAddress.Text.ToUpper
            memberAMaritalStatus = txtMaritalStatus.Text
            memberAHomeTown = txtMemberHometown.Text.ToUpper
            memberADoB = txtMemberDoB.Value
            memberAStaffID = txtMemberStaffID.Text.ToUpper
            memberAPicture = txtImageName.Text


            ''Children side
            If (noChild.Checked = True) Then
                switchPages(SecAddMemberPage2)
            End If

            ''child one detail
            If (oneChild.Checked = True) Then
                ' MsgBox("Enter the child's name")
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the child's name")
                    txtChild1Name.Focus()
                ElseIf (IsNumeric(txtChild1Name.Text) = True Or containsNumber3) Then
                    MsgBox("Invalid child name")
                    txtChild1Name.Focus()
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the child's Date Of Birth(DoB)")
                    txtChild1DoBA.Focus()
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If


            ''Two children details
            If (twoChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                    txtChild1Name.Focus()
                ElseIf (IsNumeric(txtChild1Name.Text) = True Or containsNumber3) Then
                    MsgBox("The first child's name is Invalid")
                    txtChild1Name.Focus()
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                    txtChild2Name.Focus()
                ElseIf (IsNumeric(txtChild2Name.Text) = True Or containsNumber4) Then
                    MsgBox("The second child's name is Invalid")
                    txtChild2Name.Focus()
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                    txtChild1DoBA.Focus()
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                    txtChild2DoBB.Focus()
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    switchPages(SecAddMemberPage2)
                End If


            End If

            ''three children details
            If (threeChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                    txtChild1Name.Focus()
                ElseIf (IsNumeric(txtChild1Name.Text) = True Or containsNumber3) Then
                    MsgBox("The first child's name is Invalid")
                    txtChild1Name.Focus()
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                    txtChild2Name.Focus()
                ElseIf (IsNumeric(txtChild2Name.Text) = True Or containsNumber4) Then
                    MsgBox("The second child's name is Invalid")
                    txtChild2Name.Focus()
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                    txtChild3Name.Focus()
                ElseIf (IsNumeric(txtChild3Name.Text) = True Or containsNumber5) Then
                    MsgBox("The Third child's name is Invalid")
                    txtChild3Name.Focus()
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                    txtChild1DoBA.Focus()
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                    txtChild2DoBB.Focus()
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                    txtChild3DoBC.Focus()
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            ''Four children details
            If (fourChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                    txtChild1Name.Focus()
                ElseIf (IsNumeric(txtChild1Name.Text) = True Or containsNumber3) Then
                    MsgBox("The first child's name is Invalid")
                    txtChild1Name.Focus()
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                    txtChild2Name.Focus()
                ElseIf (IsNumeric(txtChild2Name.Text) = True Or containsNumber4) Then
                    MsgBox("The second child's name is Invalid")
                    txtChild2Name.Focus()
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                    txtChild3Name.Focus()
                ElseIf (IsNumeric(txtChild3Name.Text) = True Or containsNumber5) Then
                    MsgBox("The third child's name is Invalid")
                    txtChild3Name.Focus()
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                    txtChild4Name.Focus()
                ElseIf (IsNumeric(txtChild4Name.Text) = True Or containsNumber6) Then
                    MsgBox("The fourth child's name is Invalid")
                    txtChild4Name.Focus()
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                    txtChild1DoBA.Focus()
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                    txtChild2DoBB.Focus()
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                    txtChild3DoBC.Focus()
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    txtChild4DoBD.Focus()
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            ''Five children details
            If (fiveChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                    txtChild1Name.Focus()
                ElseIf (IsNumeric(txtChild1Name.Text) = True Or containsNumber3) Then
                    MsgBox("The first child's name is Invalid")
                    txtChild1Name.Focus()
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                    txtChild2Name.Focus()
                ElseIf (IsNumeric(txtChild2Name.Text) = True Or containsNumber4) Then
                    MsgBox("The second child's name is Invalid")
                    txtChild2Name.Focus()
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                    txtChild3Name.Focus()
                ElseIf (IsNumeric(txtChild3Name.Text) = True Or containsNumber5) Then
                    MsgBox("The third child's name is Invalid")
                    txtChild3Name.Focus()
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                    txtChild4Name.Focus()
                ElseIf (IsNumeric(txtChild4Name.Text) = True Or containsNumber6) Then
                    MsgBox("The fourth child's name is Invalid")
                    txtChild4Name.Focus()
                ElseIf (txtChild5Name.Text = "") Then
                    MsgBox("Enter the fifth child's name")
                    txtChild5Name.Focus()
                ElseIf (IsNumeric(txtChild5Name.Text) = True Or containsNumber7) Then
                    MsgBox("The fifth child's name is Invalid")
                    txtChild5Name.Focus()
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                    txtChild1DoBA.Focus()
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                    txtChild2DoBB.Focus()
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                    txtChild3DoBC.Focus()
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    txtChild4DoBD.Focus()
                ElseIf (txtChild5DoBE.Text.Length < 8) Then
                    MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    txtChild5DoBE.Focus()
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    memberAChild5name = txtChild5Name.Text.ToUpper
                    memberAChild5DoB = txtChild5DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            ''Six children details
            If (sixChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                    txtChild1Name.Focus()
                ElseIf (IsNumeric(txtChild1Name.Text) = True Or containsNumber3) Then
                    MsgBox("The first child's name is Invalid")
                    txtChild1Name.Focus()
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                    txtChild2Name.Focus()
                ElseIf (IsNumeric(txtChild2Name.Text) = True Or containsNumber4) Then
                    MsgBox("The second child's name is Invalid")
                    txtChild2Name.Focus()
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                    txtChild3Name.Focus()
                ElseIf (IsNumeric(txtChild3Name.Text) = True Or containsNumber5) Then
                    MsgBox("The third child's name is Invalid")
                    txtChild3Name.Focus()
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                    txtChild4Name.Focus()
                ElseIf (IsNumeric(txtChild4Name.Text) = True Or containsNumber6) Then
                    MsgBox("The fourth child's name is Invalid")
                    txtChild4Name.Focus()
                ElseIf (txtChild5Name.Text = "") Then
                    MsgBox("Enter the fifth child's name")
                    txtChild5Name.Focus()
                ElseIf (IsNumeric(txtChild5Name.Text) = True Or containsNumber7) Then
                    MsgBox("The fifth child's name is Invalid")
                    txtChild5Name.Focus()
                ElseIf (txtChild6Name.Text = "") Then
                    MsgBox("Enter the sixth child's name")
                ElseIf (IsNumeric(txtChild6Name.Text) = True Or containsNumber8) Then
                    MsgBox("The sixth child's name is Invalid")
                    txtChild6Name.Focus()
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                    txtChild1DoBA.Focus()
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                    txtChild2DoBB.Focus()
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                    txtChild3DoBC.Focus()
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    txtChild4DoBD.Focus()
                ElseIf (txtChild5DoBE.Text.Length < 8) Then
                    MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    txtChild5DoBE.Focus()
                ElseIf (txtChild6DoBF.Text.Length < 8) Then
                    MsgBox("Set the sixth child's Date Of Birth(DoB)")
                    txtChild6DoBF.Focus()
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    memberAChild5name = txtChild5Name.Text.ToUpper
                    memberAChild5DoB = txtChild5DoB.Value
                    memberAChild6name = txtChild6Name.Text.ToUpper
                    memberAChild6DoB = txtChild6DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If


            ''Seven children details
            If (sevenChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                    txtChild1Name.Focus()
                ElseIf (IsNumeric(txtChild1Name.Text) = True Or containsNumber3) Then
                    MsgBox("The first child's name is Invalid")
                    txtChild1Name.Focus()
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                    txtChild2Name.Focus()
                ElseIf (IsNumeric(txtChild2Name.Text) = True Or containsNumber4) Then
                    MsgBox("The second child's name is Invalid")
                    txtChild2Name.Focus()
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                    txtChild3Name.Focus()
                ElseIf (IsNumeric(txtChild3Name.Text) = True Or containsNumber5) Then
                    MsgBox("The third child's name is Invalid")
                    txtChild3Name.Focus()
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                    txtChild4Name.Focus()
                ElseIf (IsNumeric(txtChild4Name.Text) = True Or containsNumber6) Then
                    MsgBox("The fourth child's name is Invalid")
                    txtChild4Name.Focus()
                ElseIf (txtChild5Name.Text = "") Then
                    MsgBox("Enter the fifth child's name")
                    txtChild5Name.Focus()
                ElseIf (IsNumeric(txtChild5Name.Text) = True Or containsNumber7) Then
                    MsgBox("The fifth child's name is Invalid")
                    txtChild5Name.Focus()
                ElseIf (txtChild6Name.Text = "") Then
                    MsgBox("Enter the sixth child's name")
                ElseIf (IsNumeric(txtChild6Name.Text) = True Or containsNumber8) Then
                    MsgBox("The sixth child's name is Invalid")
                    txtChild6Name.Focus()
                ElseIf (txtChild7Name.Text = "") Then
                    MsgBox("Enter the seventh child's name")
                    txtChild7Name.Focus()
                ElseIf (IsNumeric(txtChild7Name.Text) = True Or containsNumber9) Then
                    MsgBox("The seventh child's name is Invalid")
                    txtChild7Name.Focus()
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                    txtChild1DoBA.Focus()
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                    txtChild2DoBB.Focus()
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                    txtChild3DoBC.Focus()
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    txtChild4DoBD.Focus()
                ElseIf (txtChild5DoBE.Text.Length < 8) Then
                    MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    txtChild5DoBE.Focus()
                ElseIf (txtChild6DoBF.Text.Length < 8) Then
                    MsgBox("Set the sixth child's Date Of Birth(DoB)")
                    txtChild6DoBF.Focus()
                ElseIf (txtChild7DoBG.Text.Length < 8) Then
                    MsgBox("Set the seventh child's Date Of Birth(DoB)")
                    txtChild7DoBG.Focus()
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    memberAChild5name = txtChild5Name.Text.ToUpper
                    memberAChild5DoB = txtChild5DoB.Value
                    memberAChild6name = txtChild6Name.Text.ToUpper
                    memberAChild6DoB = txtChild6DoB.Value
                    memberAChild7name = txtChild7Name.Text.ToUpper
                    memberAChild7DoB = txtChild7DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            ''Eight children details
            If (eightChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                    txtChild1Name.Focus()
                ElseIf (IsNumeric(txtChild1Name.Text) = True Or containsNumber3) Then
                    MsgBox("The first child's name is Invalid")
                    txtChild1Name.Focus()
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                    txtChild2Name.Focus()
                ElseIf (IsNumeric(txtChild2Name.Text) = True Or containsNumber4) Then
                    MsgBox("The second child's name is Invalid")
                    txtChild2Name.Focus()
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                    txtChild3Name.Focus()
                ElseIf (IsNumeric(txtChild3Name.Text) = True Or containsNumber5) Then
                    MsgBox("The third child's name is Invalid")
                    txtChild3Name.Focus()
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                    txtChild4Name.Focus()
                ElseIf (IsNumeric(txtChild4Name.Text) = True Or containsNumber6) Then
                    MsgBox("The fourth child's name is Invalid")
                    txtChild4Name.Focus()
                ElseIf (txtChild5Name.Text = "") Then
                    MsgBox("Enter the fifth child's name")
                    txtChild5Name.Focus()
                ElseIf (IsNumeric(txtChild5Name.Text) = True Or containsNumber7) Then
                    MsgBox("The fifth child's name is Invalid")
                    txtChild5Name.Focus()
                ElseIf (txtChild6Name.Text = "") Then
                    MsgBox("Enter the sixth child's name")
                ElseIf (IsNumeric(txtChild6Name.Text) = True Or containsNumber8) Then
                    MsgBox("The sixth child's name is Invalid")
                    txtChild6Name.Focus()
                ElseIf (txtChild7Name.Text = "") Then
                    MsgBox("Enter the seventh child's name")
                    txtChild7Name.Focus()
                ElseIf (IsNumeric(txtChild7Name.Text) = True Or containsNumber9) Then
                    MsgBox("The seventh child's name is Invalid")
                    txtChild7Name.Focus()
                ElseIf (txtChild8Name.Text = "") Then
                    MsgBox("Enter the eighth child's name")
                    txtChild8Name.Focus()
                ElseIf (IsNumeric(txtChild8Name.Text) = True Or containsNumber9) Then
                    MsgBox("The eighth child's name is Invalid")
                    txtChild7Name.Focus()
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                    txtChild1DoBA.Focus()
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                    txtChild2DoBB.Focus()
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                    txtChild3DoBC.Focus()
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    txtChild4DoBD.Focus()
                ElseIf (txtChild5DoBE.Text.Length < 8) Then
                    MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    txtChild5DoBE.Focus()
                ElseIf (txtChild6DoBF.Text.Length < 8) Then
                    MsgBox("Set the sixth child's Date Of Birth(DoB)")
                    txtChild6DoBF.Focus()
                ElseIf (txtChild7DoBG.Text.Length < 8) Then
                    MsgBox("Set the seventh child's Date Of Birth(DoB)")
                    txtChild7DoBG.Focus()
                ElseIf (txtChild8DoBH.Text.Length < 8) Then
                    MsgBox("Set the seventh child's Date Of Birth(DoB)")
                    txtChild8DoBH.Focus()
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    memberAChild5name = txtChild5Name.Text.ToUpper
                    memberAChild5DoB = txtChild5DoB.Value
                    memberAChild6name = txtChild6Name.Text.ToUpper
                    memberAChild6DoB = txtChild6DoB.Value
                    memberAChild7name = txtChild7Name.Text.ToUpper
                    memberAChild7DoB = txtChild7DoB.Value
                    memberAChild8name = txtChild8Name.Text.ToUpper
                    memberAChild8DoB = txtChild8DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            '
            '
        ElseIf (txtMaritalStatus.Text = "Single" And IsNumeric(txtMemberStaffID.Text) = True) Then
            If (noProfilePic.Checked = True) Then
                txtImageName.Text = ""
            End If
            ' Member Personal Details When Single
            memberASurname = txtMemberSurname.Text.ToUpper
            memberAOthername = txtMemberOthername.Text.ToUpper
            memberASex = txtMemberSex.Text
            memberAPhone = txtMemberPhone.Text
            memberAHouseNo = txtMemberHouseNo.Text.ToUpper
            memberAPostalAddress = txtMemberPostalAddress.Text.ToUpper
            memberAMaritalStatus = txtMaritalStatus.Text
            memberAHomeTown = txtMemberHometown.Text.ToUpper
            memberADoB = txtMemberDoB.Value
            memberAStaffID = txtMemberStaffID.Text.ToUpper
            memberAPicture = txtImageName.Text


            ''Children side
            If (noChild.Checked = True) Then
                switchPages(SecAddMemberPage2)

            End If

            ''child one detail
            If (oneChild.Checked = True) Then
                ' MsgBox("Enter the child's name")
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the child's name")
                ElseIf (IsNumeric(txtChild1Name.Text) = True) Then
                    MsgBox("Invalid child name")
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the child's Date Of Birth(DoB)")
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If


            ''Two children details
            If (twoChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                ElseIf (IsNumeric(txtChild1Name.Text) = True) Then
                    MsgBox("The first child's name is Invalid")
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                ElseIf (IsNumeric(txtChild2Name.Text) = True) Then
                    MsgBox("The second child's name is Invalid")
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    switchPages(SecAddMemberPage2)
                End If


            End If

            ''three children details
            If (threeChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                ElseIf (IsNumeric(txtChild1Name.Text) = True) Then
                    MsgBox("The first child's name is Invalid")
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                ElseIf (IsNumeric(txtChild2Name.Text) = True) Then
                    MsgBox("The second child's name is Invalid")
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                ElseIf (IsNumeric(txtChild3Name.Text) = True) Then
                    MsgBox("The Third child's name is Invalid")
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            ''Four children details
            If (fourChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                ElseIf (IsNumeric(txtChild1Name.Text) = True) Then
                    MsgBox("The first child's name is Invalid")
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                ElseIf (IsNumeric(txtChild2Name.Text) = True) Then
                    MsgBox("The second child's name is Invalid")
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                ElseIf (IsNumeric(txtChild3Name.Text) = True) Then
                    MsgBox("The third child's name is Invalid")
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                ElseIf (IsNumeric(txtChild4Name.Text) = True) Then
                    MsgBox("The fourth child's name is Invalid")
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            ''Five children details
            If (fiveChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                ElseIf (IsNumeric(txtChild1Name.Text) = True) Then
                    MsgBox("The first child's name is Invalid")
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                ElseIf (IsNumeric(txtChild2Name.Text) = True) Then
                    MsgBox("The second child's name is Invalid")
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                ElseIf (IsNumeric(txtChild3Name.Text) = True) Then
                    MsgBox("The third child's name is Invalid")
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                ElseIf (IsNumeric(txtChild4Name.Text) = True) Then
                    MsgBox("The fourth child's name is Invalid")
                ElseIf (txtChild5Name.Text = "") Then
                    MsgBox("Enter the fifth child's name")
                ElseIf (IsNumeric(txtChild5Name.Text) = True) Then
                    MsgBox("The fifth child's name is Invalid")
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                ElseIf (txtChild5DoBE.Text.Length < 8) Then
                    MsgBox("Set the fifth child's Date Of Birth(DoB)")
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    memberAChild5name = txtChild5Name.Text.ToUpper
                    memberAChild5DoB = txtChild5DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            ''Six children details
            If (sixChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                ElseIf (IsNumeric(txtChild1Name.Text) = True) Then
                    MsgBox("The first child's name is Invalid")
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                ElseIf (IsNumeric(txtChild2Name.Text) = True) Then
                    MsgBox("The second child's name is Invalid")
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                ElseIf (IsNumeric(txtChild3Name.Text) = True) Then
                    MsgBox("The third child's name is Invalid")
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                ElseIf (IsNumeric(txtChild4Name.Text) = True) Then
                    MsgBox("The fourth child's name is Invalid")
                ElseIf (txtChild5Name.Text = "") Then
                    MsgBox("Enter the fifth child's name")
                ElseIf (IsNumeric(txtChild5Name.Text) = True) Then
                    MsgBox("The fifth child's name is Invalid")
                ElseIf (txtChild6Name.Text = "") Then
                    MsgBox("Enter the sixth child's name")
                ElseIf (IsNumeric(txtChild6Name.Text) = True) Then
                    MsgBox("The sixth child's name is Invalid")
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                ElseIf (txtChild5DoBE.Text.Length < 8) Then
                    MsgBox("Set the fifth child's Date Of Birth(DoB)")
                ElseIf (txtChild6DoBF.Text.Length < 8) Then
                    MsgBox("Set the sixth child's Date Of Birth(DoB)")
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    memberAChild5name = txtChild5Name.Text.ToUpper
                    memberAChild5DoB = txtChild5DoB.Value
                    memberAChild6name = txtChild6Name.Text.ToUpper
                    memberAChild6DoB = txtChild6DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If


            ''Seven children details
            If (sevenChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                ElseIf (IsNumeric(txtChild1Name.Text) = True) Then
                    MsgBox("The first child's name is Invalid")
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                ElseIf (IsNumeric(txtChild2Name.Text) = True) Then
                    MsgBox("The second child's name is Invalid")
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                ElseIf (IsNumeric(txtChild3Name.Text) = True) Then
                    MsgBox("The third child's name is Invalid")
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                ElseIf (IsNumeric(txtChild4Name.Text) = True) Then
                    MsgBox("The fourth child's name is Invalid")
                ElseIf (txtChild5Name.Text = "") Then
                    MsgBox("Enter the fifth child's name")
                ElseIf (IsNumeric(txtChild5Name.Text) = True) Then
                    MsgBox("The fifth child's name is Invalid")
                ElseIf (txtChild6Name.Text = "") Then
                    MsgBox("Enter the sixth child's name")
                ElseIf (IsNumeric(txtChild6Name.Text) = True) Then
                    MsgBox("The sixth child's name is Invalid")
                ElseIf (txtChild7Name.Text = "") Then
                    MsgBox("Enter the seventh child's name")
                ElseIf (IsNumeric(txtChild7Name.Text) = True) Then
                    MsgBox("The seventh child's name is Invalid")
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                ElseIf (txtChild5DoBE.Text.Length < 8) Then
                    MsgBox("Set the fifth child's Date Of Birth(DoB)")
                ElseIf (txtChild6DoBF.Text.Length < 8) Then
                    MsgBox("Set the sixth child's Date Of Birth(DoB)")
                ElseIf (txtChild7DoBG.Text.Length < 8) Then
                    MsgBox("Set the seventh child's Date Of Birth(DoB)")
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    memberAChild5name = txtChild5Name.Text.ToUpper
                    memberAChild5DoB = txtChild5DoB.Value
                    memberAChild6name = txtChild6Name.Text.ToUpper
                    memberAChild6DoB = txtChild6DoB.Value
                    memberAChild7name = txtChild7Name.Text.ToUpper
                    memberAChild7DoB = txtChild7DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            ''Eight children details
            If (eightChildren.Checked = True) Then
                If (txtChild1Name.Text = "") Then
                    MsgBox("Enter the first child's name")
                ElseIf (IsNumeric(txtChild1Name.Text) = True) Then
                    MsgBox("The first child's name is Invalid")
                ElseIf (txtChild2Name.Text = "") Then
                    MsgBox("Enter the second child's name")
                ElseIf (IsNumeric(txtChild2Name.Text) = True) Then
                    MsgBox("The second child's name is Invalid")
                ElseIf (txtChild3Name.Text = "") Then
                    MsgBox("Enter the third child's name")
                ElseIf (IsNumeric(txtChild3Name.Text) = True) Then
                    MsgBox("The third child's name is Invalid")
                ElseIf (txtChild4Name.Text = "") Then
                    MsgBox("Enter the fourth child's name")
                ElseIf (IsNumeric(txtChild4Name.Text) = True) Then
                    MsgBox("The fourth child's name is Invalid")
                ElseIf (txtChild5Name.Text = "") Then
                    MsgBox("Enter the fifth child's name")
                ElseIf (IsNumeric(txtChild5Name.Text) = True) Then
                    MsgBox("The fifth child's name is Invalid")
                ElseIf (txtChild6Name.Text = "") Then
                    MsgBox("Enter the sixth child's name")
                ElseIf (IsNumeric(txtChild6Name.Text) = True) Then
                    MsgBox("The sixth child's name is Invalid")
                ElseIf (txtChild7Name.Text = "") Then
                    MsgBox("Enter the seventh child's name")
                ElseIf (IsNumeric(txtChild7Name.Text) = True) Then
                    MsgBox("The seventh child's name is Invalid")
                ElseIf (txtChild8Name.Text = "") Then
                    MsgBox("Enter the eighth child's name")
                ElseIf (IsNumeric(txtChild8Name.Text) = True) Then
                    MsgBox("The eighth child's name is Invalid")
                ElseIf (txtChild1DoBA.Text.Length < 8) Then
                    MsgBox("Set the first child's Date Of Birth(DoB)")
                ElseIf (txtChild2DoBB.Text.Length < 8) Then
                    MsgBox("Set the second child's Date Of Birth(DoB)")
                ElseIf (txtChild3DoBC.Text.Length < 8) Then
                    MsgBox("Set the third child's Date Of Birth(DoB)")
                ElseIf (txtChild4DoBD.Text.Length < 8) Then
                    MsgBox("Set the fourth child's Date Of Birth(DoB)")
                ElseIf (txtChild5DoBE.Text.Length < 8) Then
                    MsgBox("Set the fifth child's Date Of Birth(DoB)")
                ElseIf (txtChild6DoBF.Text.Length < 8) Then
                    MsgBox("Set the sixth child's Date Of Birth(DoB)")
                ElseIf (txtChild7DoBG.Text.Length < 8) Then
                    MsgBox("Set the seventh child's Date Of Birth(DoB)")
                ElseIf (txtChild8DoBH.Text.Length < 8) Then
                    MsgBox("Set the seventh child's Date Of Birth(DoB)")
                Else
                    memberAChild1name = txtChild1Name.Text.ToUpper
                    memberAChild1DoB = txtChild1DoB.Value
                    memberAChild2name = txtChild2Name.Text.ToUpper
                    memberAChild2DoB = txtChild2DoB.Value
                    memberAChild3name = txtChild3Name.Text.ToUpper
                    memberAChild3DoB = txtChild3DoB.Value
                    memberAChild4name = txtChild4Name.Text.ToUpper
                    memberAChild4DoB = txtChild4DoB.Value
                    memberAChild5name = txtChild5Name.Text.ToUpper
                    memberAChild5DoB = txtChild5DoB.Value
                    memberAChild6name = txtChild6Name.Text.ToUpper
                    memberAChild6DoB = txtChild6DoB.Value
                    memberAChild7name = txtChild7Name.Text.ToUpper
                    memberAChild7DoB = txtChild7DoB.Value
                    memberAChild8name = txtChild8Name.Text.ToUpper
                    memberAChild8DoB = txtChild8DoB.Value
                    switchPages(SecAddMemberPage2)
                End If
            End If

            '

            '


            '
            '

        ElseIf (txtMaritalStatus.Text = "Married" And txtTypeOfMarriage.Text = "") Then
            MsgBox("Select the 'Type Of Marriage'")
        ElseIf (first4.ToLower = "sno-" Or first4.ToLower = "gov-" Or first4.ToLower = "adb-") Then

            ' Member Personal Details When Married
            memberASurname = txtMemberSurname.Text.ToUpper
            memberAOthername = txtMemberOthername.Text.ToUpper
            memberASex = txtMemberSex.Text
            memberAPhone = txtMemberPhone.Text
            memberAHouseNo = txtMemberHouseNo.Text.ToUpper
            memberAPostalAddress = txtMemberPostalAddress.Text.ToUpper
            memberAMaritalStatus = txtMaritalStatus.Text
            memberATypeOfMarriage = txtTypeOfMarriage.Text
            memberAHomeTown = txtMemberHometown.Text.ToUpper
            memberADoB = txtMemberDoB.Value
            memberAStaffID = txtMemberStaffID.Text.ToUpper
            memberAPicture = txtImageName.Text

            'If (txtMaritalStatus.Text = "Married") Then
            ' MsgBox(" or Address field is empty")
            ' Else
            If (txtSpouseName.Text = "") Then
                MsgBox("Enter the Spouse's Name")
            ElseIf (txtSpouseAddress.Text = "") Then
                MsgBox("Enter the Spouse's Address")
            ElseIf (txtSpousePhone.Text.Length < 14) Then
                MsgBox("Invalid Phone number e.g (024)000-0000)")
            ElseIf ((txtSpouseName.Text = "") = False And (txtSpouseAddress.Text = "") = False)
                ''Spouse Details
                memberASpouseName = txtSpouseName.Text.ToUpper
                memberASpousePhone = txtSpousePhone.Text
                memberASpouseAddress = txtSpouseAddress.Text.ToUpper

                ''Children side
                If (noChild.Checked = True) Then
                    switchPages(SecAddMemberPage2)
                End If

                ''child one detail
                If (oneChild.Checked = True) Then
                    ' MsgBox("Enter the child's name")
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If


                ''Two children details
                If (twoChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If


                End If

                ''three children details
                If (threeChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If

                ''Four children details
                If (fourChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If

                ''Five children details
                If (fiveChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild5Name.Text = "") Then
                        MsgBox("Enter the fifth child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    ElseIf (txtChild5DoBE.Text.Length < 8) Then
                        MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        memberAChild5name = txtChild5Name.Text.ToUpper
                        memberAChild5DoB = txtChild5DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If

                ''Six children details
                If (sixChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild5Name.Text = "") Then
                        MsgBox("Enter the fifth child's name")
                    ElseIf (txtChild6Name.Text = "") Then
                        MsgBox("Enter the sixth child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    ElseIf (txtChild5DoBE.Text.Length < 8) Then
                        MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    ElseIf (txtChild6DoBF.Text.Length < 8) Then
                        MsgBox("Set the sixth child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        memberAChild5name = txtChild5Name.Text.ToUpper
                        memberAChild5DoB = txtChild5DoB.Value
                        memberAChild6name = txtChild6Name.Text.ToUpper
                        memberAChild6DoB = txtChild6DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If


                ''Seven children details
                If (sevenChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild5Name.Text = "") Then
                        MsgBox("Enter the fifth child's name")
                    ElseIf (txtChild6Name.Text = "") Then
                        MsgBox("Enter the sixth child's name")
                    ElseIf (txtChild7Name.Text = "") Then
                        MsgBox("Enter the seventh child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    ElseIf (txtChild5DoBE.Text.Length < 8) Then
                        MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    ElseIf (txtChild6DoBF.Text.Length < 8) Then
                        MsgBox("Set the sixth child's Date Of Birth(DoB)")
                    ElseIf (txtChild7DoBG.Text.Length < 8) Then
                        MsgBox("Set the seventh child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        memberAChild5name = txtChild5Name.Text.ToUpper
                        memberAChild5DoB = txtChild5DoB.Value
                        memberAChild6name = txtChild6Name.Text.ToUpper
                        memberAChild6DoB = txtChild6DoB.Value
                        memberAChild7name = txtChild7Name.Text.ToUpper
                        memberAChild7DoB = txtChild7DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If

                ''Eight children details
                If (eightChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild5Name.Text = "") Then
                        MsgBox("Enter the fifth child's name")
                    ElseIf (txtChild6Name.Text = "") Then
                        MsgBox("Enter the sixth child's name")
                    ElseIf (txtChild7Name.Text = "") Then
                        MsgBox("Enter the seventh child's name")
                    ElseIf (txtChild8Name.Text = "") Then
                        MsgBox("Enter the eighth child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    ElseIf (txtChild5DoBE.Text.Length < 8) Then
                        MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    ElseIf (txtChild6DoBF.Text.Length < 8) Then
                        MsgBox("Set the sixth child's Date Of Birth(DoB)")
                    ElseIf (txtChild7DoBG.Text.Length < 8) Then
                        MsgBox("Set the seventh child's Date Of Birth(DoB)")
                    ElseIf (txtChild8DoBH.Text.Length < 8) Then
                        MsgBox("Set the seventh child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        memberAChild5name = txtChild5Name.Text.ToUpper
                        memberAChild5DoB = txtChild5DoB.Value
                        memberAChild6name = txtChild6Name.Text.ToUpper
                        memberAChild6DoB = txtChild6DoB.Value
                        memberAChild7name = txtChild7Name.Text.ToUpper
                        memberAChild7DoB = txtChild7DoB.Value
                        memberAChild8name = txtChild8Name.Text.ToUpper
                        memberAChild8DoB = txtChild8DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                    'Children End If
                End If
                'Married End If
            End If
        ElseIf (IsNumeric(txtMemberStaffID.Text) = True) Then

            ' Member Personal Details When Married
            memberASurname = txtMemberSurname.Text.ToUpper
            memberAOthername = txtMemberOthername.Text.ToUpper
            memberASex = txtMemberSex.Text
            memberAPhone = txtMemberPhone.Text
            memberAHouseNo = txtMemberHouseNo.Text.ToUpper
            memberAPostalAddress = txtMemberPostalAddress.Text.ToUpper
            memberAMaritalStatus = txtMaritalStatus.Text
            memberATypeOfMarriage = txtTypeOfMarriage.Text
            memberAHomeTown = txtMemberHometown.Text.ToUpper
            memberADoB = txtMemberDoB.Value
            memberAStaffID = txtMemberStaffID.Text.ToUpper
            memberAPicture = txtImageName.Text

            ' If (txtMaritalStatus.Text = "Married") Then
            ' MsgBox(" or Address field is empty")
            ' Else
            If (txtSpouseName.Text = "") Then
                MsgBox("Enter the Spouse's Name")
            ElseIf (txtSpousePhone.Text.Length < 14) Then
                MsgBox("Invalid Phone number e.g (024)000-0000)")
            ElseIf (txtSpouseAddress.Text = "") Then
                MsgBox("Enter the Spouse's Address")
            ElseIf ((txtSpouseName.Text = "") = False And (txtSpouseAddress.Text = "") = False)
                ''Spouse Details
                memberASpouseName = txtSpouseName.Text.ToUpper
                memberASpousePhone = txtSpousePhone.Text
                memberASpouseAddress = txtSpouseAddress.Text.ToUpper
                '
                '
                ''Children side
                If (noChild.Checked = True) Then
                    switchPages(SecAddMemberPage2)
                End If

                ''child one detail
                If (oneChild.Checked = True) Then
                    ' MsgBox("Enter the child's name")
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If

                ''Two children details
                If (twoChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If


                End If

                ''three children details
                If (threeChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If

                ''Four children details
                If (fourChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If

                ''Five children details
                If (fiveChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild5Name.Text = "") Then
                        MsgBox("Enter the fifth child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    ElseIf (txtChild5DoBE.Text.Length < 8) Then
                        MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        memberAChild5name = txtChild5Name.Text.ToUpper
                        memberAChild5DoB = txtChild5DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If

                ''Six children details
                If (sixChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild5Name.Text = "") Then
                        MsgBox("Enter the fifth child's name")
                    ElseIf (txtChild6Name.Text = "") Then
                        MsgBox("Enter the sixth child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    ElseIf (txtChild5DoBE.Text.Length < 8) Then
                        MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    ElseIf (txtChild6DoBF.Text.Length < 8) Then
                        MsgBox("Set the sixth child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        memberAChild5name = txtChild5Name.Text.ToUpper
                        memberAChild5DoB = txtChild5DoB.Value
                        memberAChild6name = txtChild6Name.Text.ToUpper
                        memberAChild6DoB = txtChild6DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If


                ''Seven children details
                If (sevenChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild5Name.Text = "") Then
                        MsgBox("Enter the fifth child's name")
                    ElseIf (txtChild6Name.Text = "") Then
                        MsgBox("Enter the sixth child's name")
                    ElseIf (txtChild7Name.Text = "") Then
                        MsgBox("Enter the seventh child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    ElseIf (txtChild5DoBE.Text.Length < 8) Then
                        MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    ElseIf (txtChild6DoBF.Text.Length < 8) Then
                        MsgBox("Set the sixth child's Date Of Birth(DoB)")
                    ElseIf (txtChild7DoBG.Text.Length < 8) Then
                        MsgBox("Set the seventh child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        memberAChild5name = txtChild5Name.Text.ToUpper
                        memberAChild5DoB = txtChild5DoB.Value
                        memberAChild6name = txtChild6Name.Text.ToUpper
                        memberAChild6DoB = txtChild6DoB.Value
                        memberAChild7name = txtChild7Name.Text.ToUpper
                        memberAChild7DoB = txtChild7DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                End If

                ''Eight children details
                If (eightChildren.Checked = True) Then
                    If (txtChild1Name.Text = "") Then
                        MsgBox("Enter the first child's name")
                    ElseIf (txtChild2Name.Text = "") Then
                        MsgBox("Enter the second child's name")
                    ElseIf (txtChild3Name.Text = "") Then
                        MsgBox("Enter the third child's name")
                    ElseIf (txtChild4Name.Text = "") Then
                        MsgBox("Enter the fourth child's name")
                    ElseIf (txtChild5Name.Text = "") Then
                        MsgBox("Enter the fifth child's name")
                    ElseIf (txtChild6Name.Text = "") Then
                        MsgBox("Enter the sixth child's name")
                    ElseIf (txtChild7Name.Text = "") Then
                        MsgBox("Enter the seventh child's name")
                    ElseIf (txtChild8Name.Text = "") Then
                        MsgBox("Enter the eighth child's name")
                    ElseIf (txtChild1DoBA.Text.Length < 8) Then
                        MsgBox("Set the first child's Date Of Birth(DoB)")
                    ElseIf (txtChild2DoBB.Text.Length < 8) Then
                        MsgBox("Set the second child's Date Of Birth(DoB)")
                    ElseIf (txtChild3DoBC.Text.Length < 8) Then
                        MsgBox("Set the third child's Date Of Birth(DoB)")
                    ElseIf (txtChild4DoBD.Text.Length < 8) Then
                        MsgBox("Set the fourth child's Date Of Birth(DoB)")
                    ElseIf (txtChild5DoBE.Text.Length < 8) Then
                        MsgBox("Set the fifth child's Date Of Birth(DoB)")
                    ElseIf (txtChild6DoBF.Text.Length < 8) Then
                        MsgBox("Set the sixth child's Date Of Birth(DoB)")
                    ElseIf (txtChild7DoBG.Text.Length < 8) Then
                        MsgBox("Set the seventh child's Date Of Birth(DoB)")
                    ElseIf (txtChild8DoBH.Text.Length < 8) Then
                        MsgBox("Set the seventh child's Date Of Birth(DoB)")
                    Else
                        memberAChild1name = txtChild1Name.Text.ToUpper
                        memberAChild1DoB = txtChild1DoB.Value
                        memberAChild2name = txtChild2Name.Text.ToUpper
                        memberAChild2DoB = txtChild2DoB.Value
                        memberAChild3name = txtChild3Name.Text.ToUpper
                        memberAChild3DoB = txtChild3DoB.Value
                        memberAChild4name = txtChild4Name.Text.ToUpper
                        memberAChild4DoB = txtChild4DoB.Value
                        memberAChild5name = txtChild5Name.Text.ToUpper
                        memberAChild5DoB = txtChild5DoB.Value
                        memberAChild6name = txtChild6Name.Text.ToUpper
                        memberAChild6DoB = txtChild6DoB.Value
                        memberAChild7name = txtChild7Name.Text.ToUpper
                        memberAChild7DoB = txtChild7DoB.Value
                        memberAChild8name = txtChild8Name.Text.ToUpper
                        memberAChild8DoB = txtChild8DoB.Value
                        switchPages(SecAddMemberPage2)
                    End If
                    'Children End If
                End If
                '
                'Married End If
            End If

            '
            '
            '
        Else
            MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

            '
            'Main End If
        End If
    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        Dim nwSecMembers = New SecMembers
        switchPages(nwSecMembers)
    End Sub

    Private Sub noChild_CheckedChanged(sender As Object, e As EventArgs) Handles noChild.CheckedChanged
        Try
            txtChild1Name.ReadOnly = True
            txtChild1DoBA.ReadOnly = True
            txtChild2Name.ReadOnly = True
            txtChild2DoBB.ReadOnly = True
            txtChild3Name.ReadOnly = True
            txtChild3DoBC.ReadOnly = True
            txtChild4Name.ReadOnly = True
            txtChild4DoBD.ReadOnly = True
            txtChild5Name.ReadOnly = True
            txtChild5DoBE.ReadOnly = True
            txtChild6Name.ReadOnly = True
            txtChild6DoBF.ReadOnly = True
            txtChild7Name.ReadOnly = True
            txtChild7DoBG.ReadOnly = True
            txtChild8Name.ReadOnly = True
            txtChild8DoBH.ReadOnly = True


            ' Delete TextBox Values 
            txtChild1Name.Text = ""
            txtChild1DoBA.Text = ""
            txtChild2Name.Text = ""
            txtChild2DoBB.Text = ""
            txtChild3Name.Text = ""
            txtChild3DoBC.Text = ""
            txtChild4Name.Text = ""
            txtChild4DoBD.Text = ""
            txtChild5Name.Text = ""
            txtChild5DoBE.Text = ""
            txtChild6Name.Text = ""
            txtChild6DoBF.Text = ""
            txtChild7Name.Text = ""
            txtChild7DoBG.Text = ""
            txtChild8Name.Text = ""
            txtChild8DoBH.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub oneChild_CheckedChanged(sender As Object, e As EventArgs) Handles oneChild.CheckedChanged
        Try
            txtChild1Name.ReadOnly = False
            txtChild1DoBA.ReadOnly = False
            txtChild2Name.ReadOnly = True
            txtChild2DoBB.ReadOnly = True
            txtChild3Name.ReadOnly = True
            txtChild3DoBC.ReadOnly = True
            txtChild4Name.ReadOnly = True
            txtChild4DoBD.ReadOnly = True
            txtChild5Name.ReadOnly = True
            txtChild5DoBE.ReadOnly = True
            txtChild6Name.ReadOnly = True
            txtChild6DoBF.ReadOnly = True
            txtChild7Name.ReadOnly = True
            txtChild7DoBG.ReadOnly = True
            txtChild8Name.ReadOnly = True
            txtChild8DoBH.ReadOnly = True

            ' Delete TextBox Values 
            txtChild2Name.Text = ""
            txtChild2DoBB.Text = ""
            txtChild3Name.Text = ""
            txtChild3DoBC.Text = ""
            txtChild4Name.Text = ""
            txtChild4DoBD.Text = ""
            txtChild5Name.Text = ""
            txtChild5DoBE.Text = ""
            txtChild6Name.Text = ""
            txtChild6DoBF.Text = ""
            txtChild7Name.Text = ""
            txtChild7DoBG.Text = ""
            txtChild8Name.Text = ""
            txtChild8DoBH.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub twoChildren_CheckedChanged(sender As Object, e As EventArgs) Handles twoChildren.CheckedChanged
        Try
            txtChild1Name.ReadOnly = False
            txtChild1DoBA.ReadOnly = False
            txtChild2Name.ReadOnly = False
            txtChild2DoBB.ReadOnly = False
            txtChild3Name.ReadOnly = True
            txtChild3DoBC.ReadOnly = True
            txtChild4Name.ReadOnly = True
            txtChild4DoBD.ReadOnly = True
            txtChild5Name.ReadOnly = True
            txtChild5DoBE.ReadOnly = True
            txtChild6Name.ReadOnly = True
            txtChild6DoBF.ReadOnly = True
            txtChild7Name.ReadOnly = True
            txtChild7DoBG.ReadOnly = True
            txtChild8Name.ReadOnly = True
            txtChild8DoBH.ReadOnly = True

            ' Delete TextBox Values 
            txtChild3Name.Text = ""
            txtChild3DoBC.Text = ""
            txtChild4Name.Text = ""
            txtChild4DoBD.Text = ""
            txtChild5Name.Text = ""
            txtChild5DoBE.Text = ""
            txtChild6Name.Text = ""
            txtChild6DoBF.Text = ""
            txtChild7Name.Text = ""
            txtChild7DoBG.Text = ""
            txtChild8Name.Text = ""
            txtChild8DoBH.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub threeChildren_CheckedChanged(sender As Object, e As EventArgs) Handles threeChildren.CheckedChanged
        Try
            txtChild1Name.ReadOnly = False
            txtChild1DoBA.ReadOnly = False
            txtChild2Name.ReadOnly = False
            txtChild2DoBB.ReadOnly = False
            txtChild3Name.ReadOnly = False
            txtChild3DoBC.ReadOnly = False
            txtChild4Name.ReadOnly = True
            txtChild4DoBD.ReadOnly = True
            txtChild5Name.ReadOnly = True
            txtChild5DoBE.ReadOnly = True
            txtChild6Name.ReadOnly = True
            txtChild6DoBF.ReadOnly = True
            txtChild7Name.ReadOnly = True
            txtChild7DoBG.ReadOnly = True
            txtChild8Name.ReadOnly = True
            txtChild8DoBH.ReadOnly = True

            ' Delete TextBox Values 
            txtChild4Name.Text = ""
            txtChild4DoBD.Text = ""
            txtChild5Name.Text = ""
            txtChild5DoBE.Text = ""
            txtChild6Name.Text = ""
            txtChild6DoBF.Text = ""
            txtChild7Name.Text = ""
            txtChild7DoBG.Text = ""
            txtChild8Name.Text = ""
            txtChild8DoBH.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub fourChildren_CheckedChanged(sender As Object, e As EventArgs) Handles fourChildren.CheckedChanged
        Try
            txtChild1Name.ReadOnly = False
            txtChild1DoBA.ReadOnly = False
            txtChild2Name.ReadOnly = False
            txtChild2DoBB.ReadOnly = False
            txtChild3Name.ReadOnly = False
            txtChild3DoBC.ReadOnly = False
            txtChild4Name.ReadOnly = False
            txtChild4DoBD.ReadOnly = False
            txtChild5Name.ReadOnly = True
            txtChild5DoBE.ReadOnly = True
            txtChild6Name.ReadOnly = True
            txtChild6DoBF.ReadOnly = True
            txtChild7Name.ReadOnly = True
            txtChild7DoBG.ReadOnly = True
            txtChild8Name.ReadOnly = True
            txtChild8DoBH.ReadOnly = True

            ' Delete TextBox Values 
            txtChild5Name.Text = ""
            txtChild5DoBE.Text = ""
            txtChild6Name.Text = ""
            txtChild6DoBF.Text = ""
            txtChild7Name.Text = ""
            txtChild7DoBG.Text = ""
            txtChild8Name.Text = ""
            txtChild8DoBH.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub fiveChildren_CheckedChanged(sender As Object, e As EventArgs) Handles fiveChildren.CheckedChanged
        Try
            txtChild1Name.ReadOnly = False
            txtChild1DoBA.ReadOnly = False
            txtChild2Name.ReadOnly = False
            txtChild2DoBB.ReadOnly = False
            txtChild3Name.ReadOnly = False
            txtChild3DoBC.ReadOnly = False
            txtChild4Name.ReadOnly = False
            txtChild4DoBD.ReadOnly = False
            txtChild5Name.ReadOnly = False
            txtChild5DoBE.ReadOnly = False
            txtChild6Name.ReadOnly = True
            txtChild6DoBF.ReadOnly = True
            txtChild7Name.ReadOnly = True
            txtChild7DoBG.ReadOnly = True
            txtChild8Name.ReadOnly = True
            txtChild8DoBH.ReadOnly = True

            ' Delete TextBox Values 
            txtChild6Name.Text = ""
            txtChild6DoBF.Text = ""
            txtChild7Name.Text = ""
            txtChild7DoBG.Text = ""
            txtChild8Name.Text = ""
            txtChild8DoBH.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub sixChildren_CheckedChanged(sender As Object, e As EventArgs) Handles sixChildren.CheckedChanged
        Try
            txtChild1Name.ReadOnly = False
            txtChild1DoBA.ReadOnly = False
            txtChild2Name.ReadOnly = False
            txtChild2DoBB.ReadOnly = False
            txtChild3Name.ReadOnly = False
            txtChild3DoBC.ReadOnly = False
            txtChild4Name.ReadOnly = False
            txtChild4DoBD.ReadOnly = False
            txtChild5Name.ReadOnly = False
            txtChild5DoBE.ReadOnly = False
            txtChild6Name.ReadOnly = False
            txtChild6DoBF.ReadOnly = False
            txtChild7Name.ReadOnly = True
            txtChild7DoBG.ReadOnly = True
            txtChild8Name.ReadOnly = True
            txtChild8DoBH.ReadOnly = True

            ' Delete TextBox Values 
            txtChild7Name.Text = ""
            txtChild7DoBG.Text = ""
            txtChild8Name.Text = ""
            txtChild8DoBH.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub sevenChildren_CheckedChanged(sender As Object, e As EventArgs) Handles sevenChildren.CheckedChanged
        Try
            txtChild1Name.ReadOnly = False
            txtChild1DoBA.ReadOnly = False
            txtChild2Name.ReadOnly = False
            txtChild2DoBB.ReadOnly = False
            txtChild3Name.ReadOnly = False
            txtChild3DoBC.ReadOnly = False
            txtChild4Name.ReadOnly = False
            txtChild4DoBD.ReadOnly = False
            txtChild5Name.ReadOnly = False
            txtChild5DoBE.ReadOnly = False
            txtChild6Name.ReadOnly = False
            txtChild6DoBF.ReadOnly = False
            txtChild7Name.ReadOnly = False
            txtChild7DoBG.ReadOnly = False
            txtChild8Name.ReadOnly = True
            txtChild8DoBH.ReadOnly = True

            ' Delete TextBox Values 
            txtChild8Name.Text = ""
            txtChild8DoBH.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub eightChildren_CheckedChanged(sender As Object, e As EventArgs) Handles eightChildren.CheckedChanged
        txtChild1Name.ReadOnly = False
        txtChild1DoBA.ReadOnly = False
        txtChild2Name.ReadOnly = False
        txtChild2DoBB.ReadOnly = False
        txtChild3Name.ReadOnly = False
        txtChild3DoBC.ReadOnly = False
        txtChild4Name.ReadOnly = False
        txtChild4DoBD.ReadOnly = False
        txtChild5Name.ReadOnly = False
        txtChild5DoBE.ReadOnly = False
        txtChild6Name.ReadOnly = False
        txtChild6DoBF.ReadOnly = False
        txtChild7Name.ReadOnly = False
        txtChild7DoBG.ReadOnly = False
        txtChild8Name.ReadOnly = False
        txtChild8DoBH.ReadOnly = False
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        Try

            Dim imagepath As String
            Dim ofd As FileDialog = New OpenFileDialog()
            ofd.Filter = "Image File(*.jpg;*.png;*.gif;*.jpeg)|*.jpg;*.png;*.gif;*.jpeg"
            If ofd.ShowDialog() = DialogResult.OK Then

                imagepath = ofd.FileName
                ' Image = System.IO.File.ReadAllBytes(imagepath)
                txtImageName.Text = imagepath

            End If
            ofd = Nothing
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try
    End Sub

    Private Sub txtMaritalStatus_SelectedValueChanged(sender As Object, e As EventArgs) Handles txtMaritalStatus.SelectedValueChanged
        If (txtMaritalStatus.Text = "Married") Then
            txtSpouseName.ReadOnly = False
            txtSpousePhone.ReadOnly = False
            txtSpouseAddress.ReadOnly = False

            txtTypeOfMarriage.Visible = True
            typeOfMarriageText.Visible = True
        Else
            txtSpouseName.ReadOnly = True
            txtSpousePhone.ReadOnly = True
            txtSpouseAddress.ReadOnly = True

            txtTypeOfMarriage.Visible = False
            typeOfMarriageText.Visible = False

            txtSpouseName.Text = ""
            txtSpousePhone.Text = ""
            txtSpouseAddress.Text = ""
        End If
    End Sub

    Private Sub txtMaritalStatus_KeyUp(sender As Object, e As KeyEventArgs) Handles txtMaritalStatus.KeyUp
        'txtMaritalStatus.Text = ""
    End Sub

    Private Sub txtTypeOfMarriage_KeyUp(sender As Object, e As KeyEventArgs) Handles txtTypeOfMarriage.KeyUp
        'txtTypeOfMarriage.Text = ""
    End Sub

    Private Sub txtMemberDoB_ValueChanged(sender As Object, e As EventArgs) Handles txtMemberDoB.ValueChanged
        txtMemberDoB1.Text = txtMemberDoB.Value
    End Sub

    Private Sub txtMemberDoB_KeyUp(sender As Object, e As KeyEventArgs) Handles txtMemberDoB.KeyUp
        txtMemberDoB1.Text = txtMemberDoB.Value
    End Sub

    Private Sub txtMemberSex_KeyUp(sender As Object, e As KeyEventArgs) Handles txtMemberSex.KeyUp
        'txtMemberSex.Text = ""
    End Sub

End Class