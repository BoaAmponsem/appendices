﻿Imports System.Data.SqlClient
Public Class AccountEditHistory
    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select * from AccountEditHistoryTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Initial_Staff_ID  like '%' +@parm1+ '%' "
            query &= " or Current_Staff_ID like '%' +@parm1+ '%' "
            query &= " or Current_Username like '%' +@parm1+ '%' "
            query &= " or Initial_Username like '%' +@parm1+ '%' "
            query &= " or Initial_Phone like '%' +@parm1+ '%' "
            query &= " or Current_Phone like '%' +@parm1+ '%' "
            query &= " or Initial_Gmail like '%' +@parm1+ '%' "
            query &= " or Current_Gmail like '%' +@parm1+ '%' "
            query &= " or Initial_Password like '%' +@parm1+ '%' "
            query &= " or Current_Password like '%' +@parm1+ '%' "
            query &= " or Date_Modified like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using
            '  End Using
        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function

    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select * from AccountEditHistoryTbl"
            cmd = New SqlCommand(query, Con)
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            AccountEditDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        AccountEditDataGridView.DataSource = Me.SearchItem
    End Sub

    Private Sub AccountEditHistory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
    End Sub
End Class