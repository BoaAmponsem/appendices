﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AddMemberPage1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.noProfilePic = New System.Windows.Forms.CheckBox()
        Me.txtMemberDoB = New System.Windows.Forms.DateTimePicker()
        Me.txtMemberDoB1 = New System.Windows.Forms.MaskedTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtMemberStaffID = New System.Windows.Forms.MaskedTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtImageName = New System.Windows.Forms.TextBox()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.txtTypeOfMarriage = New System.Windows.Forms.ComboBox()
        Me.txtMaritalStatus = New System.Windows.Forms.ComboBox()
        Me.txtMemberHometown = New System.Windows.Forms.TextBox()
        Me.typeOfMarriageText = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtMemberPostalAddress = New System.Windows.Forms.TextBox()
        Me.txtMemberHouseNo = New System.Windows.Forms.TextBox()
        Me.txtMemberPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtMemberSex = New System.Windows.Forms.ComboBox()
        Me.txtMemberOthername = New System.Windows.Forms.TextBox()
        Me.txtMemberSurname = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtSpousePhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtSpouseAddress = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtSpouseName = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.noChild = New System.Windows.Forms.RadioButton()
        Me.eightChildren = New System.Windows.Forms.RadioButton()
        Me.sevenChildren = New System.Windows.Forms.RadioButton()
        Me.sixChildren = New System.Windows.Forms.RadioButton()
        Me.fiveChildren = New System.Windows.Forms.RadioButton()
        Me.fourChildren = New System.Windows.Forms.RadioButton()
        Me.threeChildren = New System.Windows.Forms.RadioButton()
        Me.twoChildren = New System.Windows.Forms.RadioButton()
        Me.oneChild = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtChild3DoB = New System.Windows.Forms.DateTimePicker()
        Me.txtChild2DoB = New System.Windows.Forms.DateTimePicker()
        Me.txtChild6DoB = New System.Windows.Forms.DateTimePicker()
        Me.txtChild5DoB = New System.Windows.Forms.DateTimePicker()
        Me.txtChild4DoB = New System.Windows.Forms.DateTimePicker()
        Me.txtChild7DoB = New System.Windows.Forms.DateTimePicker()
        Me.txtChild8DoB = New System.Windows.Forms.DateTimePicker()
        Me.txtChild1DoB = New System.Windows.Forms.DateTimePicker()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtChild7DoBG = New System.Windows.Forms.MaskedTextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtChild8DoBH = New System.Windows.Forms.MaskedTextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtChild8Name = New System.Windows.Forms.TextBox()
        Me.txtChild7Name = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtChild6DoBF = New System.Windows.Forms.MaskedTextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtChild4DoBD = New System.Windows.Forms.MaskedTextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtChild5DoBE = New System.Windows.Forms.MaskedTextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtChild6Name = New System.Windows.Forms.TextBox()
        Me.txtChild5Name = New System.Windows.Forms.TextBox()
        Me.txtChild4Name = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtChild3DoBC = New System.Windows.Forms.MaskedTextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtChild1DoBA = New System.Windows.Forms.MaskedTextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtChild2DoBB = New System.Windows.Forms.MaskedTextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtChild3Name = New System.Windows.Forms.TextBox()
        Me.txtChild2Name = New System.Windows.Forms.TextBox()
        Me.txtChild1Name = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.NextBtn = New FontAwesome.Sharp.IconButton()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.noProfilePic)
        Me.GroupBox1.Controls.Add(Me.txtMemberDoB)
        Me.GroupBox1.Controls.Add(Me.txtMemberDoB1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtMemberStaffID)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtImageName)
        Me.GroupBox1.Controls.Add(Me.IconButton2)
        Me.GroupBox1.Controls.Add(Me.txtTypeOfMarriage)
        Me.GroupBox1.Controls.Add(Me.txtMaritalStatus)
        Me.GroupBox1.Controls.Add(Me.txtMemberHometown)
        Me.GroupBox1.Controls.Add(Me.typeOfMarriageText)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtMemberPostalAddress)
        Me.GroupBox1.Controls.Add(Me.txtMemberHouseNo)
        Me.GroupBox1.Controls.Add(Me.txtMemberPhone)
        Me.GroupBox1.Controls.Add(Me.txtMemberSex)
        Me.GroupBox1.Controls.Add(Me.txtMemberOthername)
        Me.GroupBox1.Controls.Add(Me.txtMemberSurname)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(16, 41)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(967, 173)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "PERSONAL DETAILS"
        '
        'noProfilePic
        '
        Me.noProfilePic.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.noProfilePic.AutoSize = True
        Me.noProfilePic.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noProfilePic.Location = New System.Drawing.Point(689, 151)
        Me.noProfilePic.Name = "noProfilePic"
        Me.noProfilePic.Size = New System.Drawing.Size(109, 18)
        Me.noProfilePic.TabIndex = 106
        Me.noProfilePic.Text = "No profile picture"
        Me.noProfilePic.UseVisualStyleBackColor = True
        '
        'txtMemberDoB
        '
        Me.txtMemberDoB.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemberDoB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtMemberDoB.Location = New System.Drawing.Point(409, 126)
        Me.txtMemberDoB.Name = "txtMemberDoB"
        Me.txtMemberDoB.Size = New System.Drawing.Size(104, 21)
        Me.txtMemberDoB.TabIndex = 105
        Me.txtMemberDoB.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'txtMemberDoB1
        '
        Me.txtMemberDoB1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemberDoB1.Location = New System.Drawing.Point(313, 106)
        Me.txtMemberDoB1.Mask = "00/00/0000"
        Me.txtMemberDoB1.Name = "txtMemberDoB1"
        Me.txtMemberDoB1.ReadOnly = True
        Me.txtMemberDoB1.Size = New System.Drawing.Size(95, 21)
        Me.txtMemberDoB1.TabIndex = 104
        Me.txtMemberDoB1.ValidatingType = GetType(Date)
        Me.txtMemberDoB1.Visible = False
        '
        'Label3
        '
        Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(410, 107)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 15)
        Me.Label3.TabIndex = 97
        Me.Label3.Text = "DoB(mm/dd/yyyy)"
        '
        'txtMemberStaffID
        '
        Me.txtMemberStaffID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemberStaffID.Location = New System.Drawing.Point(526, 126)
        Me.txtMemberStaffID.Name = "txtMemberStaffID"
        Me.txtMemberStaffID.Size = New System.Drawing.Size(109, 21)
        Me.txtMemberStaffID.TabIndex = 24
        '
        'Label10
        '
        Me.Label10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(523, 109)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 15)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Staff ID:"
        '
        'txtImageName
        '
        Me.txtImageName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtImageName.Location = New System.Drawing.Point(748, 118)
        Me.txtImageName.Multiline = True
        Me.txtImageName.Name = "txtImageName"
        Me.txtImageName.ReadOnly = True
        Me.txtImageName.Size = New System.Drawing.Size(200, 29)
        Me.txtImageName.TabIndex = 21
        '
        'IconButton2
        '
        Me.IconButton2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.IconButton2.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.IconButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton2.FlatAppearance.BorderSize = 0
        Me.IconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.ForeColor = System.Drawing.Color.White
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton2.IconColor = System.Drawing.Color.Black
        Me.IconButton2.IconSize = 16
        Me.IconButton2.Location = New System.Drawing.Point(667, 118)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(81, 29)
        Me.IconButton2.TabIndex = 20
        Me.IconButton2.Text = "Add Picture"
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'txtTypeOfMarriage
        '
        Me.txtTypeOfMarriage.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTypeOfMarriage.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTypeOfMarriage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtTypeOfMarriage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtTypeOfMarriage.FormattingEnabled = True
        Me.txtTypeOfMarriage.Items.AddRange(New Object() {"", "Marriage Ordinance", "Customary Marriage", "Marriage Of Mohammedans Ordinance"})
        Me.txtTypeOfMarriage.Location = New System.Drawing.Point(801, 81)
        Me.txtTypeOfMarriage.Name = "txtTypeOfMarriage"
        Me.txtTypeOfMarriage.Size = New System.Drawing.Size(155, 23)
        Me.txtTypeOfMarriage.TabIndex = 19
        Me.txtTypeOfMarriage.Visible = False
        '
        'txtMaritalStatus
        '
        Me.txtMaritalStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMaritalStatus.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtMaritalStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtMaritalStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtMaritalStatus.FormattingEnabled = True
        Me.txtMaritalStatus.Items.AddRange(New Object() {"", "Married", "Single"})
        Me.txtMaritalStatus.Location = New System.Drawing.Point(673, 82)
        Me.txtMaritalStatus.Name = "txtMaritalStatus"
        Me.txtMaritalStatus.Size = New System.Drawing.Size(108, 23)
        Me.txtMaritalStatus.TabIndex = 18
        '
        'txtMemberHometown
        '
        Me.txtMemberHometown.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemberHometown.Location = New System.Drawing.Point(8, 126)
        Me.txtMemberHometown.Multiline = True
        Me.txtMemberHometown.Name = "txtMemberHometown"
        Me.txtMemberHometown.Size = New System.Drawing.Size(384, 22)
        Me.txtMemberHometown.TabIndex = 17
        '
        'typeOfMarriageText
        '
        Me.typeOfMarriageText.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.typeOfMarriageText.AutoSize = True
        Me.typeOfMarriageText.Location = New System.Drawing.Point(803, 63)
        Me.typeOfMarriageText.Name = "typeOfMarriageText"
        Me.typeOfMarriageText.Size = New System.Drawing.Size(98, 15)
        Me.typeOfMarriageText.TabIndex = 16
        Me.typeOfMarriageText.Text = "Type Of Marriage:"
        Me.typeOfMarriageText.Visible = False
        '
        'Label9
        '
        Me.Label9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(676, 64)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 15)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Marital Status:"
        '
        'txtMemberPostalAddress
        '
        Me.txtMemberPostalAddress.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberPostalAddress.Location = New System.Drawing.Point(486, 79)
        Me.txtMemberPostalAddress.Multiline = True
        Me.txtMemberPostalAddress.Name = "txtMemberPostalAddress"
        Me.txtMemberPostalAddress.Size = New System.Drawing.Size(174, 22)
        Me.txtMemberPostalAddress.TabIndex = 14
        '
        'txtMemberHouseNo
        '
        Me.txtMemberHouseNo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberHouseNo.Location = New System.Drawing.Point(8, 78)
        Me.txtMemberHouseNo.Multiline = True
        Me.txtMemberHouseNo.Name = "txtMemberHouseNo"
        Me.txtMemberHouseNo.Size = New System.Drawing.Size(457, 22)
        Me.txtMemberHouseNo.TabIndex = 13
        '
        'txtMemberPhone
        '
        Me.txtMemberPhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberPhone.Location = New System.Drawing.Point(820, 35)
        Me.txtMemberPhone.Name = "txtMemberPhone"
        Me.txtMemberPhone.Size = New System.Drawing.Size(117, 21)
        Me.txtMemberPhone.TabIndex = 12
        '
        'txtMemberSex
        '
        Me.txtMemberSex.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberSex.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtMemberSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtMemberSex.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtMemberSex.FormattingEnabled = True
        Me.txtMemberSex.Items.AddRange(New Object() {"", "Male", "Female"})
        Me.txtMemberSex.Location = New System.Drawing.Point(692, 34)
        Me.txtMemberSex.Name = "txtMemberSex"
        Me.txtMemberSex.Size = New System.Drawing.Size(99, 23)
        Me.txtMemberSex.TabIndex = 10
        '
        'txtMemberOthername
        '
        Me.txtMemberOthername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberOthername.Location = New System.Drawing.Point(487, 34)
        Me.txtMemberOthername.Multiline = True
        Me.txtMemberOthername.Name = "txtMemberOthername"
        Me.txtMemberOthername.Size = New System.Drawing.Size(176, 22)
        Me.txtMemberOthername.TabIndex = 9
        '
        'txtMemberSurname
        '
        Me.txtMemberSurname.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberSurname.Location = New System.Drawing.Point(8, 34)
        Me.txtMemberSurname.Multiline = True
        Me.txtMemberSurname.Name = "txtMemberSurname"
        Me.txtMemberSurname.Size = New System.Drawing.Size(457, 21)
        Me.txtMemberSurname.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(488, 61)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(82, 15)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Postal Address:"
        '
        'Label7
        '
        Me.Label7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(825, 17)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 15)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Phone:"
        '
        'Label6
        '
        Me.Label6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(695, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(26, 15)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Sex:"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "House No."
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 108)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Hometown:"
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(488, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Other Names:"
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Surname:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.txtSpousePhone)
        Me.GroupBox2.Controls.Add(Me.txtSpouseAddress)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.txtSpouseName)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(16, 217)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(967, 73)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "DETAILS OF SPOUSE(IF ANY)"
        '
        'txtSpousePhone
        '
        Me.txtSpousePhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtSpousePhone.Location = New System.Drawing.Point(377, 38)
        Me.txtSpousePhone.Mask = "(999) 000-0000"
        Me.txtSpousePhone.Name = "txtSpousePhone"
        Me.txtSpousePhone.ReadOnly = True
        Me.txtSpousePhone.Size = New System.Drawing.Size(267, 21)
        Me.txtSpousePhone.TabIndex = 24
        '
        'txtSpouseAddress
        '
        Me.txtSpouseAddress.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSpouseAddress.Location = New System.Drawing.Point(746, 38)
        Me.txtSpouseAddress.Multiline = True
        Me.txtSpouseAddress.Name = "txtSpouseAddress"
        Me.txtSpouseAddress.ReadOnly = True
        Me.txtSpouseAddress.Size = New System.Drawing.Size(194, 22)
        Me.txtSpouseAddress.TabIndex = 26
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(22, 20)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(38, 15)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Name:"
        '
        'txtSpouseName
        '
        Me.txtSpouseName.Location = New System.Drawing.Point(13, 39)
        Me.txtSpouseName.Multiline = True
        Me.txtSpouseName.Name = "txtSpouseName"
        Me.txtSpouseName.ReadOnly = True
        Me.txtSpouseName.Size = New System.Drawing.Size(308, 21)
        Me.txtSpouseName.TabIndex = 23
        '
        'Label12
        '
        Me.Label12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(749, 20)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(90, 15)
        Me.Label12.TabIndex = 21
        Me.Label12.Text = "Contact Address:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(380, 20)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(58, 15)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Phone No:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.BackColor = System.Drawing.Color.White
        Me.GroupBox3.Controls.Add(Me.noChild)
        Me.GroupBox3.Controls.Add(Me.eightChildren)
        Me.GroupBox3.Controls.Add(Me.sevenChildren)
        Me.GroupBox3.Controls.Add(Me.sixChildren)
        Me.GroupBox3.Controls.Add(Me.fiveChildren)
        Me.GroupBox3.Controls.Add(Me.fourChildren)
        Me.GroupBox3.Controls.Add(Me.threeChildren)
        Me.GroupBox3.Controls.Add(Me.twoChildren)
        Me.GroupBox3.Controls.Add(Me.oneChild)
        Me.GroupBox3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(13, 294)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(967, 40)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "CHILDREN(IF ANY)"
        '
        'noChild
        '
        Me.noChild.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.noChild.AutoSize = True
        Me.noChild.Checked = True
        Me.noChild.Location = New System.Drawing.Point(279, 13)
        Me.noChild.Name = "noChild"
        Me.noChild.Size = New System.Drawing.Size(31, 19)
        Me.noChild.TabIndex = 8
        Me.noChild.TabStop = True
        Me.noChild.Text = "0"
        Me.noChild.UseVisualStyleBackColor = True
        '
        'eightChildren
        '
        Me.eightChildren.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.eightChildren.AutoSize = True
        Me.eightChildren.Location = New System.Drawing.Point(685, 14)
        Me.eightChildren.Name = "eightChildren"
        Me.eightChildren.Size = New System.Drawing.Size(31, 19)
        Me.eightChildren.TabIndex = 7
        Me.eightChildren.Text = "8"
        Me.eightChildren.UseVisualStyleBackColor = True
        '
        'sevenChildren
        '
        Me.sevenChildren.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.sevenChildren.AutoSize = True
        Me.sevenChildren.Location = New System.Drawing.Point(630, 13)
        Me.sevenChildren.Name = "sevenChildren"
        Me.sevenChildren.Size = New System.Drawing.Size(31, 19)
        Me.sevenChildren.TabIndex = 6
        Me.sevenChildren.Text = "7"
        Me.sevenChildren.UseVisualStyleBackColor = True
        '
        'sixChildren
        '
        Me.sixChildren.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.sixChildren.AutoSize = True
        Me.sixChildren.Location = New System.Drawing.Point(574, 13)
        Me.sixChildren.Name = "sixChildren"
        Me.sixChildren.Size = New System.Drawing.Size(31, 19)
        Me.sixChildren.TabIndex = 5
        Me.sixChildren.Text = "6"
        Me.sixChildren.UseVisualStyleBackColor = True
        '
        'fiveChildren
        '
        Me.fiveChildren.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.fiveChildren.AutoSize = True
        Me.fiveChildren.Location = New System.Drawing.Point(523, 13)
        Me.fiveChildren.Name = "fiveChildren"
        Me.fiveChildren.Size = New System.Drawing.Size(31, 19)
        Me.fiveChildren.TabIndex = 4
        Me.fiveChildren.Text = "5"
        Me.fiveChildren.UseVisualStyleBackColor = True
        '
        'fourChildren
        '
        Me.fourChildren.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.fourChildren.AutoSize = True
        Me.fourChildren.Location = New System.Drawing.Point(472, 13)
        Me.fourChildren.Name = "fourChildren"
        Me.fourChildren.Size = New System.Drawing.Size(31, 19)
        Me.fourChildren.TabIndex = 3
        Me.fourChildren.Text = "4"
        Me.fourChildren.UseVisualStyleBackColor = True
        '
        'threeChildren
        '
        Me.threeChildren.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.threeChildren.AutoSize = True
        Me.threeChildren.Location = New System.Drawing.Point(423, 14)
        Me.threeChildren.Name = "threeChildren"
        Me.threeChildren.Size = New System.Drawing.Size(31, 19)
        Me.threeChildren.TabIndex = 2
        Me.threeChildren.Text = "3"
        Me.threeChildren.UseVisualStyleBackColor = True
        '
        'twoChildren
        '
        Me.twoChildren.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.twoChildren.AutoSize = True
        Me.twoChildren.Location = New System.Drawing.Point(375, 14)
        Me.twoChildren.Name = "twoChildren"
        Me.twoChildren.Size = New System.Drawing.Size(31, 19)
        Me.twoChildren.TabIndex = 1
        Me.twoChildren.Text = "2"
        Me.twoChildren.UseVisualStyleBackColor = True
        '
        'oneChild
        '
        Me.oneChild.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.oneChild.AutoSize = True
        Me.oneChild.Location = New System.Drawing.Point(325, 14)
        Me.oneChild.Name = "oneChild"
        Me.oneChild.Size = New System.Drawing.Size(31, 19)
        Me.oneChild.TabIndex = 0
        Me.oneChild.Text = "1"
        Me.oneChild.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.txtChild3DoB)
        Me.Panel1.Controls.Add(Me.txtChild2DoB)
        Me.Panel1.Controls.Add(Me.txtChild6DoB)
        Me.Panel1.Controls.Add(Me.txtChild5DoB)
        Me.Panel1.Controls.Add(Me.txtChild4DoB)
        Me.Panel1.Controls.Add(Me.txtChild7DoB)
        Me.Panel1.Controls.Add(Me.txtChild8DoB)
        Me.Panel1.Controls.Add(Me.txtChild1DoB)
        Me.Panel1.Controls.Add(Me.Label37)
        Me.Panel1.Controls.Add(Me.Label36)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.Label34)
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.Label31)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.txtChild7DoBG)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.txtChild8DoBH)
        Me.Panel1.Controls.Add(Me.Label27)
        Me.Panel1.Controls.Add(Me.txtChild8Name)
        Me.Panel1.Controls.Add(Me.txtChild7Name)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Controls.Add(Me.txtChild6DoBF)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.txtChild4DoBD)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.txtChild5DoBE)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.txtChild6Name)
        Me.Panel1.Controls.Add(Me.txtChild5Name)
        Me.Panel1.Controls.Add(Me.txtChild4Name)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.txtChild3DoBC)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.txtChild1DoBA)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.txtChild2DoBB)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.txtChild3Name)
        Me.Panel1.Controls.Add(Me.txtChild2Name)
        Me.Panel1.Controls.Add(Me.txtChild1Name)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Location = New System.Drawing.Point(16, 333)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(967, 147)
        Me.Panel1.TabIndex = 3
        '
        'txtChild3DoB
        '
        Me.txtChild3DoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild3DoB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtChild3DoB.Location = New System.Drawing.Point(186, 118)
        Me.txtChild3DoB.Name = "txtChild3DoB"
        Me.txtChild3DoB.Size = New System.Drawing.Size(95, 20)
        Me.txtChild3DoB.TabIndex = 103
        Me.txtChild3DoB.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'txtChild2DoB
        '
        Me.txtChild2DoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild2DoB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtChild2DoB.Location = New System.Drawing.Point(186, 70)
        Me.txtChild2DoB.Name = "txtChild2DoB"
        Me.txtChild2DoB.Size = New System.Drawing.Size(95, 20)
        Me.txtChild2DoB.TabIndex = 102
        Me.txtChild2DoB.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'txtChild6DoB
        '
        Me.txtChild6DoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild6DoB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtChild6DoB.Location = New System.Drawing.Point(507, 118)
        Me.txtChild6DoB.Name = "txtChild6DoB"
        Me.txtChild6DoB.Size = New System.Drawing.Size(95, 20)
        Me.txtChild6DoB.TabIndex = 101
        Me.txtChild6DoB.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'txtChild5DoB
        '
        Me.txtChild5DoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild5DoB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtChild5DoB.Location = New System.Drawing.Point(507, 76)
        Me.txtChild5DoB.Name = "txtChild5DoB"
        Me.txtChild5DoB.Size = New System.Drawing.Size(95, 20)
        Me.txtChild5DoB.TabIndex = 100
        Me.txtChild5DoB.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'txtChild4DoB
        '
        Me.txtChild4DoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild4DoB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtChild4DoB.Location = New System.Drawing.Point(507, 25)
        Me.txtChild4DoB.Name = "txtChild4DoB"
        Me.txtChild4DoB.Size = New System.Drawing.Size(95, 20)
        Me.txtChild4DoB.TabIndex = 96
        Me.txtChild4DoB.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'txtChild7DoB
        '
        Me.txtChild7DoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild7DoB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtChild7DoB.Location = New System.Drawing.Point(847, 21)
        Me.txtChild7DoB.Name = "txtChild7DoB"
        Me.txtChild7DoB.Size = New System.Drawing.Size(101, 20)
        Me.txtChild7DoB.TabIndex = 97
        Me.txtChild7DoB.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'txtChild8DoB
        '
        Me.txtChild8DoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild8DoB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtChild8DoB.Location = New System.Drawing.Point(847, 72)
        Me.txtChild8DoB.Name = "txtChild8DoB"
        Me.txtChild8DoB.Size = New System.Drawing.Size(103, 20)
        Me.txtChild8DoB.TabIndex = 98
        Me.txtChild8DoB.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'txtChild1DoB
        '
        Me.txtChild1DoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild1DoB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtChild1DoB.Location = New System.Drawing.Point(186, 22)
        Me.txtChild1DoB.Name = "txtChild1DoB"
        Me.txtChild1DoB.Size = New System.Drawing.Size(95, 20)
        Me.txtChild1DoB.TabIndex = 99
        Me.txtChild1DoB.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'Label37
        '
        Me.Label37.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(672, 72)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(16, 13)
        Me.Label37.TabIndex = 59
        Me.Label37.Text = "8."
        '
        'Label36
        '
        Me.Label36.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(672, 25)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(16, 13)
        Me.Label36.TabIndex = 58
        Me.Label36.Text = "7."
        '
        'Label35
        '
        Me.Label35.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(331, 121)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(16, 13)
        Me.Label35.TabIndex = 57
        Me.Label35.Text = "6."
        '
        'Label34
        '
        Me.Label34.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(331, 73)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(16, 13)
        Me.Label34.TabIndex = 56
        Me.Label34.Text = "5."
        '
        'Label33
        '
        Me.Label33.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(331, 25)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(16, 13)
        Me.Label33.TabIndex = 55
        Me.Label33.Text = "4."
        '
        'Label32
        '
        Me.Label32.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(5, 121)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(16, 13)
        Me.Label32.TabIndex = 54
        Me.Label32.Text = "3."
        '
        'Label31
        '
        Me.Label31.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(8, 75)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(16, 13)
        Me.Label31.TabIndex = 53
        Me.Label31.Text = "2."
        '
        'Label29
        '
        Me.Label29.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(8, 25)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(16, 13)
        Me.Label29.TabIndex = 52
        Me.Label29.Text = "1."
        '
        'txtChild7DoBG
        '
        Me.txtChild7DoBG.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild7DoBG.Location = New System.Drawing.Point(744, 3)
        Me.txtChild7DoBG.Mask = "00/00/0000"
        Me.txtChild7DoBG.Name = "txtChild7DoBG"
        Me.txtChild7DoBG.ReadOnly = True
        Me.txtChild7DoBG.Size = New System.Drawing.Size(95, 20)
        Me.txtChild7DoBG.TabIndex = 51
        Me.txtChild7DoBG.ValidatingType = GetType(Date)
        Me.txtChild7DoBG.Visible = False
        '
        'Label26
        '
        Me.Label26.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(842, 5)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(92, 13)
        Me.Label26.TabIndex = 50
        Me.Label26.Text = "DoB(mm/dd/yyyy)"
        '
        'txtChild8DoBH
        '
        Me.txtChild8DoBH.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild8DoBH.Location = New System.Drawing.Point(746, 49)
        Me.txtChild8DoBH.Mask = "00/00/0000"
        Me.txtChild8DoBH.Name = "txtChild8DoBH"
        Me.txtChild8DoBH.ReadOnly = True
        Me.txtChild8DoBH.Size = New System.Drawing.Size(95, 20)
        Me.txtChild8DoBH.TabIndex = 49
        Me.txtChild8DoBH.ValidatingType = GetType(Date)
        Me.txtChild8DoBH.Visible = False
        '
        'Label27
        '
        Me.Label27.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(842, 56)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(92, 13)
        Me.Label27.TabIndex = 48
        Me.Label27.Text = "DoB(mm/dd/yyyy)"
        '
        'txtChild8Name
        '
        Me.txtChild8Name.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild8Name.Location = New System.Drawing.Point(694, 70)
        Me.txtChild8Name.Multiline = True
        Me.txtChild8Name.Name = "txtChild8Name"
        Me.txtChild8Name.ReadOnly = True
        Me.txtChild8Name.Size = New System.Drawing.Size(128, 22)
        Me.txtChild8Name.TabIndex = 47
        '
        'txtChild7Name
        '
        Me.txtChild7Name.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild7Name.Location = New System.Drawing.Point(694, 22)
        Me.txtChild7Name.Multiline = True
        Me.txtChild7Name.Name = "txtChild7Name"
        Me.txtChild7Name.ReadOnly = True
        Me.txtChild7Name.Size = New System.Drawing.Size(128, 21)
        Me.txtChild7Name.TabIndex = 46
        '
        'Label28
        '
        Me.Label28.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(695, 52)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(38, 13)
        Me.Label28.TabIndex = 45
        Me.Label28.Text = "Name:"
        '
        'Label30
        '
        Me.Label30.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(695, 5)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(38, 13)
        Me.Label30.TabIndex = 43
        Me.Label30.Text = "Name:"
        '
        'txtChild6DoBF
        '
        Me.txtChild6DoBF.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild6DoBF.Location = New System.Drawing.Point(407, 93)
        Me.txtChild6DoBF.Mask = "00/00/0000"
        Me.txtChild6DoBF.Name = "txtChild6DoBF"
        Me.txtChild6DoBF.ReadOnly = True
        Me.txtChild6DoBF.Size = New System.Drawing.Size(95, 20)
        Me.txtChild6DoBF.TabIndex = 42
        Me.txtChild6DoBF.ValidatingType = GetType(Date)
        Me.txtChild6DoBF.Visible = False
        '
        'Label20
        '
        Me.Label20.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(508, 99)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(92, 13)
        Me.Label20.TabIndex = 41
        Me.Label20.Text = "DoB(mm/dd/yyyy)"
        '
        'txtChild4DoBD
        '
        Me.txtChild4DoBD.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild4DoBD.Location = New System.Drawing.Point(403, 2)
        Me.txtChild4DoBD.Mask = "00/00/0000"
        Me.txtChild4DoBD.Name = "txtChild4DoBD"
        Me.txtChild4DoBD.ReadOnly = True
        Me.txtChild4DoBD.Size = New System.Drawing.Size(95, 20)
        Me.txtChild4DoBD.TabIndex = 40
        Me.txtChild4DoBD.ValidatingType = GetType(Date)
        Me.txtChild4DoBD.Visible = False
        '
        'Label21
        '
        Me.Label21.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(504, 5)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(92, 13)
        Me.Label21.TabIndex = 39
        Me.Label21.Text = "DoB(mm/dd/yyyy)"
        '
        'txtChild5DoBE
        '
        Me.txtChild5DoBE.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild5DoBE.Location = New System.Drawing.Point(403, 45)
        Me.txtChild5DoBE.Mask = "00/00/0000"
        Me.txtChild5DoBE.Name = "txtChild5DoBE"
        Me.txtChild5DoBE.ReadOnly = True
        Me.txtChild5DoBE.Size = New System.Drawing.Size(95, 20)
        Me.txtChild5DoBE.TabIndex = 38
        Me.txtChild5DoBE.ValidatingType = GetType(Date)
        Me.txtChild5DoBE.Visible = False
        '
        'Label22
        '
        Me.Label22.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(504, 56)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(92, 13)
        Me.Label22.TabIndex = 37
        Me.Label22.Text = "DoB(mm/dd/yyyy)"
        '
        'txtChild6Name
        '
        Me.txtChild6Name.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild6Name.Location = New System.Drawing.Point(353, 118)
        Me.txtChild6Name.Multiline = True
        Me.txtChild6Name.Name = "txtChild6Name"
        Me.txtChild6Name.ReadOnly = True
        Me.txtChild6Name.Size = New System.Drawing.Size(128, 22)
        Me.txtChild6Name.TabIndex = 36
        '
        'txtChild5Name
        '
        Me.txtChild5Name.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild5Name.Location = New System.Drawing.Point(353, 70)
        Me.txtChild5Name.Multiline = True
        Me.txtChild5Name.Name = "txtChild5Name"
        Me.txtChild5Name.ReadOnly = True
        Me.txtChild5Name.Size = New System.Drawing.Size(128, 22)
        Me.txtChild5Name.TabIndex = 35
        '
        'txtChild4Name
        '
        Me.txtChild4Name.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild4Name.Location = New System.Drawing.Point(353, 22)
        Me.txtChild4Name.Multiline = True
        Me.txtChild4Name.Name = "txtChild4Name"
        Me.txtChild4Name.ReadOnly = True
        Me.txtChild4Name.Size = New System.Drawing.Size(128, 21)
        Me.txtChild4Name.TabIndex = 34
        '
        'Label23
        '
        Me.Label23.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(354, 52)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(38, 13)
        Me.Label23.TabIndex = 33
        Me.Label23.Text = "Name:"
        '
        'Label24
        '
        Me.Label24.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(354, 100)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(38, 13)
        Me.Label24.TabIndex = 32
        Me.Label24.Text = "Name:"
        '
        'Label25
        '
        Me.Label25.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(354, 5)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(38, 13)
        Me.Label25.TabIndex = 31
        Me.Label25.Text = "Name:"
        '
        'txtChild3DoBC
        '
        Me.txtChild3DoBC.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild3DoBC.Location = New System.Drawing.Point(75, 92)
        Me.txtChild3DoBC.Mask = "00/00/0000"
        Me.txtChild3DoBC.Name = "txtChild3DoBC"
        Me.txtChild3DoBC.ReadOnly = True
        Me.txtChild3DoBC.Size = New System.Drawing.Size(95, 20)
        Me.txtChild3DoBC.TabIndex = 30
        Me.txtChild3DoBC.ValidatingType = GetType(Date)
        Me.txtChild3DoBC.Visible = False
        '
        'Label19
        '
        Me.Label19.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(187, 99)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(92, 13)
        Me.Label19.TabIndex = 29
        Me.Label19.Text = "DoB(mm/dd/yyyy)"
        '
        'txtChild1DoBA
        '
        Me.txtChild1DoBA.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild1DoBA.Location = New System.Drawing.Point(82, 3)
        Me.txtChild1DoBA.Mask = "00/00/0000"
        Me.txtChild1DoBA.Name = "txtChild1DoBA"
        Me.txtChild1DoBA.ReadOnly = True
        Me.txtChild1DoBA.Size = New System.Drawing.Size(95, 20)
        Me.txtChild1DoBA.TabIndex = 28
        Me.txtChild1DoBA.ValidatingType = GetType(Date)
        Me.txtChild1DoBA.Visible = False
        '
        'Label18
        '
        Me.Label18.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(183, 5)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(92, 13)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = "DoB(mm/dd/yyyy)"
        '
        'txtChild2DoBB
        '
        Me.txtChild2DoBB.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtChild2DoBB.Location = New System.Drawing.Point(82, 44)
        Me.txtChild2DoBB.Mask = "00/00/0000"
        Me.txtChild2DoBB.Name = "txtChild2DoBB"
        Me.txtChild2DoBB.ReadOnly = True
        Me.txtChild2DoBB.Size = New System.Drawing.Size(95, 20)
        Me.txtChild2DoBB.TabIndex = 26
        Me.txtChild2DoBB.ValidatingType = GetType(Date)
        Me.txtChild2DoBB.Visible = False
        '
        'Label16
        '
        Me.Label16.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(183, 56)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(92, 13)
        Me.Label16.TabIndex = 25
        Me.Label16.Text = "DoB(mm/dd/yyyy)"
        '
        'txtChild3Name
        '
        Me.txtChild3Name.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild3Name.Location = New System.Drawing.Point(30, 118)
        Me.txtChild3Name.Multiline = True
        Me.txtChild3Name.Name = "txtChild3Name"
        Me.txtChild3Name.ReadOnly = True
        Me.txtChild3Name.Size = New System.Drawing.Size(147, 22)
        Me.txtChild3Name.TabIndex = 24
        '
        'txtChild2Name
        '
        Me.txtChild2Name.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild2Name.Location = New System.Drawing.Point(30, 70)
        Me.txtChild2Name.Multiline = True
        Me.txtChild2Name.Name = "txtChild2Name"
        Me.txtChild2Name.ReadOnly = True
        Me.txtChild2Name.Size = New System.Drawing.Size(147, 22)
        Me.txtChild2Name.TabIndex = 23
        '
        'txtChild1Name
        '
        Me.txtChild1Name.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChild1Name.Location = New System.Drawing.Point(30, 22)
        Me.txtChild1Name.Multiline = True
        Me.txtChild1Name.Name = "txtChild1Name"
        Me.txtChild1Name.ReadOnly = True
        Me.txtChild1Name.Size = New System.Drawing.Size(147, 21)
        Me.txtChild1Name.TabIndex = 22
        '
        'Label14
        '
        Me.Label14.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(31, 52)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(38, 13)
        Me.Label14.TabIndex = 21
        Me.Label14.Text = "Name:"
        '
        'Label15
        '
        Me.Label15.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(31, 100)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(38, 13)
        Me.Label15.TabIndex = 20
        Me.Label15.Text = "Name:"
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(31, 5)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 13)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "Name:"
        '
        'NextBtn
        '
        Me.NextBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NextBtn.BackColor = System.Drawing.Color.SeaGreen
        Me.NextBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NextBtn.FlatAppearance.BorderSize = 0
        Me.NextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NextBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.NextBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NextBtn.ForeColor = System.Drawing.Color.White
        Me.NextBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.NextBtn.IconColor = System.Drawing.Color.Black
        Me.NextBtn.IconSize = 16
        Me.NextBtn.Location = New System.Drawing.Point(903, 485)
        Me.NextBtn.Name = "NextBtn"
        Me.NextBtn.Rotation = 0R
        Me.NextBtn.Size = New System.Drawing.Size(67, 23)
        Me.NextBtn.TabIndex = 4
        Me.NextBtn.Text = "Next"
        Me.NextBtn.UseVisualStyleBackColor = False
        '
        'IconButton1
        '
        Me.IconButton1.BackColor = System.Drawing.Color.White
        Me.IconButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.ForeColor = System.Drawing.Color.Black
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft
        Me.IconButton1.IconColor = System.Drawing.Color.DarkGreen
        Me.IconButton1.IconSize = 18
        Me.IconButton1.Location = New System.Drawing.Point(12, 3)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(48, 23)
        Me.IconButton1.TabIndex = 5
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'AddMemberPage1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(996, 531)
        Me.Controls.Add(Me.IconButton1)
        Me.Controls.Add(Me.NextBtn)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "AddMemberPage1"
        Me.Text = "AddMemberPage1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents txtMemberSex As ComboBox
    Friend WithEvents txtMemberOthername As TextBox
    Friend WithEvents txtMemberSurname As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtMemberPhone As MaskedTextBox
    Friend WithEvents txtMemberHometown As TextBox
    Friend WithEvents typeOfMarriageText As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtMemberPostalAddress As TextBox
    Friend WithEvents txtMemberHouseNo As TextBox
    Friend WithEvents txtMaritalStatus As ComboBox
    Friend WithEvents txtTypeOfMarriage As ComboBox
    Friend WithEvents txtSpouseAddress As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtSpouseName As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents fiveChildren As RadioButton
    Friend WithEvents fourChildren As RadioButton
    Friend WithEvents threeChildren As RadioButton
    Friend WithEvents twoChildren As RadioButton
    Friend WithEvents oneChild As RadioButton
    Friend WithEvents eightChildren As RadioButton
    Friend WithEvents sevenChildren As RadioButton
    Friend WithEvents sixChildren As RadioButton
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtChild3Name As TextBox
    Friend WithEvents txtChild2Name As TextBox
    Friend WithEvents txtChild1Name As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents txtChild3DoBC As MaskedTextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents txtChild1DoBA As MaskedTextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents txtChild2DoBB As MaskedTextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txtChild6DoBF As MaskedTextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtChild4DoBD As MaskedTextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents txtChild5DoBE As MaskedTextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents txtChild6Name As TextBox
    Friend WithEvents txtChild5Name As TextBox
    Friend WithEvents txtChild4Name As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents NextBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents txtChild7DoBG As MaskedTextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents txtChild8DoBH As MaskedTextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents txtChild8Name As TextBox
    Friend WithEvents txtChild7Name As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents txtImageName As TextBox
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents Label37 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents noChild As RadioButton
    Friend WithEvents Label10 As Label
    Friend WithEvents txtSpousePhone As MaskedTextBox
    Friend WithEvents txtMemberStaffID As MaskedTextBox
    Friend WithEvents txtChild3DoB As DateTimePicker
    Friend WithEvents txtChild2DoB As DateTimePicker
    Friend WithEvents txtChild6DoB As DateTimePicker
    Friend WithEvents txtChild5DoB As DateTimePicker
    Friend WithEvents txtChild4DoB As DateTimePicker
    Friend WithEvents txtChild7DoB As DateTimePicker
    Friend WithEvents txtChild8DoB As DateTimePicker
    Friend WithEvents txtChild1DoB As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents txtMemberDoB As DateTimePicker
    Friend WithEvents txtMemberDoB1 As MaskedTextBox
    Friend WithEvents noProfilePic As CheckBox
End Class
