﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ClaimStatus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txtArreass = New System.Windows.Forms.Label()
        Me.monthAreasLabel = New System.Windows.Forms.Label()
        Me.numOfContributions = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtTotalClaims = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtSex = New System.Windows.Forms.Label()
        Me.txtDoB = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.Label()
        Me.txtFullName = New System.Windows.Forms.Label()
        Me.txtMemberId = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.btnProceed = New FontAwesome.Sharp.IconButton()
        Me.txtQualification = New FontAwesome.Sharp.IconButton()
        Me.MemberProfile = New System.Windows.Forms.PictureBox()
        CType(Me.MemberProfile, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtArreass
        '
        Me.txtArreass.AutoSize = True
        Me.txtArreass.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtArreass.Location = New System.Drawing.Point(489, 132)
        Me.txtArreass.Name = "txtArreass"
        Me.txtArreass.Size = New System.Drawing.Size(13, 15)
        Me.txtArreass.TabIndex = 75
        Me.txtArreass.Text = "0"
        Me.txtArreass.Visible = False
        '
        'monthAreasLabel
        '
        Me.monthAreasLabel.AutoSize = True
        Me.monthAreasLabel.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.monthAreasLabel.Location = New System.Drawing.Point(458, 115)
        Me.monthAreasLabel.Name = "monthAreasLabel"
        Me.monthAreasLabel.Size = New System.Drawing.Size(83, 13)
        Me.monthAreasLabel.TabIndex = 74
        Me.monthAreasLabel.Text = "Month Arrears"
        Me.monthAreasLabel.Visible = False
        '
        'numOfContributions
        '
        Me.numOfContributions.AutoSize = True
        Me.numOfContributions.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.numOfContributions.Location = New System.Drawing.Point(489, 96)
        Me.numOfContributions.Name = "numOfContributions"
        Me.numOfContributions.Size = New System.Drawing.Size(13, 15)
        Me.numOfContributions.TabIndex = 73
        Me.numOfContributions.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(434, 79)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(143, 13)
        Me.Label6.TabIndex = 72
        Me.Label6.Text = "Number Of Contributions"
        '
        'txtTotalClaims
        '
        Me.txtTotalClaims.AutoSize = True
        Me.txtTotalClaims.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalClaims.Location = New System.Drawing.Point(489, 55)
        Me.txtTotalClaims.Name = "txtTotalClaims"
        Me.txtTotalClaims.Size = New System.Drawing.Size(13, 15)
        Me.txtTotalClaims.TabIndex = 71
        Me.txtTotalClaims.Text = "0"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(447, 38)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(104, 13)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "Total Claims Made"
        '
        'txtSex
        '
        Me.txtSex.AutoSize = True
        Me.txtSex.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSex.Location = New System.Drawing.Point(284, 143)
        Me.txtSex.Name = "txtSex"
        Me.txtSex.Size = New System.Drawing.Size(26, 15)
        Me.txtSex.TabIndex = 67
        Me.txtSex.Text = "Sex:"
        '
        'txtDoB
        '
        Me.txtDoB.AutoSize = True
        Me.txtDoB.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDoB.Location = New System.Drawing.Point(284, 113)
        Me.txtDoB.Name = "txtDoB"
        Me.txtDoB.Size = New System.Drawing.Size(74, 15)
        Me.txtDoB.TabIndex = 66
        Me.txtDoB.Text = "Date of Birth:"
        '
        'txtPhone
        '
        Me.txtPhone.AutoSize = True
        Me.txtPhone.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhone.Location = New System.Drawing.Point(284, 77)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(58, 15)
        Me.txtPhone.TabIndex = 65
        Me.txtPhone.Text = "Phone No."
        '
        'txtFullName
        '
        Me.txtFullName.AutoSize = True
        Me.txtFullName.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFullName.Location = New System.Drawing.Point(284, 39)
        Me.txtFullName.Name = "txtFullName"
        Me.txtFullName.Size = New System.Drawing.Size(60, 15)
        Me.txtFullName.TabIndex = 64
        Me.txtFullName.Text = "Full Name:"
        '
        'txtMemberId
        '
        Me.txtMemberId.AutoSize = True
        Me.txtMemberId.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMemberId.Location = New System.Drawing.Point(38, 164)
        Me.txtMemberId.Name = "txtMemberId"
        Me.txtMemberId.Size = New System.Drawing.Size(23, 15)
        Me.txtMemberId.TabIndex = 63
        Me.txtMemberId.Text = "ID:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(174, 143)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(26, 15)
        Me.Label4.TabIndex = 61
        Me.Label4.Text = "Sex:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(174, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 15)
        Me.Label3.TabIndex = 60
        Me.Label3.Text = "Date of Birth:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(174, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 15)
        Me.Label2.TabIndex = 59
        Me.Label2.Text = "Phone No."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(174, 39)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 15)
        Me.Label5.TabIndex = 58
        Me.Label5.Text = "Full Name:"
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(627, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(16, 15)
        Me.Label1.TabIndex = 57
        Me.Label1.Text = "X"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.SeaGreen
        Me.LinkLabel1.Location = New System.Drawing.Point(357, 181)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(64, 15)
        Me.LinkLabel1.TabIndex = 76
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Print Status"
        '
        'btnProceed
        '
        Me.btnProceed.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.btnProceed.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnProceed.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnProceed.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProceed.ForeColor = System.Drawing.Color.White
        Me.btnProceed.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnProceed.IconColor = System.Drawing.Color.White
        Me.btnProceed.IconSize = 21
        Me.btnProceed.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnProceed.Location = New System.Drawing.Point(507, 171)
        Me.btnProceed.Name = "btnProceed"
        Me.btnProceed.Rotation = 0R
        Me.btnProceed.Size = New System.Drawing.Size(87, 32)
        Me.btnProceed.TabIndex = 69
        Me.btnProceed.Text = "Proceed"
        Me.btnProceed.UseVisualStyleBackColor = False
        Me.btnProceed.Visible = False
        '
        'txtQualification
        '
        Me.txtQualification.BackColor = System.Drawing.Color.Green
        Me.txtQualification.FlatAppearance.BorderSize = 0
        Me.txtQualification.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green
        Me.txtQualification.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green
        Me.txtQualification.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtQualification.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.txtQualification.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQualification.ForeColor = System.Drawing.Color.White
        Me.txtQualification.IconChar = FontAwesome.Sharp.IconChar.Check
        Me.txtQualification.IconColor = System.Drawing.Color.White
        Me.txtQualification.IconSize = 21
        Me.txtQualification.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.txtQualification.Location = New System.Drawing.Point(239, 171)
        Me.txtQualification.Name = "txtQualification"
        Me.txtQualification.Rotation = 0R
        Me.txtQualification.Size = New System.Drawing.Size(112, 32)
        Me.txtQualification.TabIndex = 68
        Me.txtQualification.Text = "Qualified"
        Me.txtQualification.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.txtQualification.UseVisualStyleBackColor = False
        '
        'MemberProfile
        '
        Me.MemberProfile.BackColor = System.Drawing.Color.WhiteSmoke
        Me.MemberProfile.Location = New System.Drawing.Point(15, 31)
        Me.MemberProfile.Name = "MemberProfile"
        Me.MemberProfile.Size = New System.Drawing.Size(131, 127)
        Me.MemberProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.MemberProfile.TabIndex = 62
        Me.MemberProfile.TabStop = False
        '
        'ClaimStatus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(658, 216)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.txtArreass)
        Me.Controls.Add(Me.monthAreasLabel)
        Me.Controls.Add(Me.numOfContributions)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtTotalClaims)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.btnProceed)
        Me.Controls.Add(Me.txtQualification)
        Me.Controls.Add(Me.txtSex)
        Me.Controls.Add(Me.txtDoB)
        Me.Controls.Add(Me.txtPhone)
        Me.Controls.Add(Me.txtFullName)
        Me.Controls.Add(Me.txtMemberId)
        Me.Controls.Add(Me.MemberProfile)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "ClaimStatus"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ClaimStatus"
        CType(Me.MemberProfile, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtArreass As Label
    Friend WithEvents monthAreasLabel As Label
    Friend WithEvents numOfContributions As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtTotalClaims As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents btnProceed As FontAwesome.Sharp.IconButton
    Friend WithEvents txtQualification As FontAwesome.Sharp.IconButton
    Friend WithEvents txtSex As Label
    Friend WithEvents txtDoB As Label
    Friend WithEvents txtPhone As Label
    Friend WithEvents txtFullName As Label
    Friend WithEvents txtMemberId As Label
    Friend WithEvents MemberProfile As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents LinkLabel1 As LinkLabel
End Class
