﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SecEditMemberProfile2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.IconButton8 = New FontAwesome.Sharp.IconButton()
        Me.IconButton5 = New FontAwesome.Sharp.IconButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.txtFatherPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtMotherPhone = New System.Windows.Forms.MaskedTextBox()
        Me.motherLiveStatus = New System.Windows.Forms.Panel()
        Me.txtMotherAlive = New System.Windows.Forms.RadioButton()
        Me.txtMotherDead = New System.Windows.Forms.RadioButton()
        Me.fatherLiveStatus = New System.Windows.Forms.Panel()
        Me.txtFatherAlive = New System.Windows.Forms.RadioButton()
        Me.txtFatherDead = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtFatherName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtMotherName = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.beneficiariesDataGridView = New System.Windows.Forms.DataGridView()
        Me.previousBtn = New FontAwesome.Sharp.IconButton()
        Me.GroupBox2.SuspendLayout()
        Me.motherLiveStatus.SuspendLayout()
        Me.fatherLiveStatus.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.beneficiariesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IconButton8
        '
        Me.IconButton8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton8.BackColor = System.Drawing.Color.SaddleBrown
        Me.IconButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton8.FlatAppearance.BorderSize = 0
        Me.IconButton8.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton8.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton8.ForeColor = System.Drawing.Color.White
        Me.IconButton8.IconChar = FontAwesome.Sharp.IconChar.Upload
        Me.IconButton8.IconColor = System.Drawing.Color.White
        Me.IconButton8.IconSize = 16
        Me.IconButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton8.Location = New System.Drawing.Point(446, 183)
        Me.IconButton8.Name = "IconButton8"
        Me.IconButton8.Rotation = 0R
        Me.IconButton8.Size = New System.Drawing.Size(91, 27)
        Me.IconButton8.TabIndex = 30
        Me.IconButton8.Text = "Update"
        Me.IconButton8.UseVisualStyleBackColor = False
        '
        'IconButton5
        '
        Me.IconButton5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton5.BackColor = System.Drawing.Color.Tomato
        Me.IconButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton5.FlatAppearance.BorderSize = 0
        Me.IconButton5.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton5.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton5.ForeColor = System.Drawing.Color.White
        Me.IconButton5.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton5.IconColor = System.Drawing.Color.White
        Me.IconButton5.IconSize = 16
        Me.IconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton5.Location = New System.Drawing.Point(446, 376)
        Me.IconButton5.Name = "IconButton5"
        Me.IconButton5.Rotation = 0R
        Me.IconButton5.Size = New System.Drawing.Size(113, 27)
        Me.IconButton5.TabIndex = 29
        Me.IconButton5.Text = "Update Page"
        Me.IconButton5.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.IconButton1)
        Me.GroupBox2.Controls.Add(Me.txtFatherPhone)
        Me.GroupBox2.Controls.Add(Me.txtMotherPhone)
        Me.GroupBox2.Controls.Add(Me.motherLiveStatus)
        Me.GroupBox2.Controls.Add(Me.fatherLiveStatus)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.txtFatherName)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.txtMotherName)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(16, 43)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(967, 134)
        Me.GroupBox2.TabIndex = 28
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "DETAILS OF PARENTS(IF ANY)"
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton1.BackColor = System.Drawing.Color.Orange
        Me.IconButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton1.ForeColor = System.Drawing.Color.White
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.Edit
        Me.IconButton1.IconColor = System.Drawing.Color.Black
        Me.IconButton1.IconSize = 24
        Me.IconButton1.Location = New System.Drawing.Point(933, 9)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(28, 23)
        Me.IconButton1.TabIndex = 36
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'txtFatherPhone
        '
        Me.txtFatherPhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFatherPhone.Location = New System.Drawing.Point(494, 104)
        Me.txtFatherPhone.Name = "txtFatherPhone"
        Me.txtFatherPhone.ReadOnly = True
        Me.txtFatherPhone.Size = New System.Drawing.Size(280, 21)
        Me.txtFatherPhone.TabIndex = 35
        '
        'txtMotherPhone
        '
        Me.txtMotherPhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMotherPhone.Location = New System.Drawing.Point(494, 45)
        Me.txtMotherPhone.Name = "txtMotherPhone"
        Me.txtMotherPhone.ReadOnly = True
        Me.txtMotherPhone.Size = New System.Drawing.Size(280, 21)
        Me.txtMotherPhone.TabIndex = 34
        '
        'motherLiveStatus
        '
        Me.motherLiveStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.motherLiveStatus.BackColor = System.Drawing.Color.WhiteSmoke
        Me.motherLiveStatus.Controls.Add(Me.txtMotherAlive)
        Me.motherLiveStatus.Controls.Add(Me.txtMotherDead)
        Me.motherLiveStatus.Location = New System.Drawing.Point(819, 41)
        Me.motherLiveStatus.Name = "motherLiveStatus"
        Me.motherLiveStatus.Size = New System.Drawing.Size(118, 25)
        Me.motherLiveStatus.TabIndex = 33
        '
        'txtMotherAlive
        '
        Me.txtMotherAlive.AutoSize = True
        Me.txtMotherAlive.Location = New System.Drawing.Point(58, 3)
        Me.txtMotherAlive.Name = "txtMotherAlive"
        Me.txtMotherAlive.Size = New System.Drawing.Size(51, 19)
        Me.txtMotherAlive.TabIndex = 1
        Me.txtMotherAlive.TabStop = True
        Me.txtMotherAlive.Text = "Alive"
        Me.txtMotherAlive.UseVisualStyleBackColor = True
        '
        'txtMotherDead
        '
        Me.txtMotherDead.AutoSize = True
        Me.txtMotherDead.Location = New System.Drawing.Point(5, 3)
        Me.txtMotherDead.Name = "txtMotherDead"
        Me.txtMotherDead.Size = New System.Drawing.Size(50, 19)
        Me.txtMotherDead.TabIndex = 0
        Me.txtMotherDead.TabStop = True
        Me.txtMotherDead.Text = "Dead"
        Me.txtMotherDead.UseVisualStyleBackColor = True
        '
        'fatherLiveStatus
        '
        Me.fatherLiveStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.fatherLiveStatus.BackColor = System.Drawing.Color.WhiteSmoke
        Me.fatherLiveStatus.Controls.Add(Me.txtFatherAlive)
        Me.fatherLiveStatus.Controls.Add(Me.txtFatherDead)
        Me.fatherLiveStatus.Location = New System.Drawing.Point(819, 99)
        Me.fatherLiveStatus.Name = "fatherLiveStatus"
        Me.fatherLiveStatus.Size = New System.Drawing.Size(118, 25)
        Me.fatherLiveStatus.TabIndex = 32
        '
        'txtFatherAlive
        '
        Me.txtFatherAlive.AutoSize = True
        Me.txtFatherAlive.Location = New System.Drawing.Point(58, 3)
        Me.txtFatherAlive.Name = "txtFatherAlive"
        Me.txtFatherAlive.Size = New System.Drawing.Size(51, 19)
        Me.txtFatherAlive.TabIndex = 1
        Me.txtFatherAlive.TabStop = True
        Me.txtFatherAlive.Text = "Alive"
        Me.txtFatherAlive.UseVisualStyleBackColor = True
        '
        'txtFatherDead
        '
        Me.txtFatherDead.AutoSize = True
        Me.txtFatherDead.Location = New System.Drawing.Point(5, 4)
        Me.txtFatherDead.Name = "txtFatherDead"
        Me.txtFatherDead.Size = New System.Drawing.Size(50, 19)
        Me.txtFatherDead.TabIndex = 0
        Me.txtFatherDead.TabStop = True
        Me.txtFatherDead.Text = "Dead"
        Me.txtFatherDead.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 15)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Father's Name:"
        '
        'txtFatherName
        '
        Me.txtFatherName.Location = New System.Drawing.Point(13, 104)
        Me.txtFatherName.Multiline = True
        Me.txtFatherName.Name = "txtFatherName"
        Me.txtFatherName.ReadOnly = True
        Me.txtFatherName.Size = New System.Drawing.Size(431, 21)
        Me.txtFatherName.TabIndex = 28
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(498, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 15)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Phone No:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(22, 26)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(85, 15)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Mother's Name:"
        '
        'txtMotherName
        '
        Me.txtMotherName.Location = New System.Drawing.Point(13, 45)
        Me.txtMotherName.Multiline = True
        Me.txtMotherName.Name = "txtMotherName"
        Me.txtMotherName.ReadOnly = True
        Me.txtMotherName.Size = New System.Drawing.Size(431, 21)
        Me.txtMotherName.TabIndex = 23
        '
        'Label11
        '
        Me.Label11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(497, 26)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(58, 15)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Phone No:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.beneficiariesDataGridView)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(11, 227)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(967, 143)
        Me.GroupBox1.TabIndex = 27
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "BENEFICIARIES/NEXT OF KIN"
        '
        'beneficiariesDataGridView
        '
        Me.beneficiariesDataGridView.AllowUserToAddRows = False
        Me.beneficiariesDataGridView.AllowUserToDeleteRows = False
        Me.beneficiariesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.beneficiariesDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.beneficiariesDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.beneficiariesDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.beneficiariesDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.beneficiariesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.beneficiariesDataGridView.DefaultCellStyle = DataGridViewCellStyle5
        Me.beneficiariesDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.beneficiariesDataGridView.Location = New System.Drawing.Point(3, 17)
        Me.beneficiariesDataGridView.Name = "beneficiariesDataGridView"
        Me.beneficiariesDataGridView.ReadOnly = True
        Me.beneficiariesDataGridView.RowHeadersVisible = False
        Me.beneficiariesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.beneficiariesDataGridView.Size = New System.Drawing.Size(961, 123)
        Me.beneficiariesDataGridView.TabIndex = 1
        '
        'previousBtn
        '
        Me.previousBtn.BackColor = System.Drawing.Color.White
        Me.previousBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.previousBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.previousBtn.ForeColor = System.Drawing.Color.Black
        Me.previousBtn.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft
        Me.previousBtn.IconColor = System.Drawing.Color.DarkGreen
        Me.previousBtn.IconSize = 18
        Me.previousBtn.Location = New System.Drawing.Point(11, 3)
        Me.previousBtn.Name = "previousBtn"
        Me.previousBtn.Rotation = 0R
        Me.previousBtn.Size = New System.Drawing.Size(48, 23)
        Me.previousBtn.TabIndex = 26
        Me.previousBtn.UseVisualStyleBackColor = False
        '
        'SecEditMemberProfile2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(996, 531)
        Me.Controls.Add(Me.IconButton8)
        Me.Controls.Add(Me.IconButton5)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.previousBtn)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "SecEditMemberProfile2"
        Me.Text = "SecEditMemberProfile2"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.motherLiveStatus.ResumeLayout(False)
        Me.motherLiveStatus.PerformLayout()
        Me.fatherLiveStatus.ResumeLayout(False)
        Me.fatherLiveStatus.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.beneficiariesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents IconButton8 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton5 As FontAwesome.Sharp.IconButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtFatherPhone As MaskedTextBox
    Friend WithEvents txtMotherPhone As MaskedTextBox
    Friend WithEvents motherLiveStatus As Panel
    Friend WithEvents txtMotherAlive As RadioButton
    Friend WithEvents txtMotherDead As RadioButton
    Friend WithEvents fatherLiveStatus As Panel
    Friend WithEvents txtFatherAlive As RadioButton
    Friend WithEvents txtFatherDead As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents txtFatherName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents txtMotherName As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents beneficiariesDataGridView As DataGridView
    Friend WithEvents previousBtn As FontAwesome.Sharp.IconButton
End Class
