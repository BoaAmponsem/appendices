﻿Imports System.Data.SqlClient
Public Class UsersPage
    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select * from UsersTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Date_Account_Created  like '%' +@parm1+ '%' "
            query &= " or Staff_ID like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using
            '  End Using
        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function
    Sub switchPages(ByVal pageSwitch1 As Form)
        Try

            Form1.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            Form1.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        Dim nwAddUserFormPage = New AddUserFormPage
        switchPages(nwAddUserFormPage)
    End Sub
    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select * from UsersTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            usersDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub UsersPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
    End Sub

    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        usersDataGridView.DataSource = Me.SearchItem
    End Sub
End Class