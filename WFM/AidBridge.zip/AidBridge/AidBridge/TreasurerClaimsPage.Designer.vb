﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TreasurerClaimsPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.txtSearchItem = New System.Windows.Forms.TextBox()
        Me.ClaimsDataGridView = New System.Windows.Forms.DataGridView()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ClaimRequestTab = New System.Windows.Forms.GroupBox()
        Me.approvalsDataGridView = New System.Windows.Forms.DataGridView()
        Me.memberNotFoundFeedback = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.memberNoFTxt = New System.Windows.Forms.Label()
        Me.ClaimsTab = New System.Windows.Forms.GroupBox()
        Me.MemberClaimsDataGridView = New System.Windows.Forms.DataGridView()
        Me.showProfileBtn = New FontAwesome.Sharp.IconButton()
        Me.ClaimStatusBtn = New FontAwesome.Sharp.IconButton()
        Me.InformationTab = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtStaffID = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtPostalAddress = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtHouseNo = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtMarriageType = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtMaritalStatus = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtHomeTown = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtSex = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBirthDate = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtMemberOtherName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.selectIDType = New System.Windows.Forms.ComboBox()
        Me.QueryBtn = New FontAwesome.Sharp.IconButton()
        Me.searchBox = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.ClaimsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.ClaimRequestTab.SuspendLayout()
        CType(Me.approvalsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.memberNotFoundFeedback.SuspendLayout()
        Me.ClaimsTab.SuspendLayout()
        CType(Me.MemberClaimsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.InformationTab.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(905, 518)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.IconButton2)
        Me.TabPage1.Controls.Add(Me.txtSearchItem)
        Me.TabPage1.Controls.Add(Me.ClaimsDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(897, 490)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Claims"
        '
        'IconButton2
        '
        Me.IconButton2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton2.BackColor = System.Drawing.Color.SeaGreen
        Me.IconButton2.FlatAppearance.BorderSize = 0
        Me.IconButton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen
        Me.IconButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.ForestGreen
        Me.IconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.Search
        Me.IconButton2.IconColor = System.Drawing.Color.White
        Me.IconButton2.IconSize = 19
        Me.IconButton2.Location = New System.Drawing.Point(257, 14)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(41, 28)
        Me.IconButton2.TabIndex = 4
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'txtSearchItem
        '
        Me.txtSearchItem.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtSearchItem.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchItem.Location = New System.Drawing.Point(297, 14)
        Me.txtSearchItem.Multiline = True
        Me.txtSearchItem.Name = "txtSearchItem"
        Me.txtSearchItem.Size = New System.Drawing.Size(311, 28)
        Me.txtSearchItem.TabIndex = 3
        '
        'ClaimsDataGridView
        '
        Me.ClaimsDataGridView.AllowUserToAddRows = False
        Me.ClaimsDataGridView.AllowUserToDeleteRows = False
        Me.ClaimsDataGridView.AllowUserToResizeColumns = False
        Me.ClaimsDataGridView.AllowUserToResizeRows = False
        Me.ClaimsDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClaimsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.ClaimsDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.ClaimsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ClaimsDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.ClaimsDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.ClaimsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ClaimsDataGridView.DefaultCellStyle = DataGridViewCellStyle1
        Me.ClaimsDataGridView.Location = New System.Drawing.Point(8, 84)
        Me.ClaimsDataGridView.Name = "ClaimsDataGridView"
        Me.ClaimsDataGridView.ReadOnly = True
        Me.ClaimsDataGridView.RowHeadersVisible = False
        Me.ClaimsDataGridView.RowTemplate.Height = 32
        Me.ClaimsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ClaimsDataGridView.Size = New System.Drawing.Size(881, 398)
        Me.ClaimsDataGridView.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage2.Controls.Add(Me.ClaimRequestTab)
        Me.TabPage2.Controls.Add(Me.memberNotFoundFeedback)
        Me.TabPage2.Controls.Add(Me.ClaimsTab)
        Me.TabPage2.Controls.Add(Me.showProfileBtn)
        Me.TabPage2.Controls.Add(Me.ClaimStatusBtn)
        Me.TabPage2.Controls.Add(Me.InformationTab)
        Me.TabPage2.Controls.Add(Me.selectIDType)
        Me.TabPage2.Controls.Add(Me.QueryBtn)
        Me.TabPage2.Controls.Add(Me.searchBox)
        Me.TabPage2.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(897, 490)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Make Claims"
        '
        'ClaimRequestTab
        '
        Me.ClaimRequestTab.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClaimRequestTab.BackColor = System.Drawing.Color.White
        Me.ClaimRequestTab.Controls.Add(Me.approvalsDataGridView)
        Me.ClaimRequestTab.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClaimRequestTab.Location = New System.Drawing.Point(375, 343)
        Me.ClaimRequestTab.Name = "ClaimRequestTab"
        Me.ClaimRequestTab.Size = New System.Drawing.Size(517, 141)
        Me.ClaimRequestTab.TabIndex = 8
        Me.ClaimRequestTab.TabStop = False
        Me.ClaimRequestTab.Text = "Claim Request"
        Me.ClaimRequestTab.Visible = False
        '
        'approvalsDataGridView
        '
        Me.approvalsDataGridView.AllowUserToAddRows = False
        Me.approvalsDataGridView.AllowUserToDeleteRows = False
        Me.approvalsDataGridView.AllowUserToResizeColumns = False
        Me.approvalsDataGridView.AllowUserToResizeRows = False
        Me.approvalsDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.approvalsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.approvalsDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.approvalsDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.approvalsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.approvalsDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.approvalsDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.approvalsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.approvalsDataGridView.DefaultCellStyle = DataGridViewCellStyle2
        Me.approvalsDataGridView.Location = New System.Drawing.Point(6, 17)
        Me.approvalsDataGridView.Name = "approvalsDataGridView"
        Me.approvalsDataGridView.ReadOnly = True
        Me.approvalsDataGridView.RowHeadersVisible = False
        Me.approvalsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.approvalsDataGridView.Size = New System.Drawing.Size(505, 118)
        Me.approvalsDataGridView.TabIndex = 7
        '
        'memberNotFoundFeedback
        '
        Me.memberNotFoundFeedback.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.memberNotFoundFeedback.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.memberNotFoundFeedback.Controls.Add(Me.Label13)
        Me.memberNotFoundFeedback.Controls.Add(Me.memberNoFTxt)
        Me.memberNotFoundFeedback.Location = New System.Drawing.Point(754, 7)
        Me.memberNotFoundFeedback.Name = "memberNotFoundFeedback"
        Me.memberNotFoundFeedback.Size = New System.Drawing.Size(136, 40)
        Me.memberNotFoundFeedback.TabIndex = 8
        Me.memberNotFoundFeedback.Visible = False
        '
        'Label13
        '
        Me.Label13.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label13.AutoSize = True
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(123, -2)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(12, 15)
        Me.Label13.TabIndex = 22
        Me.Label13.Text = "x"
        '
        'memberNoFTxt
        '
        Me.memberNoFTxt.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.memberNoFTxt.AutoSize = True
        Me.memberNoFTxt.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.memberNoFTxt.ForeColor = System.Drawing.Color.White
        Me.memberNoFTxt.Location = New System.Drawing.Point(8, 11)
        Me.memberNoFTxt.Name = "memberNoFTxt"
        Me.memberNoFTxt.Size = New System.Drawing.Size(120, 20)
        Me.memberNoFTxt.TabIndex = 6
        Me.memberNoFTxt.Text = "Member not found"
        '
        'ClaimsTab
        '
        Me.ClaimsTab.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ClaimsTab.BackColor = System.Drawing.Color.White
        Me.ClaimsTab.Controls.Add(Me.MemberClaimsDataGridView)
        Me.ClaimsTab.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClaimsTab.Location = New System.Drawing.Point(8, 343)
        Me.ClaimsTab.Name = "ClaimsTab"
        Me.ClaimsTab.Size = New System.Drawing.Size(351, 141)
        Me.ClaimsTab.TabIndex = 7
        Me.ClaimsTab.TabStop = False
        Me.ClaimsTab.Text = "Claims Made"
        Me.ClaimsTab.Visible = False
        '
        'MemberClaimsDataGridView
        '
        Me.MemberClaimsDataGridView.AllowUserToAddRows = False
        Me.MemberClaimsDataGridView.AllowUserToDeleteRows = False
        Me.MemberClaimsDataGridView.AllowUserToResizeColumns = False
        Me.MemberClaimsDataGridView.AllowUserToResizeRows = False
        Me.MemberClaimsDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MemberClaimsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.MemberClaimsDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.MemberClaimsDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.MemberClaimsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MemberClaimsDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.MemberClaimsDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.MemberClaimsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.MemberClaimsDataGridView.DefaultCellStyle = DataGridViewCellStyle3
        Me.MemberClaimsDataGridView.Location = New System.Drawing.Point(6, 17)
        Me.MemberClaimsDataGridView.Name = "MemberClaimsDataGridView"
        Me.MemberClaimsDataGridView.ReadOnly = True
        Me.MemberClaimsDataGridView.RowHeadersVisible = False
        Me.MemberClaimsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.MemberClaimsDataGridView.Size = New System.Drawing.Size(339, 118)
        Me.MemberClaimsDataGridView.TabIndex = 7
        '
        'showProfileBtn
        '
        Me.showProfileBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.showProfileBtn.BackColor = System.Drawing.Color.Salmon
        Me.showProfileBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.showProfileBtn.FlatAppearance.BorderSize = 0
        Me.showProfileBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.showProfileBtn.ForeColor = System.Drawing.Color.White
        Me.showProfileBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.showProfileBtn.IconColor = System.Drawing.Color.Black
        Me.showProfileBtn.IconSize = 16
        Me.showProfileBtn.Location = New System.Drawing.Point(647, 297)
        Me.showProfileBtn.Name = "showProfileBtn"
        Me.showProfileBtn.Rotation = 0R
        Me.showProfileBtn.Size = New System.Drawing.Size(92, 31)
        Me.showProfileBtn.TabIndex = 6
        Me.showProfileBtn.Text = "Show Profile"
        Me.showProfileBtn.UseVisualStyleBackColor = False
        Me.showProfileBtn.Visible = False
        '
        'ClaimStatusBtn
        '
        Me.ClaimStatusBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClaimStatusBtn.BackColor = System.Drawing.Color.Chocolate
        Me.ClaimStatusBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ClaimStatusBtn.FlatAppearance.BorderSize = 0
        Me.ClaimStatusBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.ClaimStatusBtn.ForeColor = System.Drawing.Color.White
        Me.ClaimStatusBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.ClaimStatusBtn.IconColor = System.Drawing.Color.Black
        Me.ClaimStatusBtn.IconSize = 16
        Me.ClaimStatusBtn.Location = New System.Drawing.Point(782, 297)
        Me.ClaimStatusBtn.Name = "ClaimStatusBtn"
        Me.ClaimStatusBtn.Rotation = 0R
        Me.ClaimStatusBtn.Size = New System.Drawing.Size(92, 31)
        Me.ClaimStatusBtn.TabIndex = 5
        Me.ClaimStatusBtn.Text = "Claim Status"
        Me.ClaimStatusBtn.UseVisualStyleBackColor = False
        Me.ClaimStatusBtn.Visible = False
        '
        'InformationTab
        '
        Me.InformationTab.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.InformationTab.BackColor = System.Drawing.Color.White
        Me.InformationTab.Controls.Add(Me.Label9)
        Me.InformationTab.Controls.Add(Me.txtStaffID)
        Me.InformationTab.Controls.Add(Me.Label11)
        Me.InformationTab.Controls.Add(Me.txtPhone)
        Me.InformationTab.Controls.Add(Me.Label12)
        Me.InformationTab.Controls.Add(Me.txtPostalAddress)
        Me.InformationTab.Controls.Add(Me.Label5)
        Me.InformationTab.Controls.Add(Me.txtHouseNo)
        Me.InformationTab.Controls.Add(Me.Label6)
        Me.InformationTab.Controls.Add(Me.txtMarriageType)
        Me.InformationTab.Controls.Add(Me.Label7)
        Me.InformationTab.Controls.Add(Me.txtMaritalStatus)
        Me.InformationTab.Controls.Add(Me.Label8)
        Me.InformationTab.Controls.Add(Me.txtHomeTown)
        Me.InformationTab.Controls.Add(Me.Label4)
        Me.InformationTab.Controls.Add(Me.txtSex)
        Me.InformationTab.Controls.Add(Me.Label3)
        Me.InformationTab.Controls.Add(Me.txtBirthDate)
        Me.InformationTab.Controls.Add(Me.Label2)
        Me.InformationTab.Controls.Add(Me.txtMemberOtherName)
        Me.InformationTab.Controls.Add(Me.Label1)
        Me.InformationTab.Controls.Add(Me.txtSurname)
        Me.InformationTab.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InformationTab.Location = New System.Drawing.Point(6, 98)
        Me.InformationTab.Name = "InformationTab"
        Me.InformationTab.Size = New System.Drawing.Size(886, 193)
        Me.InformationTab.TabIndex = 3
        Me.InformationTab.TabStop = False
        Me.InformationTab.Text = "Information"
        Me.InformationTab.Visible = False
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(503, 134)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 15)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Staff ID:"
        '
        'txtStaffID
        '
        Me.txtStaffID.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtStaffID.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStaffID.Location = New System.Drawing.Point(503, 153)
        Me.txtStaffID.Multiline = True
        Me.txtStaffID.Name = "txtStaffID"
        Me.txtStaffID.ReadOnly = True
        Me.txtStaffID.Size = New System.Drawing.Size(146, 27)
        Me.txtStaffID.TabIndex = 20
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(257, 134)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 15)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Phone No.:"
        '
        'txtPhone
        '
        Me.txtPhone.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPhone.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhone.Location = New System.Drawing.Point(257, 153)
        Me.txtPhone.Multiline = True
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.ReadOnly = True
        Me.txtPhone.Size = New System.Drawing.Size(188, 27)
        Me.txtPhone.TabIndex = 18
        '
        'Label12
        '
        Me.Label12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(19, 134)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 15)
        Me.Label12.TabIndex = 17
        Me.Label12.Text = "Postal Address:"
        '
        'txtPostalAddress
        '
        Me.txtPostalAddress.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPostalAddress.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPostalAddress.Location = New System.Drawing.Point(19, 153)
        Me.txtPostalAddress.Multiline = True
        Me.txtPostalAddress.Name = "txtPostalAddress"
        Me.txtPostalAddress.ReadOnly = True
        Me.txtPostalAddress.Size = New System.Drawing.Size(201, 27)
        Me.txtPostalAddress.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(696, 82)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 15)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "House No.:"
        '
        'txtHouseNo
        '
        Me.txtHouseNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtHouseNo.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHouseNo.Location = New System.Drawing.Point(696, 101)
        Me.txtHouseNo.Multiline = True
        Me.txtHouseNo.Name = "txtHouseNo"
        Me.txtHouseNo.ReadOnly = True
        Me.txtHouseNo.Size = New System.Drawing.Size(152, 27)
        Me.txtHouseNo.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(503, 82)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(95, 15)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Type of Marriage:"
        '
        'txtMarriageType
        '
        Me.txtMarriageType.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMarriageType.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMarriageType.Location = New System.Drawing.Point(503, 101)
        Me.txtMarriageType.Multiline = True
        Me.txtMarriageType.Name = "txtMarriageType"
        Me.txtMarriageType.ReadOnly = True
        Me.txtMarriageType.Size = New System.Drawing.Size(146, 27)
        Me.txtMarriageType.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(254, 82)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 15)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Marital Status:"
        '
        'txtMaritalStatus
        '
        Me.txtMaritalStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMaritalStatus.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMaritalStatus.Location = New System.Drawing.Point(254, 101)
        Me.txtMaritalStatus.Multiline = True
        Me.txtMaritalStatus.Name = "txtMaritalStatus"
        Me.txtMaritalStatus.ReadOnly = True
        Me.txtMaritalStatus.Size = New System.Drawing.Size(188, 27)
        Me.txtMaritalStatus.TabIndex = 10
        '
        'Label8
        '
        Me.Label8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(16, 82)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 15)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Hometown:"
        '
        'txtHomeTown
        '
        Me.txtHomeTown.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtHomeTown.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHomeTown.Location = New System.Drawing.Point(16, 101)
        Me.txtHomeTown.Multiline = True
        Me.txtHomeTown.Name = "txtHomeTown"
        Me.txtHomeTown.ReadOnly = True
        Me.txtHomeTown.Size = New System.Drawing.Size(201, 27)
        Me.txtHomeTown.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(696, 29)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(26, 15)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Sex:"
        '
        'txtSex
        '
        Me.txtSex.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSex.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSex.Location = New System.Drawing.Point(696, 48)
        Me.txtSex.Multiline = True
        Me.txtSex.Name = "txtSex"
        Me.txtSex.ReadOnly = True
        Me.txtSex.Size = New System.Drawing.Size(152, 27)
        Me.txtSex.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(503, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Date of Birth:"
        '
        'txtBirthDate
        '
        Me.txtBirthDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBirthDate.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBirthDate.Location = New System.Drawing.Point(503, 48)
        Me.txtBirthDate.Multiline = True
        Me.txtBirthDate.Name = "txtBirthDate"
        Me.txtBirthDate.ReadOnly = True
        Me.txtBirthDate.Size = New System.Drawing.Size(146, 27)
        Me.txtBirthDate.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(254, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Other Names:"
        '
        'txtMemberOtherName
        '
        Me.txtMemberOtherName.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberOtherName.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMemberOtherName.Location = New System.Drawing.Point(254, 48)
        Me.txtMemberOtherName.Multiline = True
        Me.txtMemberOtherName.Name = "txtMemberOtherName"
        Me.txtMemberOtherName.ReadOnly = True
        Me.txtMemberOtherName.Size = New System.Drawing.Size(188, 27)
        Me.txtMemberOtherName.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Surname:"
        '
        'txtSurname
        '
        Me.txtSurname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSurname.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSurname.Location = New System.Drawing.Point(16, 48)
        Me.txtSurname.Multiline = True
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.ReadOnly = True
        Me.txtSurname.Size = New System.Drawing.Size(201, 27)
        Me.txtSurname.TabIndex = 0
        '
        'selectIDType
        '
        Me.selectIDType.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.selectIDType.BackColor = System.Drawing.Color.White
        Me.selectIDType.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.selectIDType.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.selectIDType.Items.AddRange(New Object() {"Staff ID", "Phone"})
        Me.selectIDType.Location = New System.Drawing.Point(19, 26)
        Me.selectIDType.Name = "selectIDType"
        Me.selectIDType.Size = New System.Drawing.Size(146, 23)
        Me.selectIDType.TabIndex = 2
        Me.selectIDType.Text = "Staff ID"
        '
        'QueryBtn
        '
        Me.QueryBtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.QueryBtn.BackColor = System.Drawing.Color.SeaGreen
        Me.QueryBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.QueryBtn.FlatAppearance.BorderSize = 0
        Me.QueryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.QueryBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.QueryBtn.ForeColor = System.Drawing.Color.White
        Me.QueryBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.QueryBtn.IconColor = System.Drawing.Color.Black
        Me.QueryBtn.IconSize = 16
        Me.QueryBtn.Location = New System.Drawing.Point(652, 22)
        Me.QueryBtn.Name = "QueryBtn"
        Me.QueryBtn.Rotation = 0R
        Me.QueryBtn.Size = New System.Drawing.Size(76, 30)
        Me.QueryBtn.TabIndex = 1
        Me.QueryBtn.Text = "Query"
        Me.QueryBtn.UseVisualStyleBackColor = False
        '
        'searchBox
        '
        Me.searchBox.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.searchBox.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.searchBox.Location = New System.Drawing.Point(172, 21)
        Me.searchBox.Multiline = True
        Me.searchBox.Name = "searchBox"
        Me.searchBox.Size = New System.Drawing.Size(471, 30)
        Me.searchBox.TabIndex = 0
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'TreasurerClaimsPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(905, 518)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "TreasurerClaimsPage"
        Me.Text = "TreasurerClaimsPage"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.ClaimsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ClaimRequestTab.ResumeLayout(False)
        CType(Me.approvalsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.memberNotFoundFeedback.ResumeLayout(False)
        Me.memberNotFoundFeedback.PerformLayout()
        Me.ClaimsTab.ResumeLayout(False)
        CType(Me.MemberClaimsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.InformationTab.ResumeLayout(False)
        Me.InformationTab.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtSearchItem As TextBox
    Friend WithEvents ClaimsDataGridView As DataGridView
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents memberNotFoundFeedback As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents memberNoFTxt As Label
    Friend WithEvents ClaimsTab As GroupBox
    Friend WithEvents MemberClaimsDataGridView As DataGridView
    Friend WithEvents showProfileBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents ClaimStatusBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents InformationTab As GroupBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtStaffID As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtPostalAddress As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtHouseNo As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtMarriageType As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtMaritalStatus As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtHomeTown As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtSex As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtBirthDate As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtMemberOtherName As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtSurname As TextBox
    Friend WithEvents selectIDType As ComboBox
    Friend WithEvents QueryBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents searchBox As TextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ClaimRequestTab As GroupBox
    Friend WithEvents approvalsDataGridView As DataGridView
End Class
