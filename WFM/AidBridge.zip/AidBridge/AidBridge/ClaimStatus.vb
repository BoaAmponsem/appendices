﻿Imports System.Data.SqlClient
Imports System.Drawing.Drawing2D


Imports Microsoft.Reporting.WinForms
Imports System.Net

Public Class ClaimStatus
    Private borderRadius As Integer = 20
    Private borderSize As Integer = 3
    Private borderColor As Color = Color.SeaGreen

    'Constractor
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Private Function GetRoundedPath(rect As Rectangle, radius As Single) As GraphicsPath
        Dim path As GraphicsPath = New GraphicsPath()
        Dim curveSize As Single = radius * 2.0F
        path.StartFigure()
        path.AddArc(rect.X, rect.Y, curveSize, curveSize, 180, 90)
        path.AddArc(rect.Right - curveSize, rect.Y, curveSize, curveSize, 270, 90)
        path.AddArc(rect.Right - curveSize, rect.Bottom - curveSize, curveSize, curveSize, 0, 90)
        path.AddArc(rect.X, rect.Bottom - curveSize, curveSize, curveSize, 90, 90)
        path.CloseFigure()
        Return path
    End Function

    Private Sub FormRegionAndBorder(form As Form, radius As Single, graph As Graphics, borderColor As Color, borderSize As Single)
        If Me.WindowState <> FormWindowState.Minimized Then
            Using roundPath As GraphicsPath = GetRoundedPath(form.ClientRectangle, radius)
                Using penBorder As Pen = New Pen(borderColor, borderSize)
                    Using transform As Matrix = New Matrix()

                        graph.SmoothingMode = SmoothingMode.AntiAlias
                        form.Region = New Region(roundPath)
                        If borderSize >= 1 Then
                            Dim rect As Rectangle = form.ClientRectangle
                            Dim scaleX As Single = 1.0F - ((borderSize + 1) / rect.Width)
                            Dim scaleY As Single = 1.0F - ((borderSize + 1) / rect.Height)
                            transform.Scale(scaleX, scaleY)
                            transform.Translate(borderSize / 1.6F, borderSize / 1.6F)
                            graph.Transform = transform
                            graph.DrawPath(penBorder, roundPath)
                        End If
                    End Using
                End Using
            End Using

        End If
    End Sub


    Sub switchPages(ByVal pageSwitch1 As Form)
        Try
            Form1.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            Form1.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Try
            Me.Hide()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    ' 'Show the list of the member's beneficiaries in datagridview at ProceedClaimPage
    Private Function BeneficiariesByMember(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ProceedClaimPage.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Function

    'Show the list of the member's children in datagridview at ProceedClaimPage
    Private Function ChildrenByMember(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ChildrenTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ProceedClaimPage.childrenDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Function
    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        ' With Form1
        '' Get the get the of Childrn by the member
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ChildrenTbl where Member_ID='" & txtMemberId.Text & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            memberNoChildren = ds.Tables(0).Rows.Count

        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        '' Get the total number of dues paid by the member
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select sum(Amount) from ContributionsTbl where Member_ID='" & txtMemberId.Text & "'"
            cmd = New SqlCommand(query22, Con)
            membertTotalDues = cmd.ExecuteScalar
            If (IsDBNull(membertTotalDues) = True) Then
                membertTotalDues = 0
                '  membertTotalDues = membertTotalDues.ToString
                '  Else
                ' AdmintotalDept = amountTotal
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try


        Try
            ProceedClaimPage.txtTotalClaimsLabel.Text = memberTotalClaim
            ProceedClaimPage.txtName.Text = memberUserSurname + " " + memberUserOthername
            ProceedClaimPage.txtPhone.Text = memberUserPhone
            ProceedClaimPage.txtStaffID.Text = memberUserStaffID
            ProceedClaimPage.txtMaritalStatus.Text = memberUserMaritalStatus
            ProceedClaimPage.txtNoChildren.Text = memberNoChildren
            ProceedClaimPage.txtTotalDues.Text = membertTotalDues
            ' Dim nwClaimStatus = New ClaimStatus
            Dim proFPic As String = Application.StartupPath & "\Profile pictures\" & memberUserPicture
            ProceedClaimPage.ProfilePic.ImageLocation = proFPic

            ' 'Show the list of the member's beneficiaries in datagridview at ProceedClaimPage
            BeneficiariesByMember(memberUserStaffID)

            'Show the list of the member's children in datagridview at ProceedClaimPage
            ChildrenByMember(memberUserStaffID)

            Me.Hide()
            ' Dim nwProceedClaimPage = New ProceedClaimPage
            switchPages(ProceedClaimPage)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        '  End With
    End Sub
    Dim aa2 As Integer
    Dim tim As Integer = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs)
        ' tim = tim + 1

    End Sub

    Private Sub ClaimStatus_Paint(sender As Object, e As PaintEventArgs) Handles MyBase.Paint
        FormRegionAndBorder(Me, borderRadius, e.Graphics, borderColor, borderSize)
    End Sub



    'Claim Status report Sub
    Sub LoadClaimStatusReport()
        Cursor = Cursors.WaitCursor
        Dim rptDS As ReportDataSource
        AdminPrintClaimStatus.ClaimReport.RefreshReport()
        Try

            With AdminPrintClaimStatus.ClaimReport.LocalReport
                .ReportPath = Application.StartupPath & "\Reports\ProfileReport1.rdlc"
                .DataSources.Clear()
            End With
            Dim dss As New ProfileDataSet2
            Dim da As New SqlDataAdapter

            Con.Open()
            Dim Queryy As String = "SELECT Staff_ID, Surname, Other_Names, Phone, Sex, House_No, Postal_Address, Marital_Status, Marriage_Type, Hometown, Birth_Date FROM MembersTbl WHERE Staff_ID = '" & txtMemberId.Text & "'"

            da.SelectCommand = New SqlCommand(Queryy, Con)
            'da.SelectCommand.Parameters.AddWithValue("@StartDate", fromDateTimePicker.Value)
            ' da.SelectCommand.Parameters.AddWithValue("@EndDate", toDateTimePicker2.Value)
            da.Fill(dss.Tables("ProfileTbl"))
            Con.Close()
            rptDS = New ReportDataSource("DataSet1", dss.Tables("ProfileTbl"))
            AdminPrintClaimStatus.ClaimReport.LocalReport.DataSources.Add(rptDS)
            AdminPrintClaimStatus.ClaimReport.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            AdminPrintClaimStatus.ClaimReport.ZoomMode = ZoomMode.Percent
            AdminPrintClaimStatus.ClaimReport.ZoomPercent = 100
        Catch ex As SqlException
            Con.Close()
            MsgBox(ex.Message)
        End Try



        Try

            With AdminPrintClaimStatus.ClaimReport.LocalReport
                .ReportPath = Application.StartupPath & "\Reports\ProfileReport1.rdlc"
                '  .DataSources.Clear()
            End With
            Dim dss As New ProfileDataSet2
            Dim da As New SqlDataAdapter

            Con.Open()
            Dim Queryy As String = "SELECT Amount_Given, Reason, Claimer, Beneficiary_Name, Claim_Date, Operator_ID, Operator FROM ClaimsTbl WHERE Member_ID = '" & txtMemberId.Text & "' "

            da.SelectCommand = New SqlCommand(Queryy, Con)
            'da.SelectCommand.Parameters.AddWithValue("@StartDate", fromDateTimePicker.Value)
            ' da.SelectCommand.Parameters.AddWithValue("@EndDate", toDateTimePicker2.Value)
            da.Fill(dss.Tables("ClaimsTbl"))
            Con.Close()
            rptDS = New ReportDataSource("DataSet2", dss.Tables("ClaimsTbl"))
            AdminPrintClaimStatus.ClaimReport.LocalReport.DataSources.Add(rptDS)
            AdminPrintClaimStatus.ClaimReport.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            AdminPrintClaimStatus.ClaimReport.ZoomMode = ZoomMode.Percent
            AdminPrintClaimStatus.ClaimReport.ZoomPercent = 100
        Catch ex As SqlException
            Con.Close()
            MsgBox(ex.Message)
        End Try



        Try
            ' Create a ReportParameter object and set its value
            Dim reportParameter1 As New ReportParameter("ClaimStatus", txtQualification.Text.ToString)
            Dim reportParameter2 As New ReportParameter("NoOfContributions", Convert.ToInt32(numOfContributions.Text))
            Dim reportParameter3 As New ReportParameter("NoOfClaims", Convert.ToInt32(txtTotalClaims.Text))

            'Clear existing report parameters (if any)
            AdminPrintClaimStatus.ClaimReport.LocalReport.SetParameters(New ReportParameter() {reportParameter1, reportParameter2, reportParameter3})
            ' AdminPrintClaimStatus.ClaimReport.RefreshReport()
            AdminPrintClaimStatus.Show()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Cursor = Cursors.Default
    End Sub
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        LoadClaimStatusReport()
    End Sub
End Class