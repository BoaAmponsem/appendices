﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SecEditAccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSaveChanges = New FontAwesome.Sharp.IconButton()
        Me.InformationTab = New System.Windows.Forms.GroupBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.txtMemberStaffID = New System.Windows.Forms.MaskedTextBox()
        Me.txtUserPhone = New System.Windows.Forms.MaskedTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnEditAccount = New FontAwesome.Sharp.IconButton()
        Me.txtUserGmail = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtUserName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtUserPassword = New System.Windows.Forms.TextBox()
        Me.InformationTab.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSaveChanges
        '
        Me.btnSaveChanges.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnSaveChanges.BackColor = System.Drawing.Color.SeaGreen
        Me.btnSaveChanges.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSaveChanges.FlatAppearance.BorderSize = 0
        Me.btnSaveChanges.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaveChanges.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnSaveChanges.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveChanges.ForeColor = System.Drawing.Color.White
        Me.btnSaveChanges.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnSaveChanges.IconColor = System.Drawing.Color.Black
        Me.btnSaveChanges.IconSize = 16
        Me.btnSaveChanges.Location = New System.Drawing.Point(386, 166)
        Me.btnSaveChanges.Name = "btnSaveChanges"
        Me.btnSaveChanges.Rotation = 0R
        Me.btnSaveChanges.Size = New System.Drawing.Size(161, 32)
        Me.btnSaveChanges.TabIndex = 17
        Me.btnSaveChanges.Text = "Save changes"
        Me.btnSaveChanges.UseVisualStyleBackColor = False
        Me.btnSaveChanges.Visible = False
        '
        'InformationTab
        '
        Me.InformationTab.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.InformationTab.BackColor = System.Drawing.Color.White
        Me.InformationTab.Controls.Add(Me.LinkLabel1)
        Me.InformationTab.Controls.Add(Me.txtMemberStaffID)
        Me.InformationTab.Controls.Add(Me.txtUserPhone)
        Me.InformationTab.Controls.Add(Me.Label8)
        Me.InformationTab.Controls.Add(Me.btnEditAccount)
        Me.InformationTab.Controls.Add(Me.txtUserGmail)
        Me.InformationTab.Controls.Add(Me.Label3)
        Me.InformationTab.Controls.Add(Me.Label121)
        Me.InformationTab.Controls.Add(Me.Label1)
        Me.InformationTab.Controls.Add(Me.txtUserName)
        Me.InformationTab.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InformationTab.Location = New System.Drawing.Point(9, 12)
        Me.InformationTab.Name = "InformationTab"
        Me.InformationTab.Size = New System.Drawing.Size(834, 147)
        Me.InformationTab.TabIndex = 14
        Me.InformationTab.TabStop = False
        Me.InformationTab.Text = "Account Details"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.LinkColor = System.Drawing.Color.SeaGreen
        Me.LinkLabel1.Location = New System.Drawing.Point(720, 122)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(103, 15)
        Me.LinkLabel1.TabIndex = 16
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Change Password"
        '
        'txtMemberStaffID
        '
        Me.txtMemberStaffID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberStaffID.Location = New System.Drawing.Point(251, 47)
        Me.txtMemberStaffID.Name = "txtMemberStaffID"
        Me.txtMemberStaffID.ReadOnly = True
        Me.txtMemberStaffID.Size = New System.Drawing.Size(255, 22)
        Me.txtMemberStaffID.TabIndex = 15
        '
        'txtUserPhone
        '
        Me.txtUserPhone.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtUserPhone.Location = New System.Drawing.Point(535, 49)
        Me.txtUserPhone.Name = "txtUserPhone"
        Me.txtUserPhone.ReadOnly = True
        Me.txtUserPhone.Size = New System.Drawing.Size(256, 22)
        Me.txtUserPhone.TabIndex = 14
        '
        'Label8
        '
        Me.Label8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(16, 82)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 15)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Gmail:"
        '
        'btnEditAccount
        '
        Me.btnEditAccount.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditAccount.BackColor = System.Drawing.Color.Orange
        Me.btnEditAccount.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEditAccount.FlatAppearance.BorderSize = 0
        Me.btnEditAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEditAccount.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnEditAccount.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditAccount.ForeColor = System.Drawing.Color.White
        Me.btnEditAccount.IconChar = FontAwesome.Sharp.IconChar.Edit
        Me.btnEditAccount.IconColor = System.Drawing.Color.Black
        Me.btnEditAccount.IconSize = 24
        Me.btnEditAccount.Location = New System.Drawing.Point(800, 12)
        Me.btnEditAccount.Name = "btnEditAccount"
        Me.btnEditAccount.Rotation = 0R
        Me.btnEditAccount.Size = New System.Drawing.Size(28, 23)
        Me.btnEditAccount.TabIndex = 12
        Me.btnEditAccount.UseVisualStyleBackColor = False
        '
        'txtUserGmail
        '
        Me.txtUserGmail.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtUserGmail.Location = New System.Drawing.Point(16, 101)
        Me.txtUserGmail.Multiline = True
        Me.txtUserGmail.Name = "txtUserGmail"
        Me.txtUserGmail.ReadOnly = True
        Me.txtUserGmail.Size = New System.Drawing.Size(219, 27)
        Me.txtUserGmail.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(538, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Phone:"
        '
        'Label121
        '
        Me.Label121.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label121.AutoSize = True
        Me.Label121.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label121.Location = New System.Drawing.Point(254, 29)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(49, 15)
        Me.Label121.TabIndex = 3
        Me.Label121.Text = "Staff ID:"
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Username:"
        '
        'txtUserName
        '
        Me.txtUserName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtUserName.Location = New System.Drawing.Point(16, 48)
        Me.txtUserName.Multiline = True
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.ReadOnly = True
        Me.txtUserName.Size = New System.Drawing.Size(219, 27)
        Me.txtUserName.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(839, 343)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 15)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Password:"
        Me.Label4.Visible = False
        '
        'txtUserPassword
        '
        Me.txtUserPassword.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtUserPassword.Location = New System.Drawing.Point(832, 360)
        Me.txtUserPassword.Multiline = True
        Me.txtUserPassword.Name = "txtUserPassword"
        Me.txtUserPassword.ReadOnly = True
        Me.txtUserPassword.Size = New System.Drawing.Size(118, 27)
        Me.txtUserPassword.TabIndex = 15
        Me.txtUserPassword.Visible = False
        '
        'SecEditAccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(853, 509)
        Me.Controls.Add(Me.btnSaveChanges)
        Me.Controls.Add(Me.InformationTab)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtUserPassword)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "SecEditAccount"
        Me.Text = "SecEditAccount"
        Me.InformationTab.ResumeLayout(False)
        Me.InformationTab.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSaveChanges As FontAwesome.Sharp.IconButton
    Friend WithEvents InformationTab As GroupBox
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents txtMemberStaffID As MaskedTextBox
    Friend WithEvents txtUserPhone As MaskedTextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents btnEditAccount As FontAwesome.Sharp.IconButton
    Friend WithEvents txtUserGmail As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label121 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtUserName As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtUserPassword As TextBox
End Class
