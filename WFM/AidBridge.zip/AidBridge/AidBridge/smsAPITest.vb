﻿Imports Newtonsoft.Json.Linq
Imports System.Net
Imports System.Data.SqlClient
Public Class smsAPITest
    Private Sub sendSMS(memberName, memberStaffID, amountt, lastContributionMonth, recipient, contributionMonth)
        ' Define the base URL and API key
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). This is a gentle reminder that your monthly contribution for (" & contributionMonth & ") is now due. Your last contribution month is (" & lastContributionMonth & "). Please make your payment at your earliest convenience. Thank You!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()
        'Dim url As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=0247086663&from=SenderID&sms=YourMessage"


        Try
            Dim response As String = client.DownloadString(baseURL)
            '  MsgBox(response, MsgBoxStyle.Information)
        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.OK) Then
                '' resendSMS("ODM", "2020", "34", "March,2025", "0247086663")
            End If
            '' MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try

        'Try

        'Process.Start(baseURL)
        'Catch ex As Exception
        'MsgBox(ex.Message)
        'End Try

    End Sub

    Private Sub resendSMS(memberName, memberStaffID, amountt, contributionMonth, recipient)
        ' Define the base URL and API key
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). We have received your monthly (" & contributionMonth & ") contribution of Ghc" & amountt & ".00. Thank You!    [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()
        'Dim url As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=0247086663&from=SenderID&sms=YourMessage"


        Try
            Dim response As String = client.DownloadString(baseURL)
            '  MsgBox(response, MsgBoxStyle.Information)
        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                ' sendSMS("ODM", "2020", "34", "March,2025", "0247086663")
            End If
            '' MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub
    Public Function dateTimeAPI()
        ' Create a WebClient instance
        Dim client As New WebClient()

        ' Define the API endpoint
        Dim url As String = "http://worldtimeapi.org/api/timezone/Africa/Accra"

        Try
            ' Make the request and get the response as a string
            Dim response As String = client.DownloadString(url)

            ' Parse the JSON response
            Dim jsonResponse As JObject = JObject.Parse(response)

            ' Extract desired information from the JSON object
            Dim abbreviation As String = jsonResponse("abbreviation")
            Dim onlinetime As String = jsonResponse("datetime")
            Dim timezone As String = jsonResponse("timezone")
            Dim unixtime As Long = jsonResponse("unixtime")

            Dim getDateOnly As DateTime = onlinetime


            If (getDateOnly.Date <> DateTime.Now.Date) Then
                Dim dateTimeDialog As DialogResult = MessageBox.Show("Set your system 'Date and Time!", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                If (dateTimeDialog = DialogResult.Retry) Then
                    Application.ExitThread()
                End If
            End If

        Catch ex As Exception
            ' Handle any exceptions
            Dim errMessage As DialogResult = MessageBox.Show("An error occurred 'Check your internet connection': " & ex.Message, "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error)
            If (errMessage = DialogResult.Retry) Then
                refetchDateTimeAPI()
            Else
                Application.ExitThread()
            End If
        End Try
    End Function

    Public Function refetchDateTimeAPI()
        ' Create a WebClient instance
        Dim client As New WebClient()

        ' Define the API endpoint
        Dim url As String = "http://worldtimeapi.org/api/timezone/Africa/Accra"

        Try
            ' Make the request and get the response as a string
            Dim response As String = client.DownloadString(url)

            ' Parse the JSON response
            Dim jsonResponse As JObject = JObject.Parse(response)

            ' Extract desired information from the JSON object
            Dim abbreviation As String = jsonResponse("abbreviation")
            Dim onlinetime As String = jsonResponse("datetime")
            Dim timezone As String = jsonResponse("timezone")
            Dim unixtime As Long = jsonResponse("unixtime")

            Dim getDateOnly As DateTime = onlinetime


            If (getDateOnly.Date <> DateTime.Now.Date) Then
                Dim dateTimeDialog As DialogResult = MessageBox.Show("Set your system 'Date and Time!", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                If (dateTimeDialog = DialogResult.OK) Then
                    Application.ExitThread()
                End If
            End If

        Catch ex As Exception
            ' Handle any exceptions
            Dim errMessage As DialogResult = MessageBox.Show("An error occurred 'Check your internet connection': " & ex.Message, "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error)
            If (errMessage = DialogResult.Retry) Then
                dateTimeAPI()
            Else
                Application.ExitThread()
            End If
        End Try
    End Function


    Private Sub debtorsList()
        ' Get the current month and year
        Dim currentMonth As Integer = DateTime.Now.Month
        Dim currentYear As Integer = DateTime.Now.Year

        Try
            Con.Open()
            ' Query to find members who have not paid for the current month and year
            Dim query As String = "
        SELECT DISTINCT MAX(c1.Id) AS Id,c1.Member_ID, c1.Surname, c1.Other_Names, c1.Phone, c1.Amount
        FROM ContributionsTbl c1
        WHERE NOT EXISTS (
            SELECT 1
            FROM ContributionsTbl c2
            WHERE c2.Member_ID = c1.Member_ID
            AND MONTH(c2.Month_Of_Payment) = @Month
            AND YEAR(c2.Month_Of_Payment) = @Year
        )
        GROUP BY c1.Member_ID, c1.Surname, c1.Other_Names, c1.Phone, c1.Amount"

            ' Create a new SqlDataAdapter with a parameterized query
            Using adaptor As New SqlDataAdapter(query, Con)
                ' Add parameters to the query
                adaptor.SelectCommand.Parameters.AddWithValue("@Month", currentMonth)
                adaptor.SelectCommand.Parameters.AddWithValue("@Year", currentYear)

                ' Fill the DataSet
                Dim ds As New DataSet()
                adaptor.Fill(ds)
                debtorssDataGridView.DataSource = ds.Tables(0)
            End Using
        Catch ex As Exception
            ' Handle any errors that may have occurred
            MsgBox("An error occurred: " & ex.Message)
        Finally
            ' Ensure the connection is closed
            Con.Close()
        End Try

        ' Create and add the Send Alert button column
        Dim sendSmsButtonColumn As New DataGridViewButtonColumn()
        sendSmsButtonColumn.HeaderText = ""
        sendSmsButtonColumn.Text = "Send Alert"
        sendSmsButtonColumn.Name = "sendAlert"
        sendSmsButtonColumn.UseColumnTextForButtonValue = True

        ' Add the button column to the DataGridView if it doesn't already exist
        ' If debtorsDataGridView.Columns("sendAlert") Is Nothing Then
        debtorssDataGridView.Columns.Add(sendSmsButtonColumn)
        ' End If
    End Sub
    Dim blockButtonColumn As New DataGridViewButtonColumn()
    Private Sub smsAPITest_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' Assume your DataGridView is named dataGridView1

        blockButtonColumn.HeaderText = "Status"
        blockButtonColumn.Text = "Block"
        blockButtonColumn.Name = "blockUnblockButton"
        blockButtonColumn.UseColumnTextForButtonValue = True


        debtorssDataGridView.Columns.Add(blockButtonColumn)




        ' Add some sample data
        debtorssDataGridView.Rows.Add("John Doe", "Ghc 10")
        debtorssDataGridView.Rows.Add("Jane Smith", "Ghc 30")




        'debtorsList()
    End Sub
    Dim theLastMonthOfPayment As DateTime
    Private Sub getLastPaymentMonth(maxId)


        Try
            Con.Open()
            Dim query = "select * from ContributionsTbl where Id ='" & maxId & "'"
            cmd = New SqlCommand(query, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            theLastMonthOfPayment = myReader("Month_Of_Payment")


            '     memberUserPicture = myReader("Picture")
        Catch ex As SqlException
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub debtorsDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles debtorssDataGridView.CellContentClick

        '   If (e.RowIndex >= 0 AndAlso e.ColumnIndex = debtorssDataGridView.Columns("sendAlert").Index) Then

        ' Dim rowID As Integer = Convert.ToInt32(membersDataGridView.Rows(e.RowIndex).Cells("Id").Value)
        'Dim row As DataGridViewRow = debtorssDataGridView.Rows(e.RowIndex)
        'Dim defaultID As String = row.Cells(0).Value.ToString
        'Dim membID As String = row.Cells(1).Value.ToString
        'Dim memFirstName As String = row.Cells(2).Value.ToString
        'Dim membOtherName As String = row.Cells(3).Value.ToString
        'Dim membNumber As String = row.Cells(4).Value.ToString
        'Dim contributAmount As String = row.Cells(5).Value.ToString

        'getLastPaymentMonth(defaultID)

        'MsgBox(defaultID + ", " + membID + ", " + memFirstName + ", " + membOtherName + ", " + membNumber + ", " + theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString + ", " + DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)
        'sendSMS(memFirstName, membID, contributAmount, theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString, membNumber, DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)

        'End If
    End Sub

    Private Sub debtorssDataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles debtorssDataGridView.CellClick
        ' Ensure the click is on a valid row and in the button column
        If e.RowIndex >= 0 AndAlso e.ColumnIndex = debtorssDataGridView.Columns("blockUnblockButton").Index Then
            ' Toggle the button text between "Block" and "Unblock"
            Dim cell As DataGridViewButtonCell = CType(debtorssDataGridView.Rows(e.RowIndex).Cells(e.ColumnIndex), DataGridViewButtonCell)
            If cell.Value Is Nothing OrElse cell.Value.ToString() = "Block" Then
                cell.Value = "Unblock"
                blockButtonColumn.Text = "Unblock"

            Else
                cell.Value = "Block"
                blockButtonColumn.Text = "Block"
            End If
        End If

    End Sub

    '
    '
    '
    '
    '

End Class