﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormAdminInterim
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnMembers = New FontAwesome.Sharp.IconButton()
        Me.txtUsernameHomePage = New System.Windows.Forms.TextBox()
        Me.adminText = New FontAwesome.Sharp.IconButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnHome = New FontAwesome.Sharp.IconButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.pageSwitch = New System.Windows.Forms.Panel()
        Me.EditAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnEditAccount = New FontAwesome.Sharp.IconButton()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MembersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnLogOut = New FontAwesome.Sharp.IconButton()
        Me.PanelMenu = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.PanelMenu.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnMembers
        '
        Me.btnMembers.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMembers.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnMembers.FlatAppearance.BorderSize = 0
        Me.btnMembers.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMembers.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnMembers.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMembers.ForeColor = System.Drawing.Color.White
        Me.btnMembers.IconChar = FontAwesome.Sharp.IconChar.UserFriends
        Me.btnMembers.IconColor = System.Drawing.Color.White
        Me.btnMembers.IconSize = 29
        Me.btnMembers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMembers.Location = New System.Drawing.Point(0, 144)
        Me.btnMembers.Name = "btnMembers"
        Me.btnMembers.Rotation = 0R
        Me.btnMembers.Size = New System.Drawing.Size(150, 42)
        Me.btnMembers.TabIndex = 5
        Me.btnMembers.Text = "Members"
        Me.btnMembers.UseVisualStyleBackColor = True
        '
        'txtUsernameHomePage
        '
        Me.txtUsernameHomePage.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtUsernameHomePage.BackColor = System.Drawing.Color.White
        Me.txtUsernameHomePage.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtUsernameHomePage.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUsernameHomePage.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtUsernameHomePage.Location = New System.Drawing.Point(902, 12)
        Me.txtUsernameHomePage.Multiline = True
        Me.txtUsernameHomePage.Name = "txtUsernameHomePage"
        Me.txtUsernameHomePage.ReadOnly = True
        Me.txtUsernameHomePage.Size = New System.Drawing.Size(106, 22)
        Me.txtUsernameHomePage.TabIndex = 1
        Me.txtUsernameHomePage.Text = "Username"
        '
        'adminText
        '
        Me.adminText.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.adminText.FlatAppearance.BorderSize = 0
        Me.adminText.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.adminText.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.adminText.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.adminText.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.adminText.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.adminText.ForeColor = System.Drawing.Color.SeaGreen
        Me.adminText.IconChar = FontAwesome.Sharp.IconChar.None
        Me.adminText.IconColor = System.Drawing.Color.SeaGreen
        Me.adminText.IconSize = 29
        Me.adminText.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.adminText.Location = New System.Drawing.Point(6, 6)
        Me.adminText.Name = "adminText"
        Me.adminText.Rotation = 0R
        Me.adminText.Size = New System.Drawing.Size(123, 35)
        Me.adminText.TabIndex = 0
        Me.adminText.Text = "IconButton4"
        Me.adminText.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.adminText.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = Global.AidBridge.My.Resources.Resources.Handshake5
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(150, 102)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.LogOutToolStripMenuItem.Text = "LogOut"
        '
        'btnHome
        '
        Me.btnHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHome.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnHome.FlatAppearance.BorderSize = 0
        Me.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHome.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnHome.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHome.ForeColor = System.Drawing.Color.White
        Me.btnHome.IconChar = FontAwesome.Sharp.IconChar.Home
        Me.btnHome.IconColor = System.Drawing.Color.White
        Me.btnHome.IconSize = 29
        Me.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnHome.Location = New System.Drawing.Point(0, 102)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Rotation = 0R
        Me.btnHome.Size = New System.Drawing.Size(150, 42)
        Me.btnHome.TabIndex = 1
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.txtUsernameHomePage)
        Me.Panel2.Controls.Add(Me.adminText)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(150, 24)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1017, 47)
        Me.Panel2.TabIndex = 14
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.PictureBox1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(150, 102)
        Me.Panel4.TabIndex = 0
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'pageSwitch
        '
        Me.pageSwitch.BackColor = System.Drawing.Color.WhiteSmoke
        Me.pageSwitch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pageSwitch.Location = New System.Drawing.Point(150, 24)
        Me.pageSwitch.Name = "pageSwitch"
        Me.pageSwitch.Size = New System.Drawing.Size(1017, 617)
        Me.pageSwitch.TabIndex = 15
        '
        'EditAccountToolStripMenuItem
        '
        Me.EditAccountToolStripMenuItem.Name = "EditAccountToolStripMenuItem"
        Me.EditAccountToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.EditAccountToolStripMenuItem.Text = "Edit Account"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.HomeToolStripMenuItem.Text = "Home"
        '
        'btnEditAccount
        '
        Me.btnEditAccount.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEditAccount.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnEditAccount.FlatAppearance.BorderSize = 0
        Me.btnEditAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEditAccount.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnEditAccount.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditAccount.ForeColor = System.Drawing.Color.White
        Me.btnEditAccount.IconChar = FontAwesome.Sharp.IconChar.PencilAlt
        Me.btnEditAccount.IconColor = System.Drawing.Color.White
        Me.btnEditAccount.IconSize = 29
        Me.btnEditAccount.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEditAccount.Location = New System.Drawing.Point(0, 533)
        Me.btnEditAccount.Name = "btnEditAccount"
        Me.btnEditAccount.Rotation = 0R
        Me.btnEditAccount.Size = New System.Drawing.Size(150, 42)
        Me.btnEditAccount.TabIndex = 8
        Me.btnEditAccount.Text = "Edit Account"
        Me.btnEditAccount.UseVisualStyleBackColor = True
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.Checked = True
        Me.FileToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.FileToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.MembersToolStripMenuItem, Me.EditAccountToolStripMenuItem, Me.LogOutToolStripMenuItem})
        Me.FileToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'MembersToolStripMenuItem
        '
        Me.MembersToolStripMenuItem.Name = "MembersToolStripMenuItem"
        Me.MembersToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.MembersToolStripMenuItem.Text = "Members"
        '
        'btnLogOut
        '
        Me.btnLogOut.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogOut.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnLogOut.FlatAppearance.BorderSize = 0
        Me.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogOut.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnLogOut.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.IconChar = FontAwesome.Sharp.IconChar.ArrowAltCircleLeft
        Me.btnLogOut.IconColor = System.Drawing.Color.White
        Me.btnLogOut.IconSize = 29
        Me.btnLogOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogOut.Location = New System.Drawing.Point(0, 575)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Rotation = 0R
        Me.btnLogOut.Size = New System.Drawing.Size(150, 42)
        Me.btnLogOut.TabIndex = 7
        Me.btnLogOut.Text = "Log Out"
        Me.btnLogOut.UseVisualStyleBackColor = True
        '
        'PanelMenu
        '
        Me.PanelMenu.BackColor = System.Drawing.Color.SeaGreen
        Me.PanelMenu.Controls.Add(Me.btnEditAccount)
        Me.PanelMenu.Controls.Add(Me.btnLogOut)
        Me.PanelMenu.Controls.Add(Me.btnMembers)
        Me.PanelMenu.Controls.Add(Me.btnHome)
        Me.PanelMenu.Controls.Add(Me.Panel4)
        Me.PanelMenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelMenu.Location = New System.Drawing.Point(0, 24)
        Me.PanelMenu.Name = "PanelMenu"
        Me.PanelMenu.Size = New System.Drawing.Size(150, 617)
        Me.PanelMenu.TabIndex = 13
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ViewToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1167, 24)
        Me.MenuStrip1.TabIndex = 12
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FormAdminInterim
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1167, 641)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.pageSwitch)
        Me.Controls.Add(Me.PanelMenu)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "FormAdminInterim"
        Me.Text = "FormAdminInterim"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.PanelMenu.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnMembers As FontAwesome.Sharp.IconButton
    Friend WithEvents txtUsernameHomePage As TextBox
    Friend WithEvents adminText As FontAwesome.Sharp.IconButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents LogOutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnHome As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents ViewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents pageSwitch As Panel
    Friend WithEvents EditAccountToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnEditAccount As FontAwesome.Sharp.IconButton
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MembersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnLogOut As FontAwesome.Sharp.IconButton
    Friend WithEvents PanelMenu As Panel
    Friend WithEvents MenuStrip1 As MenuStrip
End Class
