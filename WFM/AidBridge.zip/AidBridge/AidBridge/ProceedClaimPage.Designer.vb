﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ProceedClaimPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtBeneficiaryProportion = New System.Windows.Forms.TextBox()
        Me.txtBeneficiaryID = New System.Windows.Forms.TextBox()
        Me.txtBeneficiaryNameLabel = New System.Windows.Forms.Label()
        Me.txtBeneficiaryName = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtClaimer = New System.Windows.Forms.ComboBox()
        Me.txtAmountGiven = New System.Windows.Forms.MaskedTextBox()
        Me.ClaimStatusBtn = New FontAwesome.Sharp.IconButton()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtReason = New System.Windows.Forms.ComboBox()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.beneficiariesDataGridView = New System.Windows.Forms.DataGridView()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.childrenDataGridView = New System.Windows.Forms.DataGridView()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.txtChildOneID = New System.Windows.Forms.TextBox()
        Me.txtChildTwoID = New System.Windows.Forms.TextBox()
        Me.txtChildThreeID = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtChild3Name = New System.Windows.Forms.TextBox()
        Me.txtChild3DoB = New System.Windows.Forms.MaskedTextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtChild2Name = New System.Windows.Forms.TextBox()
        Me.txtChild2DoB = New System.Windows.Forms.MaskedTextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtChild1Name = New System.Windows.Forms.TextBox()
        Me.txtChild1DoB = New System.Windows.Forms.MaskedTextBox()
        Me.ChidDateOfBirthLabel = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.threeChildren = New System.Windows.Forms.RadioButton()
        Me.twoChildren = New System.Windows.Forms.RadioButton()
        Me.oneChild = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ProfilePic = New System.Windows.Forms.PictureBox()
        Me.txtTotalDues = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtTotalClaimsLabel = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtNoChildren = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtMaritalStatus = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.Label()
        Me.txtStaffID = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.beneficiariesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.childrenDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.ProfilePic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(753, 493)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.GroupBox4)
        Me.TabPage1.Controls.Add(Me.IconButton1)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(745, 465)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Make Claims"
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.White
        Me.GroupBox4.Controls.Add(Me.Panel2)
        Me.GroupBox4.Location = New System.Drawing.Point(8, 177)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(357, 181)
        Me.GroupBox4.TabIndex = 94
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Entries"
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.txtBeneficiaryProportion)
        Me.Panel2.Controls.Add(Me.txtBeneficiaryID)
        Me.Panel2.Controls.Add(Me.txtBeneficiaryNameLabel)
        Me.Panel2.Controls.Add(Me.txtBeneficiaryName)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.txtClaimer)
        Me.Panel2.Controls.Add(Me.txtAmountGiven)
        Me.Panel2.Controls.Add(Me.ClaimStatusBtn)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.txtReason)
        Me.Panel2.Location = New System.Drawing.Point(6, 16)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(345, 165)
        Me.Panel2.TabIndex = 56
        '
        'txtBeneficiaryProportion
        '
        Me.txtBeneficiaryProportion.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryProportion.Location = New System.Drawing.Point(20, 134)
        Me.txtBeneficiaryProportion.Name = "txtBeneficiaryProportion"
        Me.txtBeneficiaryProportion.Size = New System.Drawing.Size(100, 22)
        Me.txtBeneficiaryProportion.TabIndex = 109
        Me.txtBeneficiaryProportion.Visible = False
        '
        'txtBeneficiaryID
        '
        Me.txtBeneficiaryID.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryID.Location = New System.Drawing.Point(238, 111)
        Me.txtBeneficiaryID.Name = "txtBeneficiaryID"
        Me.txtBeneficiaryID.Size = New System.Drawing.Size(100, 22)
        Me.txtBeneficiaryID.TabIndex = 108
        Me.txtBeneficiaryID.Visible = False
        '
        'txtBeneficiaryNameLabel
        '
        Me.txtBeneficiaryNameLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryNameLabel.AutoSize = True
        Me.txtBeneficiaryNameLabel.Location = New System.Drawing.Point(208, 68)
        Me.txtBeneficiaryNameLabel.Name = "txtBeneficiaryNameLabel"
        Me.txtBeneficiaryNameLabel.Size = New System.Drawing.Size(111, 15)
        Me.txtBeneficiaryNameLabel.TabIndex = 107
        Me.txtBeneficiaryNameLabel.Text = "Beneficiary's Name:"
        Me.txtBeneficiaryNameLabel.Visible = False
        '
        'txtBeneficiaryName
        '
        Me.txtBeneficiaryName.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryName.Location = New System.Drawing.Point(204, 87)
        Me.txtBeneficiaryName.Name = "txtBeneficiaryName"
        Me.txtBeneficiaryName.ReadOnly = True
        Me.txtBeneficiaryName.Size = New System.Drawing.Size(136, 22)
        Me.txtBeneficiaryName.TabIndex = 106
        Me.txtBeneficiaryName.Visible = False
        '
        'Label25
        '
        Me.Label25.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(227, 7)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(47, 15)
        Me.Label25.TabIndex = 89
        Me.Label25.Text = "Claimer:"
        '
        'txtClaimer
        '
        Me.txtClaimer.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtClaimer.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtClaimer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtClaimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtClaimer.FormattingEnabled = True
        Me.txtClaimer.Items.AddRange(New Object() {"Member", "Beneficiary"})
        Me.txtClaimer.Location = New System.Drawing.Point(224, 25)
        Me.txtClaimer.Name = "txtClaimer"
        Me.txtClaimer.Size = New System.Drawing.Size(114, 23)
        Me.txtClaimer.TabIndex = 88
        '
        'txtAmountGiven
        '
        Me.txtAmountGiven.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtAmountGiven.Location = New System.Drawing.Point(13, 89)
        Me.txtAmountGiven.Name = "txtAmountGiven"
        Me.txtAmountGiven.ReadOnly = True
        Me.txtAmountGiven.Size = New System.Drawing.Size(150, 22)
        Me.txtAmountGiven.TabIndex = 87
        Me.txtAmountGiven.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ClaimStatusBtn
        '
        Me.ClaimStatusBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.ClaimStatusBtn.BackColor = System.Drawing.Color.OrangeRed
        Me.ClaimStatusBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ClaimStatusBtn.FlatAppearance.BorderSize = 0
        Me.ClaimStatusBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.ClaimStatusBtn.ForeColor = System.Drawing.Color.White
        Me.ClaimStatusBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.ClaimStatusBtn.IconColor = System.Drawing.Color.Black
        Me.ClaimStatusBtn.IconSize = 16
        Me.ClaimStatusBtn.Location = New System.Drawing.Point(126, 127)
        Me.ClaimStatusBtn.Name = "ClaimStatusBtn"
        Me.ClaimStatusBtn.Rotation = 0R
        Me.ClaimStatusBtn.Size = New System.Drawing.Size(107, 29)
        Me.ClaimStatusBtn.TabIndex = 83
        Me.ClaimStatusBtn.Text = "Send Request"
        Me.ClaimStatusBtn.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(58, 70)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(54, 15)
        Me.Label14.TabIndex = 86
        Me.Label14.Text = "Amount:"
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(10, 7)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 15)
        Me.Label6.TabIndex = 85
        Me.Label6.Text = "Reason:"
        '
        'txtReason
        '
        Me.txtReason.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtReason.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtReason.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtReason.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtReason.FormattingEnabled = True
        Me.txtReason.Items.AddRange(New Object() {"", "Child & Father Death", "Child & Mother Death", "Child Death", "Deceased Member", "Departure", "Father & Mother Death", "Father Death", "Husband/Wife & Child Death", "Husband/Wife & Father Death", "Husband/Wife & Mother Death", "Husband/Wife Death", "Mother Death", "Retirement", "Self Medical Treatment", "Wedding"})
        Me.txtReason.Location = New System.Drawing.Point(5, 25)
        Me.txtReason.Name = "txtReason"
        Me.txtReason.Size = New System.Drawing.Size(202, 23)
        Me.txtReason.Sorted = True
        Me.txtReason.TabIndex = 84
        '
        'IconButton1
        '
        Me.IconButton1.BackColor = System.Drawing.Color.White
        Me.IconButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.ForeColor = System.Drawing.Color.Black
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft
        Me.IconButton1.IconColor = System.Drawing.Color.DarkGreen
        Me.IconButton1.IconSize = 18
        Me.IconButton1.Location = New System.Drawing.Point(5, 3)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(48, 23)
        Me.IconButton1.TabIndex = 93
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.BackColor = System.Drawing.Color.White
        Me.GroupBox3.Controls.Add(Me.beneficiariesDataGridView)
        Me.GroupBox3.Location = New System.Drawing.Point(8, 364)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(356, 95)
        Me.GroupBox3.TabIndex = 92
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Beneficiaries"
        '
        'beneficiariesDataGridView
        '
        Me.beneficiariesDataGridView.AllowUserToAddRows = False
        Me.beneficiariesDataGridView.AllowUserToDeleteRows = False
        Me.beneficiariesDataGridView.AllowUserToResizeColumns = False
        Me.beneficiariesDataGridView.AllowUserToResizeRows = False
        Me.beneficiariesDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.beneficiariesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.beneficiariesDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.beneficiariesDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.beneficiariesDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.beneficiariesDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.beneficiariesDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.beneficiariesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.beneficiariesDataGridView.DefaultCellStyle = DataGridViewCellStyle3
        Me.beneficiariesDataGridView.Location = New System.Drawing.Point(3, 18)
        Me.beneficiariesDataGridView.Name = "beneficiariesDataGridView"
        Me.beneficiariesDataGridView.ReadOnly = True
        Me.beneficiariesDataGridView.RowHeadersVisible = False
        Me.beneficiariesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.beneficiariesDataGridView.Size = New System.Drawing.Size(350, 74)
        Me.beneficiariesDataGridView.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.childrenDataGridView)
        Me.GroupBox2.Location = New System.Drawing.Point(370, 364)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(367, 95)
        Me.GroupBox2.TabIndex = 91
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Children"
        '
        'childrenDataGridView
        '
        Me.childrenDataGridView.AllowUserToAddRows = False
        Me.childrenDataGridView.AllowUserToDeleteRows = False
        Me.childrenDataGridView.AllowUserToResizeColumns = False
        Me.childrenDataGridView.AllowUserToResizeRows = False
        Me.childrenDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.childrenDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.childrenDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.childrenDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.childrenDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.childrenDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.childrenDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.childrenDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.childrenDataGridView.DefaultCellStyle = DataGridViewCellStyle4
        Me.childrenDataGridView.Location = New System.Drawing.Point(3, 18)
        Me.childrenDataGridView.Name = "childrenDataGridView"
        Me.childrenDataGridView.ReadOnly = True
        Me.childrenDataGridView.RowHeadersVisible = False
        Me.childrenDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.childrenDataGridView.Size = New System.Drawing.Size(361, 74)
        Me.childrenDataGridView.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BackColor = System.Drawing.Color.White
        Me.Panel3.Controls.Add(Me.txtChildOneID)
        Me.Panel3.Controls.Add(Me.txtChildTwoID)
        Me.Panel3.Controls.Add(Me.txtChildThreeID)
        Me.Panel3.Controls.Add(Me.Label24)
        Me.Panel3.Controls.Add(Me.Label23)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Controls.Add(Me.txtChild3Name)
        Me.Panel3.Controls.Add(Me.txtChild3DoB)
        Me.Panel3.Controls.Add(Me.Label21)
        Me.Panel3.Controls.Add(Me.Label18)
        Me.Panel3.Controls.Add(Me.txtChild2Name)
        Me.Panel3.Controls.Add(Me.txtChild2DoB)
        Me.Panel3.Controls.Add(Me.Label19)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.txtChild1Name)
        Me.Panel3.Controls.Add(Me.txtChild1DoB)
        Me.Panel3.Controls.Add(Me.ChidDateOfBirthLabel)
        Me.Panel3.Controls.Add(Me.GroupBox1)
        Me.Panel3.Location = New System.Drawing.Point(370, 177)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(367, 181)
        Me.Panel3.TabIndex = 90
        '
        'txtChildOneID
        '
        Me.txtChildOneID.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChildOneID.Location = New System.Drawing.Point(161, 61)
        Me.txtChildOneID.Name = "txtChildOneID"
        Me.txtChildOneID.Size = New System.Drawing.Size(100, 22)
        Me.txtChildOneID.TabIndex = 109
        Me.txtChildOneID.Visible = False
        '
        'txtChildTwoID
        '
        Me.txtChildTwoID.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChildTwoID.Location = New System.Drawing.Point(161, 100)
        Me.txtChildTwoID.Name = "txtChildTwoID"
        Me.txtChildTwoID.Size = New System.Drawing.Size(100, 22)
        Me.txtChildTwoID.TabIndex = 110
        Me.txtChildTwoID.Visible = False
        '
        'txtChildThreeID
        '
        Me.txtChildThreeID.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtChildThreeID.Location = New System.Drawing.Point(161, 151)
        Me.txtChildThreeID.Name = "txtChildThreeID"
        Me.txtChildThreeID.Size = New System.Drawing.Size(100, 22)
        Me.txtChildThreeID.TabIndex = 111
        Me.txtChildThreeID.Visible = False
        '
        'Label24
        '
        Me.Label24.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(16, 155)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(16, 13)
        Me.Label24.TabIndex = 116
        Me.Label24.Text = "3."
        '
        'Label23
        '
        Me.Label23.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(16, 109)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(16, 13)
        Me.Label23.TabIndex = 115
        Me.Label23.Text = "2."
        '
        'Label22
        '
        Me.Label22.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(16, 65)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(16, 13)
        Me.Label22.TabIndex = 114
        Me.Label22.Text = "1."
        '
        'Label20
        '
        Me.Label20.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(41, 133)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(99, 15)
        Me.Label20.TabIndex = 113
        Me.Label20.Text = "Child's full Name:"
        '
        'txtChild3Name
        '
        Me.txtChild3Name.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtChild3Name.Location = New System.Drawing.Point(38, 151)
        Me.txtChild3Name.Name = "txtChild3Name"
        Me.txtChild3Name.ReadOnly = True
        Me.txtChild3Name.Size = New System.Drawing.Size(153, 22)
        Me.txtChild3Name.TabIndex = 112
        '
        'txtChild3DoB
        '
        Me.txtChild3DoB.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtChild3DoB.Location = New System.Drawing.Point(217, 151)
        Me.txtChild3DoB.Name = "txtChild3DoB"
        Me.txtChild3DoB.ReadOnly = True
        Me.txtChild3DoB.Size = New System.Drawing.Size(141, 22)
        Me.txtChild3DoB.TabIndex = 111
        Me.txtChild3DoB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtChild3DoB.ValidatingType = GetType(Date)
        '
        'Label21
        '
        Me.Label21.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(222, 130)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(138, 15)
        Me.Label21.TabIndex = 110
        Me.Label21.Text = "Child's DoB(mm/dd/yyyy)"
        '
        'Label18
        '
        Me.Label18.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(41, 87)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(99, 15)
        Me.Label18.TabIndex = 109
        Me.Label18.Text = "Child's full Name:"
        '
        'txtChild2Name
        '
        Me.txtChild2Name.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtChild2Name.Location = New System.Drawing.Point(38, 105)
        Me.txtChild2Name.Name = "txtChild2Name"
        Me.txtChild2Name.ReadOnly = True
        Me.txtChild2Name.Size = New System.Drawing.Size(153, 22)
        Me.txtChild2Name.TabIndex = 108
        '
        'txtChild2DoB
        '
        Me.txtChild2DoB.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtChild2DoB.Location = New System.Drawing.Point(217, 105)
        Me.txtChild2DoB.Name = "txtChild2DoB"
        Me.txtChild2DoB.ReadOnly = True
        Me.txtChild2DoB.Size = New System.Drawing.Size(141, 22)
        Me.txtChild2DoB.TabIndex = 107
        Me.txtChild2DoB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(214, 87)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(138, 15)
        Me.Label19.TabIndex = 106
        Me.Label19.Text = "Child's DoB(mm/dd/yyyy)"
        '
        'Label15
        '
        Me.Label15.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(41, 43)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(99, 15)
        Me.Label15.TabIndex = 105
        Me.Label15.Text = "Child's full Name:"
        '
        'txtChild1Name
        '
        Me.txtChild1Name.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtChild1Name.Location = New System.Drawing.Point(38, 61)
        Me.txtChild1Name.Name = "txtChild1Name"
        Me.txtChild1Name.ReadOnly = True
        Me.txtChild1Name.Size = New System.Drawing.Size(153, 22)
        Me.txtChild1Name.TabIndex = 104
        '
        'txtChild1DoB
        '
        Me.txtChild1DoB.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtChild1DoB.Location = New System.Drawing.Point(217, 61)
        Me.txtChild1DoB.Name = "txtChild1DoB"
        Me.txtChild1DoB.ReadOnly = True
        Me.txtChild1DoB.Size = New System.Drawing.Size(141, 22)
        Me.txtChild1DoB.TabIndex = 103
        Me.txtChild1DoB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ChidDateOfBirthLabel
        '
        Me.ChidDateOfBirthLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ChidDateOfBirthLabel.AutoSize = True
        Me.ChidDateOfBirthLabel.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChidDateOfBirthLabel.Location = New System.Drawing.Point(214, 43)
        Me.ChidDateOfBirthLabel.Name = "ChidDateOfBirthLabel"
        Me.ChidDateOfBirthLabel.Size = New System.Drawing.Size(138, 15)
        Me.ChidDateOfBirthLabel.TabIndex = 102
        Me.ChidDateOfBirthLabel.Text = "Child's DoB(mm/dd/yyyy)"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.threeChildren)
        Me.GroupBox1.Controls.Add(Me.twoChildren)
        Me.GroupBox1.Controls.Add(Me.oneChild)
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(367, 40)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Deceased Child"
        '
        'threeChildren
        '
        Me.threeChildren.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.threeChildren.AutoSize = True
        Me.threeChildren.Location = New System.Drawing.Point(241, 14)
        Me.threeChildren.Name = "threeChildren"
        Me.threeChildren.Size = New System.Drawing.Size(31, 19)
        Me.threeChildren.TabIndex = 2
        Me.threeChildren.TabStop = True
        Me.threeChildren.Text = "3"
        Me.threeChildren.UseVisualStyleBackColor = True
        '
        'twoChildren
        '
        Me.twoChildren.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.twoChildren.AutoSize = True
        Me.twoChildren.Location = New System.Drawing.Point(176, 14)
        Me.twoChildren.Name = "twoChildren"
        Me.twoChildren.Size = New System.Drawing.Size(31, 19)
        Me.twoChildren.TabIndex = 1
        Me.twoChildren.TabStop = True
        Me.twoChildren.Text = "2"
        Me.twoChildren.UseVisualStyleBackColor = True
        '
        'oneChild
        '
        Me.oneChild.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.oneChild.AutoSize = True
        Me.oneChild.Location = New System.Drawing.Point(105, 16)
        Me.oneChild.Name = "oneChild"
        Me.oneChild.Size = New System.Drawing.Size(31, 19)
        Me.oneChild.TabIndex = 0
        Me.oneChild.TabStop = True
        Me.oneChild.Text = "1"
        Me.oneChild.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.ProfilePic)
        Me.Panel1.Controls.Add(Me.txtTotalDues)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.txtTotalClaimsLabel)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.txtNoChildren)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.txtMaritalStatus)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.txtPhone)
        Me.Panel1.Controls.Add(Me.txtName)
        Me.Panel1.Controls.Add(Me.txtStaffID)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(6, 41)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(733, 126)
        Me.Panel1.TabIndex = 55
        '
        'ProfilePic
        '
        Me.ProfilePic.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ProfilePic.Location = New System.Drawing.Point(12, 12)
        Me.ProfilePic.Name = "ProfilePic"
        Me.ProfilePic.Size = New System.Drawing.Size(120, 103)
        Me.ProfilePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.ProfilePic.TabIndex = 85
        Me.ProfilePic.TabStop = False
        '
        'txtTotalDues
        '
        Me.txtTotalDues.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtTotalDues.AutoSize = True
        Me.txtTotalDues.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalDues.Location = New System.Drawing.Point(638, 67)
        Me.txtTotalDues.Name = "txtTotalDues"
        Me.txtTotalDues.Size = New System.Drawing.Size(37, 15)
        Me.txtTotalDues.TabIndex = 84
        Me.txtTotalDues.Text = "38574"
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(507, 67)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(115, 15)
        Me.Label17.TabIndex = 83
        Me.Label17.Text = "Total Dues Paid (Ghc)"
        '
        'txtTotalClaimsLabel
        '
        Me.txtTotalClaimsLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtTotalClaimsLabel.AutoSize = True
        Me.txtTotalClaimsLabel.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalClaimsLabel.Location = New System.Drawing.Point(408, 103)
        Me.txtTotalClaimsLabel.Name = "txtTotalClaimsLabel"
        Me.txtTotalClaimsLabel.Size = New System.Drawing.Size(13, 15)
        Me.txtTotalClaimsLabel.TabIndex = 78
        Me.txtTotalClaimsLabel.Text = "0"
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(324, 102)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 15)
        Me.Label10.TabIndex = 77
        Me.Label10.Text = "Total Claims:"
        '
        'txtNoChildren
        '
        Me.txtNoChildren.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtNoChildren.AutoSize = True
        Me.txtNoChildren.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoChildren.Location = New System.Drawing.Point(638, 40)
        Me.txtNoChildren.Name = "txtNoChildren"
        Me.txtNoChildren.Size = New System.Drawing.Size(13, 15)
        Me.txtNoChildren.TabIndex = 75
        Me.txtNoChildren.Text = "5"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(507, 40)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(48, 15)
        Me.Label5.TabIndex = 74
        Me.Label5.Text = "Children"
        '
        'txtMaritalStatus
        '
        Me.txtMaritalStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtMaritalStatus.AutoSize = True
        Me.txtMaritalStatus.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMaritalStatus.Location = New System.Drawing.Point(638, 14)
        Me.txtMaritalStatus.Name = "txtMaritalStatus"
        Me.txtMaritalStatus.Size = New System.Drawing.Size(35, 15)
        Me.txtMaritalStatus.TabIndex = 73
        Me.txtMaritalStatus.Text = "Single"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(507, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 15)
        Me.Label2.TabIndex = 72
        Me.Label2.Text = "Marital Status"
        '
        'Label9
        '
        Me.Label9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(164, 44)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 15)
        Me.Label9.TabIndex = 70
        Me.Label9.Text = "Staff ID"
        '
        'Label11
        '
        Me.Label11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(164, 74)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(58, 15)
        Me.Label11.TabIndex = 69
        Me.Label11.Text = "Phone No."
        '
        'txtPhone
        '
        Me.txtPhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtPhone.AutoSize = True
        Me.txtPhone.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhone.Location = New System.Drawing.Point(292, 74)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(67, 15)
        Me.txtPhone.TabIndex = 68
        Me.txtPhone.Text = "0247086663"
        '
        'txtName
        '
        Me.txtName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtName.AutoSize = True
        Me.txtName.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(292, 14)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(160, 15)
        Me.txtName.TabIndex = 67
        Me.txtName.Text = "Oduro Maclean Kwame(ODM)"
        '
        'txtStaffID
        '
        Me.txtStaffID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtStaffID.AutoSize = True
        Me.txtStaffID.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStaffID.Location = New System.Drawing.Point(292, 44)
        Me.txtStaffID.Name = "txtStaffID"
        Me.txtStaffID.Size = New System.Drawing.Size(77, 15)
        Me.txtStaffID.TabIndex = 66
        Me.txtStaffID.Text = "SDA-6564343"
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(164, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 15)
        Me.Label1.TabIndex = 65
        Me.Label1.Text = "Full Name:"
        '
        'ProceedClaimPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(753, 493)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "ProceedClaimPage"
        Me.Text = "ProceedClaimPage"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.beneficiariesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.childrenDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.ProfilePic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtTotalDues As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents txtTotalClaimsLabel As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txtNoChildren As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtMaritalStatus As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents txtPhone As Label
    Friend WithEvents txtName As Label
    Friend WithEvents txtStaffID As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents txtAmountGiven As MaskedTextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtReason As ComboBox
    Friend WithEvents ClaimStatusBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label20 As Label
    Friend WithEvents txtChild3Name As TextBox
    Friend WithEvents txtChild3DoB As MaskedTextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txtChild2Name As TextBox
    Friend WithEvents txtChild2DoB As MaskedTextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents txtChild1Name As TextBox
    Friend WithEvents txtChild1DoB As MaskedTextBox
    Friend WithEvents ChidDateOfBirthLabel As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents threeChildren As RadioButton
    Friend WithEvents twoChildren As RadioButton
    Friend WithEvents oneChild As RadioButton
    Friend WithEvents ProfilePic As PictureBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents beneficiariesDataGridView As DataGridView
    Friend WithEvents childrenDataGridView As DataGridView
    Friend WithEvents txtClaimer As ComboBox
    Friend WithEvents txtBeneficiaryNameLabel As Label
    Friend WithEvents txtBeneficiaryName As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents txtBeneficiaryID As TextBox
    Friend WithEvents txtChildOneID As TextBox
    Friend WithEvents txtChildTwoID As TextBox
    Friend WithEvents txtChildThreeID As TextBox
    Friend WithEvents txtBeneficiaryProportion As TextBox
End Class
