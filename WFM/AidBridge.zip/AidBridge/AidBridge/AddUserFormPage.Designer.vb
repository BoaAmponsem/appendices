﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddUserFormPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.IconButton3 = New FontAwesome.Sharp.IconButton()
        Me.txtAccountType = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.IconButton5 = New FontAwesome.Sharp.IconButton()
        Me.txtStaffID = New System.Windows.Forms.MaskedTextBox()
        Me.IconButton4 = New FontAwesome.Sharp.IconButton()
        Me.txtGmail = New System.Windows.Forms.MaskedTextBox()
        Me.IconButton8 = New FontAwesome.Sharp.IconButton()
        Me.txtPhone = New System.Windows.Forms.MaskedTextBox()
        Me.IconButton7 = New FontAwesome.Sharp.IconButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPassword1 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnCreateAccount = New FontAwesome.Sharp.IconButton()
        Me.showPassword = New System.Windows.Forms.CheckBox()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtPassword2 = New System.Windows.Forms.TextBox()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnBack = New FontAwesome.Sharp.IconButton()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.IconButton3)
        Me.Panel1.Controls.Add(Me.txtAccountType)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.IconButton5)
        Me.Panel1.Controls.Add(Me.txtStaffID)
        Me.Panel1.Controls.Add(Me.IconButton4)
        Me.Panel1.Controls.Add(Me.txtGmail)
        Me.Panel1.Controls.Add(Me.IconButton8)
        Me.Panel1.Controls.Add(Me.txtPhone)
        Me.Panel1.Controls.Add(Me.IconButton7)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.txtPassword1)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.btnCreateAccount)
        Me.Panel1.Controls.Add(Me.showPassword)
        Me.Panel1.Controls.Add(Me.IconButton2)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.txtPassword2)
        Me.Panel1.Controls.Add(Me.IconButton1)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.txtUsername)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(66, 48)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(498, 475)
        Me.Panel1.TabIndex = 0
        '
        'IconButton3
        '
        Me.IconButton3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.IconButton3.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton3.FlatAppearance.BorderSize = 0
        Me.IconButton3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton3.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton3.IconChar = FontAwesome.Sharp.IconChar.Certificate
        Me.IconButton3.IconColor = System.Drawing.Color.White
        Me.IconButton3.IconSize = 16
        Me.IconButton3.Location = New System.Drawing.Point(254, 104)
        Me.IconButton3.Name = "IconButton3"
        Me.IconButton3.Rotation = 0R
        Me.IconButton3.Size = New System.Drawing.Size(37, 22)
        Me.IconButton3.TabIndex = 42
        Me.IconButton3.UseVisualStyleBackColor = False
        '
        'txtAccountType
        '
        Me.txtAccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtAccountType.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAccountType.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtAccountType.FormattingEnabled = True
        Me.txtAccountType.Items.AddRange(New Object() {"", "SECRETARY", "TREASURER"})
        Me.txtAccountType.Location = New System.Drawing.Point(290, 104)
        Me.txtAccountType.Name = "txtAccountType"
        Me.txtAccountType.Size = New System.Drawing.Size(192, 22)
        Me.txtAccountType.Sorted = True
        Me.txtAccountType.TabIndex = 41
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label8.Location = New System.Drawing.Point(251, 86)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(81, 15)
        Me.Label8.TabIndex = 40
        Me.Label8.Text = "Account Type:"
        '
        'IconButton5
        '
        Me.IconButton5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.IconButton5.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton5.FlatAppearance.BorderSize = 0
        Me.IconButton5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton5.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton5.IconChar = FontAwesome.Sharp.IconChar.IdCard
        Me.IconButton5.IconColor = System.Drawing.Color.White
        Me.IconButton5.IconSize = 16
        Me.IconButton5.Location = New System.Drawing.Point(255, 240)
        Me.IconButton5.Name = "IconButton5"
        Me.IconButton5.Rotation = 0R
        Me.IconButton5.Size = New System.Drawing.Size(37, 21)
        Me.IconButton5.TabIndex = 39
        Me.IconButton5.UseVisualStyleBackColor = False
        '
        'txtStaffID
        '
        Me.txtStaffID.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtStaffID.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStaffID.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtStaffID.Location = New System.Drawing.Point(291, 240)
        Me.txtStaffID.Name = "txtStaffID"
        Me.txtStaffID.Size = New System.Drawing.Size(191, 21)
        Me.txtStaffID.TabIndex = 38
        '
        'IconButton4
        '
        Me.IconButton4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.IconButton4.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton4.FlatAppearance.BorderSize = 0
        Me.IconButton4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton4.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton4.IconChar = FontAwesome.Sharp.IconChar.Google
        Me.IconButton4.IconColor = System.Drawing.Color.White
        Me.IconButton4.IconSize = 16
        Me.IconButton4.Location = New System.Drawing.Point(257, 287)
        Me.IconButton4.Name = "IconButton4"
        Me.IconButton4.Rotation = 0R
        Me.IconButton4.Size = New System.Drawing.Size(37, 21)
        Me.IconButton4.TabIndex = 37
        Me.IconButton4.UseVisualStyleBackColor = False
        '
        'txtGmail
        '
        Me.txtGmail.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtGmail.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGmail.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtGmail.Location = New System.Drawing.Point(291, 287)
        Me.txtGmail.Name = "txtGmail"
        Me.txtGmail.Size = New System.Drawing.Size(191, 21)
        Me.txtGmail.TabIndex = 36
        '
        'IconButton8
        '
        Me.IconButton8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.IconButton8.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton8.FlatAppearance.BorderSize = 0
        Me.IconButton8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton8.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton8.IconChar = FontAwesome.Sharp.IconChar.Phone
        Me.IconButton8.IconColor = System.Drawing.Color.White
        Me.IconButton8.IconSize = 16
        Me.IconButton8.Location = New System.Drawing.Point(255, 192)
        Me.IconButton8.Name = "IconButton8"
        Me.IconButton8.Rotation = 0R
        Me.IconButton8.Size = New System.Drawing.Size(37, 21)
        Me.IconButton8.TabIndex = 35
        Me.IconButton8.UseVisualStyleBackColor = False
        '
        'txtPhone
        '
        Me.txtPhone.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPhone.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhone.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtPhone.Location = New System.Drawing.Point(291, 192)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(191, 21)
        Me.txtPhone.TabIndex = 34
        '
        'IconButton7
        '
        Me.IconButton7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.IconButton7.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton7.FlatAppearance.BorderSize = 0
        Me.IconButton7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton7.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton7.IconChar = FontAwesome.Sharp.IconChar.Lock
        Me.IconButton7.IconColor = System.Drawing.Color.White
        Me.IconButton7.IconSize = 16
        Me.IconButton7.Location = New System.Drawing.Point(255, 333)
        Me.IconButton7.Name = "IconButton7"
        Me.IconButton7.Rotation = 0R
        Me.IconButton7.Size = New System.Drawing.Size(37, 21)
        Me.IconButton7.TabIndex = 33
        Me.IconButton7.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label7.Location = New System.Drawing.Point(254, 315)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 15)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Password:"
        '
        'txtPassword1
        '
        Me.txtPassword1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPassword1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword1.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtPassword1.Location = New System.Drawing.Point(291, 333)
        Me.txtPassword1.Multiline = True
        Me.txtPassword1.Name = "txtPassword1"
        Me.txtPassword1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword1.Size = New System.Drawing.Size(191, 21)
        Me.txtPassword1.TabIndex = 31
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label6.Location = New System.Drawing.Point(254, 268)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 15)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "Gmail:"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label5.Location = New System.Drawing.Point(254, 222)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 15)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "Staff ID:"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label4.Location = New System.Drawing.Point(254, 174)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 15)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Phone:"
        '
        'btnCreateAccount
        '
        Me.btnCreateAccount.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btnCreateAccount.BackColor = System.Drawing.Color.SeaGreen
        Me.btnCreateAccount.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCreateAccount.FlatAppearance.BorderSize = 0
        Me.btnCreateAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCreateAccount.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnCreateAccount.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateAccount.ForeColor = System.Drawing.Color.White
        Me.btnCreateAccount.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnCreateAccount.IconColor = System.Drawing.Color.Black
        Me.btnCreateAccount.IconSize = 16
        Me.btnCreateAccount.Location = New System.Drawing.Point(254, 425)
        Me.btnCreateAccount.Name = "btnCreateAccount"
        Me.btnCreateAccount.Rotation = 0R
        Me.btnCreateAccount.Size = New System.Drawing.Size(226, 44)
        Me.btnCreateAccount.TabIndex = 21
        Me.btnCreateAccount.Text = "Create Account"
        Me.btnCreateAccount.UseVisualStyleBackColor = False
        '
        'showPassword
        '
        Me.showPassword.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.showPassword.AutoSize = True
        Me.showPassword.FlatAppearance.BorderSize = 0
        Me.showPassword.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.showPassword.ForeColor = System.Drawing.Color.SeaGreen
        Me.showPassword.Location = New System.Drawing.Point(384, 404)
        Me.showPassword.Name = "showPassword"
        Me.showPassword.Size = New System.Drawing.Size(94, 18)
        Me.showPassword.TabIndex = 20
        Me.showPassword.Text = "Show password"
        Me.showPassword.UseVisualStyleBackColor = True
        '
        'IconButton2
        '
        Me.IconButton2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.IconButton2.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton2.FlatAppearance.BorderSize = 0
        Me.IconButton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.Lock
        Me.IconButton2.IconColor = System.Drawing.Color.White
        Me.IconButton2.IconSize = 16
        Me.IconButton2.Location = New System.Drawing.Point(255, 379)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(37, 21)
        Me.IconButton2.TabIndex = 19
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label2.Location = New System.Drawing.Point(254, 361)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 15)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "Confirm Password:"
        '
        'txtPassword2
        '
        Me.txtPassword2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPassword2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword2.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtPassword2.Location = New System.Drawing.Point(291, 379)
        Me.txtPassword2.Multiline = True
        Me.txtPassword2.Name = "txtPassword2"
        Me.txtPassword2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword2.Size = New System.Drawing.Size(191, 21)
        Me.txtPassword2.TabIndex = 17
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.IconButton1.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.User
        Me.IconButton1.IconColor = System.Drawing.Color.White
        Me.IconButton1.IconSize = 16
        Me.IconButton1.Location = New System.Drawing.Point(255, 147)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(37, 22)
        Me.IconButton1.TabIndex = 16
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label3.Location = New System.Drawing.Point(290, 4)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(151, 22)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "SIGN-UP FORM"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label1.Location = New System.Drawing.Point(254, 129)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 15)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Username:"
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.PictureBox2.Image = Global.AidBridge.My.Resources.Resources._username_login
        Me.PictureBox2.Location = New System.Drawing.Point(315, 28)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 51)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 13
        Me.PictureBox2.TabStop = False
        '
        'txtUsername
        '
        Me.txtUsername.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtUsername.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUsername.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtUsername.Location = New System.Drawing.Point(291, 147)
        Me.txtUsername.Multiline = True
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(191, 22)
        Me.txtUsername.TabIndex = 12
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.AidBridge.My.Resources.Resources.d_2
        Me.PictureBox1.Location = New System.Drawing.Point(1, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(235, 509)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.White
        Me.btnBack.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBack.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnBack.ForeColor = System.Drawing.Color.Black
        Me.btnBack.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft
        Me.btnBack.IconColor = System.Drawing.Color.DarkGreen
        Me.btnBack.IconSize = 18
        Me.btnBack.Location = New System.Drawing.Point(5, 3)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Rotation = 0R
        Me.btnBack.Size = New System.Drawing.Size(48, 23)
        Me.btnBack.TabIndex = 7
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'AddUserFormPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(634, 535)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "AddUserFormPage"
        Me.Text = "AddUserFormPage"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnCreateAccount As FontAwesome.Sharp.IconButton
    Friend WithEvents showPassword As CheckBox
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents Label2 As Label
    Friend WithEvents txtPassword2 As TextBox
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents IconButton7 As FontAwesome.Sharp.IconButton
    Friend WithEvents Label7 As Label
    Friend WithEvents txtPassword1 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtPhone As MaskedTextBox
    Friend WithEvents IconButton8 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtGmail As MaskedTextBox
    Friend WithEvents IconButton4 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtStaffID As MaskedTextBox
    Friend WithEvents IconButton5 As FontAwesome.Sharp.IconButton
    Friend WithEvents btnBack As FontAwesome.Sharp.IconButton
    Friend WithEvents Label8 As Label
    Friend WithEvents txtAccountType As ComboBox
    Friend WithEvents IconButton3 As FontAwesome.Sharp.IconButton
End Class
