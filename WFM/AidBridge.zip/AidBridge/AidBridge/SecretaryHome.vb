﻿Public Class SecretaryHome
    Private Sub SecretaryHome_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            txtTotalContributions.Text = "Ghc " + totalContributions.ToString
            txtTotalClaims.Text = "Ghc " + totalMoneyGivenOut.ToString
            txtTotalMembers.Text = totalMembers.ToString

            txtYear.Text = currentYear
            txtYear2.Text = currentYear
        Catch ex As Exception

        End Try


        Try
            Dim dataTable As New DataTable()
            dataTable.Columns.Add("Description", GetType(String))
            dataTable.Columns.Add("Amount", GetType(Integer))

            dataTable.Rows.Add("Contributions", totalContributions)

            dataTable.Rows.Add("Claims", totalMoneyGivenOut)

            Me.Chart1.DataSource = dataTable

            Chart1.Series("Series1").XValueMember = "Description"
            Chart1.Series("Series1").YValueMembers = "Amount"

        Catch ex As Exception

        End Try

        Try
            'Doughnut Chart
            Dim dataTable2 As New DataTable()

            dataTable2.Columns.Add("Description", GetType(String))
            dataTable2.Columns.Add("Value", GetType(Integer))

            dataTable2.Rows.Add("No. Of Claims", totalClaims)
            dataTable2.Rows.Add("Members", totalMembers)

            Me.Chart2.DataSource = dataTable2

            Chart2.Series("Series1").XValueMember = "Description"
            Chart2.Series("Series1").YValueMembers = "Value"
        Catch ex As Exception

        End Try
    End Sub

    Private Sub dashBoardBtnMembers_Click(sender As Object, e As EventArgs) Handles dashBoardBtnMembers.Click
        SecretryForm.btnMembers.PerformClick()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        SecretryForm.btnMembers.PerformClick()
    End Sub
End Class