﻿Imports System.Data.SqlClient
Public Class ProceedClaimPage

    Sub switchPages(ByVal pageSwitch1 As Form)
        Try
            UserPage.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            UserPage.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub PopulateBeneficiaries()
        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & memberUserStaffID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            beneficiariesDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub

    Private Sub Populatechildren()
        '
        '

        Try
            Con.Open()
            Dim query = "select * from ChildrenTbl where Member_ID='" & memberUserStaffID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            childrenDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles oneChild.CheckedChanged
        If (txtReason.Text = "Child Death" Or txtReason.Text = "Husband/Wife & Child Death" Or txtReason.Text = "Child & Mother Death" Or txtReason.Text = "Child & Father Death") Then
            txtChild1Name.ReadOnly = False
            txtChild1DoB.ReadOnly = False
            txtChild2Name.ReadOnly = True
            txtChild2DoB.ReadOnly = True
            txtChild3Name.ReadOnly = True
            txtChild3DoB.ReadOnly = True

            'Delete text in the boxes
            txtChild2Name.Text = ""
            txtChild2DoB.Text = ""
            txtChild3Name.Text = ""
            txtChild3DoB.Text = ""
            txtChildTwoID.Text = ""
            txtChildThreeID.Text = ""
        Else
            oneChild.Checked = False
            twoChildren.Checked = False
            threeChildren.Checked = False
        End If

    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles twoChildren.CheckedChanged
        If (txtReason.Text = "Child Death" Or txtReason.Text = "Husband/Wife & Child Death" Or txtReason.Text = "Child & Mother Death" Or txtReason.Text = "Child & Father Death") Then
            txtChild1Name.ReadOnly = False
            txtChild1DoB.ReadOnly = False
            txtChild2Name.ReadOnly = False
            txtChild2DoB.ReadOnly = False
            txtChild3Name.ReadOnly = True
            txtChild3DoB.ReadOnly = True

            'Delete text in the boxes
            txtChild3Name.Text = ""
            txtChild3DoB.Text = ""
            txtChildThreeID.Text = ""
        Else
            oneChild.Checked = False
            twoChildren.Checked = False
            threeChildren.Checked = False

        End If

    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles threeChildren.CheckedChanged
        If (txtReason.Text = "Child Death" Or txtReason.Text = "Husband/Wife & Child Death" Or txtReason.Text = "Child & Mother Death" Or txtReason.Text = "Child & Father Death") Then
            txtChild1Name.ReadOnly = False
            txtChild1DoB.ReadOnly = False
            txtChild2Name.ReadOnly = False
            txtChild2DoB.ReadOnly = False
            txtChild3Name.ReadOnly = False
            txtChild3DoB.ReadOnly = False
        Else
            oneChild.Checked = False
            twoChildren.Checked = False
            threeChildren.Checked = False
        End If


    End Sub
    'check if member has claimed for his/her spouse before
    Dim countNum As Integer
    Private Sub CheckClaimedSpouse()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from ClaimsTbl where Member_ID ='" & txtStaffID.Text & "' And  Reason='Husband/Wife Death'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            countNum = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub

    Private Sub txtReason_SelectedValueChanged(sender As Object, e As EventArgs) Handles txtReason.SelectedValueChanged
        txtBeneficiaryProportion.Text = ""
        'check if member has claimed for his/her spouse before
        Try
            CheckClaimedSpouse()
        Catch ex As Exception

        End Try


        Try
            If (txtReason.Text = "Husband/Wife & Mother Death" Or txtReason.Text = "Husband/Wife & Father Death" Or txtReason.Text = "Husband/Wife & Child Death") Then
                txtAmountGiven.Text = "500"
            ElseIf (txtReason.Text = "Wedding") Then
                txtAmountGiven.Text = "200"
            ElseIf (txtReason.Text = "Self Medical Treatment") Then
                txtAmountGiven.Text = "100"
            ElseIf (txtReason.Text = "Child Death" Or txtReason.Text = "Father Death" Or txtReason.Text = "Father & Mother Death" Or txtReason.Text = "Child & Father Death" Or txtReason.Text = "Child & Mother Death" Or txtReason.Text = "Mother Death") Then
                txtAmountGiven.Text = "500"
            ElseIf (txtReason.Text = "Husband/Wife Death" And countNum < 1) Then
                txtAmountGiven.Text = "500"
            ElseIf (txtReason.Text = "Husband/Wife Death" And countNum > 0) Then
                txtAmountGiven.Text = "250"
            ElseIf (txtReason.Text = "Departure" Or txtReason.Text = "Retirement")
                If (DuesPaidBeforeNwRate = 0) Then
                    '
                    '
                    If (Convert.ToInt32(txtTotalClaimsLabel.Text) = 0) Then
                        TheClaimAmount = ((P2 / 100) * Convert.ToDouble(txtTotalDues.Text)) + GiftAmount
                        txtAmountGiven.Text = TheClaimAmount.ToString

                    ElseIf (Convert.ToInt32(txtTotalClaimsLabel.Text) <> 0) Then
                        TheClaimAmount = ((P1 / 100) * Convert.ToDouble(txtTotalDues.Text)) + GiftAmount
                        txtAmountGiven.Text = TheClaimAmount.ToString
                    End If

                    '
                    '
                    '
                ElseIf (DuesPaidBeforeNwRate <> 0) Then
                    '
                    '
                    If (Convert.ToInt32(txtTotalClaimsLabel.Text) = 0) Then
                        Dim Difference As Double = DuesAmount - InitialDues
                        Dim DuesPaidBIncrement As Double = DuesPaidBeforeNwRate * Difference
                        Dim TheTotalDuez As Double = Convert.ToDouble(txtTotalDues.Text) + DuesPaidBIncrement
                        TheClaimAmount = ((P2 / 100) * TheTotalDuez) + GiftAmount
                        txtAmountGiven.Text = TheClaimAmount


                    ElseIf (Convert.ToInt32(txtTotalClaimsLabel.Text) <> 0) Then
                        Dim Difference As Double = DuesAmount - InitialDues
                        Dim DuesPaidBIncrement As Double = DuesPaidBeforeNwRate * Difference
                        Dim TheTotalDuez As Double = Convert.ToDouble(txtTotalDues.Text) + DuesPaidBIncrement
                        TheClaimAmount = ((P1 / 100) * TheTotalDuez) + GiftAmount
                        txtAmountGiven.Text = TheClaimAmount
                    End If
                    'DuesPaidBeforeNwRate EndIf
                End If

                'Main End If
            End If
        Catch ex As Exception

        End Try

        '
        '

        '
        '
        Try
            If (txtReason.Text = "Husband/Wife & Mother Death" Or txtReason.Text = "Husband/Wife & Father Death" Or txtReason.Text = "Father & Mother Death" Or txtReason.Text = "Self Medical Treatment" Or txtReason.Text = "Wedding" Or txtReason.Text = "Father Death" Or txtReason.Text = "Mother Death" Or txtReason.Text = "Husband/Wife Death" Or txtReason.Text = "Deceased Member" Or txtReason.Text = "Retirement" Or txtReason.Text = "Departure") Then
                oneChild.Checked = False
                twoChildren.Checked = False
                threeChildren.Checked = False
                txtChild1Name.ReadOnly = True
                txtChild1DoB.ReadOnly = True
                txtChild2Name.ReadOnly = True
                txtChild2DoB.ReadOnly = True
                txtChild3Name.ReadOnly = True
                txtChild3DoB.ReadOnly = True

                'Delete text in the boxes
                txtChild1Name.Text = ""
                txtChild1DoB.Text = ""
                txtChild2Name.Text = ""
                txtChild2DoB.Text = ""
                txtChild3Name.Text = ""
                txtChild3DoB.Text = ""

                txtChildOneID.Text = ""
                txtChildTwoID.Text = ""
                txtChildThreeID.Text = ""

            End If
        Catch ex As Exception

        End Try
        '
        '
        Try
            If (txtReason.Text = "Deceased Member") Then
                txtClaimer.Text = "Beneficiary"
                txtAmountGiven.Text = ""
                txtBeneficiaryNameLabel.Visible = True
                txtBeneficiaryName.Visible = True
            ElseIf (txtReason.Text <> "Deceased Member") Then
                txtClaimer.Text = "Member"
                txtBeneficiaryName.Text = ""
            End If
        Catch ex As Exception

        End Try



    End Sub

    Private Sub txtClaimer_SelectedValueChanged(sender As Object, e As EventArgs) Handles txtClaimer.SelectedValueChanged
        If (txtClaimer.Text = "Beneficiary") Then
            txtBeneficiaryNameLabel.Visible = True
            txtBeneficiaryName.Visible = True
            txtReason.Text = "Deceased Member"
        Else
            ' Member
            txtReason.Text = ""
            txtBeneficiaryNameLabel.Visible = False
            txtBeneficiaryName.Visible = False
        End If
    End Sub


    'Function to Update parentsTbl
    Private Function UpdatePrentsTbl(parentID)
        Try
            Con.Open()
            Cursor = Cursors.WaitCursor
            Dim query As String
            query = "Update ParentsTbl set Live_Status='" & AMotherDeadStatus & "'  where Id =" & parentID & ""
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            '  
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function


    'Private sub to insert to ClaimsTbl if claim is successfull
    Private Sub InsertIntoApprovalsAndApprovalStatusTbl()
        Dim theDate = New DateTimePicker
        Dim ClaimDate As Date = theDate.Value
        '  Dim changeTheDateFormat As Date = txtMonthOfPayment1.Value.Date
        '  Dim ClaimDate As String = ClaimDate.ToString("yyyy-MM-dd")
        Try
            Con.Open()
            Dim query3 As String
            query3 = "insert into ApprovalTbl values('" & txtStaffID.Text & "','" & txtName.Text & "','" & txtAmountGiven.Text & "','" & txtReason.Text & "','" & txtClaimer.Text & "','" & txtBeneficiaryName.Text & "','" & ClaimDate & "','" & Uname & "','" & UStaffID & "','Pending...','')"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()
            '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim query3 As String
            query3 = "insert into ApprovalStatusTbl values('" & txtStaffID.Text & "','" & txtName.Text & "','" & txtAmountGiven.Text & "','" & txtReason.Text & "','" & txtClaimer.Text & "','" & txtBeneficiaryName.Text & "','" & ClaimDate & "','" & Uname & "','" & UStaffID & "','Pending...','')"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()
            '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub


    'Update member Marital Status to Single
    Private Sub UpdateMemberMaritalStatusToSingle()
        Try
            Con.Open()
            Cursor = Cursors.WaitCursor
            Dim query As String
            query = "Update MembersTbl set Marital_Status='" & theMemberSingle & "', Marriage_Type='" & nullMarriageStatus & "'   where Staff_ID ='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            '   MessageBox.Show("Claim successfull", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    'Update member Marital Status to Married
    Private Sub UpdateMemberMaritalStatusToMarried()
        Try
            Con.Open()
            Cursor = Cursors.WaitCursor
            Dim query As String
            query = "Update MembersTbl set Marital_Status='" & theMemberMarried & "' where Staff_ID ='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            '  MessageBox.Show("Claim successfull", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub


    ''Delete Beneficiary
    Private Sub DeleteBeneficiary()
        Try
            Con.Open()
            Dim query3 As String
            query3 = "delete from BeneficiariesTbl where Id = " & txtBeneficiaryID.Text & ""
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()
            '  MessageBox.Show("Claim successfull", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    'DeleteSpouse
    Private Function DeleteSpouse(spouseID)
        Try
            Con.Open()
            Dim query3 As String
            query3 = "delete from SpouseTbl where Member_ID = '" & spouseID & "'"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    'Read the mother or father ID for ParentsTbl
    Private Function ReadFatherOrMother(ParentType)
        Try
            Con.Open()
            Dim query = "select * from ParentsTbl where Member_ID='" & txtStaffID.Text & "'and Parent_Type = '" & ParentType & "'"
            cmd = New SqlCommand(query, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            AMotherOrFatherID = myReader("Id")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

    End Function

    'Reset Page
    Private Sub ResetPage()
        txtReason.Text = ""
        txtClaimer.Text = ""
        txtAmountGiven.Text = ""
        txtBeneficiaryName.Text = ""
        txtBeneficiaryID.Text = ""

        txtChild1Name.Text = ""
        txtChild2Name.Text = ""
        txtChild3Name.Text = ""

        txtChild1DoB.Text = ""
        txtChild2DoB.Text = ""
        txtChild3DoB.Text = ""

        oneChild.Checked = False
        twoChildren.Checked = False
        threeChildren.Checked = False


    End Sub
    'Delete One Child
    Private Function DeleteOneChild(childID)
        Try
            Con.Open()
            Dim Queryy = "delete from ChildrenTbl where Id=" & childID & ""
            cmd = New SqlCommand(Queryy, Con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function
    'Delete Two Children
    Private Function DeleteTwoChildren(childID, child2ID)
        Try
            Con.Open()
            Dim Queryy = "delete from ChildrenTbl where Id=" & childID & ""
            cmd = New SqlCommand(Queryy, Con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim Queryy = "delete from ChildrenTbl where Id=" & child2ID & ""
            cmd = New SqlCommand(Queryy, Con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function
    'Delete Three Children
    Private Function DeleteThreeChildren(childID, child2ID, child3ID)
        Try
            Con.Open()
            Dim Queryy = "delete from ChildrenTbl where Id=" & childID & ""
            cmd = New SqlCommand(Queryy, Con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim Queryy = "delete from ChildrenTbl where Id=" & child2ID & ""
            cmd = New SqlCommand(Queryy, Con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim Queryy = "delete from ChildrenTbl where Id=" & child3ID & ""
            cmd = New SqlCommand(Queryy, Con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    Dim aa2 As Integer = 0, aa3 As Integer = 0

    Private Sub checkIfMemberIsMarried()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from SpouseTbl where Member_ID ='" & txtStaffID.Text & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa2 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub

    'CheckIfMemberIsMarried
    Private Sub CheckSpouse()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from SpouseTbl where Member_ID ='" & txtStaffID.Text & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa3 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub

    Dim aa6 As Integer = 0, aa7 As Integer = 0
    'Check Reason for retired 
    Private Sub CheckReasonIfRetired()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from ClaimsTbl where Member_ID ='" & txtStaffID.Text & "' And Reason ='" & txtRetirement & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa6 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub

    'Check Reason for Departure 
    Private Sub CheckReasonIfDeparted()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from ClaimsTbl where Member_ID ='" & txtStaffID.Text & "' And Reason ='" & txtDeparture & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa7 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub

    'Check If the member is dead
    Dim aa5 As Integer = 0
    Private Sub CheckDeceasedMember()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from ClaimsTbl where Member_ID ='" & txtStaffID.Text & "' And  Claimer='" & txtClaimByBeneficiary & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa5 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub
    Dim countUncompletedRequest As Integer = 0
    Private Sub CheckUncompletedRequest()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from ApprovalStatusTbl where Member_ID ='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            countUncompletedRequest = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub
    Private Sub PopulateApprovalAfAction()
        Try
            Con.Open()
            Dim query = "select Id,Member_Name,Member_ID,Amount,Reason,Claimer,Beneficiary_Name,Request_Date,Operator from ApprovalTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ClaimsPage.approvalsDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

    End Sub

    Dim countSelfMediClaimForThisYear As Integer = 0
    Private Sub checkSelfMedicalClaimYear(memberId)

        Dim currentYear As Integer = DateTime.Now.Year

        Try
            Con.Open()
            ' SQL query to count the number of claims for the current year
            Dim query As String = "SELECT COUNT(*) FROM ClaimsTbl WHERE YEAR(Claim_Date) = @Year AND Member_ID='" & memberId & "'"
            cmd = New SqlCommand(query, Con)
            ' Add the parameter to the query
            cmd.Parameters.AddWithValue("@Year", currentYear)
            ' Execute the command and get the count
            countSelfMediClaimForThisYear = Convert.ToInt32(cmd.ExecuteScalar())

        Catch ex As Exception
            MsgBox("An error occurred: " & ex.Message)
        Finally
            Con.Close()
        End Try


    End Sub


    Private Sub ClaimStatusBtn_Click(sender As Object, e As EventArgs) Handles ClaimStatusBtn.Click
        ''MessageBox.Show("OKKKKKKK", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Cursor = Cursors.WaitCursor

        If (txtReason.Text = "") Then
            MsgBox("Select a 'Reason'", MsgBoxStyle.Exclamation)
        ElseIf (txtClaimer.Text = "") Then
            MsgBox("Select the 'Claimer'", MsgBoxStyle.Exclamation)
        ElseIf (txtAmountGiven.Text = "") Then
            MsgBox("Enter the amount", MsgBoxStyle.Exclamation)
        ElseIf (txtClaimer.Text = "Beneficiary" And txtBeneficiaryName.Text = "") Then
            MsgBox("Select the 'Beneficiarie's' name by clicking on his/her name in the 'Beneficiaries' Box'", MsgBoxStyle.Exclamation)
        ElseIf (txtClaimer.Text = "Beneficiary" And txtBeneficiaryName.Text <> "") Then
            'Insert to beneficiariesTbl
            'Check If the member has already claimes for his REtirement Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()
            CheckReasonIfRetired()
            'Check if member is Dead
            '  CheckDeceasedMember()

            If (aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                InsertIntoApprovalsAndApprovalStatusTbl()

                'Delete beneficiariesTbl
                DeleteBeneficiary()
                MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                ResetPage()
                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)
            ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
            End If


        ElseIf (txtReason.Text = "Husband/Wife Death") Then
            'check if the member married
            checkIfMemberIsMarried()
            '' MessageBox.Show(aa2, "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Check If the member has already claimes for his REtirement Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()
            CheckReasonIfRetired()
            'Check if member is Dead
            CheckDeceasedMember()
            'insert into database if the member has a spouse or hasn't claimed for the spouse
            If (txtMaritalStatus.Text = "Married" And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                'Insert into ApprovalsTbl And ApprovalStatusTbl
                InsertIntoApprovalsAndApprovalStatusTbl()


                'Trying something


                ''If (aa2 <> 0) Then
                'Delete beneficiariesTbl
                'DeleteSpouse(txtStaffID.Text)
                'End If
                ''Update the member marital status if he/she claims for his/her spouse
                ' UpdateMemberMaritalStatusToSingle()


                MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                ResetPage()

                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)

            ElseIf (txtMaritalStatus.Text = "Single") Then
                MsgBox("The member is single", MsgBoxStyle.Exclamation)
            ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
            ElseIf (aa5 <> 0) Then
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            End If


            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        ElseIf (txtReason.Text = "Mother Death") Then
            'check if the member has already claimed for his/her Mother
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AMother & "' And  Live_Status='" & AMotherDeadStatus & "'"
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
            'Check If the member has already claimes for his REtirement Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()
            CheckReasonIfRetired()
            'Check if member is Dead
            CheckDeceasedMember()
            'Insert to Database If the member's Mother is not already dead or has not claimed for his/her mum
            If (aa2 = 0 And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                InsertIntoApprovalsAndApprovalStatusTbl()

                'read the mother ID
                '  ReadFatherOrMother(AMother)
                'update the mother live Status using her ID
                'UpdatePrentsTbl(AMotherOrFatherID)

                MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                ResetPage()

                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)
            ElseIf (aa5 <> 0) Then
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)

            Else
                MsgBox("The member has already claimed for his/her Mother Or his/her Mother was already dead when Registering", MsgBoxStyle.Exclamation)
            End If

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        ElseIf (txtReason.Text = "Father Death") Then
            'check if the member has already claimed for his/her Father
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AFather & "' And  Live_Status='" & AMotherDeadStatus & "'"
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try

            'Check If the member has already claimes for his REtirement Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()
            CheckReasonIfRetired()

            'Check if member is Dead
            CheckDeceasedMember()
            'Insert to Database If the member's Mother is not already dead or has not claimed for his/her mum
            If (aa2 = 0 And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                InsertIntoApprovalsAndApprovalStatusTbl()

                'read the mother ID
                ' ReadFatherOrMother(AFather)
                'update the mother live Status using her ID
                'UpdatePrentsTbl(AMotherOrFatherID)

                MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                ResetPage()

                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)
            ElseIf (aa5 <> 0) Then
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
            Else
                MsgBox("The member has already claimed for his/her Father Or his/her Father was already dead when Registering", MsgBoxStyle.Exclamation)
            End If



        ElseIf (txtReason.Text = "Wedding") Then
            'Check if the member is currently single
            'Check If the member has already claimes for his REtirement Departure
            CheckUncompletedRequest()

            CheckReasonIfDeparted()
            CheckReasonIfRetired()
            'Check if member is Dead
            CheckDeceasedMember()
            'Insert to Claims Table
            If (txtMaritalStatus.Text = "Single" And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                InsertIntoApprovalsAndApprovalStatusTbl()

                '    UpdateMemberMaritalStatus()
                '  UpdateMemberMaritalStatusToMarried()

                MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                ResetPage()
                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)

            ElseIf (aa5 <> 0) Then
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
            Else
                MsgBox("The member has already Married", MsgBoxStyle.Exclamation)
            End If

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        ElseIf (txtReason.Text = "Self Medical Treatment") Then
            'Check If the member has already claimes for his REtirement Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()
            CheckReasonIfRetired()

            checkSelfMedicalClaimYear(txtStaffID.Text)

            'Check if member is Dead
            CheckDeceasedMember()
            If (aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0 And countSelfMediClaimForThisYear = 0) Then

                'Insert to Claims Table
                InsertIntoApprovalsAndApprovalStatusTbl()
                MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                ResetPage()

                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)
            ElseIf (aa5 <> 0) Then
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
            ElseIf (countSelfMediClaimForThisYear > 0) Then
                MsgBox("The member can only make one claim for 'Self Medical Treatment' per year!", MsgBoxStyle.Exclamation)
            End If



        ElseIf (txtReason.Text = "Father & Mother Death") Then
            ''check if the member has already claimed for his/her Father or Mother
            'check if the member has already claimed for his/her Mother
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AMother & "' And  Live_Status='" & AMotherDeadStatus & "'"
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try

            'check if the member has already claimed for his/her Father
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AFather & "' And  Live_Status='" & AMotherDeadStatus & "'"
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa3 = ds.Tables(0).Rows.Count
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
            'Check If the member has already claimes for his REtirement Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()
            CheckReasonIfRetired()
            'Check if member is Dead
            CheckDeceasedMember()
            'Finally insert to ClaimsTbl
            If (aa2 = 0 And aa3 = 0 And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                InsertIntoApprovalsAndApprovalStatusTbl()

                'read the mother ID
                'ReadFatherOrMother(AMother)
                'update the mother live Status using her ID
                'UpdatePrentsTbl(AMotherOrFatherID)

                'read the father ID
                '  ReadFatherOrMother(AFather)
                'update the father live Status using her ID
                ' UpdatePrentsTbl(AMotherOrFatherID)
                ' Update()
                MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                ResetPage()
                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)

            ElseIf (aa5 <> 0) Then
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
            ElseIf (aa2 <> 0 And aa3 <> 0) Then
                MsgBox("The member has already claimed for his/her Father And Mohter Or his/her Father And Mother was already dead when Registering", MsgBoxStyle.Exclamation)
            End If



        ElseIf (txtReason.Text = "Husband/Wife & Father Death") Then
            'check if the member has already claimed for his/her Father or Wife/Husband
            'check if the member has already claimed for his/her Father
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AFather & "' And  Live_Status='" & AMotherDeadStatus & "'"
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa3 = ds.Tables(0).Rows.Count
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try

            'check if the member has already claimed for his/her husband or wife
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from SpouseTbl where Member_ID ='" & txtStaffID.Text & "' "
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
            'Check If the member has already claimes for his REtirement Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()
            CheckReasonIfRetired()
            'Check if member is Dead
            CheckDeceasedMember()

            If (aa3 = 0 And txtMaritalStatus.Text = "Married" And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                'Insert to Claims
                InsertIntoApprovalsAndApprovalStatusTbl()

                If (aa2 <> 0) Then
                    'Delete beneficiariesTbl
                    '  DeleteSpouse(txtStaffID.Text)
                End If


                'Update Father LiveStatus
                'read the mother ID
                ' ReadFatherOrMother(AFather)
                'update the mother live Status using her ID
                'UpdatePrentsTbl(AMotherOrFatherID)
                '  UpdateMemberMaritalStatusToSingle()

                MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                ResetPage()
                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)

            ElseIf (aa5 <> 0) Then
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            ElseIf (aa3 <> 0 And aa2 = 0) Then
                MsgBox("The member has already claimed for his/her Father And Spouse Or his/her Father was already dead when Registering", MsgBoxStyle.Exclamation)
            ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)

            End If



        ElseIf (txtReason.Text = "Husband/Wife & Mother Death") Then
            'check if the member has already claimed for his/her Mother or Wife/Husband
            'check if the member has already claimed for his/her Mother
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AMother & "' And  Live_Status='" & AMotherDeadStatus & "'"
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try

            'check if the member has already claimed for his/her husband or wife
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from SpouseTbl where Member_ID ='" & txtStaffID.Text & "' "
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa3 = ds.Tables(0).Rows.Count
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
            'Check If the member has already claimes for his REtirement Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()
            CheckReasonIfRetired()

            'Check if member is Dead
            CheckDeceasedMember()

            If (aa3 <> 0 And txtMaritalStatus.Text = "Married" And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                'Insert to Claims
                InsertIntoApprovalsAndApprovalStatusTbl()

                If (aa2 <> 0) Then
                    'Delete beneficiariesTbl
                    '  DeleteSpouse(txtStaffID.Text)
                End If

                'Update Father LiveStatus
                'read the mother ID
                '  ReadFatherOrMother(AMother)
                'update the mother live Status using her ID
                ' UpdatePrentsTbl(AMotherOrFatherID)

                ' UpdateMemberMaritalStatusToSingle()

                MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                ResetPage()
                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)

            ElseIf (aa5 <> 0) Then
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            ElseIf (aa3 = 0 And aa2 <> 0) Then
                MsgBox("The member has already claimed for his/her Mother And Spouse Or his/her Mother was already dead when Registering", MsgBoxStyle.Exclamation)
            ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
            End If



            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


        ElseIf (txtReason.Text = "Retirement") Then
            'Check if the member is alive
            CheckDeceasedMember()
            'Check for Retirement
            CheckReasonIfRetired()
            'Check for Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()

            If (aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                '
                '
                InsertIntoApprovalsAndApprovalStatusTbl()
                MsgBox("Claim request sent", MsgBoxStyle.Information)
                ResetPage()
                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)

            ElseIf (aa6 <> 0) Then
                MsgBox("The member has already claimed for his/her retirement", MsgBoxStyle.Exclamation)
            ElseIf (aa7 <> 0) Then
                MsgBox("The member has already claimed for his/her Departure", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
            Else
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            End If

            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        ElseIf (txtReason.Text = "Departure") Then
            'Check if the member is alive
            CheckDeceasedMember()
            'Check for Departure
            CheckUncompletedRequest()
            CheckReasonIfDeparted()
            'Check for Retirement
            CheckReasonIfRetired()

            If (aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                '
                '
                InsertIntoApprovalsAndApprovalStatusTbl()
                MsgBox("Claim request sent", MsgBoxStyle.Information)
                ResetPage()
                Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                switchPages(nwTreasurerClaimsPage)

            ElseIf (aa6 <> 0) Then
                MsgBox("The member has already claimed for his/her retirement", MsgBoxStyle.Exclamation)
            ElseIf (aa7 <> 0) Then
                MsgBox("The member has already claimed for his/her Departure", MsgBoxStyle.Exclamation)
            ElseIf (countUncompletedRequest <> 0) Then
                MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
            Else
                MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
            End If


        ElseIf (txtReason.Text = "Child Death") Then
            'another If condition to check The no of Children dead
            If (oneChild.Checked = False And twoChildren.Checked = False And threeChildren.Checked = False) Then
                'Message Box to tell the operator to select the number of deceased children
                MsgBox("Select the number of children the member has lost", MsgBoxStyle.Exclamation)
            ElseIf (oneChild.Checked = True) Then
                'check if the child has been selected by the operator
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild1Name.Text <> "" Or txtChild1DoB.Text <> "") Then
                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    'Check if member is Dead
                    CheckDeceasedMember()
                    If (aa5 = 0 And aa7 = 0 And countUncompletedRequest = 0 And aa6 = 0) Then
                        'insert the claimed child into claimsTbl
                        InsertIntoApprovalsAndApprovalStatusTbl()
                        'Delete the child After inserting
                        DeleteOneChild(txtChildOneID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    End If

                    ''EndIf for checking if the child has been selected
                End If

            ElseIf (twoChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the first  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the first field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild2Name.Text = "" Or txtChild2DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the second field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)

                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "") Then
                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    CheckDeceasedMember()
                    If (aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        'insert the claimed child into claimsTbl
                        InsertIntoApprovalsAndApprovalStatusTbl()
                        'Delete the child After inserting
                        DeleteTwoChildren(txtChildOneID.Text, txtChildTwoID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    End If

                    ''end If for checking if the member has claim for and of the children selected 
                End If


            ElseIf (threeChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the first  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the first field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild2Name.Text = "" Or txtChild2DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the second field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild3Name.Text = "" Or txtChild3DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the third field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "" And txtChild3Name.Text <> "" And txtChild3DoB.Text <> "") Then
                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    'Check if member is Dead
                    CheckDeceasedMember()
                    If (aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        ''insert the claimed child into claimsTbl
                        InsertIntoApprovalsAndApprovalStatusTbl()
                        'Delete the child After inserting
                        DeleteThreeChildren(txtChildOneID.Text, txtChildTwoID.Text, txtChildThreeID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    End If

                    ''end If for checking if the member has claim for and of the children selected 
                End If
                'another If condition to check The no of Children dead End If
            End If
            ''Done for the Child Death



        ElseIf (txtReason.Text = "Husband/Wife & Child Death") Then
            If (oneChild.Checked = False And twoChildren.Checked = False And threeChildren.Checked = False) Then
                MsgBox("Select the number of children the member has lost", MsgBoxStyle.Exclamation)
            ElseIf (oneChild.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild1Name.Text <> "" Or txtChild1DoB.Text <> "") Then
                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    'check if the member has already claim for the Husband
                    CheckSpouse()
                    'Check if member is Dead
                    CheckDeceasedMember()

                    If (txtMaritalStatus.Text = "Married" And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        ''
                        ''insert the claimed child into claimsTbl
                        InsertIntoApprovalsAndApprovalStatusTbl()

                        'Set the member marital status to Single
                        ' UpdateMemberMaritalStatusToSingle()

                        If (aa3 <> 0) Then
                            'Delete beneficiariesTbl
                            ' DeleteSpouse(txtStaffID.Text)
                        End If

                        'Delete the child After inserting
                        DeleteOneChild(txtChildOneID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa5 <> 0) Then
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member has already claimed for his/her spouse Or he/she was single when registering")
                    End If

                    'End If for Child one selected
                End If
                '
                '
                '
            ElseIf (twoChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the first  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the first field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild2Name.Text = "" Or txtChild2DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the second field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)

                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "") Then
                    'check if the member has claim for  the children selected
                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    'Check if member is Dead
                    CheckDeceasedMember()
                    'check if the member has already claim for the Husband
                    CheckSpouse()
                    If (txtMaritalStatus.Text = "Marriage" And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        ''
                        ''insert the claimed child into claimsTbl
                        InsertIntoApprovalsAndApprovalStatusTbl()

                        'Set the member marital status to Single
                        ' UpdateMemberMaritalStatusToSingle()

                        If (aa3 <> 0) Then
                            'Delete beneficiariesTbl
                            '  DeleteSpouse(txtStaffID.Text)
                        End If

                        'Delete the child After inserting
                        DeleteTwoChildren(txtChildOneID.Text, txtChildTwoID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa5 <> 0) Then
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member has already claimed for his/her spouse Or he/she was single when registering")
                    End If

                    ''end If for checking if the member has claim for and of the children selected 
                    'End If for Child two selected
                End If

            ElseIf (threeChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the first  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the first field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild2Name.Text = "" Or txtChild2DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the second field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild3Name.Text = "" Or txtChild3DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the third field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "" And txtChild3Name.Text <> "" And txtChild3DoB.Text <> "") Then
                    'check if the member has claim for and of the children selected
                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    'Check if member is Dead
                    CheckDeceasedMember()
                    CheckSpouse()
                    If (txtMaritalStatus.Text = "Marriage" And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        ''
                        ''insert the claimed child into claimsTbl
                        InsertIntoApprovalsAndApprovalStatusTbl()

                        'Set the member marital status to Single
                        'UpdateMemberMaritalStatusToSingle()

                        If (aa3 <> 0) Then
                            'Delete beneficiariesTbl
                            '   DeleteSpouse(txtStaffID.Text)
                        End If

                        'Delete the child After inserting
                        DeleteThreeChildren(txtChildOneID.Text, txtChildTwoID.Text, txtChildThreeID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa5 <> 0) Then
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member has already claimed for his/her spouse Or he/she was single when registering")
                    End If

                    ''end If for checking if the member has claim for and of the children selected 
                End If
                ''End If for deceased children  selected
            End If



        ElseIf (txtReason.Text = "Child & Mother Death") Then
            If (oneChild.Checked = False And twoChildren.Checked = False And threeChildren.Checked = False) Then
                MsgBox("Select the number of children the member has lost", MsgBoxStyle.Exclamation)
            ElseIf (oneChild.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild1Name.Text <> "" Or txtChild1DoB.Text <> "") Then
                    'check if the member has already claim for the child selected
                    'check if the member has already claimed for his/her Mother
                    Try
                        Cursor = Cursors.WaitCursor
                        Con.Open()
                        Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AMother & "' And  Live_Status='" & AMotherDeadStatus & "'"
                        cmd = New SqlCommand(query22, Con)
                        adaptor = New SqlDataAdapter(cmd)
                        ds = New DataSet()
                        adaptor.Fill(ds)
                        aa2 = ds.Tables(0).Rows.Count
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Cursor = Cursors.Default
                        Con.Close()
                    End Try

                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    'Check if member is Dead
                    CheckDeceasedMember()
                    If (aa2 = 0 And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        'Insert To Claims Tbls
                        InsertIntoApprovalsAndApprovalStatusTbl()

                        'read the mother ID
                        ' ReadFatherOrMother(AMother)
                        'update the mother live Status using her ID
                        'UpdatePrentsTbl(AMotherOrFatherID)

                        'Delete the child After inserting
                        DeleteOneChild(txtChildOneID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa5 <> 0) Then
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member has already claimed for his/her Mother or his/her Mother was dead when registering")
                    End If
                    'End If for Child one selected
                End If
                '             '
                '
            ElseIf (twoChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the first  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the first field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild2Name.Text = "" Or txtChild2DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the second field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)

                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "") Then
                    'check if the member has claim for  the children selected
                    'check if the member has already claimed for his/her Mother
                    Try
                        Cursor = Cursors.WaitCursor
                        Con.Open()
                        Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AMother & "' And  Live_Status='" & AMotherDeadStatus & "'"
                        cmd = New SqlCommand(query22, Con)
                        adaptor = New SqlDataAdapter(cmd)
                        ds = New DataSet()
                        adaptor.Fill(ds)
                        aa2 = ds.Tables(0).Rows.Count
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Cursor = Cursors.Default
                        Con.Close()
                    End Try
                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    'Check if member is Dead
                    CheckDeceasedMember()
                    If (aa2 = 0 And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        'Insert To Claims Tbls
                        InsertIntoApprovalsAndApprovalStatusTbl()

                        'read the mother ID
                        ' ReadFatherOrMother(AMother)
                        'update the mother live Status using her ID
                        'UpdatePrentsTbl(AMotherOrFatherID)

                        'Delete the child After inserting
                        DeleteTwoChildren(txtChildOneID.Text, txtChildTwoID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)

                    ElseIf (aa5 <> 0) Then
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)

                    Else
                        MsgBox("The member has already claimed for his/her Mother or his/her Mother was dead when registering")
                    End If
                    ''end If for checking if the member has claim for and of the children selected 
                    'End If for Child two selected
                End If

            ElseIf (threeChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the first  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the first field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild2Name.Text = "" Or txtChild2DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the second field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild3Name.Text = "" Or txtChild3DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the third field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "" And txtChild3Name.Text <> "" And txtChild3DoB.Text <> "") Then
                    'check if the member has claim for and of the children selected
                    'check if the member has already claimed for his/her Mother
                    Try
                        Cursor = Cursors.WaitCursor
                        Con.Open()
                        Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AMother & "' And  Live_Status='" & AMotherDeadStatus & "'"
                        cmd = New SqlCommand(query22, Con)
                        adaptor = New SqlDataAdapter(cmd)
                        ds = New DataSet()
                        adaptor.Fill(ds)
                        aa2 = ds.Tables(0).Rows.Count
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Cursor = Cursors.Default
                        Con.Close()
                    End Try

                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()

                    'Check if member is Dead
                    CheckDeceasedMember()

                    If (aa2 = 0 And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        'Insert To Claims Tbls
                        InsertIntoApprovalsAndApprovalStatusTbl()

                        'read the mother ID
                        '   ReadFatherOrMother(AMother)
                        'update the mother live Status using her ID
                        '  UpdatePrentsTbl(AMotherOrFatherID)

                        'Delete the child After inserting
                        DeleteThreeChildren(txtChildOneID.Text, txtChildTwoID.Text, txtChildThreeID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa5 <> 0) Then
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member has already claimed for his/her Mother or his/her Mother was dead when registering")
                    End If

                    ''end If for checking if the member has claim for and of the children selected 
                End If
                ''End If for deceased children  selected
            End If



        ElseIf (txtReason.Text = "Child & Father Death") Then
            If (oneChild.Checked = False And twoChildren.Checked = False And threeChildren.Checked = False) Then
                MsgBox("Select the number of children the member has lost", MsgBoxStyle.Exclamation)
            ElseIf (oneChild.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild1Name.Text <> "" Or txtChild1DoB.Text <> "") Then
                    'check if the member has already claim for the child selected

                    'check if the member has already claimed for his/her Father
                    Try
                        Cursor = Cursors.WaitCursor
                        Con.Open()
                        Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AFather & "' And  Live_Status='" & AMotherDeadStatus & "'"
                        cmd = New SqlCommand(query22, Con)
                        adaptor = New SqlDataAdapter(cmd)
                        ds = New DataSet()
                        adaptor.Fill(ds)
                        aa3 = ds.Tables(0).Rows.Count
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Cursor = Cursors.Default
                        Con.Close()
                    End Try
                    'Check if member is Dead

                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()

                    CheckDeceasedMember()

                    If (aa3 = 0 And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        'Insert To Claims Tbls
                        InsertIntoApprovalsAndApprovalStatusTbl()

                        'read the mother ID
                        ' ReadFatherOrMother(AFather)
                        'update the mother live Status using her ID
                        'UpdatePrentsTbl(AMotherOrFatherID)

                        'Delete the child After inserting
                        DeleteOneChild(txtChildOneID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa5 <> 0) Then
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)

                    Else
                        MsgBox("The member has already claimed for his/her Father or his/her Father was dead when registering")
                    End If
                    'End If for Child one selected
                End If


                '
                '
                '
            ElseIf (twoChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the first  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the first field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild2Name.Text = "" Or txtChild2DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the second field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)

                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "") Then
                    'check if the member has claim for  the children selected
                    'check if the member has already claimed for his/her Father
                    Try
                        Cursor = Cursors.WaitCursor
                        Con.Open()
                        Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AFather & "' And  Live_Status='" & AMotherDeadStatus & "'"
                        cmd = New SqlCommand(query22, Con)
                        adaptor = New SqlDataAdapter(cmd)
                        ds = New DataSet()
                        adaptor.Fill(ds)
                        aa3 = ds.Tables(0).Rows.Count
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Cursor = Cursors.Default
                        Con.Close()
                    End Try

                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    'Check if member is Dead
                    CheckDeceasedMember()

                    If (aa3 = 0 And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        'Insert To Claims Tbls
                        InsertIntoApprovalsAndApprovalStatusTbl()

                        'read the mother ID
                        ' ReadFatherOrMother(AFather)
                        'update the mother live Status using her ID
                        'UpdatePrentsTbl(AMotherOrFatherID)

                        'Delete the child After inserting
                        DeleteTwoChildren(txtChildOneID.Text, txtChildTwoID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa5 <> 0) Then
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member has already claimed for his/her Father or his/her Father was dead when registering")
                    End If
                    ''end If for checking if the member has claim for and of the children selected 
                    'End If for Child two selected
                End If

            ElseIf (threeChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    'Message Box to tell the operator to select the first  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the first field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild2Name.Text = "" Or txtChild2DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the second field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild3Name.Text = "" Or txtChild3DoB.Text = "") Then
                    'Message Box to tell the operator to select the second  of deceased child
                    MsgBox("Select the deceased child's Name & DoB(Date Of Birth) at the third field by clicking on his/her in the 'Children Box'", MsgBoxStyle.Exclamation)
                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "" And txtChild3Name.Text <> "" And txtChild3DoB.Text <> "") Then
                    'check if the member has claim for and of the children selected
                    'check if the member has already claimed for his/her Father
                    Try
                        Cursor = Cursors.WaitCursor
                        Con.Open()
                        Dim query22 = "select * from ParentsTbl where Member_ID ='" & txtStaffID.Text & "' And Parent_Type='" & AFather & "' And  Live_Status='" & AMotherDeadStatus & "'"
                        cmd = New SqlCommand(query22, Con)
                        adaptor = New SqlDataAdapter(cmd)
                        ds = New DataSet()
                        adaptor.Fill(ds)
                        aa3 = ds.Tables(0).Rows.Count
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    Finally
                        Cursor = Cursors.Default
                        Con.Close()
                    End Try

                    'Check If the member has already claimes for his REtirement Departure
                    CheckUncompletedRequest()
                    CheckReasonIfDeparted()
                    CheckReasonIfRetired()
                    'Check if member is Dead
                    CheckDeceasedMember()

                    If (aa3 = 0 And aa5 = 0 And aa6 = 0 And aa7 = 0 And countUncompletedRequest = 0) Then
                        'Insert To Claims Tbls
                        InsertIntoApprovalsAndApprovalStatusTbl()

                        'read the mother ID
                        ' ReadFatherOrMother(AFather)
                        'update the mother live Status using her ID
                        'UpdatePrentsTbl(AMotherOrFatherID)

                        'Delete the child After inserting
                        DeleteThreeChildren(txtChildOneID.Text, txtChildTwoID.Text, txtChildThreeID.Text)

                        MessageBox.Show("Claim request sent", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                        ResetPage()
                        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
                        switchPages(nwTreasurerClaimsPage)
                    ElseIf (aa5 <> 0) Then
                        MsgBox("The member is dead.Only beneficiaries can make claims", MsgBoxStyle.Exclamation)
                    ElseIf (aa6 <> 0 Or aa7 <> 0) Then
                        MsgBox("The member has left the facility.Cannot proceed ", MsgBoxStyle.Exclamation)
                    ElseIf (countUncompletedRequest <> 0) Then
                        MsgBox("The member made a claim request which has not been completed ", MsgBoxStyle.Exclamation)
                    Else
                        MsgBox("The member has already claimed for his/her Father or his/her Father was dead when registering")
                    End If
                    ''end If for checking if the member has claim for and of the children selected 
                End If
                ''End If for deceased children  selected
            End If
            'Main End If
        End If
        Cursor = Cursors.Default
    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        Dim nwTreasurerClaimsPage = New TreasurerClaimsPage
        switchPages(nwTreasurerClaimsPage)
    End Sub

    Private Sub txtChild1DoB_KeyUp(sender As Object, e As KeyEventArgs) Handles txtChild1DoB.KeyUp
        txtChild1Name.Text = ""
        txtChild1DoB.Text = ""
        MsgBox("Select the deceased child's name and DoB(Date Of Birth) by clicking on his/her name in the 'Children's' box", MsgBoxStyle.Exclamation)
        txtChild1Name.Text = ""
        txtChild1DoB.Text = ""
    End Sub

    Private Sub txtChild2Name_KeyUp(sender As Object, e As KeyEventArgs) Handles txtChild2Name.KeyUp
        txtChild2Name.Text = ""
        txtChild2DoB.Text = ""
        MsgBox("Select the deceased child's name and DoB(Date Of Birth) by clicking on his/her name in the 'Children's' box", MsgBoxStyle.Exclamation)
        txtChild2Name.Text = ""
        txtChild2DoB.Text = ""
    End Sub

    Private Sub txtChild2DoB_KeyUp(sender As Object, e As KeyEventArgs) Handles txtChild2DoB.KeyUp
        txtChild2Name.Text = ""
        txtChild2DoB.Text = ""
        MsgBox("Select the deceased child's name and DoB(Date Of Birth) by clicking on his/her name in the 'Children's' box", MsgBoxStyle.Exclamation)
        txtChild2Name.Text = ""
        txtChild2DoB.Text = ""
    End Sub

    Private Sub txtChild3Name_KeyUp(sender As Object, e As KeyEventArgs) Handles txtChild3Name.KeyUp
        txtChild3Name.Text = ""
        txtChild3DoB.Text = ""
        MsgBox("Select the deceased child's name and DoB(Date Of Birth) by clicking on his/her name in the 'Children's' box", MsgBoxStyle.Exclamation)
        txtChild3Name.Text = ""
        txtChild3DoB.Text = ""
    End Sub

    Private Sub txtChild3DoB_KeyUp(sender As Object, e As KeyEventArgs) Handles txtChild3DoB.KeyUp
        txtChild2Name.Text = ""
        txtChild2DoB.Text = ""
        MsgBox("Select the deceased child's name and DoB(Date Of Birth) by clicking on his/her name in the 'Children's' box", MsgBoxStyle.Exclamation)
        txtChild2Name.Text = ""
        txtChild2DoB.Text = ""
    End Sub

    Private Sub txtBeneficiary_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBeneficiaryName.KeyUp
        txtBeneficiaryName.Text = ""
        MsgBox("Select the beneficiary's name by clicking on his/her name in the 'Children's' box", MsgBoxStyle.Exclamation)
    End Sub

    Private Sub txtChild1Name_KeyUp(sender As Object, e As KeyEventArgs) Handles txtChild1Name.KeyUp
        txtChild1Name.Text = ""
        txtChild1DoB.Text = ""
        MsgBox("Select the deceased child's name and DoB(Date Of Birth) by clicking on his/her name in the 'Children's' box", MsgBoxStyle.Exclamation)
        txtChild1Name.Text = ""
        txtChild1DoB.Text = ""
    End Sub
    Dim key = 0
    Dim TheClaimAmount As Double
    Private Sub beneficiariesDataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles beneficiariesDataGridView.CellClick
        Try
            If (txtClaimer.Text = "Beneficiary") Then
                Dim row As DataGridViewRow = beneficiariesDataGridView.Rows(e.RowIndex)
                txtBeneficiaryID.Text = row.Cells(0).Value.ToString
                txtBeneficiaryName.Text = row.Cells(2).Value.ToString
                txtBeneficiaryProportion.Text = row.Cells(7).Value.ToString

                If (DuesPaidBeforeNwRate = 0) Then
                    '
                    '
                    If (Convert.ToInt32(txtTotalClaimsLabel.Text) = 0) Then
                        '
                        TheClaimAmount = ((P2 / 100) * Convert.ToDouble(txtTotalDues.Text)) + GiftAmount
                        txtAmountGiven.Text = (Convert.ToDouble(txtBeneficiaryProportion.Text) / 100) * TheClaimAmount

                    ElseIf (Convert.ToInt32(txtTotalClaimsLabel.Text) <> 0) Then
                        '
                        TheClaimAmount = ((P1 / 100) * Convert.ToDouble(txtTotalDues.Text)) + GiftAmount
                        txtAmountGiven.Text = (Convert.ToDouble(txtBeneficiaryProportion.Text) / 100) * TheClaimAmount
                    End If

                    '
                    '
                ElseIf (DuesPaidBeforeNwRate <> 0) Then

                    '
                    If (Convert.ToInt32(txtTotalClaimsLabel.Text) = 0) Then
                        '
                        Dim Difference As Double = DuesAmount - InitialDues
                        Dim DuesPaidBIncrement As Double = DuesPaidBeforeNwRate * Difference
                        Dim TheTotalDuez As Double = Convert.ToDouble(txtTotalDues.Text) + DuesPaidBIncrement
                        TheClaimAmount = ((P2 / 100) * TheTotalDuez) + GiftAmount
                        txtAmountGiven.Text = (Convert.ToDouble(txtBeneficiaryProportion.Text) / 100) * TheClaimAmount

                    ElseIf (Convert.ToInt32(txtTotalClaimsLabel.Text) <> 0) Then
                        '
                        Dim Difference As Double = DuesAmount - InitialDues
                        '   MsgBox(Difference)
                        Dim DuesPaidBIncrement As Double = DuesPaidBeforeNwRate * Difference
                        '  MsgBox(DuesPaidBIncrement)
                        Dim TheTotalDuez As Double = Convert.ToDouble(txtTotalDues.Text) + DuesPaidBIncrement
                        ' MsgBox(TheTotalDuez)
                        TheClaimAmount = ((P1 / 100) * TheTotalDuez) + GiftAmount
                        'MsgBox(TheClaimAmount)
                        txtAmountGiven.Text = (Convert.ToDouble(txtBeneficiaryProportion.Text) / 100) * TheClaimAmount
                    End If

                    '

                End If

                If txtBeneficiaryID.Text = "" Or txtBeneficiaryName.Text = "" Then
                    key = 0
                Else
                    key = Convert.ToInt32(row.Cells(0).Value.ToString)
                End If
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub childrenDataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles childrenDataGridView.CellClick
        Try
            Dim row As DataGridViewRow = childrenDataGridView.Rows(e.RowIndex)
            If (oneChild.Checked = True) Then
                txtChildOneID.Text = row.Cells(0).Value.ToString
                txtChild1Name.Text = row.Cells(2).Value.ToString
                txtChild1DoB.Text = row.Cells(3).Value.ToString


            ElseIf (twoChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    txtChildOneID.Text = row.Cells(0).Value.ToString
                    If (txtChildOneID.Text = txtChildTwoID.Text) Then
                        MsgBox("The child has been already selected at the second field", MsgBoxStyle.Exclamation)
                        txtChild1Name.Text = ""
                        txtChild1DoB.Text = ""
                    Else
                        txtChild1Name.Text = row.Cells(2).Value.ToString
                        txtChild1DoB.Text = row.Cells(3).Value.ToString
                    End If


                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "") Then
                    txtChildTwoID.Text = row.Cells(0).Value.ToString
                    If (txtChildTwoID.Text = txtChildOneID.Text) Then
                        MsgBox("The child has been already selected at the first field", MsgBoxStyle.Exclamation)
                        txtChildTwoID.Text = ""
                        txtChild2Name.Text = ""
                        txtChild2DoB.Text = ""
                    Else
                        txtChild2Name.Text = row.Cells(2).Value.ToString
                        txtChild2DoB.Text = row.Cells(3).Value.ToString
                    End If

                    ' ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "") Then

                End If

            ElseIf (threeChildren.Checked = True) Then
                If (txtChild1Name.Text = "" Or txtChild1DoB.Text = "") Then
                    txtChildOneID.Text = row.Cells(0).Value.ToString
                    If (txtChildOneID.Text = txtChildTwoID.Text) Then
                        MsgBox("The child has been already selected at the second field", MsgBoxStyle.Exclamation)
                        txtChildOneID.Text = ""
                        txtChild1Name.Text = ""
                        txtChild1DoB.Text = ""
                    ElseIf (txtChildOneID.Text = txtChildThreeID.Text) Then
                        MsgBox("The child has been already selected at the Third field", MsgBoxStyle.Exclamation)
                        txtChildOneID.Text = ""
                        txtChild1Name.Text = ""
                        txtChild1DoB.Text = ""
                    Else
                        txtChild1Name.Text = row.Cells(2).Value.ToString
                        txtChild1DoB.Text = row.Cells(3).Value.ToString
                    End If



                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text = "" And txtChild2DoB.Text = "") Then
                    txtChildTwoID.Text = row.Cells(0).Value.ToString
                    If (txtChildTwoID.Text = txtChildOneID.Text) Then
                        MsgBox("The child has been already selected at the first field", MsgBoxStyle.Exclamation)
                        txtChildTwoID.Text = ""
                        txtChild2Name.Text = ""
                        txtChild2DoB.Text = ""
                    Else
                        txtChild2Name.Text = row.Cells(2).Value.ToString
                        txtChild2DoB.Text = row.Cells(3).Value.ToString
                    End If
                    '
                    '
                ElseIf (txtChild1Name.Text <> "" And txtChild1DoB.Text <> "" And txtChild2Name.Text <> "" And txtChild2DoB.Text <> "" And txtChild3Name.Text = "" And txtChild3DoB.Text = "") Then
                    txtChildThreeID.Text = row.Cells(0).Value.ToString
                    If (txtChildThreeID.Text = txtChildOneID.Text) Then
                        MsgBox("The child has been already selected at the first field", MsgBoxStyle.Exclamation)
                        txtChildThreeID.Text = ""
                        txtChild3Name.Text = ""
                        txtChild3DoB.Text = ""
                    ElseIf (txtChildThreeID.Text = txtChildTwoID.Text)
                        MsgBox("The child has been already selected at the second field", MsgBoxStyle.Exclamation)
                        txtChildThreeID.Text = ""
                        txtChild3Name.Text = ""
                        txtChild3DoB.Text = ""
                    Else
                        txtChild3Name.Text = row.Cells(2).Value.ToString
                        txtChild3DoB.Text = row.Cells(3).Value.ToString
                    End If

                End If
            End If
        Catch ex As Exception

        End Try

    End Sub
End Class