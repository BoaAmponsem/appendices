﻿Imports System.Data.SqlClient
Imports System.Drawing.Printing
Imports Microsoft.Reporting.WinForms
Imports System.Net
Public Class UserContributions
    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select * from ContributionsTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Surname  like '%' +@parm1+ '%' "
            query &= " or Member_ID like '%' +@parm1+ '%' "
            query &= " or Phone like '%' +@parm1+ '%' "
            query &= " or Amount like '%' +@parm1+ '%' "
            query &= " or Other_Names like '%' +@parm1+ '%' "
            query &= " or Month_Of_Payment like '%' +@parm1+ '%' "
            query &= " or Date like '%' +@parm1+ '%' "
            query &= " or Payees_Name like '%' +@parm1+ '%' "
            query &= " or Operator like '%' +@parm1+ '%' "
            query &= " or Operator_ID like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using
            '  End Using
        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function
    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select * from ContributionsTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ContributionsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub


    Private Sub UserContributions_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            AcceptButton = addDepositBtn
            txtMonthOfPayment.Text = ""
            Populate()
            Me.contributionReportViewer.RefreshReport()
            Me.contributionReportViewer.RefreshReport()
        Catch ex As Exception

        End Try

        Try
            debtorsList()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        ContributionsDataGridView.DataSource = Me.SearchItem
    End Sub
    Dim counterr As Integer
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        counterr = counterr + 1
        If (counterr = 3) Then
            memberNotFoundFeedback.Visible = False
            counterr = 0
            Timer1.Stop()
        End If
    End Sub

    Private Function ContributionsByMember(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ContributionsTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            memberContributionsDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Function

    Private Function ContributionsByMemberPhone(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ContributionsTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            memberContributionsDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Function
    Dim aa2 As Integer = 0
    Private Sub QueryBtn_Click(sender As Object, e As EventArgs) Handles QueryBtn.Click
        If (searchBox.Text = "") Then
            txtPaidIBy.Text = ""

            InformationTab.Visible = False
            makePaymentGroupBox.Visible = False
            ContributionsGroupBox.Visible = False
            ' payBtn.Visible = False

            MessageBox.Show("Enter the member's ID/Phone", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

        ElseIf (selectIDType.Text = "") Then
            txtPaidIBy.Text = ""
            InformationTab.Visible = False
            makePaymentGroupBox.Visible = False
            ContributionsGroupBox.Visible = False
            ' payBtn.Visible = False
            txtPaidIBy.Text = ""

            MessageBox.Show("Select the ID Type", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

        ElseIf (selectIDType.Text = "Staff ID") Then
            '
            '
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from MembersTbl where Staff_ID ='" & searchBox.Text & "' "
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count


            Catch ex As Exception
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
            '
            '
            'When member exist
            If ((aa2 = 0) = False) Then
                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Staff_ID='" & searchBox.Text & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUserStaffID = myReader("Staff_ID")
                    memberUserSurname = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")
                    profilePicture = CType(myReader("Picture"), Byte())


                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                Try
                    txtSurname.Text = memberUserSurname.ToUpper
                    txtMemberOtherName.Text = memberUserOthername.ToUpper
                    txtBirthDate.Text = memberUserDoB
                    txtSex.Text = memberUserSex
                    txtHomeTown.Text = memberUserHomeTown.ToUpper
                    txtMaritalStatus.Text = memberUserMaritalStatus
                    txtMarriageType.Text = memberUserTypeOfMarriage
                    txtHouseNo.Text = memberUserHouseNo.ToUpper
                    txtPostalAddress.Text = memberUserPostalAddress.ToUpper
                    txtPhone.Text = memberUserPhone
                    txtStaffID.Text = memberUserStaffID.ToUpper
                    txtPaidIBy.Text = ""

                    memberNotFoundFeedback.Visible = False

                    ContributionsByMember(txtStaffID.Text)

                    InformationTab.Visible = True
                    makePaymentGroupBox.Visible = True
                    ContributionsGroupBox.Visible = True
                    'payBtn.Visible = True


                Catch ex As Exception

                End Try

            Else
                'When member doesn't exist
                InformationTab.Visible = False
                makePaymentGroupBox.Visible = False
                ContributionsGroupBox.Visible = False
                ' payBtn.Visible = False
                txtPaidIBy.Text = ""

                memberNotFoundFeedback.Visible = True
                Timer1.Start()
            End If

        ElseIf (selectIDType.Text = "Phone") Then
            '
            'Check if member with Phone number entered exist
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from MembersTbl where Phone ='" & searchBox.Text & "' "
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count

            Catch ex As Exception
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try

            'When member exist
            If ((aa2 = 0) = False) Then
                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Phone='" & searchBox.Text & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUserStaffID = myReader("Staff_ID")
                    memberUserSurname = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")

                    '     memberUserPicture = myReader("Picture")
                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                Try
                    txtSurname.Text = memberUserSurname.ToUpper
                    txtMemberOtherName.Text = memberUserOthername.ToUpper
                    txtBirthDate.Text = memberUserDoB
                    txtSex.Text = memberUserSex
                    txtHomeTown.Text = memberUserHomeTown.ToUpper
                    txtMaritalStatus.Text = memberUserMaritalStatus
                    txtMarriageType.Text = memberUserTypeOfMarriage
                    txtHouseNo.Text = memberUserHouseNo.ToUpper
                    txtPostalAddress.Text = memberUserPostalAddress.ToUpper
                    txtPhone.Text = memberUserPhone
                    txtStaffID.Text = memberUserStaffID.ToUpper
                    txtPaidIBy.Text = ""

                    memberNotFoundFeedback.Visible = False

                    ContributionsByMemberPhone(txtStaffID.Text)

                    InformationTab.Visible = True
                    makePaymentGroupBox.Visible = True
                    ContributionsGroupBox.Visible = True
                    ' payBtn.Visible = True
                Catch ex As Exception

                End Try
            Else
                ''Member doesn't exist message
                InformationTab.Visible = False
                makePaymentGroupBox.Visible = False
                ContributionsGroupBox.Visible = False
                txtPaidIBy.Text = ""
                ' payBtn.Visible = False

                memberNotFoundFeedback.Visible = True
                Timer1.Start()
                ''member with Phone number exist End If
            End If

            'Main If
        End If
    End Sub

    Private Sub TabControl1_Click(sender As Object, e As EventArgs) Handles TabControl1.Click
        AcceptButton = QueryBtn
        Populate()
        txtMonthOfPayment.Text = ""
    End Sub
    Dim maxDateMonthh As Integer, maxDateYearr As Integer, checkContributionssMade As Integer
    Dim subtractMonth As Integer, subtractYear As Integer
    Private Function GetUnpaidMonthsForMember()
        '' Check if the member has contribute before

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl where Member_ID ='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checkContributionssMade = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try



        '' Get last payment date
        Try
            If (checkContributionssMade > 0) Then

                Try
                    Con.Open()
                    Dim query As String = "SELECT MAX([Month_Of_Payment]) AS MaxDate FROM ContributionsTbl WHERE Member_ID ='" & txtStaffID.Text & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    Dim maxDate As DateTime = myReader("MaxDate")
                    maxDateMonthh = Convert.ToInt32(maxDate.Month)
                    maxDateYearr = Convert.ToInt32(maxDate.Year)
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Con.Close()

                End Try

            End If
        Catch ex As Exception

        End Try


        ''Add contributions
        Try
            '' MsgBox("The Contributions made " + checkContributionssMade)
            If (checkContributionssMade < 1) Then
                Dim askIfFirstTimeOfContributing As DialogResult = MessageBox.Show("Is the selected 'Contribution Month' (" & txtMonthOfPayment1.Value.ToString("MMMM") + "," + txtMonthOfPayment1.Value.Year.ToString & ") the member's first contribution month? Check if his/her starting 'Contribution Month' is correct before proceeding.", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If (askIfFirstTimeOfContributing = DialogResult.Yes) Then
                    'Store payment
                    ProceedPayment()
                End If
            ElseIf (checkContributionssMade > 0) Then
                '' MsgBox("The Contributions made " + checkContributionssMade.ToString)
                If (Convert.ToInt32(txtMonthOfPayment1.Value.Year) < maxDateYearr) Then
                    MsgBox("The selected Contribution Month is earlier than the last Contribution Month the member paid for.", MsgBoxStyle.Exclamation)
                ElseIf (maxDateYearr = Convert.ToInt32(txtMonthOfPayment1.Value.Year) And Convert.ToInt32(txtMonthOfPayment1.Value.Month) < maxDateMonthh) Then
                    MsgBox("The selected Contribution Month is earlier than the last Contribution Month the member paid for.", MsgBoxStyle.Exclamation)
                ElseIf (Convert.ToInt32(txtMonthOfPayment1.Value.Year) > maxDateYearr And maxDateMonthh < 12)
                    MsgBox(txtSurname.Text + " " + txtMemberOtherName.Text + " must pay for the previous month(s)", MsgBoxStyle.Exclamation)
                ElseIf (Convert.ToInt32(txtMonthOfPayment1.Value.Year) > maxDateYearr And maxDateMonthh = 12 And (Convert.ToInt32(txtMonthOfPayment1.Value.Year) - maxDateYearr) > 1) Then
                    MsgBox("The selected year should follow the last payment year.", MsgBoxStyle.Exclamation)
                ElseIf (Convert.ToInt32(txtMonthOfPayment1.Value.Year) > maxDateYearr And maxDateMonthh = 12 And (Convert.ToInt32(txtMonthOfPayment1.Value.Year) - maxDateYearr) = 1 And Convert.ToInt32(txtMonthOfPayment1.Value.Month) > 1) Then
                    MsgBox("The 'Contribution Month' must start from the first month of the year selected.", MsgBoxStyle.Exclamation)
                ElseIf (Convert.ToInt32(txtMonthOfPayment1.Value.Year) > maxDateYearr And maxDateMonthh = 12 And (Convert.ToInt32(txtMonthOfPayment1.Value.Year) - maxDateYearr) = 1 And Convert.ToInt32(txtMonthOfPayment1.Value.Month) = 1) Then
                    Dim askAddContribution As DialogResult = MessageBox.Show("Add (" & txtMonthOfPayment1.Value.ToString("MMMM") + "," + txtMonthOfPayment1.Value.Year.ToString & ") Contribution?", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (askAddContribution = DialogResult.Yes) Then
                        'Store payment
                        ' sendContributionSms(txtSurname.Text, txtStaffID.Text, txtAmount.Text, txtMonthOfPayment1.Value.ToString("MMMM") + "," + txtMonthOfPayment1.Value.Year.ToString, txtPhone.Text)
                        ProceedPayment()
                    End If
                ElseIf (maxDateYearr = Convert.ToInt32(txtMonthOfPayment1.Value.Year) And Convert.ToInt32(txtMonthOfPayment1.Value.Month) > maxDateMonthh Or Convert.ToInt32(txtMonthOfPayment1.Value.Month) = maxDateMonthh) Then
                    subtractMonth = Convert.ToInt32(txtMonthOfPayment1.Value.Month) - maxDateMonthh
                    If (subtractMonth > 1) Then
                        MsgBox(txtSurname.Text + " " + txtMemberOtherName.Text + " must pay for the previous month(s)", MsgBoxStyle.Exclamation)
                    ElseIf (subtractMonth <= 1) Then
                        Dim askAddContribution As DialogResult = MessageBox.Show("Add (" & txtMonthOfPayment1.Value.ToString("MMMM") + "," + txtMonthOfPayment1.Value.Year.ToString & ") Contribution?", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                        If (askAddContribution = DialogResult.Yes) Then
                            'Store payment                           
                            ProceedPayment()
                        End If
                    End If
                End If
                'MsgBox("The day is " + maxDateMonthh.ToString + " The year is " + maxDateYearr.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Function



    Private Sub ProceedPayment()
        Dim getCurrentDate = New DateTimePicker
        Dim currentDate = getCurrentDate.Value
        Dim getMonth = txtMonthOfPayment1.Value.Month
        Dim getYear = txtMonthOfPayment1.Value.Year


        Dim changeTheDateFormat As Date = txtMonthOfPayment1.Value.Date
        Dim theCorrectFormat As String = changeTheDateFormat.ToString("yyyy-MM-dd")
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl where Member_ID='" & txtStaffID.Text & "' and month(Month_Of_Payment)='" & getMonth & "' and year(Month_Of_Payment)='" & getYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa4 = ds.Tables(0).Rows.Count

        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
        ' MsgBox(aa4)
        If ((aa4 = 0) = True) Then
            Try

                Con.Open()
                Dim queryy = "insert into ContributionsTbl values('" & txtStaffID.Text & "','" & txtSurname.Text & "','" & txtMemberOtherName.Text & "','" & txtPhone.Text & "','" & txtAmount.Text & "','" & theCorrectFormat & "','" & currentDate & "','" & Uname & "','" & UStaffID & "','" & txtPaidIBy.Text & "')"
                cmd = New SqlCommand(queryy, Con)
                cmd.ExecuteNonQuery()


                PrintPreviewDialog1.Document = PrintDocument1
                PrintPreviewDialog1.WindowState = FormWindowState.Maximized
                PrintPreviewDialog1.Show()
                sendContributionSms(txtSurname.Text, txtStaffID.Text, txtAmount.Text, txtMonthOfPayment1.Value.ToString("MMMM") + "," + txtMonthOfPayment1.Value.Year.ToString, txtPhone.Text)
                MsgBox("Payment successful", MsgBoxStyle.Information)

                txtMonthOfPayment.Text = ""
                ' txtAmount.Text = ""
                'txtPaidIBy.Text = ""
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical)
            Finally
                Con.Close()
            End Try

            ContributionsByMember(txtStaffID.Text)

        Else
            MsgBox("Member has already made payment for the month selected", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub sendContributionSms(memberName, memberStaffID, amountt, contributionMonth, recipient)

        Cursor = Cursors.WaitCursor
        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        ' Define the base URL and API key
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). We have received your monthly (" & contributionMonth & ") contribution of Ghc" & amountt & ".00. Thank You!    [SDA HOSPITAL,SUNYANI]"

        Dim client As New WebClient()
        'Dim url As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=0247086663&from=SenderID&sms=YourMessage"


        Try
            Dim response As String = client.DownloadString(baseURL)
            txtResponseMaskedTextBox.Text = response
            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. SMS not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            Else
                ' MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                txtResponseMaskedTextBox.Text = ""
            End If
            ''MsgBox(response, MsgBoxStyle.Information)
        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                resendContributionSMS(txtSurname.Text, txtStaffID.Text, txtAmount.Text, txtMonthOfPayment1.Value.ToString("MMMM") + "," + txtMonthOfPayment1.Value.Year.ToString, txtPhone.Text)
            End If
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub resendContributionSMS(memberName, memberStaffID, amountt, contributionMonth, recipient)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). We have received your monthly (" & contributionMonth & ") contribution of Ghc" & amountt & ".00. Thank You!    [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()
        'Dim url As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=0247086663&from=SenderID&sms=YourMessage"


        Try
            Dim response As String = client.DownloadString(baseURL)
            txtResponseMaskedTextBox.Text = response
            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. SMS not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            Else

                txtResponseMaskedTextBox.Text = ""
            End If
            '' MsgBox(response, MsgBoxStyle.Information)
        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                sendContributionSms(txtSurname.Text, txtStaffID.Text, txtAmount.Text, txtMonthOfPayment1.Value.ToString("MMMM") + "," + txtMonthOfPayment1.Value.Year.ToString, txtPhone.Text)
            End If
        Finally
            Cursor = Cursors.Default
            '' MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Dim aa4 As Integer = 0
    Private Sub payBtn_Click(sender As Object, e As EventArgs) Handles payBtn.Click
        Cursor = Cursors.WaitCursor

        Dim currentMonth1 As Integer = DateTime.Now.Month
        Dim currentYear1 As Integer = DateTime.Now.Year
        'MsgBox(getYear)
        If (txtAmount.Text = "") Then
            MsgBox("Enter the amount", MsgBoxStyle.Exclamation)
        ElseIf (txtPaidIBy.Text = "") Then
            MsgBox("Enter the payees' name", MsgBoxStyle.Exclamation)
        ElseIf (IsNumeric(txtPaidIBy.Text) = True) Then
            MsgBox("The Payees' name can't be a number", MsgBoxStyle.Exclamation)
        ElseIf (txtMonthOfPayment.Text = "") Then
            MsgBox("Set the month the member is paying for", MsgBoxStyle.Exclamation)
        ElseIf (IsNumeric(txtPaidIBy.Text) = True) Then
            MsgBox("The payees' name can't be a number", MsgBoxStyle.Exclamation)
        Else
            PrintPreviewDialog1 = New PrintPreviewDialog
            '' CheckPreviousPayment(txtStaffID.Text, currentMonth1, currentYear1)
            Try
                GetUnpaidMonthsForMember()
            Catch ex As Exception

            End Try

            Try
                debtorsList()
            Catch ex As Exception

            End Try

            Try
                debtorsCount()
            Catch ex As Exception

            End Try

        End If

        Cursor = Cursors.Default
    End Sub

    Private Sub txtMonthOfPayment1_ValueChanged(sender As Object, e As EventArgs) Handles txtMonthOfPayment1.ValueChanged
        txtMonthOfPayment.Text = txtMonthOfPayment1.Value
    End Sub

    Private Sub txtMonthOfPayment1_KeyUp(sender As Object, e As KeyEventArgs) Handles txtMonthOfPayment1.KeyUp
        txtMonthOfPayment.Text = txtMonthOfPayment1.Value
    End Sub
    Private Sub RefreshDepositSlipInfo()
        ' txtDepositor.Text = ""
        'txtDepositorStaffID.Text = ""
        txtDepositedAmount.Text = ""
        txtReferenceNO.Text = ""
        txtBank.Text = ""
        txtTeller.Text = ""
    End Sub
    Private Sub InsertIntoDepositsTbl()
        Dim datee As New DateTimePicker
        '  Dim DateeTime = datee.Value

        Dim changeTheDateFormat As Date = datee.Value.Date
        Dim DateeTime As String = changeTheDateFormat.ToString("yyyy-MM-dd")

        Try
            Con.Open()
            Dim query = "insert into DepositsTbl values('" & txtDepositedAmount.Text & "','" & txtReferenceNO.Text.ToUpper & "','" & txtBank.Text & "','" & txtTeller.Text.ToUpper & "','" & DateeTime & "','" & Uname.ToUpper & "','" & UStaffID.ToUpper & "','" & txtTrasactionType.Text & "','" & txtWithdrawalPurpose.Text & "')"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            MsgBox("Done", MsgBoxStyle.Information)
            RefreshDepositSlipInfo()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        PopulateDepositSlips()
    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles addDepositBtn.Click
        '  MsgBox(txtAmount.Text + "    " + txtAmount.Text.Length)
        SumOfDepositsAndWithdrawals()
        Dim checkEnoughDeposits As Double = totalDeposits - totalWithdrawal

        If (txtTrasactionType.Text = "Deposit") Then
            If (txtBank.Text = "") Then
                MsgBox("Select the 'Bank'", MsgBoxStyle.Exclamation)
                txtBank.Focus()
            ElseIf (txtTrasactionType.Text = "") Then
                MsgBox("Select 'Transaction Type'", MsgBoxStyle.Exclamation)
                txtTrasactionType.Focus()
            ElseIf (txtDepositedAmount.Text = "") Then
                MsgBox("Enter the 'Amount' Deposited", MsgBoxStyle.Exclamation)
                txtDepositedAmount.Focus()
            ElseIf (IsNumeric(txtDepositedAmount.Text) = False) Then
                MsgBox("Invalid 'Amount'", MsgBoxStyle.Exclamation)
                txtDepositedAmount.Focus()
            ElseIf (txtReferenceNO.Text = "") Then
                MsgBox("Enter the 'Ref NO' on the 'Deposit Slip'", MsgBoxStyle.Exclamation)
                txtReferenceNO.Focus()
            ElseIf (txtTeller.Text = "") Then
                MsgBox("Enter the 'Teller's' name on the 'Deposit Slip'", MsgBoxStyle.Exclamation)
                txtTeller.Focus()
            ElseIf (IsNumeric(txtTeller.Text) = True) Then
                MsgBox("The ' Teller's ' name cannot be a number ", MsgBoxStyle.Exclamation)
                txtTeller.Focus()

            Else
                txtWithdrawalPurpose.Text = ""
                InsertIntoDepositsTbl()
            End If

        ElseIf (txtTrasactionType.Text = "Withdrawal") Then
            If (txtBank.Text = "") Then
                MsgBox("Select the 'Bank'", MsgBoxStyle.Exclamation)
                txtBank.Focus()
            ElseIf (txtTrasactionType.Text = "") Then
                MsgBox("Select 'Transaction Type'", MsgBoxStyle.Exclamation)
                txtTrasactionType.Focus()
            ElseIf (txtDepositedAmount.Text = "") Then
                MsgBox("Enter the 'Withdrawal Amount'", MsgBoxStyle.Exclamation)
                txtDepositedAmount.Focus()
            ElseIf (IsNumeric(txtDepositedAmount.Text) = False) Then
                MsgBox("Invalid 'Amount'", MsgBoxStyle.Exclamation)
                txtDepositedAmount.Focus()
            ElseIf (txtWithdrawalPurpose.Text = "") Then
                MsgBox("Select/Enter the purpose for the 'Withdrawal'", MsgBoxStyle.Exclamation)
                txtWithdrawalPurpose.Focus()
            ElseIf (txtTrasactionType.Text = "Withdrawal" AndAlso Convert.ToDouble(txtDepositedAmount.Text) > checkEnoughDeposits) Then
                MsgBox("The 'Withdrawal' amount exceeds the 'Deposited' amount", MsgBoxStyle.Exclamation)
            Else
                InsertIntoDepositsTbl()
            End If
            '
            '
        End If

    End Sub

    Private Sub txtBank_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBank.KeyUp
        'txtBank.Text = ""
    End Sub
    'All report Sub
    Sub LoadContributionStatement()
        Dim rptDS As ReportDataSource
        Me.contributionReportViewer.RefreshReport()
        Try

            With contributionReportViewer.LocalReport
                .ReportPath = Application.StartupPath & "\Reports\ContributionStatement.rdlc"
                .DataSources.Clear()
            End With
            Dim dss As New DataSet1
            Dim da As New SqlDataAdapter

            Con.Open()
            Dim Queryy = "select Member_ID, Surname, Other_Names, Phone, Amount, Month_Of_Payment, Date, Payees_Name from ContributionsTbl where Member_ID ='" & txtMemID.Text & "' and Month_Of_Payment between @StartDate and @EndDate"
            da.SelectCommand = New SqlCommand(Queryy, Con)
            da.SelectCommand.Parameters.AddWithValue("@StartDate", fromDateTimePicker.Value)
            da.SelectCommand.Parameters.AddWithValue("@EndDate", toDateTimePicker2.Value)
            da.Fill(dss.Tables("ContributionsTbl"))
            Con.Close()

            rptDS = New ReportDataSource("DataSet1", dss.Tables("ContributionsTbl"))
            contributionReportViewer.LocalReport.DataSources.Add(rptDS)
            contributionReportViewer.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            contributionReportViewer.ZoomMode = ZoomMode.Percent
            contributionReportViewer.ZoomPercent = 100
        Catch ex As SqlException
            Con.Close()
            MsgBox(ex.Message, vbCritical)
        End Try
    End Sub

    'All report Sub
    Sub LoadContributionStatementPhone()
        Dim rptDS As ReportDataSource
        Me.contributionReportViewer.RefreshReport()
        Try

            With contributionReportViewer.LocalReport
                .ReportPath = Application.StartupPath & "\Reports\ContributionStatement.rdlc"
                .DataSources.Clear()
            End With
            Dim dss As New DataSet1
            Dim da As New SqlDataAdapter

            Con.Open()
            Dim Queryy = "select Member_ID, Surname, Other_Names, Phone, Amount, Month_Of_Payment, Date, Payees_Name from ContributionsTbl where Member_ID ='" & memberUserStaffID & "' and Month_Of_Payment between @StartDate and @EndDate"
            da.SelectCommand = New SqlCommand(Queryy, Con)
            da.SelectCommand.Parameters.AddWithValue("@StartDate", fromDateTimePicker.Value)
            da.SelectCommand.Parameters.AddWithValue("@EndDate", toDateTimePicker2.Value)
            da.Fill(dss.Tables("ContributionsTbl"))
            Con.Close()
            rptDS = New ReportDataSource("DataSet1", dss.Tables("ContributionsTbl"))
            contributionReportViewer.LocalReport.DataSources.Add(rptDS)
            contributionReportViewer.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            contributionReportViewer.ZoomMode = ZoomMode.Percent
            contributionReportViewer.ZoomPercent = 100
        Catch ex As SqlException
            Con.Close()
            MsgBox(ex.Message, vbCritical)
        End Try
    End Sub

    '' Load all contributions report
    Sub LoadAllContributionStatement()
        Dim rptDS As ReportDataSource
        Me.contributionReportViewer.RefreshReport()
        Try

            With contributionReportViewer.LocalReport
                .ReportPath = Application.StartupPath & "\Reports\AllContributionsReport1.rdlc"
                .DataSources.Clear()
            End With
            Dim dss As New DataSet1
            Dim da As New SqlDataAdapter

            Con.Open()
            Dim Queryy = "select Id, Member_ID, Surname, Other_Names, Phone, Amount, Month_Of_Payment, Date, Operator, Operator_ID, Payees_Name from ContributionsTbl where Month_Of_Payment between @StartDate and @EndDate"
            da.SelectCommand = New SqlCommand(Queryy, Con)
            da.SelectCommand.Parameters.AddWithValue("@StartDate", fromDateTimePicker.Value)
            da.SelectCommand.Parameters.AddWithValue("@EndDate", toDateTimePicker2.Value)
            da.Fill(dss.Tables("ContributionsTbl"))
            Con.Close()

            rptDS = New ReportDataSource("ContributionsDataSet2", dss.Tables("ContributionsTbl"))
            contributionReportViewer.LocalReport.DataSources.Add(rptDS)
            contributionReportViewer.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            contributionReportViewer.ZoomMode = ZoomMode.Percent
            contributionReportViewer.ZoomPercent = 100
        Catch ex As SqlException
            Con.Close()
            MsgBox(ex.Message, vbCritical)
        End Try
    End Sub



    'All report Sub
    Sub LoadDepositAndWithdrawalStatement()
        Dim rptDS As ReportDataSource
        Me.contributionReportViewer.RefreshReport()
        Try

            With contributionReportViewer.LocalReport
                .ReportPath = Application.StartupPath & "\Reports\DepositAndWidrawlReportNw.rdlc"
                .DataSources.Clear()
            End With
            Dim dss As New DepositAndWithdrawalDataSet
            Dim da As New SqlDataAdapter

            Con.Open()
            Dim Queryy = "select Id,Transaction_Type,Amount,Ref_No,Bank,Teller,Date,Purpose from DepositsTbl where Date between @StartDate and @EndDate"
            da.SelectCommand = New SqlCommand(Queryy, Con)
            da.SelectCommand.Parameters.AddWithValue("@StartDate", fromDateTimePicker.Value)
            da.SelectCommand.Parameters.AddWithValue("@EndDate", toDateTimePicker2.Value)
            da.Fill(dss.Tables("DepositsTbl"))
            Con.Close()
            rptDS = New ReportDataSource("DataSet1", dss.Tables("DepositsTbl"))
            contributionReportViewer.LocalReport.DataSources.Add(rptDS)
            contributionReportViewer.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            contributionReportViewer.ZoomMode = ZoomMode.Percent
            contributionReportViewer.ZoomPercent = 100
        Catch ex As SqlException
            Con.Close()
            MsgBox(ex.Message, vbCritical)
        End Try
    End Sub


    Private Sub getMemberId()
        Try
            Con.Open()
            Dim querry = "Select * from MembersTbl where Phone = '" & txtMemID.Text & "'"
            cmd = New SqlCommand(querry, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            memberUserStaffID = myReader("Staff_ID")
        Catch ex As Exception
            MsgBox("Member not found. " + ex.Message, MsgBoxStyle.Exclamation)
        Finally
            Con.Close()
        End Try
    End Sub

    ''Check if MemberId is in the members' Table
    Dim memberExistence As Integer
    Private Sub checkMemberExistence()
        Try

            Cursor = Cursors.WaitCursor
                Con.Open()
            Dim query3 = "select * from MembersTbl where Staff_ID='" & txtMemID.Text & "'"
            cmd = New SqlCommand(query3, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
            memberExistence = ds.Tables(0).Rows.Count
            ' If (memberExistence = 0) Then
            'MsgBox("Member not found", MsgBoxStyle.Exclamation, MsgBoxResult.Ok)
            'End If

        Catch ex As SqlException
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()

        End Try
    End Sub

    Private Sub IconButton1_Click_1(sender As Object, e As EventArgs) Handles btnQueryContributionStatement.Click
        If (txtStatementType.Text = "") Then
            MsgBox("Select the 'Statement Type'", MsgBoxStyle.Exclamation)
            txtStatementType.Focus()
        ElseIf (txtStatementType.Text = "Member Contributions") Then
            If (txtMemID.Text = "") Then
                MsgBox("Enter the member's 'Staff-ID/Phone'", MsgBoxStyle.Exclamation)
                txtMemID.Focus()
            ElseIf (txtSearchType.Text = "") Then
                MsgBox("Select 'ID' Type", MsgBoxStyle.Exclamation)
                txtSearchType.Focus()
            ElseIf (txtSearchType.Text = "Phone") Then
                Cursor = Cursors.WaitCursor
                getMemberId()
                LoadContributionStatementPhone()
            ElseIf (txtSearchType.Text = "Staff ID")
                checkMemberExistence()
                If (memberExistence = 0) Then
                    MsgBox("Member not found", MsgBoxStyle.Exclamation)
                    contributionReportViewer.Clear()

                Else
                    Cursor = Cursors.WaitCursor
                    LoadContributionStatement()
                End If

            End If
            '
            '
        ElseIf (txtStatementType.Text = "Deposits/Withdrawals") Then
            Cursor = Cursors.WaitCursor
            LoadDepositAndWithdrawalStatement()

        ElseIf (txtStatementType.Text = "Contributions") Then
            Cursor = Cursors.WaitCursor
            LoadAllContributionStatement()
        End If


        Cursor = Cursors.Default
        '   LoadContributionStatement()
    End Sub

    Private Sub TabPage4_Click(sender As Object, e As EventArgs) Handles TabPage4.Click
        AcceptButton = btnQueryContributionStatement
    End Sub

    Private Sub TabPage3_Click(sender As Object, e As EventArgs) Handles TabPage3.Click
        AcceptButton = addDepositBtn
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        Try

            Dim theDay = New DateTimePicker
            Dim seeTheDate2 = theDay.Value
            Dim f5 As New Font("Calibri", 8, FontStyle.Regular)
            Dim f6 As New Font("Calibri", 7, FontStyle.Regular)
            Dim f7 As New Font("Calibri", 10, FontStyle.Regular)
            Dim f8 As New Font("Calibri", 11, FontStyle.Regular)
            Dim f10 As New Font("Calibri", 11, FontStyle.Regular)
            Dim f6b As New Font("Calibri", 6, FontStyle.Bold)
            Dim f14 As New Font("Calibri", 15, FontStyle.Bold)
            Dim f16 As New Font("Calibri", 6, FontStyle.Regular)

            Dim leftmargin As Integer = PrintDocument1.DefaultPageSettings.Margins.Left
            Dim centermargin As Integer = PrintDocument1.DefaultPageSettings.PaperSize.Width / 2
            Dim rightmargin As Integer = PrintDocument1.DefaultPageSettings.PaperSize.Width

            'font alignment
            Dim right As New StringFormat
            Dim center As New StringFormat

            right.Alignment = StringAlignment.Far
            center.Alignment = StringAlignment.Center

            Dim line As String
            line = "***************************************************"

            Dim line2 As String
            line2 = "------------------------------------------------------------------------------------------------"



            e.Graphics.DrawString("WELFARE UNIT", f8, Brushes.Black, centermargin, 3, center)
            e.Graphics.DrawString("SDA Hospital, Sunyani", f7, Brushes.Black, centermargin, 15, center)
            e.Graphics.DrawString("Tell: 024 834 8704", f5, Brushes.Black, centermargin, 27, center)

            e.Graphics.DrawString(line2, f16, Brushes.Black, 0, 33)

            e.Graphics.DrawString("Operator :" + theUsername, f6, Brushes.Black, 0, 37)
            e.Graphics.DrawString("Staff ID : " + UStaffID, f6, Brushes.Black, rightmargin, 37, right)



            e.Graphics.DrawString(seeTheDate2, f6, Brushes.Black, centermargin, 45, center)
            e.Graphics.DrawString("=====Your Receipt=====", f7, Brushes.Black, centermargin, 54, center)

            Dim height As Integer 'DGV Position
            '' Dim i3 As Long
            height += 50
            e.Graphics.DrawString(line, f6, Brushes.Black, 0, 20 + height)

            e.Graphics.DrawString("Member Name", f6, Brushes.Black, 0, 25 + height)
            e.Graphics.DrawString(": ", f6, Brushes.Black, 65, 25 + height)
            e.Graphics.DrawString(txtSurname.Text + " " + txtMemberOtherName.Text, f6, Brushes.Black, 70, 25 + height)


            e.Graphics.DrawString("Member Staff ID", f6, Brushes.Black, 0, 34 + height)
            e.Graphics.DrawString(":", f6, Brushes.Black, 70, 34 + height)
            e.Graphics.DrawString(txtStaffID.Text, f6, Brushes.Black, 75, 34 + height)

            e.Graphics.DrawString("Amount(Ghc)", f6, Brushes.Black, 0, 44 + height)
            e.Graphics.DrawString(":", f6, Brushes.Black, 55, 44 + height)
            e.Graphics.DrawString(txtAmount.Text, f6, Brushes.Black, 60, 44 + height)

            e.Graphics.DrawString("Contribution Month", f6, Brushes.Black, 0, 54 + height)
            e.Graphics.DrawString(":", f6, Brushes.Black, 80, 54 + height)
            e.Graphics.DrawString(txtMonthOfPayment1.Value, f6, Brushes.Black, 85, 54 + height)

            e.Graphics.DrawString("Paid By", f6, Brushes.Black, 0, 64 + height)
            e.Graphics.DrawString(":", f6, Brushes.Black, 30, 64 + height)
            e.Graphics.DrawString(txtPaidIBy.Text, f6, Brushes.Black, 35, 64 + height)

            e.Graphics.DrawString(line, f6, Brushes.Black, 0, 73 + height)

            e.Graphics.DrawString("App Design By:(TEAM-ODM) ", f6, Brushes.Black, centermargin, 78 + height, center)
            e.Graphics.DrawString("024-708-6663/054-855-8531", f6, Brushes.Black, centermargin, 90 + height, center)

            e.Graphics.DrawString("===Thank You===", f7, Brushes.Black, centermargin, 100 + height, center)









        Catch ex As Exception

        End Try

    End Sub

    Private Sub txtTrasactionType_SelectedValueChanged(sender As Object, e As EventArgs) Handles txtTrasactionType.SelectedValueChanged
        If (txtTrasactionType.Text = "Deposit") Then
            txtReferenceNO.ReadOnly = False
            txtTeller.ReadOnly = False
            txtWithdrawalPurpose.Text = ""

        ElseIf (txtTrasactionType.Text = "Withdrawal") Then
            txtReferenceNO.ReadOnly = True
            txtTeller.ReadOnly = True
            txtReferenceNO.Text = ""
            txtTeller.Text = ""
        Else
            txtReferenceNO.ReadOnly = True
            txtTeller.ReadOnly = True
            txtReferenceNO.Text = ""
            txtTeller.Text = ""
        End If
    End Sub

    Private Sub txtWithdrawalPurpose_KeyUp(sender As Object, e As KeyEventArgs) Handles txtWithdrawalPurpose.KeyUp
        If (txtTrasactionType.Text <> "Withdrawal") Then
            ' '   MsgBox("You can only specify a purpose for 'Withdrawals' only", MsgBoxStyle.Exclamation)
            txtWithdrawalPurpose.Text = ""
        End If
    End Sub

    Dim theLastMonthOfPayment As DateTime, currentPhoneNo As String
    Private Sub getLastPaymentMonth(maxId)


        Try
            Con.Open()
            'SELECT TOP 1 * FROM ContributionsTbl WHERE Id = @Id ORDER BY Month_Of_Payment DESC
            ' Dim query = "select * from ContributionsTbl where Id ='" & maxId & "'"
            Dim query = "SELECT TOP 1 * FROM ContributionsTbl WHERE Member_ID = '" & maxId & "' ORDER BY Month_Of_Payment DESC"
            cmd = New SqlCommand(query, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            theLastMonthOfPayment = myReader("Month_Of_Payment")
            currentPhoneNo = myReader("Phone")


            '     memberUserPicture = myReader("Picture")
        Catch ex As SqlException
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub sendAlertSMS(memberName, memberStaffID, amountt, lastContributionMonth, recipient, contributionMonth)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). This is a gentle reminder that your monthly contribution for (" & contributionMonth & ") is now due. Your last contribution month is (" & lastContributionMonth & "). Please make your payment at your earliest convenience. Thank You!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()


        Try
            Dim response As String = client.DownloadString(baseURL)
            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)
            ' MsgBox(getTheResponse & getTheResponse2)

            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. Alert not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse2 = "Successfully Sent") Then
                MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                MsgBox("Alert not sent! Check if the number is correct", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            End If

        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                resendAlertSMS(memFirstName, membID, contributAmount, theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString, currentPhoneNo, DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)
            End If
        Finally
            Cursor = Cursors.Default
        End Try

    End Sub

    Private Sub resendAlertSMS(memberName, memberStaffID, amountt, lastContributionMonth, recipient, contributionMonth)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). This is a gentle reminder that your monthly contribution for (" & contributionMonth & ") is now due. Your last contribution month is (" & lastContributionMonth & "). Please make your payment at your earliest convenience. Thank You!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()


        Try
            Dim response As String = client.DownloadString(baseURL)

            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)

            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. Alert not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse2 = "Successfully Sent") Then
                MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                MsgBox("Alert not sent! Check if the number is correct", MsgBoxStyle.Exclamation)
            End If


        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                sendAlertSMS(memFirstName, membID, contributAmount, theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString, currentPhoneNo, DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)
                '' btnAlertAll.PerformClick()
            End If
        Finally
            Cursor = Cursors.Default
            '' MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Sub sendAlertAllSMS(memberName, memberStaffID, amountt, lastContributionMonth, recipient, contributionMonth)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim getTheMonthCurrent As String = DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString
        '  MsgBox(getTheMonthCurrent + "   " + lastContributionMonth)
        If (lastContributionMonth <> getTheMonthCurrent) Then
            Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). This is a gentle reminder that your monthly contribution for (" & contributionMonth & ") is now due. Your last contribution month is (" & lastContributionMonth & "). Please make your payment at your earliest convenience. Thank You!  [SDA HOSPITAL,SUNYANI]"

            ' Ensure TLS 1.2 is used
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

            Dim client As New WebClient()
            'Dim url As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=0247086663&from=SenderID&sms=YourMessage"


            Try
                Dim response As String = client.DownloadString(baseURL)
                txtResponseMaskedTextBox.Text = response

                Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
                Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)

                If (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                    MsgBox("Check if " & memberName & "(Staff-ID: " & memberStaffID & ") contact is correct. Alert not sent!", MsgBoxStyle.Exclamation)
                    txtResponseMaskedTextBox.Text = ""
                End If

                If (row <= 0) Then
                    ' txtResponseMaskedTextBox.Text = response

                    If (getTheResponse = "Insufficient balance") Then
                        MsgBox("Insufficient sms balance. Alert not sent!", MsgBoxStyle.Exclamation)
                        txtResponseMaskedTextBox.Text = ""
                    ElseIf (getTheResponse2 = "Successfully Sent") Then
                        MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                        txtResponseMaskedTextBox.Text = ""
                    Else
                        ' MsgBox("Alert not sent! Check if the number is correct", MsgBoxStyle.Exclamation)
                    End If
                    '' MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                End If
            Catch ex As Exception
                Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
                If (smsDialog = DialogResult.Retry) Then
                    resendAlertAllSMS(memFirstName, membID, contributAmount, theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString, currentPhoneNo, DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)
                End If
            Finally
                Cursor = Cursors.Default
            End Try
        End If


    End Sub
    'Dim compareLastConToCurrentMonth As String
    Private Sub resendAlertAllSMS(memberName, memberStaffID, amountt, lastContributionMonth, recipient, contributionMonth)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim getTheMonthCurrent As String = DateTime.Now.ToString("MMMM") + DateTime.Now.Year.ToString
        If (lastContributionMonth <> getTheMonthCurrent) Then

            Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName & "(Staff ID: " & memberStaffID & "). This is a gentle reminder that your monthly contribution for (" & contributionMonth & ") is now due. Your last contribution month is (" & lastContributionMonth & "). Please make your payment at your earliest convenience. Thank You!  [SDA HOSPITAL,SUNYANI]"

            ' Ensure TLS 1.2 is used
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

            Dim client As New WebClient()
            'Dim url As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=0247086663&from=SenderID&sms=YourMessage"


            Try
                Dim response As String = client.DownloadString(baseURL)
                txtResponseMaskedTextBox.Text = response

                Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
                Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)

                If (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                    MsgBox("Check if " & memberName & "(Staff-ID: " & memberStaffID & ") contact is correct. Alert not sent!", MsgBoxStyle.Exclamation)
                End If

                If (row <= 0) Then
                    'txtResponseMaskedTextBox.Text = response

                    If (getTheResponse = "Insufficient balance") Then
                        MsgBox("Insufficient sms balance. Alert not sent!", MsgBoxStyle.Exclamation)
                        txtResponseMaskedTextBox.Text = ""
                    ElseIf (getTheResponse2 = "Successfully Sent") Then
                        MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                        txtResponseMaskedTextBox.Text = ""
                    Else
                        ' MsgBox("Alert not sent! Check if the number is correct", MsgBoxStyle.Exclamation)
                    End If
                    ' MsgBox("Alert sent successfully", MsgBoxStyle.Information)
                End If

            Catch ex As Exception
                Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
                If (smsDialog = DialogResult.Retry) Then
                    sendAlertAllSMS(memFirstName, membID, contributAmount, theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString, currentPhoneNo, DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)
                    '' btnAlertAll.PerformClick()
                End If
            Finally
                Cursor = Cursors.Default
                '' MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
            End Try

        End If


    End Sub

    Dim defaultID As String, membID As String, memFirstName As String, membOtherName As String, membNumber As String, contributAmount As String

    Private Sub PrintPreviewDialog1_Load(sender As Object, e As EventArgs) Handles PrintPreviewDialog1.Load

    End Sub

    Private Sub txtStatementType_SelectedValueChanged(sender As Object, e As EventArgs) Handles txtStatementType.SelectedValueChanged
        If (txtStatementType.Text = "Deposits/Withdrawals") Then
            txtMemID.Text = ""
            txtMemID.ReadOnly = True
        ElseIf (txtStatementType.Text = "") Then
            txtMemID.Text = ""
            txtMemID.ReadOnly = True
        ElseIf (txtStatementType.Text = "Contributions") Then
            txtMemID.Text = ""
            txtMemID.ReadOnly = True
        Else
            txtMemID.ReadOnly = False
        End If
    End Sub

    Dim row As Integer
    Private Sub btnAlertAll_Click(sender As Object, e As EventArgs) Handles btnAlertAll.Click
        ' MsgBox(debtorsDataGridView.RowCount)
        Dim alertSmsDialog As DialogResult = MessageBox.Show("Alert all", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        Try
            If (alertSmsDialog = DialogResult.Yes) Then
                For row = 0 To debtorsDataGridView.RowCount - 1
                    ' Rows(row).Cells(0).Value.ToString
                    defaultID = debtorsDataGridView.Rows(row).Cells(1).Value.ToString
                    ' MsgBox(defaultID)
                    membID = debtorsDataGridView.Rows(row).Cells(2).Value.ToString
                    memFirstName = debtorsDataGridView.Rows(row).Cells(3).Value.ToString
                    membOtherName = debtorsDataGridView.Rows(row).Cells(4).Value.ToString
                    membNumber = debtorsDataGridView.Rows(row).Cells(5).Value.ToString
                    contributAmount = debtorsDataGridView.Rows(row).Cells(6).Value.ToString

                    getLastPaymentMonth(membID)

                    '' MsgBox(defaultID + ", " + membID + ", " + memFirstName + ", " + membOtherName + ", " + membNumber + ", " + theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString + ", " + DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)
                    sendAlertAllSMS(memFirstName, membID, contributAmount, theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString, currentPhoneNo, DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)


                Next
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub debtorsDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles debtorsDataGridView.CellContentClick

        Try
            If (e.RowIndex >= 0 AndAlso e.ColumnIndex = debtorsDataGridView.Columns("sendAlert").Index) Then
                Dim alertSmsDialog As DialogResult = MessageBox.Show("Send alert", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If (alertSmsDialog = DialogResult.Yes) Then
                    ' Dim rowID As Integer = Convert.ToInt32(membersDataGridView.Rows(e.RowIndex).Cells("Id").Value)
                    Dim row As DataGridViewRow = debtorsDataGridView.Rows(e.RowIndex)
                    defaultID = row.Cells(1).Value.ToString
                    ' MsgBox(defaultID)
                    membID = row.Cells(2).Value.ToString
                    memFirstName = row.Cells(3).Value.ToString
                    membOtherName = row.Cells(4).Value.ToString
                    membNumber = row.Cells(5).Value.ToString
                    contributAmount = row.Cells(6).Value.ToString

                    getLastPaymentMonth(membID)

                    ' MsgBox(defaultID + ", " + membID + ", " + memFirstName + ", " + membOtherName + ", " + membNumber + ", " + theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString + ", " + DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)
                    sendAlertSMS(memFirstName, membID, contributAmount, theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString, currentPhoneNo, DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)

                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtWithdrawalPurpose_SelectedValueChanged(sender As Object, e As EventArgs) Handles txtWithdrawalPurpose.SelectedValueChanged
        If (txtTrasactionType.Text <> "Withdrawal") Then
            MsgBox("You can only specify a purpose for 'Withdrawals' only", MsgBoxStyle.Exclamation)
            txtWithdrawalPurpose.Text = ""
        End If
    End Sub

    Private Sub PrintDocument1_BeginPrint(sender As Object, e As PrintEventArgs) Handles PrintDocument1.BeginPrint
        Try
            Dim pagesetup As New PageSettings
            ' pagesetup.PaperSize = New PaperSize("Custom", 120, 500) 'fixed size
            pagesetup.PaperSize = New PaperSize("Custom", 190, 180)
            PrintDocument1.DefaultPageSettings = pagesetup
        Catch ex As Exception

        End Try
    End Sub


    Private Sub debtorsList()
        ' Get the current month and year
        Dim currentMonth As Integer = DateTime.Now.Month
        Dim currentYear As Integer = DateTime.Now.Year

        Try
            Con.Open()
            ' Query to find members who have not paid for the current month and year
            Dim query As String = "
        SELECT DISTINCT MAX(c1.Id) AS Id,c1.Member_ID, c1.Surname, c1.Other_Names, c1.Phone, c1.Amount
        FROM ContributionsTbl c1
        WHERE NOT EXISTS (
            SELECT 1
            FROM ContributionsTbl c2
            WHERE c2.Member_ID = c1.Member_ID
            AND MONTH(c2.Month_Of_Payment) = @Month
            AND YEAR(c2.Month_Of_Payment) = @Year
        )
        GROUP BY c1.Member_ID, c1.Surname, c1.Other_Names, c1.Phone, c1.Amount"

            ' Create a new SqlDataAdapter with a parameterized query
            Using adaptor As New SqlDataAdapter(query, Con)
                ' Add parameters to the query
                adaptor.SelectCommand.Parameters.AddWithValue("@Month", currentMonth)
                adaptor.SelectCommand.Parameters.AddWithValue("@Year", currentYear)

                ' Fill the DataSet
                Dim ds As New DataSet()
                adaptor.Fill(ds)
                debtorsDataGridView.DataSource = ds.Tables(0)
            End Using
        Catch ex As Exception
            ' Handle any errors that may have occurred
            MsgBox("An error occurred: " & ex.Message)
        Finally
            ' Ensure the connection is closed
            Con.Close()
        End Try

        ' Create and add the Send Alert button column
        Dim sendSmsButtonColumn As New DataGridViewButtonColumn()
        sendSmsButtonColumn.HeaderText = ""
        sendSmsButtonColumn.Text = "Send Alert"
        sendSmsButtonColumn.Name = "sendAlert"
        sendSmsButtonColumn.UseColumnTextForButtonValue = True

        ' Add the button column to the DataGridView if it doesn't already exist
        If debtorsDataGridView.Columns("sendAlert") Is Nothing Then
            debtorsDataGridView.Columns.Add(sendSmsButtonColumn)
        End If
    End Sub




End Class