﻿Imports System.Data.SqlClient
Imports System.Drawing.Drawing2D
Imports System.Runtime.InteropServices

Public Class SecLoginForm
    Private borderRadius As Integer = 6
    Private borderSize As Integer = 4
    Private borderColor As Color = Color.SeaGreen

    'Constractor
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Private Function GetRoundedPath(rect As Rectangle, radius As Single) As GraphicsPath
        Dim path As GraphicsPath = New GraphicsPath()
        Dim curveSize As Single = radius * 2.0F
        path.StartFigure()
        path.AddArc(rect.X, rect.Y, curveSize, curveSize, 180, 90)
        path.AddArc(rect.Right - curveSize, rect.Y, curveSize, curveSize, 270, 90)
        path.AddArc(rect.Right - curveSize, rect.Bottom - curveSize, curveSize, curveSize, 0, 90)
        path.AddArc(rect.X, rect.Bottom - curveSize, curveSize, curveSize, 90, 90)
        path.CloseFigure()
        Return path
    End Function

    Private Sub FormRegionAndBorder(form As Form, radius As Single, graph As Graphics, borderColor As Color, borderSize As Single)
        If Me.WindowState <> FormWindowState.Minimized Then
            Using roundPath As GraphicsPath = GetRoundedPath(form.ClientRectangle, radius)
                Using penBorder As Pen = New Pen(borderColor, borderSize)
                    Using transform As Matrix = New Matrix()

                        graph.SmoothingMode = SmoothingMode.AntiAlias
                        form.Region = New Region(roundPath)
                        If borderSize >= 1 Then
                            Dim rect As Rectangle = form.ClientRectangle
                            Dim scaleX As Single = 1.0F - ((borderSize + 1) / rect.Width)
                            Dim scaleY As Single = 1.0F - ((borderSize + 1) / rect.Height)
                            transform.Scale(scaleX, scaleY)
                            transform.Translate(borderSize / 1.6F, borderSize / 1.6F)
                            graph.Transform = transform
                            graph.DrawPath(penBorder, roundPath)
                        End If
                    End Using
                End Using
            End Using

        End If
    End Sub




    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Application.ExitThread()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'Dim EncryptUserName = Encrypt(txtUsername.Text)
        Dim EncryptUserPassword = Encrypt(txtPassword.Text)

        Try
            If txtUsername.Text = "" Or txtPassword.Text = "" Then
                MsgBox("Enter UserName And Password")
            Else
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query3 = "select * from UsersTbl where Username='" & txtUsername.Text & "'and Password = '" & EncryptUserPassword & "' and User_Type = '" & txtSecretary & "'"
                cmd = New SqlCommand(query3, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                UserLoginSwitch = ds.Tables(0).Rows.Count
                If (UserLoginSwitch = 0) Then
                    MsgBox("Wrong UserName Or Password")
                Else

                    theUsername = txtUsername.Text
                    'Dim nwHomeUser = New UsersPage
                    'Me.Hide()
                    'nwHomeUser.Show()
                End If
            End If

        Catch ex As SqlException
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()

        End Try

        '' Get the total members 
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from MembersTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            totalMembers = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Dim checknul1 As Integer = 0, checknull2 As Integer = 0
        '' Get the total contribtions check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknul1 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Contributions
        If (checknul1 <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) AS YearlyContributionSum FROM ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalContributions = 0
                Else
                    totalContributions = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        End If

        '' Get the total claims amount check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknull2 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        If (checknull2 <> 0) Then
            'Total Amount Claimed
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount_Given) AS YearlyContributionSum FROM ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                '   Dim toTotal = cmd.ExecuteScalar
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalMoneyGivenOut = 0
                Else
                    totalMoneyGivenOut = toTotal
                End If
            Catch ex As Exception
                '   MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
        End If



        '' Get the total claims 
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            totalClaims = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try



        Try
            Dim currentDDate As New DateTimePicker
            Dim txtLogDate = currentDDate.Value
            If (theUsername = "" Or txtPassword.Text = "" Or UserLoginSwitch = 0) Then

            Else
                Con.Open()
                Dim query = "select * from UsersTbl where Username='" & txtUsername.Text & "'and Password = '" & EncryptUserPassword & "'"
                cmd = New SqlCommand(query, Con)
                myReader = cmd.ExecuteReader
                myReader.Read()
                theUsRealID = myReader("Id")
                Uname = myReader("Username")
                '  Uname2 = myReader("Username")
                Ugmail = myReader("Gmail")
                UStaffID = myReader("Staff_ID")
                Upassword = myReader("Password")
                Uphone = myReader("Phone")
                'Upassword = myReader("Password")
                'Uphone = myReader("Phone")
            End If
        Catch ex As SqlException
            MsgBox(ex.Message)

        Finally
            Con.Close()
        End Try

        Try
            If (Uname = "" Or Ugmail = "" Or UStaffID = "" Or Uphone = "") Then

            Else

                Dim currentDataNTim As New DateTimePicker
                Dim theTimeNDate = currentDataNTim.Value
                Con.Open()
                Dim query5 As String
                query5 = "insert into ViewlogsTbl values('" & UStaffID & "','" & Uname & "','" & Uphone & "','" & Ugmail & "','" & theTimeNDate & "','" & lognullDate & "')"
                cmd = New SqlCommand(query5, Con)
                cmd.ExecuteNonQuery()

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
        Try
            If ((UserLoginSwitch = 0) = False) Then
                ''''''
                UserLoginSwitch = 0
                Me.Hide()
                SecretryForm.Show()

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Me.Hide()
        SecForgotPassword.Show()
    End Sub

    Private Sub showPassword_CheckedChanged(sender As Object, e As EventArgs) Handles showPassword.CheckedChanged
        If (showPassword.Checked = True) Then
            txtPassword.PasswordChar = ""
        Else
            txtPassword.PasswordChar = "*"
        End If
    End Sub

    Private Sub SecLoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AcceptButton = btnLogin
    End Sub

    Private Sub SecLoginForm_Paint(sender As Object, e As PaintEventArgs) Handles Me.Paint
        FormRegionAndBorder(Me, borderRadius, e.Graphics, borderColor, borderSize)
    End Sub

    'Drag Form

    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub
    Private Sub PanelTitleBar_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseDown
        ReleaseCapture()
        SendMessage(Me.Handle, &H112, &HF012, 0)
        '   btnMaximize.Visible = True
        '  btnNormal.Visible = False
    End Sub
    Protected Overrides ReadOnly Property CreateParams As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            cp.Style = cp.Style Or &H20000
            Return cp
        End Get
    End Property
End Class