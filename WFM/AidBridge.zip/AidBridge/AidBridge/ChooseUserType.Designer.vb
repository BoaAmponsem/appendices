﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ChooseUserType
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.dashboardBtnContributions = New FontAwesome.Sharp.IconButton()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label4.Location = New System.Drawing.Point(267, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(14, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "X"
        '
        'Panel6
        '
        Me.Panel6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel6.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.Panel6.Location = New System.Drawing.Point(65, 58)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(10, 39)
        Me.Panel6.TabIndex = 20
        '
        'Panel7
        '
        Me.Panel7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel7.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.Panel7.Location = New System.Drawing.Point(216, 58)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(10, 39)
        Me.Panel7.TabIndex = 18
        '
        'Panel8
        '
        Me.Panel8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel8.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.Panel8.Location = New System.Drawing.Point(65, 48)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(36, 10)
        Me.Panel8.TabIndex = 19
        '
        'Panel5
        '
        Me.Panel5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel5.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.Panel5.Location = New System.Drawing.Point(191, 48)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(35, 10)
        Me.Panel5.TabIndex = 17
        '
        'Panel4
        '
        Me.Panel4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel4.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.Panel4.Controls.Add(Me.IconButton2)
        Me.Panel4.Location = New System.Drawing.Point(173, 97)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(91, 67)
        Me.Panel4.TabIndex = 15
        '
        'IconButton2
        '
        Me.IconButton2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton2.BackColor = System.Drawing.Color.White
        Me.IconButton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton2.ForeColor = System.Drawing.Color.SeaGreen
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.PenSquare
        Me.IconButton2.IconColor = System.Drawing.Color.SeaGreen
        Me.IconButton2.IconSize = 30
        Me.IconButton2.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.IconButton2.Location = New System.Drawing.Point(7, 5)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(77, 55)
        Me.IconButton2.TabIndex = 0
        Me.IconButton2.Text = "SECRETARY"
        Me.IconButton2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel2.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.Panel2.Controls.Add(Me.IconButton1)
        Me.Panel2.Location = New System.Drawing.Point(27, 97)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(91, 67)
        Me.Panel2.TabIndex = 16
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton1.BackColor = System.Drawing.Color.White
        Me.IconButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton1.ForeColor = System.Drawing.Color.SeaGreen
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.MoneyBillWave
        Me.IconButton1.IconColor = System.Drawing.Color.SeaGreen
        Me.IconButton1.IconSize = 30
        Me.IconButton1.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.IconButton1.Location = New System.Drawing.Point(7, 5)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(77, 55)
        Me.IconButton1.TabIndex = 0
        Me.IconButton1.Text = "TREASURER"
        Me.IconButton1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel3.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.Panel3.Controls.Add(Me.dashboardBtnContributions)
        Me.Panel3.Location = New System.Drawing.Point(100, 16)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(91, 67)
        Me.Panel3.TabIndex = 14
        '
        'dashboardBtnContributions
        '
        Me.dashboardBtnContributions.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dashboardBtnContributions.BackColor = System.Drawing.Color.White
        Me.dashboardBtnContributions.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.dashboardBtnContributions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.dashboardBtnContributions.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.dashboardBtnContributions.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dashboardBtnContributions.ForeColor = System.Drawing.Color.SeaGreen
        Me.dashboardBtnContributions.IconChar = FontAwesome.Sharp.IconChar.UserCog
        Me.dashboardBtnContributions.IconColor = System.Drawing.Color.SeaGreen
        Me.dashboardBtnContributions.IconSize = 30
        Me.dashboardBtnContributions.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.dashboardBtnContributions.Location = New System.Drawing.Point(7, 5)
        Me.dashboardBtnContributions.Name = "dashboardBtnContributions"
        Me.dashboardBtnContributions.Rotation = 0R
        Me.dashboardBtnContributions.Size = New System.Drawing.Size(77, 55)
        Me.dashboardBtnContributions.TabIndex = 0
        Me.dashboardBtnContributions.Text = "CHAIRMAN"
        Me.dashboardBtnContributions.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.dashboardBtnContributions.UseVisualStyleBackColor = False
        '
        'ChooseUserType
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(296, 180)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel8)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "ChooseUserType"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ChooseUserType"
        Me.Panel4.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label4 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel2 As Panel
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel3 As Panel
    Friend WithEvents dashboardBtnContributions As FontAwesome.Sharp.IconButton
End Class
