﻿Imports System.Data.SqlClient
Imports System.Runtime.InteropServices
Imports FontAwesome.Sharp
Public Class Form1
    'Dim AddMembersInstance As New AddMemberPage1
    Private currentBtn As IconButton
    Private leftBorderBtn As Panel
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        leftBorderBtn = New Panel()
        leftBorderBtn.Size = New Size(7, 42)
        PanelMenu.Controls.Add(leftBorderBtn)

    End Sub

    Private Sub ActivationButton(senderBtn As Object, customColor As Color)

        Try
            If senderBtn IsNot Nothing Then
                DisableButton()
                'Button'
                currentBtn = CType(senderBtn, IconButton)
                currentBtn.BackColor = Color.FromArgb(37, 36, 81)
                currentBtn.ForeColor = customColor
                currentBtn.IconColor = customColor
                currentBtn.TextAlign = ContentAlignment.MiddleCenter
                currentBtn.ImageAlign = ContentAlignment.MiddleRight
                currentBtn.TextImageRelation = TextImageRelation.TextBeforeImage


                'leftBorder'
                leftBorderBtn.BackColor = customColor
                leftBorderBtn.Location = New Point(0, currentBtn.Location.Y)
                leftBorderBtn.Visible = True
                leftBorderBtn.BringToFront()

                adminText.IconChar = currentBtn.IconChar
                adminText.Text = currentBtn.Text

            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub DisableButton()
        Try
            If currentBtn IsNot Nothing Then

                currentBtn.BackColor = Color.SeaGreen
                currentBtn.ForeColor = Color.White
                currentBtn.IconColor = Color.White
                currentBtn.TextAlign = ContentAlignment.MiddleLeft
                currentBtn.ImageAlign = ContentAlignment.MiddleLeft
                currentBtn.TextImageRelation = TextImageRelation.ImageBeforeText

            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub switchPages(ByVal pageSwitch1 As Form)
        Try
            pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try


    End Sub

    Public Function PublicswitchPages(ByVal pageSwitch1 As Form)
        Try
            pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try


    End Function
    Private Sub NoClaimRequests()
        'The number requested Claims
        Try
            '   Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ApprovalTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            theNumberOfApprovals = ds.Tables(0).Rows.Count

            If (Convert.ToInt32(theNumberOfApprovals) = 0) Then
                txtNoApprovals.Visible = False
                ' ClaimsPage.TabPage3.Text = ClaimsPage.TabPage3.Text + " " + theNumberOfApprovals.ToString
            Else
                txtNoApprovals.Visible = True
                txtNoApprovals.Text = theNumberOfApprovals
                ' ClaimsPage.TabPage3.Text = ClaimsPage.TabPage3.Text + " " + theNumberOfApprovals.ToString
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            '  Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub


    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles btnDashboard.Click
        ' theNumberOfApprovals
        Try
            SumAllDeposits()
            SumAllWithdrawal()
        Catch ex As Exception

        End Try
        Try
            adminDashboard.txtYear.Visible = True
            adminDashboard.txtYear2.Visible = True
            AddNewBeneficiary.Hide()
            AddNewChild.Hide()
            ClaimStatus.Hide()
            ShowProfilePage.Hide()
            '' Get the total claims 
            SumOfDepositsAndWithdrawals()
            adminDashboard.txtTotalWithdrawal.Text = "Ghc " + totalWithdrawal.ToString
            adminDashboard.txtAccountBalance.Text = "Ghc " + (totalDeposits - totalWithdrawal).ToString
        Catch ex As Exception

        End Try

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            totalClaims = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try


        'The number requested Claims
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ApprovalTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            theNumberOfApprovals = ds.Tables(0).Rows.Count

            If (Convert.ToInt32(theNumberOfApprovals) = 0) Then
                txtNoApprovals.Visible = False
                ClaimsPage.TabPage3.Text = "Approvals" + " " + theNumberOfApprovals.ToString
            Else
                txtNoApprovals.Visible = True
                txtNoApprovals.Text = theNumberOfApprovals
                ClaimsPage.TabPage3.Text = "Approvals" + " " + theNumberOfApprovals.ToString
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try


        '' Get the total members 
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from MembersTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            totalMembers = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Dim checknul1 As Integer = 0, checknull2 As Integer = 0
        '' Get the total contribtions check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknul1 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Contributions
        If (checknul1 <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) AS YearlyContributionSum FROM ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalContributions = 0
                Else
                    totalContributions = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        End If

        '' Get the total claims amount check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknull2 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        If (checknull2 <> 0) Then
            'Total Amount Claimed
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount_Given) AS YearlyContributionSum FROM ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                '   Dim toTotal = cmd.ExecuteScalar
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalMoneyGivenOut = 0
                Else
                    totalMoneyGivenOut = toTotal
                End If
            Catch ex As Exception
                '   MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
        End If


        DashboardToolStripMenuItem.Checked = True
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False


        Try
            Cursor = Cursors.WaitCursor
            ActivationButton(sender, Color.DarkSeaGreen)
            txtNoApprovals.BackColor = Color.Transparent
            adminText.IconColor = Color.DarkSeaGreen
            Dim nwDashboard = New adminDashboard
            switchPages(nwDashboard)


        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
        End Try

    End Sub

    Private Sub PopulateApprovalAfAction()
        Try
            Con.Open()
            Dim query = "select Id,Member_Name,Member_ID,Amount,Reason,Claimer,Beneficiary_Name,Request_Date,Operator from ApprovalTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ClaimsPage.approvalsDataGridView.DataSource = ds.Tables(0)

            '  End Using
            ' Dim cancelButtonColumn As New DataGridViewButtonColumn()
            'cancelButtonColumn.HeaderText = ""
            'cancelButtonColumn.Text = "Cancel"
            'cancelButtonColumn.Name = "cancelBtn"
            'cancelButtonColumn.UseColumnTextForButtonValue = True

            'Dim approveButtonColumn As New DataGridViewButtonColumn()
            'approveButtonColumn.HeaderText = ""
            'approveButtonColumn.Text = "Approve"
            'approveButtonColumn.Name = "ApproveBtn"
            'approveButtonColumn.UseColumnTextForButtonValue = True

            'ClaimsPage.approvalsDataGridView.Columns.Add(cancelButtonColumn)
            'ClaimsPage.approvalsDataGridView.Columns.Add(approveButtonColumn)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try



    End Sub

    Private Sub PopulateClaims()
        Try
            Con.Open()
            Dim query = "select * from ClaimsTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ClaimsPage.ClaimsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try


    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles btnClaims.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        ClaimStatus.Hide()
        ShowProfilePage.Hide()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = True
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False
        Try
            Cursor = Cursors.WaitCursor
            ActivationButton(sender, Color.DarkSeaGreen)
            adminText.IconColor = Color.DarkSeaGreen
            txtNoApprovals.BackColor = Color.FromArgb(37, 36, 81)
            '  NoClaimRequests()
            PopulateClaims()
            PopulateApprovalAfAction()
            Dim nwClaimsPage = ClaimsPage
            switchPages(nwClaimsPage)


        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
        End Try

    End Sub
    Private Sub GetDuesAmount()
        Try
            Con.Open()
            Dim query = "select * from SetValuesTbl"
            cmd = New SqlCommand(query, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            DuesAmount = myReader("Dues")

            ContributionsPage.txtDuesAmount.Text = DuesAmount.ToString
        Catch ex As SqlException
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    Private Sub PopulateContributions()
        Try
            Con.Open()
            Dim query = "select * from ContributionsTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ContributionsPage.ContributionsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub IconButton3_Click(sender As Object, e As EventArgs) Handles btnContribution.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        ClaimStatus.Hide()
        ShowProfilePage.Hide()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = True
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False

        Try
            Cursor = Cursors.WaitCursor
            ActivationButton(sender, Color.DarkSeaGreen)
            adminText.IconColor = Color.DarkSeaGreen
            txtNoApprovals.BackColor = Color.Transparent
            PopulateContributions()
            GetDuesAmount()
            Dim nwContributionPage = ContributionsPage
            switchPages(nwContributionPage)


        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub IconButton5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub IconButton6_Click(sender As Object, e As EventArgs) Handles btnMembers.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        ClaimStatus.Hide()
        ShowProfilePage.Hide()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = True
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False

        Try
            Cursor = Cursors.WaitCursor
            ActivationButton(sender, Color.DarkSeaGreen)
            adminText.IconColor = Color.DarkSeaGreen
            txtNoApprovals.BackColor = Color.Transparent
            '    Dim nwMembersPage = New MembersPage
            '   switchPages(nwMemhildbersPage)

            Dim childForm1 As New MembersPage()
            childForm1.TopLevel = False
            childForm1.FormBorderStyle = FormBorderStyle.None
            pageSwitch.Controls.Clear()
            childForm1.Dock = DockStyle.Fill
            pageSwitch.Controls.Add(childForm1)
            childForm1.Show()


        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub IconButton8_Click(sender As Object, e As EventArgs) Handles btnEditAccount.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        ClaimStatus.Hide()
        ShowProfilePage.Hide()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = True
        LogOutToolStripMenuItem.Checked = False

        Try
            Cursor = Cursors.WaitCursor
            ActivationButton(sender, Color.DarkSeaGreen)
            adminText.IconColor = Color.DarkSeaGreen
            txtNoApprovals.BackColor = Color.Transparent
            Dim nwAdminEditAccountPage = New AdminEditAccountPage
            switchPages(nwAdminEditAccountPage)
        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtAdminName.Text = Aname.ToUpper
        ' Subscribe to the event to show ChildForm2
        ' AddHandler MembersPage.ShowAddMembersPage1Requested, AddressOf ShowAddMembersPage1
        Try

            btnDashboard.PerformClick()

        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub IogoutTime()
        Try
            Dim currentDataNTim As New DateTimePicker
            Dim theTimeNDate = currentDataNTim.Value
            Con.Open()
            Dim query5 As String
            query5 = "insert into ViewlogsTbl values('" & AStaffID & "','" & Aname & "','" & Aphone & "','" & Agmail & "','" & lognullDate & "','" & theTimeNDate & "')"
            cmd = New SqlCommand(query5, Con)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    Private Sub IconButton7_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
        Try

            Dim logOutDialog As DialogResult = MessageBox.Show("LogOut", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If (logOutDialog = DialogResult.Yes) Then
                Cursor = Cursors.WaitCursor
                IogoutTime()
                Dim nwLoginFormPage = New AdminLoginFormPage
                btnDashboard.PerformClick()
                Me.Hide()
                nwLoginFormPage.Show()
            End If
        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub


    Private Sub ShowAddMembersPage1(sender As Object, e As EventArgs)
        ' Create an instance of ChildForm2 if it doesn't exist
        ' Try
        'If AddMembersInstance Is Nothing Then
        '   AddMembersInstance = New AddMemberPage1()
        'AddMembersInstance.TopLevel = False
        'AddMembersInstance.FormBorderStyle = FormBorderStyle.None
        'pageSwitch.Controls.Clear()
        'AddMembersInstance.Dock = DockStyle.Fill
        'pageSwitch.Controls.Add(AddMembersInstance)
        'End If
        Dim nwAddMemberPage1 As New AddMemberPage1()
        nwAddMemberPage1.TopLevel = False
        nwAddMemberPage1.FormBorderStyle = FormBorderStyle.None
        pageSwitch.Controls.Clear()
        nwAddMemberPage1.Dock = DockStyle.Fill
        pageSwitch.Controls.Add(nwAddMemberPage1)
        nwAddMemberPage1.Show()

        ' Show ChildForm2
        ' AddMembersInstance.BringToFront()
        '  AddMembersInstance.Show()
        'Catch ex As Exception
        'MsgBox(ex.Message)
        'End Try

    End Sub

    Private Sub Form1_Click(sender As Object, e As EventArgs) Handles MyBase.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub Panel2_Click(sender As Object, e As EventArgs) Handles Panel2.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub adminText_Click(sender As Object, e As EventArgs) Handles adminText.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub
    Private Sub MenuStrip1_Click(sender As Object, e As EventArgs) Handles MenuStrip1.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub PanelMenu_Click(sender As Object, e As EventArgs) Handles PanelMenu.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        ClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub DashboardToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DashboardToolStripMenuItem.Click
        btnDashboard.PerformClick()

        DashboardToolStripMenuItem.Checked = True
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub ClaimsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClaimsToolStripMenuItem.Click
        btnClaims.PerformClick()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = True
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub ContributionsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ContributionsToolStripMenuItem.Click
        btnContribution.PerformClick()


        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = True
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub MembersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MembersToolStripMenuItem.Click
        btnMembers.PerformClick()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = True
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub UsersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UsersToolStripMenuItem.Click
        btnUsers.PerformClick()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = True
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub EditAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditAccountToolStripMenuItem.Click
        btnEditAccount.PerformClick()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = True
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        btnLogOut.PerformClick()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub MinimizeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MinimizeToolStripMenuItem.Click
        Me.WindowState = FormWindowState.Minimized
        ' MinimizeToolStripMenuItem.Checked = True
        MaximizeToolStripMenuItem.Checked = False
        RestoreToolStripMenuItem.Checked = False
    End Sub

    Private Sub MaximizeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MaximizeToolStripMenuItem.Click
        Me.WindowState = FormWindowState.Maximized
        btnMaximize.Visible = False
        btnNormal.Visible = True

        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = True
        RestoreToolStripMenuItem.Checked = False
    End Sub

    Private Sub RestoreToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RestoreToolStripMenuItem.Click
        Me.WindowState = FormWindowState.Normal
        btnMaximize.Visible = True
        btnNormal.Visible = False

        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = False
        RestoreToolStripMenuItem.Checked = True
    End Sub

    'DashboardToolStripMenuItem

    Private Sub PictureBox1_MouseHover(sender As Object, e As EventArgs) Handles PictureBox1.MouseHover
        AddNewChild.Hide()
        ForgotPasswordPage.Hide()
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub btnDashboard_MouseHover(sender As Object, e As EventArgs) Handles btnDashboard.MouseHover
        ForgotPasswordPage.Hide()
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub btnClaims_MouseHover(sender As Object, e As EventArgs) Handles btnClaims.MouseHover
        ForgotPasswordPage.Hide()
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub btnContribution_MouseHover(sender As Object, e As EventArgs) Handles btnContribution.MouseHover
        ForgotPasswordPage.Hide()
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub btnMembers_MouseHover(sender As Object, e As EventArgs) Handles btnMembers.MouseHover
        ForgotPasswordPage.Hide()
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub btnUsers_MouseHover(sender As Object, e As EventArgs) Handles btnUsers.MouseHover
        ForgotPasswordPage.Hide()
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub PanelMenu_MouseHover(sender As Object, e As EventArgs) Handles PanelMenu.MouseHover
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        ForgotPasswordPage.Hide()
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub btnEditAccount_MouseHover(sender As Object, e As EventArgs) Handles btnEditAccount.MouseHover
        ForgotPasswordPage.Hide()
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub btnLogOut_MouseHover(sender As Object, e As EventArgs) Handles btnLogOut.MouseHover
        ForgotPasswordPage.Hide()
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub ExclusionListToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExclusionListToolStripMenuItem.Click
        Dim nwEclusionPage = New ExclusionListPage
        DisableButton()
        adminText.Text = "Exclusion List"
        switchPages(nwEclusionPage)
    End Sub

    Private Sub AccountEditHistoryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccountEditHistoryToolStripMenuItem.Click
        Dim nwAccountEditHistory = New AccountEditHistory
        DisableButton()
        adminText.Text = "Account Edit History"
        switchPages(nwAccountEditHistory)
    End Sub

    Private Sub LogHistoryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogHistoryToolStripMenuItem.Click
        Dim nwLogHistory = New LogHistory
        DisableButton()
        adminText.Text = "Log History"
        switchPages(nwLogHistory)
    End Sub

    Private Sub pageSwitch_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub IconButton1_Click_1(sender As Object, e As EventArgs) Handles btnUsers.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        ClaimStatus.Hide()
        ShowProfilePage.Hide()

        DashboardToolStripMenuItem.Checked = False
        ClaimsToolStripMenuItem.Checked = False
        ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        UsersToolStripMenuItem.Checked = True
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False

        Try
            Cursor = Cursors.WaitCursor
            ActivationButton(sender, Color.DarkSeaGreen)
            adminText.IconColor = Color.DarkSeaGreen
            txtNoApprovals.BackColor = Color.Transparent
            Dim nwUsersPage = New UsersPage
            switchPages(nwUsersPage)


        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click
        FileToolStripMenuItem.ForeColor = Color.Black
        ViewToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub ViewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewToolStripMenuItem.Click
        ViewToolStripMenuItem.ForeColor = Color.Black
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub ViewToolStripMenuItem_MouseHover(sender As Object, e As EventArgs) Handles ViewToolStripMenuItem.MouseHover
        ViewToolStripMenuItem.ForeColor = Color.White
        '  ViewToolStripMenuItem.BackColor = Color.SeaGreen

        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub FileToolStripMenuItem_MouseHover(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.MouseHover
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
        '  FileToolStripMenuItem.BackColor = Color.SeaGreen
    End Sub

    Private Sub Panel1_MouseHover(sender As Object, e As EventArgs) Handles Panel1.MouseHover
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub Panel2_MouseHover(sender As Object, e As EventArgs) Handles Panel2.MouseHover
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub PictureBox1_MouseHover_1(sender As Object, e As EventArgs) Handles PictureBox1.MouseHover
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub PanelMenu_MouseHover_1(sender As Object, e As EventArgs) Handles PanelMenu.MouseHover
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub MenuStrip1_MouseHover(sender As Object, e As EventArgs) Handles MenuStrip1.MouseHover
        ViewToolStripMenuItem.ForeColor = Color.White
        FileToolStripMenuItem.ForeColor = Color.White
    End Sub

    '
    'Drag Form
    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub
    Private Sub PanelTitleBar_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Panel1.MouseDown
        ReleaseCapture()
        SendMessage(Me.Handle, &H112, &HF012, 0)
        btnMaximize.Visible = True
        btnNormal.Visible = False

        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = False
        RestoreToolStripMenuItem.Checked = True
    End Sub

    Private Sub btnNormal_Click(sender As Object, e As EventArgs) Handles btnNormal.Click
        Me.WindowState = FormWindowState.Normal
        btnMaximize.Visible = True
        btnNormal.Visible = False
        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = False
        RestoreToolStripMenuItem.Checked = True
    End Sub

    Private Sub btnMinimize_Click(sender As Object, e As EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnMaximize_Click(sender As Object, e As EventArgs) Handles btnMaximize.Click
        Me.WindowState = FormWindowState.Maximized
        btnMaximize.Visible = False
        btnNormal.Visible = True
        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = True
        RestoreToolStripMenuItem.Checked = False
    End Sub

    Protected Overrides ReadOnly Property CreateParams As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            cp.Style = cp.Style Or &H20000
            Return cp
        End Get
    End Property
End Class
