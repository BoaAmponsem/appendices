﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class UserPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnMaximize = New FontAwesome.Sharp.IconButton()
        Me.btnNormal = New FontAwesome.Sharp.IconButton()
        Me.btnMinimize = New FontAwesome.Sharp.IconButton()
        Me.pageSwitch = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtUsernameHomePage = New FontAwesome.Sharp.IconButton()
        Me.adminText = New FontAwesome.Sharp.IconButton()
        Me.PanelMenu = New System.Windows.Forms.Panel()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.txtNoBirthdays = New System.Windows.Forms.Label()
        Me.txtNoDebtors = New System.Windows.Forms.Label()
        Me.btnEditAccount = New FontAwesome.Sharp.IconButton()
        Me.btnLogOut = New FontAwesome.Sharp.IconButton()
        Me.btnMembers = New FontAwesome.Sharp.IconButton()
        Me.btnContributions = New FontAwesome.Sharp.IconButton()
        Me.btnClaims = New FontAwesome.Sharp.IconButton()
        Me.btnHome = New FontAwesome.Sharp.IconButton()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClaimsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContributionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MembersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MinimizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MaximizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.PanelMenu.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.SeaGreen
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.IconButton1)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.ForeColor = System.Drawing.Color.White
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1168, 31)
        Me.Panel1.TabIndex = 1
        '
        'PictureBox2
        '
        Me.PictureBox2.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox2.Image = Global.AidBridge.My.Resources.Resources._5520872
        Me.PictureBox2.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(48, 27)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'IconButton1
        '
        Me.IconButton1.BackColor = System.Drawing.Color.SeaGreen
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.IconButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.IconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton1.ForeColor = System.Drawing.Color.White
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton1.IconColor = System.Drawing.Color.SeaGreen
        Me.IconButton1.IconSize = 29
        Me.IconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton1.Location = New System.Drawing.Point(40, 2)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(70, 24)
        Me.IconButton1.TabIndex = 2
        Me.IconButton1.Text = "AidBridge"
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnMaximize)
        Me.Panel3.Controls.Add(Me.btnNormal)
        Me.Panel3.Controls.Add(Me.btnMinimize)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(1084, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(80, 27)
        Me.Panel3.TabIndex = 0
        '
        'btnMaximize
        '
        Me.btnMaximize.FlatAppearance.BorderSize = 0
        Me.btnMaximize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btnMaximize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray
        Me.btnMaximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMaximize.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnMaximize.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMaximize.ForeColor = System.Drawing.Color.SeaGreen
        Me.btnMaximize.IconChar = FontAwesome.Sharp.IconChar.WindowMaximize
        Me.btnMaximize.IconColor = System.Drawing.Color.White
        Me.btnMaximize.IconSize = 15
        Me.btnMaximize.Location = New System.Drawing.Point(41, 3)
        Me.btnMaximize.Name = "btnMaximize"
        Me.btnMaximize.Rotation = 0R
        Me.btnMaximize.Size = New System.Drawing.Size(35, 24)
        Me.btnMaximize.TabIndex = 3
        Me.btnMaximize.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnMaximize.UseVisualStyleBackColor = True
        Me.btnMaximize.Visible = False
        '
        'btnNormal
        '
        Me.btnNormal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnNormal.FlatAppearance.BorderSize = 0
        Me.btnNormal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btnNormal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray
        Me.btnNormal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNormal.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnNormal.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNormal.ForeColor = System.Drawing.Color.SeaGreen
        Me.btnNormal.IconChar = FontAwesome.Sharp.IconChar.WindowRestore
        Me.btnNormal.IconColor = System.Drawing.Color.White
        Me.btnNormal.IconSize = 15
        Me.btnNormal.Location = New System.Drawing.Point(41, 3)
        Me.btnNormal.Name = "btnNormal"
        Me.btnNormal.Rotation = 0R
        Me.btnNormal.Size = New System.Drawing.Size(33, 20)
        Me.btnNormal.TabIndex = 2
        Me.btnNormal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnNormal.UseVisualStyleBackColor = True
        '
        'btnMinimize
        '
        Me.btnMinimize.FlatAppearance.BorderSize = 0
        Me.btnMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSlateGray
        Me.btnMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray
        Me.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMinimize.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnMinimize.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMinimize.ForeColor = System.Drawing.Color.SeaGreen
        Me.btnMinimize.IconChar = FontAwesome.Sharp.IconChar.WindowMinimize
        Me.btnMinimize.IconColor = System.Drawing.Color.White
        Me.btnMinimize.IconSize = 15
        Me.btnMinimize.Location = New System.Drawing.Point(3, 3)
        Me.btnMinimize.Name = "btnMinimize"
        Me.btnMinimize.Rotation = 0R
        Me.btnMinimize.Size = New System.Drawing.Size(32, 24)
        Me.btnMinimize.TabIndex = 1
        Me.btnMinimize.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnMinimize.UseVisualStyleBackColor = True
        '
        'pageSwitch
        '
        Me.pageSwitch.AutoScroll = True
        Me.pageSwitch.BackColor = System.Drawing.Color.WhiteSmoke
        Me.pageSwitch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pageSwitch.Location = New System.Drawing.Point(150, 102)
        Me.pageSwitch.Name = "pageSwitch"
        Me.pageSwitch.Size = New System.Drawing.Size(1018, 577)
        Me.pageSwitch.TabIndex = 7
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.txtUsernameHomePage)
        Me.Panel2.Controls.Add(Me.adminText)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(150, 55)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1018, 47)
        Me.Panel2.TabIndex = 6
        '
        'txtUsernameHomePage
        '
        Me.txtUsernameHomePage.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtUsernameHomePage.BackColor = System.Drawing.Color.White
        Me.txtUsernameHomePage.FlatAppearance.BorderSize = 0
        Me.txtUsernameHomePage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.txtUsernameHomePage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.txtUsernameHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtUsernameHomePage.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.txtUsernameHomePage.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUsernameHomePage.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtUsernameHomePage.IconChar = FontAwesome.Sharp.IconChar.None
        Me.txtUsernameHomePage.IconColor = System.Drawing.Color.SeaGreen
        Me.txtUsernameHomePage.IconSize = 29
        Me.txtUsernameHomePage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.txtUsernameHomePage.Location = New System.Drawing.Point(882, 10)
        Me.txtUsernameHomePage.Name = "txtUsernameHomePage"
        Me.txtUsernameHomePage.Rotation = 0R
        Me.txtUsernameHomePage.Size = New System.Drawing.Size(127, 29)
        Me.txtUsernameHomePage.TabIndex = 3
        Me.txtUsernameHomePage.Text = "Username"
        Me.txtUsernameHomePage.UseVisualStyleBackColor = False
        '
        'adminText
        '
        Me.adminText.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.adminText.FlatAppearance.BorderSize = 0
        Me.adminText.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White
        Me.adminText.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.adminText.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.adminText.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.adminText.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.adminText.ForeColor = System.Drawing.Color.SeaGreen
        Me.adminText.IconChar = FontAwesome.Sharp.IconChar.None
        Me.adminText.IconColor = System.Drawing.Color.SeaGreen
        Me.adminText.IconSize = 29
        Me.adminText.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.adminText.Location = New System.Drawing.Point(6, 6)
        Me.adminText.Name = "adminText"
        Me.adminText.Rotation = 0R
        Me.adminText.Size = New System.Drawing.Size(123, 35)
        Me.adminText.TabIndex = 0
        Me.adminText.Text = "IconButton4"
        Me.adminText.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.adminText.UseVisualStyleBackColor = True
        '
        'PanelMenu
        '
        Me.PanelMenu.BackColor = System.Drawing.Color.SeaGreen
        Me.PanelMenu.Controls.Add(Me.IconButton2)
        Me.PanelMenu.Controls.Add(Me.txtNoBirthdays)
        Me.PanelMenu.Controls.Add(Me.txtNoDebtors)
        Me.PanelMenu.Controls.Add(Me.btnEditAccount)
        Me.PanelMenu.Controls.Add(Me.btnLogOut)
        Me.PanelMenu.Controls.Add(Me.btnMembers)
        Me.PanelMenu.Controls.Add(Me.btnContributions)
        Me.PanelMenu.Controls.Add(Me.btnClaims)
        Me.PanelMenu.Controls.Add(Me.btnHome)
        Me.PanelMenu.Controls.Add(Me.Panel4)
        Me.PanelMenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelMenu.Location = New System.Drawing.Point(0, 55)
        Me.PanelMenu.Name = "PanelMenu"
        Me.PanelMenu.Size = New System.Drawing.Size(150, 624)
        Me.PanelMenu.TabIndex = 5
        '
        'IconButton2
        '
        Me.IconButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton2.Dock = System.Windows.Forms.DockStyle.Top
        Me.IconButton2.FlatAppearance.BorderSize = 0
        Me.IconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton2.ForeColor = System.Drawing.Color.White
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.HandHoldingUsd
        Me.IconButton2.IconColor = System.Drawing.Color.White
        Me.IconButton2.IconSize = 29
        Me.IconButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton2.Location = New System.Drawing.Point(0, 270)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(150, 42)
        Me.IconButton2.TabIndex = 13
        Me.IconButton2.Text = "Loans"
        Me.IconButton2.UseVisualStyleBackColor = True
        Me.IconButton2.Visible = False
        '
        'txtNoBirthdays
        '
        Me.txtNoBirthdays.AutoSize = True
        Me.txtNoBirthdays.BackColor = System.Drawing.Color.Transparent
        Me.txtNoBirthdays.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoBirthdays.ForeColor = System.Drawing.Color.White
        Me.txtNoBirthdays.Location = New System.Drawing.Point(101, 248)
        Me.txtNoBirthdays.Name = "txtNoBirthdays"
        Me.txtNoBirthdays.Size = New System.Drawing.Size(13, 14)
        Me.txtNoBirthdays.TabIndex = 12
        Me.txtNoBirthdays.Text = "0"
        '
        'txtNoDebtors
        '
        Me.txtNoDebtors.AutoSize = True
        Me.txtNoDebtors.BackColor = System.Drawing.Color.Transparent
        Me.txtNoDebtors.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNoDebtors.ForeColor = System.Drawing.Color.White
        Me.txtNoDebtors.Location = New System.Drawing.Point(115, 206)
        Me.txtNoDebtors.Name = "txtNoDebtors"
        Me.txtNoDebtors.Size = New System.Drawing.Size(13, 14)
        Me.txtNoDebtors.TabIndex = 11
        Me.txtNoDebtors.Text = "0"
        '
        'btnEditAccount
        '
        Me.btnEditAccount.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnEditAccount.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnEditAccount.FlatAppearance.BorderSize = 0
        Me.btnEditAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEditAccount.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnEditAccount.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditAccount.ForeColor = System.Drawing.Color.White
        Me.btnEditAccount.IconChar = FontAwesome.Sharp.IconChar.PencilAlt
        Me.btnEditAccount.IconColor = System.Drawing.Color.White
        Me.btnEditAccount.IconSize = 29
        Me.btnEditAccount.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEditAccount.Location = New System.Drawing.Point(0, 540)
        Me.btnEditAccount.Name = "btnEditAccount"
        Me.btnEditAccount.Rotation = 0R
        Me.btnEditAccount.Size = New System.Drawing.Size(150, 42)
        Me.btnEditAccount.TabIndex = 8
        Me.btnEditAccount.Text = "Edit Account"
        Me.btnEditAccount.UseVisualStyleBackColor = True
        '
        'btnLogOut
        '
        Me.btnLogOut.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogOut.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnLogOut.FlatAppearance.BorderSize = 0
        Me.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogOut.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnLogOut.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.IconChar = FontAwesome.Sharp.IconChar.ArrowAltCircleLeft
        Me.btnLogOut.IconColor = System.Drawing.Color.White
        Me.btnLogOut.IconSize = 29
        Me.btnLogOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogOut.Location = New System.Drawing.Point(0, 582)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Rotation = 0R
        Me.btnLogOut.Size = New System.Drawing.Size(150, 42)
        Me.btnLogOut.TabIndex = 7
        Me.btnLogOut.Text = "Log Out"
        Me.btnLogOut.UseVisualStyleBackColor = True
        '
        'btnMembers
        '
        Me.btnMembers.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMembers.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnMembers.FlatAppearance.BorderSize = 0
        Me.btnMembers.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMembers.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnMembers.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMembers.ForeColor = System.Drawing.Color.White
        Me.btnMembers.IconChar = FontAwesome.Sharp.IconChar.UserFriends
        Me.btnMembers.IconColor = System.Drawing.Color.White
        Me.btnMembers.IconSize = 29
        Me.btnMembers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMembers.Location = New System.Drawing.Point(0, 228)
        Me.btnMembers.Name = "btnMembers"
        Me.btnMembers.Rotation = 0R
        Me.btnMembers.Size = New System.Drawing.Size(150, 42)
        Me.btnMembers.TabIndex = 5
        Me.btnMembers.Text = "Members"
        Me.btnMembers.UseVisualStyleBackColor = True
        '
        'btnContributions
        '
        Me.btnContributions.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnContributions.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnContributions.FlatAppearance.BorderSize = 0
        Me.btnContributions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnContributions.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnContributions.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnContributions.ForeColor = System.Drawing.Color.White
        Me.btnContributions.IconChar = FontAwesome.Sharp.IconChar.MoneyBill
        Me.btnContributions.IconColor = System.Drawing.Color.White
        Me.btnContributions.IconSize = 29
        Me.btnContributions.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnContributions.Location = New System.Drawing.Point(0, 186)
        Me.btnContributions.Name = "btnContributions"
        Me.btnContributions.Rotation = 0R
        Me.btnContributions.Size = New System.Drawing.Size(150, 42)
        Me.btnContributions.TabIndex = 3
        Me.btnContributions.Text = "Transactions"
        Me.btnContributions.UseVisualStyleBackColor = True
        '
        'btnClaims
        '
        Me.btnClaims.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClaims.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnClaims.FlatAppearance.BorderSize = 0
        Me.btnClaims.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClaims.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnClaims.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClaims.ForeColor = System.Drawing.Color.White
        Me.btnClaims.IconChar = FontAwesome.Sharp.IconChar.Gift
        Me.btnClaims.IconColor = System.Drawing.Color.White
        Me.btnClaims.IconSize = 29
        Me.btnClaims.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnClaims.Location = New System.Drawing.Point(0, 144)
        Me.btnClaims.Name = "btnClaims"
        Me.btnClaims.Rotation = 0R
        Me.btnClaims.Size = New System.Drawing.Size(150, 42)
        Me.btnClaims.TabIndex = 2
        Me.btnClaims.Text = "Claims"
        Me.btnClaims.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHome.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnHome.FlatAppearance.BorderSize = 0
        Me.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHome.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnHome.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHome.ForeColor = System.Drawing.Color.White
        Me.btnHome.IconChar = FontAwesome.Sharp.IconChar.Home
        Me.btnHome.IconColor = System.Drawing.Color.White
        Me.btnHome.IconSize = 29
        Me.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnHome.Location = New System.Drawing.Point(0, 102)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Rotation = 0R
        Me.btnHome.Size = New System.Drawing.Size(150, 42)
        Me.btnHome.TabIndex = 1
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.PictureBox1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(150, 102)
        Me.Panel4.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = Global.AidBridge.My.Resources.Resources.hmnHandshake
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(150, 102)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.SeaGreen
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ViewToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 31)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1168, 24)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.Checked = True
        Me.FileToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.FileToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.ClaimsToolStripMenuItem, Me.ContributionsToolStripMenuItem, Me.MembersToolStripMenuItem, Me.EditAccountToolStripMenuItem, Me.LogOutToolStripMenuItem})
        Me.FileToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.HomeToolStripMenuItem.Text = "Home"
        '
        'ClaimsToolStripMenuItem
        '
        Me.ClaimsToolStripMenuItem.Name = "ClaimsToolStripMenuItem"
        Me.ClaimsToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.ClaimsToolStripMenuItem.Text = "Claims"
        '
        'ContributionsToolStripMenuItem
        '
        Me.ContributionsToolStripMenuItem.Name = "ContributionsToolStripMenuItem"
        Me.ContributionsToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.ContributionsToolStripMenuItem.Text = "Contributions"
        '
        'MembersToolStripMenuItem
        '
        Me.MembersToolStripMenuItem.Name = "MembersToolStripMenuItem"
        Me.MembersToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.MembersToolStripMenuItem.Text = "Members"
        '
        'EditAccountToolStripMenuItem
        '
        Me.EditAccountToolStripMenuItem.Name = "EditAccountToolStripMenuItem"
        Me.EditAccountToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.EditAccountToolStripMenuItem.Text = "Edit Account"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.LogOutToolStripMenuItem.Text = "LogOut"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MinimizeToolStripMenuItem, Me.MaximizeToolStripMenuItem, Me.RestoreToolStripMenuItem})
        Me.ViewToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'MinimizeToolStripMenuItem
        '
        Me.MinimizeToolStripMenuItem.Name = "MinimizeToolStripMenuItem"
        Me.MinimizeToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.MinimizeToolStripMenuItem.Text = "Minimize"
        '
        'MaximizeToolStripMenuItem
        '
        Me.MaximizeToolStripMenuItem.Name = "MaximizeToolStripMenuItem"
        Me.MaximizeToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.MaximizeToolStripMenuItem.Text = "Maximize"
        '
        'RestoreToolStripMenuItem
        '
        Me.RestoreToolStripMenuItem.Name = "RestoreToolStripMenuItem"
        Me.RestoreToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.RestoreToolStripMenuItem.Text = "Restore"
        '
        'UserPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1168, 679)
        Me.Controls.Add(Me.pageSwitch)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.PanelMenu)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "UserPage"
        Me.Text = "AidBridge"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.PanelMenu.ResumeLayout(False)
        Me.PanelMenu.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents pageSwitch As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents adminText As FontAwesome.Sharp.IconButton
    Friend WithEvents PanelMenu As Panel
    Friend WithEvents btnEditAccount As FontAwesome.Sharp.IconButton
    Friend WithEvents btnLogOut As FontAwesome.Sharp.IconButton
    Friend WithEvents btnMembers As FontAwesome.Sharp.IconButton
    Friend WithEvents btnContributions As FontAwesome.Sharp.IconButton
    Friend WithEvents btnClaims As FontAwesome.Sharp.IconButton
    Friend WithEvents btnHome As FontAwesome.Sharp.IconButton
    Friend WithEvents Panel4 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClaimsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContributionsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MembersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditAccountToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MinimizeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MaximizeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RestoreToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btnMinimize As FontAwesome.Sharp.IconButton
    Friend WithEvents btnNormal As FontAwesome.Sharp.IconButton
    Friend WithEvents btnMaximize As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtUsernameHomePage As FontAwesome.Sharp.IconButton
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents txtNoDebtors As Label
    Friend WithEvents txtNoBirthdays As Label
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
End Class
