﻿Imports System.Data.SqlClient
Imports System.IO
Public Class UserEditMemberProfile
    Sub switchPagesUser(ByVal pageSwitch1 As Form)
        Try

            UserPage.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            UserPage.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select Id,Name,Birth_Date from ChildrenTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            childrenDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub

    ''Function to show member children on Profile Page
    Private Function ChildrenByMember()
        Try
            Con.Open()
            Dim query = "select Id,Name,Birth_Date from ChildrenTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            AddNewChild.childrenDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function
    Private Sub UserEditMemberProfile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Children Info
        Populate()

        'Member Info
        Try
            txtMemberSurname.Text = memberUserSurname
            txtMemberOthername.Text = memberUserOthername
            txtMemberSex.Text = memberUserSex
            txtMemberPhone.Text = memberUserPhone
            txtMemberHouseNo.Text = memberUserHouseNo
            txtMemberPostalAddress.Text = memberUserPostalAddress
            txtMaritalStatus.Text = memberUserMaritalStatus
            txtTypeOfMarriage.Text = memberUserTypeOfMarriage
            txtMemberHometown.Text = memberUserHomeTown
            txtMemberDoB1.Text = memberUserDoB
            txtMemberStaffID.Text = memberUserStaffID

            'Spouse Info
            txtSpouseName.Text = memberUserSpouseName
            txtSpousePhone.Text = memberUserSpousePhone
            txtSpouseAddress.Text = memberUserSpouseAddress
        Catch ex As Exception

        End Try
    End Sub

    Private Sub IconButton5_Click(sender As Object, e As EventArgs) Handles IconButton5.Click
        ChildrenByMember()
        AddNewChild.Show()
    End Sub

    Private Sub UpdateSpouse()
        'Insert to SpouseTbl
        Try
            Con.Open()
            Dim query3 As String
            query3 = "update SpouseTbl set Name = '" & txtSpouseName.Text & "',Phone = '" & txtSpousePhone.Text & "',Contact_Address = '" & txtSpouseAddress.Text & "' where Id = '" & memberSpouseUniqueId & "'"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Spouse Details updated successfully", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub AddSpouseInSingle()
        'Insert to SpouseTbl
        Try
            Con.Open()
            Dim query3 As String
            query3 = "insert into SpouseTbl values('" & txtMemberStaffID.Text & "','" & txtSpouseName.Text & "','" & txtSpousePhone.Text & "','" & txtSpouseAddress.Text & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Spouse added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    ''Update member marital Status to Married
    Private Sub UpdateMemberMaritalStatusToMarried()
        Try
            Con.Open()
            Cursor = Cursors.WaitCursor
            Dim query As String
            query = "Update MembersTbl set Marital_Status='" & theMemberMarried & "' where Staff_ID ='" & txtMemberStaffID.Text & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            '  MessageBox.Show("Claim successfull", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
            Cursor = Cursors.Default
        End Try
    End Sub

    'CheckIfMemberIsMarried
    Private Sub CheckSpouse()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from SpouseTbl where Member_ID ='" & txtMemberStaffID.Text & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checkNoSpouse = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub
    Private Sub IconButton6_Click(sender As Object, e As EventArgs) Handles IconButton6.Click
        'CheckIfMemberIsMarried
        CheckSpouse()
        If (txtSpouseAddress.Text = "" And txtSpouseName.Text = "" And txtSpousePhone.Text = "") Then
            MsgBox("There is an empty field in the Spouse Details ")
        ElseIf (checkNoSpouse = 0 And txtSpouseName.ReadOnly = False) Then
            txtSpouseName.ReadOnly = True
            txtSpousePhone.ReadOnly = True
            txtSpouseAddress.ReadOnly = True
            AddSpouseInSingle()
            UpdateMemberMaritalStatusToMarried()
            txtMaritalStatus.Text = "Married"
        Else
            If (txtSpouseName.ReadOnly = False And checkNoSpouse <> 0) Then
                txtSpouseName.ReadOnly = True
                txtSpousePhone.ReadOnly = True
                txtSpouseAddress.ReadOnly = True
                UpdateSpouse()
            Else
                MsgBox("Can't update, no changes in the Spouse Details", MsgBoxStyle.Exclamation)
            End If
        End If

    End Sub

    Private Sub UpdateMemberProfile()
        'Update MemberTbl Profile
        memberAPicture = txtImageName.Text
        If (txtImageName.Text <> "") Then
            Dim profilePicture2 As Byte() = File.ReadAllBytes(imagepath)
            Try
                Con.Open()
                Dim query3 As String
                query3 = "UPDATE MembersTbl SET Staff_ID = @Staff_ID, Surname = @Surname, Other_Names = @OtherNames, Phone = @Phone, Sex = @Sex, House_No = @HouseNo, Postal_Address = @PostalAddress, Marital_Status = @MaritalStatus, Marriage_Type = @MarriageType, Hometown = @Hometown, Birth_Date = @BirthDate, Picture = @ProfilePicture WHERE Id = @Id"

                cmd = New SqlCommand(query3, Con)

                ' Add parameters with their respective values
                cmd.Parameters.AddWithValue("@Staff_ID", txtMemberStaffID.Text)
                cmd.Parameters.AddWithValue("@Surname", txtMemberSurname.Text)
                cmd.Parameters.AddWithValue("@OtherNames", txtMemberOthername.Text)
                cmd.Parameters.AddWithValue("@Phone", txtMemberPhone.Text)
                cmd.Parameters.AddWithValue("@Sex", txtMemberSex.Text)
                cmd.Parameters.AddWithValue("@HouseNo", txtMemberHouseNo.Text)
                cmd.Parameters.AddWithValue("@PostalAddress", txtMemberPostalAddress.Text)
                cmd.Parameters.AddWithValue("@MaritalStatus", txtMaritalStatus.Text)
                cmd.Parameters.AddWithValue("@MarriageType", txtTypeOfMarriage.Text)
                cmd.Parameters.AddWithValue("@Hometown", txtMemberHometown.Text)
                cmd.Parameters.AddWithValue("@BirthDate", txtMemberDoB1.Text)
                cmd.Parameters.AddWithValue("@ProfilePicture", profilePicture2)
                cmd.Parameters.AddWithValue("@Id", memberUniqueId) ' Assuming memberUniqueId is the ID of the record to update

                ' Execute the command
                cmd.ExecuteNonQuery()

                MessageBox.Show("Personal Details updated successfully", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try

        Else
            Try
                Con.Open()
                Dim query3 As String
                query3 = "update MembersTbl set Staff_ID ='" & txtMemberStaffID.Text & "',Surname = '" & txtMemberSurname.Text & "',Other_Names = '" & txtMemberOthername.Text & "',Phone = '" & txtMemberPhone.Text & "',Sex = '" & txtMemberSex.Text & "',House_No = '" & txtMemberHouseNo.Text & "',Postal_Address = '" & txtMemberPostalAddress.Text & "',Marital_Status = '" & txtMaritalStatus.Text & "',Marriage_Type = '" & txtTypeOfMarriage.Text & "',Hometown = '" & txtMemberHometown.Text & "',Birth_Date = '" & txtMemberDoB1.Text & "' where Id = '" & memberUniqueId & "'"
                cmd = New SqlCommand(query3, Con)
                cmd.ExecuteNonQuery()
                If memberAPicture <> "" Then
                    System.IO.File.Copy(memberAPicture, Application.StartupPath & "\Profile pictures\" & System.IO.Path.GetFileName(memberAPicture))
                End If
                MessageBox.Show("Personal Details updated successfully ", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        End If

    End Sub
    Dim aa3 As Integer
    Private Sub checkNewNumberIfAvailable()
        'Check if member is Already registered
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from MembersTbl where Phone ='" & txtMemberPhone.Text & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa3 = ds.Tables(0).Rows.Count
        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub

    Private Sub PopulateBirthdays()
        Dim currentDay As Integer = DateTime.Now.Day
        Dim currentMonth As Integer = DateTime.Now.Month

        Try
            Con.Open()
            ' SQL query to select all records
            Dim query As String = "SELECT Id, Staff_ID, Surname, Other_Names, Phone, Sex, Birth_Date FROM MembersTbl"

            Using command As New SqlCommand(query, Con)
                ' Create a data adapter
                Using adaptor As New SqlDataAdapter(command)
                    Dim ds As New DataSet()
                    adaptor.Fill(ds)

                    ' Create a DataTable to hold valid date records
                    Dim filteredTable As New DataTable()
                    filteredTable.Columns.Add("Id", GetType(Integer))
                    filteredTable.Columns.Add("Staff_ID", GetType(String))
                    filteredTable.Columns.Add("Surname", GetType(String))
                    filteredTable.Columns.Add("Other_Names", GetType(String))
                    filteredTable.Columns.Add("Phone", GetType(String))
                    filteredTable.Columns.Add("Sex", GetType(String))
                    filteredTable.Columns.Add("Birth_Date", GetType(String))

                    ' Iterate through the records and parse the Birth_Date column
                    For Each row As DataRow In ds.Tables(0).Rows
                        Dim birthDateString As String = row("Birth_Date").ToString()
                        Dim birthDate As DateTime
                        If DateTime.TryParse(birthDateString, birthDate) Then
                            If birthDate.Day = currentDay AndAlso birthDate.Month = currentMonth Then
                                ' Add the valid and matching record to the filtered table
                                filteredTable.Rows.Add(row("Id"), row("Staff_ID"), row("Surname"), row("Other_Names"), row("Phone"), row("Sex"), row("Birth_Date"))
                            End If
                        End If
                    Next

                    ' Bind the filtered table to the DataGridView
                    UserMembersPage.birthdaysDataGridView.DataSource = filteredTable
                End Using
            End Using
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        ' Create and add the Send Alert button column
        Dim sendSmsButtonColumn As New DataGridViewButtonColumn()
        sendSmsButtonColumn.HeaderText = ""
        sendSmsButtonColumn.Text = "Send Wish"
        sendSmsButtonColumn.Name = "sendWish"
        sendSmsButtonColumn.UseColumnTextForButtonValue = True

        ' Add the button column to the DataGridView if it doesn't already exist
        If UserMembersPage.birthdaysDataGridView.Columns("sendWish") Is Nothing Then
            UserMembersPage.birthdaysDataGridView.Columns.Add(sendSmsButtonColumn)
        End If

    End Sub
    Private Sub updatePersonalDetails_Click(sender As Object, e As EventArgs) Handles updatePersonalDetails.Click
        If (txtMemberSurname.ReadOnly = False) Then

            If (txtMemberPhone.Text <> memberUserPhone) Then
                checkNewNumberIfAvailable()
                If (aa3 = 0) Then
                    UpdateMemberProfile()

                    txtMemberSurname.ReadOnly = True
                    txtMemberOthername.ReadOnly = True

                    txtMemberPhone.ReadOnly = True
                    txtMemberHouseNo.ReadOnly = True
                    txtMemberPostalAddress.ReadOnly = True

                    txtMemberHometown.ReadOnly = True
                    txtMemberDoB1.ReadOnly = True
                Else
                    MsgBox("The new phone number already exist", MsgBoxStyle.Exclamation)
                End If
            ElseIf (txtMemberPhone.Text = memberUserPhone) Then
                UpdateMemberProfile()

                txtMemberSurname.ReadOnly = True
                txtMemberOthername.ReadOnly = True

                txtMemberPhone.ReadOnly = True
                txtMemberHouseNo.ReadOnly = True
                txtMemberPostalAddress.ReadOnly = True

                txtMemberHometown.ReadOnly = True
                txtMemberDoB1.ReadOnly = True
            End If
        Else
            MsgBox("Can't update, no changes in the Personal Details", MsgBoxStyle.Exclamation)
        End If

        Try
            Try
                Cursor = Cursors.WaitCursor
                PopulateBirthdays()
                Dim noBirthdays = UserMembersPage.birthdaysDataGridView.RowCount
                If (noBirthdays > 0) Then
                    UserPage.txtNoBirthdays.Text = noBirthdays.ToString
                    UserPage.txtNoBirthdays.Visible = True
                    UserMembersPage.TabPage2.Text = "Birthdays " + noBirthdays.ToString
                Else
                    UserPage.txtNoBirthdays.Visible = False
                    UserPage.txtNoBirthdays.Text = noBirthdays.ToString
                    UserMembersPage.TabPage2.Text = "Birthdays"
                End If
            Catch ex As Exception
            Finally
                Cursor = Cursors.Default
            End Try
        Catch ex As Exception

        End Try
    End Sub
    Dim imagepath As String
    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        Try
            If (txtMemberSurname.ReadOnly = True) Then
                MsgBox("Click on the 'Edit Yellow Button' before making any changes")
            Else

                Dim ofd As FileDialog = New OpenFileDialog()
                ofd.Filter = "Image File(*.jpg;*.png;*.gif;*.jpeg)|*.jpg;*.png;*.gif;*.jpeg"
                If ofd.ShowDialog() = DialogResult.OK Then

                    imagepath = ofd.FileName
                    ' Image = System.IO.File.ReadAllBytes(imagepath)
                    txtImageName.Text = imagepath

                End If
                ofd = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try
    End Sub

    Private Sub IconButton4_Click(sender As Object, e As EventArgs) Handles IconButton4.Click
        AddNewChild.Hide()
        txtMemberSurname.ReadOnly = False
        txtMemberOthername.ReadOnly = False
        '  txtMemberSex.ReadOnly = False
        txtMemberPhone.ReadOnly = False
        txtMemberHouseNo.ReadOnly = False
        txtMemberPostalAddress.ReadOnly = False
        '  txtMaritalStatus.ReadOnly = False
        '  txtTypeOfMarriage.ReadOnly = False
        txtMemberHometown.ReadOnly = False
        txtMemberDoB1.ReadOnly = False
        ' txtMemberStaffID.ReadOnly = False
    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        AddNewChild.Hide()
        'Spouse Info
        txtSpouseName.ReadOnly = False
        txtSpousePhone.ReadOnly = False
        txtSpouseAddress.ReadOnly = False
    End Sub

    Private Function MemberBeneficiaries()
        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            UserEditMemberProfile2.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function
    Private Sub NextBtn_Click(sender As Object, e As EventArgs) Handles NextBtn.Click
        AddNewChild.Hide()
        MemberBeneficiaries()

        switchPagesUser(UserEditMemberProfile2)
    End Sub
    Private Sub PopulateMembers()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Hometown,Birth_Date,Registration_Date,Operator from MembersTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            UserMembersPage.membersDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Dim deleteButtonColumn As New DataGridViewButtonColumn()
        deleteButtonColumn.HeaderText = ""
        deleteButtonColumn.Text = "Remove"
        deleteButtonColumn.Name = "DeleteBtn"
        deleteButtonColumn.UseColumnTextForButtonValue = True

        Dim EditButtonColumn2 As New DataGridViewButtonColumn()
        EditButtonColumn2.HeaderText = ""
        EditButtonColumn2.Text = "Edit"
        EditButtonColumn2.Name = "EditBtn"
        EditButtonColumn2.UseColumnTextForButtonValue = True

        ' deleteButtonColumn.Image = My.Resources.approve
        'deleteButtonColumn.Name = "Delete"
        ' deleteButtonColumn.ImageLayout = DataGridViewImageCellLayout.Zoom
        If UserMembersPage.membersDataGridView.Columns("DeleteBtn") Is Nothing Then
            UserMembersPage.membersDataGridView.Columns.Add(deleteButtonColumn)
        End If
        ' membersDataGridView.Columns.Add(deleteButtonColumn)
        If UserMembersPage.membersDataGridView.Columns("EditBtn") Is Nothing Then
            UserMembersPage.membersDataGridView.Columns.Add(EditButtonColumn2)
        End If
        ' membersDataGridView.Columns.Add(EditButtonColumn2)
    End Sub
    Private Sub IconButton3_Click(sender As Object, e As EventArgs) Handles IconButton3.Click

        Try
            AddNewChild.Hide()
            Cursor = Cursors.WaitCursor
            PopulateMembers()
        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
        End Try
        Try
            switchPagesUser(UserMembersPage)
        Catch ex As Exception


        End Try

    End Sub

    Private Sub UserEditMemberProfile_Click(sender As Object, e As EventArgs) Handles MyBase.Click
        AddNewChild.Hide()
    End Sub

    Private Sub GroupBox1_MouseHover(sender As Object, e As EventArgs) Handles GroupBox1.MouseHover
        AddNewChild.Hide()
    End Sub

    Private Sub txtMaritalStatus_SelectedValueChanged(sender As Object, e As EventArgs) Handles txtMaritalStatus.SelectedValueChanged
        If (txtMaritalStatus.Text = "Single" And txtSpouseName.Text <> "" And txtSpouseName.ReadOnly = True) Then
            ' MsgBox("The member has a spouse", MsgBoxStyle.Exclamation)
            txtMaritalStatus.Text = "Married"
        ElseIf (txtMaritalStatus.Text = "Married" And txtSpouseName.Text = "" And txtSpouseName.ReadOnly = True) Then
            ' MsgBox("If the member is married, update his/her spouse information. The 'Marital Status' will change automatically", MsgBoxStyle.Exclamation)
            txtMaritalStatus.Text = "Single"
        End If
    End Sub
End Class