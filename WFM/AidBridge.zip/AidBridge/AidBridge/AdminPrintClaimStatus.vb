﻿Public Class AdminPrintClaimStatus
    Private Sub AdminPrintClaimStatus_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.ClaimReport.RefreshReport()
    End Sub
End Class