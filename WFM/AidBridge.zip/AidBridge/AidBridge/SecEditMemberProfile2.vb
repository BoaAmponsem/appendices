﻿Imports System.Data.SqlClient
Public Class SecEditMemberProfile2
    Sub switchPagesUser(ByVal pageSwitch1 As Form)
        Try

            SecretryForm.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            SecretryForm.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SecEditMemberProfile2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If (memberUserMotherLiveStatus = "Dead") Then
            txtMotherDead.Checked = True

        Else
            txtMotherAlive.Checked = True
        End If
        txtMotherName.Text = memberUserMothername
        txtMotherPhone.Text = memberUserMotherPhone


        If (memberUserFatherLiveStatus = "Dead") Then
            txtFatherDead.Checked = True
        Else
            txtFatherAlive.Checked = True
        End If
        txtFatherName.Text = memberUserFathername
        txtFatherPhone.Text = memberUserFatherPhone

    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        AddNewBeneficiary.Hide()
        txtMotherName.ReadOnly = False
        txtMotherPhone.ReadOnly = False
        txtFatherName.ReadOnly = False
        txtFatherPhone.ReadOnly = False
    End Sub

    Private Sub UpdateParents()
        'Insert to ParentsTbl Father
        If (txtFatherAlive.Checked = True) Then
            Try
                Con.Open()
                Dim query3 As String
                query3 = "update ParentsTbl set Name = '" & txtFatherName.Text & "',Phone = '" & txtFatherPhone.Text & "',Live_Status = '" & txtFatherAlive.Text & "' where Id ='" & memberFatherUniqueId & "' "
                cmd = New SqlCommand(query3, Con)
                cmd.ExecuteNonQuery()
                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            Try
                Con.Open()
                Dim query3 As String
                query3 = "update ParentsTbl set Name = '" & txtFatherName.Text & "',Phone = '" & txtFatherPhone.Text & "',Live_Status = '" & txtFatherDead.Text & "' where Id ='" & memberFatherUniqueId & "' "
                cmd = New SqlCommand(query3, Con)
                cmd.ExecuteNonQuery()
                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        End If

        'Insert to ParentsTbl  Mother
        If (txtMotherAlive.Checked = True) Then
            Try
                Con.Open()
                Dim query3 As String
                query3 = "update ParentsTbl set Name = '" & txtMotherName.Text & "',Phone = '" & txtMotherPhone.Text & "',Live_Status = '" & txtMotherAlive.Text & "' where Id ='" & memberMotherUniqueId & "' "
                cmd = New SqlCommand(query3, Con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Parents Details updated successfully", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        Else
            Try
                Con.Open()
                Dim query3 As String
                query3 = "update ParentsTbl set Name = '" & txtMotherName.Text & "',Phone = '" & txtMotherPhone.Text & "',Live_Status = '" & txtMotherDead.Text & "' where Id ='" & memberMotherUniqueId & "' "
                cmd = New SqlCommand(query3, Con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Parents Details updated successfully", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        End If
    End Sub
    Private Sub IconButton8_Click(sender As Object, e As EventArgs) Handles IconButton8.Click
        AddNewBeneficiary.Hide()
        If (txtMotherName.ReadOnly = False) Then

            txtMotherName.ReadOnly = True
            txtMotherPhone.ReadOnly = True
            txtFatherName.ReadOnly = True
            txtFatherPhone.ReadOnly = True
            UpdateParents()
        Else
            MsgBox("Can't update, no changes in the Parents Details", MsgBoxStyle.Exclamation)
        End If

    End Sub

    ''Function to show member Beneficiaries on Profile Page
    Private Function MemberBeneficiaries()
        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            AddNewBeneficiary.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    Private Sub IconButton5_Click(sender As Object, e As EventArgs) Handles IconButton5.Click
        MemberBeneficiaries()
        AddNewBeneficiary.Show()
    End Sub

    Private Sub previousBtn_Click(sender As Object, e As EventArgs) Handles previousBtn.Click
        AddNewBeneficiary.Hide()
        '  Dim nwSecEditMemberProfile = SecEditMemberProfile
        switchPagesUser(SecEditMemberProfile)
    End Sub
End Class