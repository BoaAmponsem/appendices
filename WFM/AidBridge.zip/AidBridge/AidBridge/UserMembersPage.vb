﻿Imports System.Data.SqlClient
Imports System.Net
Imports Microsoft.Reporting.WinForms
Public Class UserMembersPage
    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Hometown,Birth_Date,Registration_Date,Operator from MembersTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Surname  like '%' +@parm1+ '%' "
            query &= " or Staff_ID like '%' +@parm1+ '%' "
            query &= " or Phone like '%' +@parm1+ '%' "
            query &= " or Marital_Status like '%' +@parm1+ '%' "
            query &= " or Other_Names like '%' +@parm1+ '%' "
            query &= " or Birth_Date like '%' +@parm1+ '%' "
            query &= " or Sex like '%' +@parm1+ '%' "
            query &= " or Postal_Address like '%' +@parm1+ '%' "
            query &= " or Registration_Date like '%' +@parm1+ '%' "
            query &= " or Operator like '%' +@parm1+ '%' "
            query &= " or Hometown like '%' +@parm1+ '%' "
            query &= " or House_No like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using

            Dim deleteButtonColumn As New DataGridViewButtonColumn()
            deleteButtonColumn.HeaderText = ""
            deleteButtonColumn.Text = "Delete"
            deleteButtonColumn.Name = "DeleteBtn"
            deleteButtonColumn.UseColumnTextForButtonValue = True

            Dim EditButtonColumn2 As New DataGridViewButtonColumn()
            EditButtonColumn2.HeaderText = ""
            EditButtonColumn2.Text = "Edit"
            EditButtonColumn2.Name = "EditBtn"
            EditButtonColumn2.UseColumnTextForButtonValue = True


            If membersDataGridView.Columns("DeleteBtn") Is Nothing Then
                membersDataGridView.Columns.Add(deleteButtonColumn)
            End If
            ' membersDataGridView.Columns.Add(deleteButtonColumn)
            If membersDataGridView.Columns("EditBtn") Is Nothing Then
                membersDataGridView.Columns.Add(EditButtonColumn2)
            End If
            ' membersDataGridView.Columns.Add(EditButtonColumn2)

            ' deleteButtonColumn.Image = My.Resources.approve
            'deleteButtonColumn.Name = "Delete"
            ' deleteButtonColumn.ImageLayout = DataGridViewImageCellLayout.Zoom
            '  membersDataGridView.Columns.Add(deleteButtonColumn)
            ' membersDataGridView.Columns.Add(EditButtonColumn2)
            '  End Using
        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function
    Sub switchPages(ByVal pageSwitch1 As Form)
        Try

            UserPage.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            UserPage.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        'Dim nwUserAddMembersPage1 = New UserAddMemberPage1
        resetAllMemberFormsUser()
        switchPages(UserAddMemberPage1)
    End Sub

    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Hometown,Birth_Date,Registration_Date,Operator from MembersTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            membersDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try

        Dim deleteButtonColumn As New DataGridViewButtonColumn()
        deleteButtonColumn.HeaderText = ""
        deleteButtonColumn.Text = "Remove"
        deleteButtonColumn.Name = "DeleteBtn"
        deleteButtonColumn.UseColumnTextForButtonValue = True

        Dim EditButtonColumn2 As New DataGridViewButtonColumn()
        EditButtonColumn2.HeaderText = ""
        EditButtonColumn2.Text = "Edit"
        EditButtonColumn2.Name = "EditBtn"
        EditButtonColumn2.UseColumnTextForButtonValue = True

        ' deleteButtonColumn.Image = My.Resources.approve
        'deleteButtonColumn.Name = "Delete"
        ' deleteButtonColumn.ImageLayout = DataGridViewImageCellLayout.Zoom
        If membersDataGridView.Columns("DeleteBtn") Is Nothing Then
            membersDataGridView.Columns.Add(deleteButtonColumn)
        End If
        ' membersDataGridView.Columns.Add(deleteButtonColumn)
        If membersDataGridView.Columns("EditBtn") Is Nothing Then
            membersDataGridView.Columns.Add(EditButtonColumn2)
        End If
        ' membersDataGridView.Columns.Add(EditButtonColumn2)
    End Sub
    Private Sub PopulateRefresh()
        Try
            Con.Open()
            Dim query = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Hometown,Birth_Date,Registration_Date,Operator from MembersTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            membersDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

    End Sub

    Private Sub PopulateBirthdays()
        Dim currentDay As Integer = DateTime.Now.Day
        Dim currentMonth As Integer = DateTime.Now.Month

        Try
            Con.Open()
            ' SQL query to select all records
            Dim query As String = "SELECT Id, Staff_ID, Surname, Other_Names, Phone, Sex, Birth_Date FROM MembersTbl"

            Using command As New SqlCommand(query, Con)
                ' Create a data adapter
                Using adaptor As New SqlDataAdapter(command)
                    Dim ds As New DataSet()
                    adaptor.Fill(ds)

                    ' Create a DataTable to hold valid date records
                    Dim filteredTable As New DataTable()
                    filteredTable.Columns.Add("Id", GetType(Integer))
                    filteredTable.Columns.Add("Staff_ID", GetType(String))
                    filteredTable.Columns.Add("Surname", GetType(String))
                    filteredTable.Columns.Add("Other_Names", GetType(String))
                    filteredTable.Columns.Add("Phone", GetType(String))
                    filteredTable.Columns.Add("Sex", GetType(String))
                    filteredTable.Columns.Add("Birth_Date", GetType(String))

                    ' Iterate through the records and parse the Birth_Date column
                    For Each row As DataRow In ds.Tables(0).Rows
                        Dim birthDateString As String = row("Birth_Date").ToString()
                        Dim birthDate As DateTime
                        If DateTime.TryParse(birthDateString, birthDate) Then
                            If birthDate.Day = currentDay AndAlso birthDate.Month = currentMonth Then
                                ' Add the valid and matching record to the filtered table
                                filteredTable.Rows.Add(row("Id"), row("Staff_ID"), row("Surname"), row("Other_Names"), row("Phone"), row("Sex"), row("Birth_Date"))
                            End If
                        End If
                    Next

                    ' Bind the filtered table to the DataGridView
                    birthdaysDataGridView.DataSource = filteredTable
                End Using
            End Using
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        ' Create and add the Send Alert button column
        Dim sendSmsButtonColumn As New DataGridViewButtonColumn()
        sendSmsButtonColumn.HeaderText = ""
        sendSmsButtonColumn.Text = "Send Wish"
        sendSmsButtonColumn.Name = "sendWish"
        sendSmsButtonColumn.UseColumnTextForButtonValue = True

        ' Add the button column to the DataGridView if it doesn't already exist
        If birthdaysDataGridView.Columns("sendWish") Is Nothing Then
            birthdaysDataGridView.Columns.Add(sendSmsButtonColumn)
        End If

    End Sub

    Private Sub UserMembersPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
        PopulateBirthdays()
    End Sub

    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        membersDataGridView.DataSource = Me.SearchItem
    End Sub

    Private Sub PopulateChild()
        Try
            Con.Open()
            Dim query = "select Id,Name,Birth_Date from ChildrenTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            UserEditMemberProfile.childrenDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub membersDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles membersDataGridView.CellContentClick
        Try
            If (e.RowIndex >= 0 AndAlso e.ColumnIndex = membersDataGridView.Columns("DeleteBtn").Index) Then

                Dim rowID As Integer = Convert.ToInt32(membersDataGridView.Rows(e.RowIndex).Cells("Id").Value)

                Dim row As DataGridViewRow = membersDataGridView.Rows(e.RowIndex)

                getStaffIDToEdit = row.Cells(3).Value.ToString
                theMemberNam = row.Cells(4).Value.ToString
                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Staff_ID='" & getStaffIDToEdit & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUserStaffID = myReader("Staff_ID")
                    memberUserSurname = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")
                    profilePicture = CType(myReader("Picture"), Byte())
                    memberRegistrationDate = myReader("Registration_Date")
                    memberUserOperator = myReader("Operator")

                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                Dim deleteDialog As DialogResult = MessageBox.Show("Remove " + theMemberNam + " with Staff ID " + "(" + getStaffIDToEdit + ")" + " from the Welfare Scheme", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If (deleteDialog = DialogResult.Yes) Then

                    removeMember(getStaffIDToEdit, Uname, UStaffID)
                    PopulateRefresh()

                End If


            ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = membersDataGridView.Columns("EditBtn").Index) Then

                Dim rowID As Integer = Convert.ToInt32(membersDataGridView.Rows(e.RowIndex).Cells("Id").Value)
                Dim row As DataGridViewRow = membersDataGridView.Rows(e.RowIndex)

                theMemberNam = row.Cells(4).Value.ToString
                getStaffIDToEdit = row.Cells(3).Value.ToString
                ''Read member Info
                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Staff_ID='" & getStaffIDToEdit & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUniqueId = myReader("Id")
                    memberUserStaffID = myReader("Staff_ID")
                    memberUserSurname = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")
                    profilePicture = CType(myReader("Picture"), Byte())
                    ' memberRegistrationDate = myReader("Registration_Date")
                    'memberUserOperator = myReader("Operator")

                    UserEditMemberProfile.txtMemberSurname.Text = memberUserSurname.ToUpper
                    UserEditMemberProfile.txtMemberOthername.Text = memberUserOthername.ToUpper
                    UserEditMemberProfile.txtMemberSex.Text = memberUserSex
                    UserEditMemberProfile.txtMemberPhone.Text = memberUserPhone
                    UserEditMemberProfile.txtMemberHouseNo.Text = memberUserHouseNo.ToUpper
                    UserEditMemberProfile.txtMemberPostalAddress.Text = memberUserPostalAddress.ToUpper
                    UserEditMemberProfile.txtMaritalStatus.Text = memberUserMaritalStatus
                    UserEditMemberProfile.txtTypeOfMarriage.Text = memberUserTypeOfMarriage
                    UserEditMemberProfile.txtMemberHometown.Text = memberUserHomeTown.ToUpper
                    UserEditMemberProfile.txtMemberDoB1.Text = memberUserDoB
                    UserEditMemberProfile.txtMemberStaffID.Text = memberUserStaffID.ToUpper
                    UserEditMemberProfile.txtImageName.Text = ""

                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try
                Dim checkSpouse As Integer = 0
                'Check if member is Married
                Try
                    Cursor = Cursors.WaitCursor
                    Con.Open()
                    Dim query22 As String = "select * from SpouseTbl where Member_ID='" & getStaffIDToEdit & "'"
                    cmd = New SqlCommand(query22, Con)
                    adaptor = New SqlDataAdapter(cmd)
                    ds = New DataSet()
                    adaptor.Fill(ds)
                    checkNoSpouse = ds.Tables(0).Rows.Count

                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Cursor = Cursors.Default
                    Con.Close()
                End Try

                If (checkNoSpouse <> 0) Then
                    'Read member Spouse Info
                    Try
                        Con.Open()
                        Dim query = "select * from SpouseTbl where Member_ID='" & getStaffIDToEdit & "'"
                        cmd = New SqlCommand(query, Con)
                        myReader = cmd.ExecuteReader
                        myReader.Read()
                        memberSpouseUniqueId = myReader("Id")
                        memberUserSpouseName = myReader("Name")
                        memberUserSpousePhone = myReader("Phone")
                        memberUserSpouseAddress = myReader("Contact_Address")

                        'Spouse Info
                        UserEditMemberProfile.txtSpouseName.Text = memberUserSpouseName.ToUpper
                        UserEditMemberProfile.txtSpousePhone.Text = memberUserSpousePhone
                        UserEditMemberProfile.txtSpouseAddress.Text = memberUserSpouseAddress.ToUpper
                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try
                Else
                    UserEditMemberProfile.txtSpouseName.Text = ""
                    UserEditMemberProfile.txtSpousePhone.Text = ""
                    UserEditMemberProfile.txtSpouseAddress.Text = ""
                    memberUserSpouseName = ""
                    memberUserSpousePhone = ""
                    memberUserSpouseAddress = ""
                End If

                'Read member Father Info
                Try
                    Con.Open()
                    Dim query = "select * from ParentsTbl where Member_ID='" & getStaffIDToEdit & "' and Parent_Type ='" & AFather & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberFatherUniqueId = myReader("Id")
                    memberUserFathername = myReader("Name")
                    memberUserFatherPhone = myReader("Phone")
                    memberUserFatherLiveStatus = myReader("Live_Status")

                    If (memberUserFatherLiveStatus = "Dead") Then
                        UserEditMemberProfile2.txtFatherDead.Checked = True
                    Else
                        UserEditMemberProfile2.txtFatherAlive.Checked = True
                    End If
                    UserEditMemberProfile2.txtFatherName.Text = memberUserFathername.ToUpper
                    UserEditMemberProfile2.txtFatherPhone.Text = memberUserFatherPhone

                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                'Read member Mother Info
                Try
                    Con.Open()
                    Dim query = "select * from ParentsTbl where Member_ID='" & getStaffIDToEdit & "' and Parent_Type ='" & AMother & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberMotherUniqueId = myReader("Id")
                    memberUserMothername = myReader("Name")
                    memberUserMotherPhone = myReader("Phone")
                    memberUserMotherLiveStatus = myReader("Live_Status")

                    If (memberUserMotherLiveStatus = "Dead") Then
                        UserEditMemberProfile2.txtMotherDead.Checked = True

                    Else
                        UserEditMemberProfile2.txtMotherAlive.Checked = True
                    End If
                    UserEditMemberProfile2.txtMotherName.Text = memberUserMothername.ToUpper
                    UserEditMemberProfile2.txtMotherPhone.Text = memberUserMotherPhone

                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try
                PopulateChild()
                switchPages(UserEditMemberProfile)

            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub sendWishSMS(memberName1, membOtherName1, memberStaffID1, recipient1)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient1 + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName1 & " " & membOtherName1 & "(Staff ID: " & memberStaffID1 & "). Wishing you the happiest of birthdays! May your special day be filled with love, joy, and the warmth of those who cherish you. Here's to a year ahead overflowing with success, health, and happiness.  Happy Birthday!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()


        Try
            Dim response As String = client.DownloadString(baseURL)
            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)

            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. Wish not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse2 = "Successfully Sent") Then
                MsgBox("Wish sent successfully", MsgBoxStyle.Information)
                txtResponseMaskedTextBox.Text = ""
            End If
        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                resendWishSMS(memFirstName, membOtherName, membID, membNumber)
            End If
        Finally
            Cursor = Cursors.Default
        End Try

    End Sub

    Private Sub resendWishSMS(memberName1, membOtherName1, memberStaffID1, recipient1)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient1 + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName1 & " " & membOtherName1 & "(Staff ID: " & memberStaffID1 & "). Wishing you the happiest of birthdays! May your special day be filled with love, joy, and the warmth of those who cherish you. Here's to a year ahead overflowing with success, health, and happiness.  Happy Birthday!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()


        Try
            Dim response As String = client.DownloadString(baseURL)
            ' If (row <= 0) Then
            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)

            If (getTheResponse = "Insufficient balance") Then
                MsgBox("Insufficient sms balance. Wish not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            ElseIf (getTheResponse2 = "Successfully Sent") Then
                MsgBox("Wish sent successfully", MsgBoxStyle.Information)
                txtResponseMaskedTextBox.Text = ""
            End If


            'End If


        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                sendWishSMS(memFirstName, membOtherName, membID, membNumber)
                '' btnAlertAll.PerformClick()
            End If
        Finally
            Cursor = Cursors.Default
            '' MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub
    Dim defaultID As String, membID As String, memFirstName As String, membOtherName As String, membNumber As String
    Dim row As Integer

    Private Sub sendWishAllSMS(memberName1, membOtherName1, memberStaffID1, recipient1)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient1 + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName1 & " " & membOtherName1 & "(Staff ID: " & memberStaffID1 & "). Wishing you the happiest of birthdays! May your special day be filled with love, joy, and the warmth of those who cherish you. Here's to a year ahead overflowing with success, health, and happiness.  Happy Birthday!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()
        'Dim url As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=0247086663&from=SenderID&sms=YourMessage"


        Try
            Dim response As String = client.DownloadString(baseURL)

            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)

            If (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                MsgBox("Check if " & memberName1 & "(Staff-ID: " & memberStaffID1 & ") contact is correct. Wish not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            End If

            If (row <= 0) Then

                If (getTheResponse = "Insufficient balance") Then
                    MsgBox("Insufficient sms balance. Wish not sent!", MsgBoxStyle.Exclamation)
                    txtResponseMaskedTextBox.Text = ""
                ElseIf (getTheResponse2 = "Successfully Sent") Then
                    MsgBox("Wish sent successfully", MsgBoxStyle.Information)
                    txtResponseMaskedTextBox.Text = ""
                End If
                'MsgBox("Wish sent successfully", MsgBoxStyle.Information)
            End If
        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                resendWishAllSMS(memFirstName, membOtherName, membID, membNumber)
            End If
        Finally
            Cursor = Cursors.Default
        End Try

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        LoadMembersReport()
    End Sub

    Private Sub resendWishAllSMS(memberName1, membOtherName1, memberStaffID1, recipient1)
        ' Define the base URL and API key
        Cursor = Cursors.WaitCursor
        Dim baseURL As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=WVFIb1F6S1R3a0VoQ1lzeFpoUFM&to=" + recipient1 + "&from=WELFARE SDA" + "&sms=" + "Hi " & memberName1 & " " & membOtherName1 & "(Staff ID: " & memberStaffID1 & "). Wishing you the happiest of birthdays! May your special day be filled with love, joy, and the warmth of those who cherish you. Here's to a year ahead overflowing with success, health, and happiness.  Happy Birthday!  [SDA HOSPITAL,SUNYANI]"

        ' Ensure TLS 1.2 is used
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        Dim client As New WebClient()
        'Dim url As String = "https://sms.arkesel.com/sms/api?action=send-sms&api_key=SVRKWUlnckZBTkJtU3pGZXlVUEI&to=0247086663&from=SenderID&sms=YourMessage"


        Try
            Dim response As String = client.DownloadString(baseURL)

            txtResponseMaskedTextBox.Text = response

            Dim getTheResponse = txtResponseMaskedTextBox.Text.Substring(25, 20)
            Dim getTheResponse2 = txtResponseMaskedTextBox.Text.Substring(24, 17)

            If (getTheResponse <> "Insufficient balance" And getTheResponse2 <> "Successfully Sent") Then
                MsgBox("Check if " & memberName1 & "(Staff-ID: " & memberStaffID1 & ") contact is correct. Wish not sent!", MsgBoxStyle.Exclamation)
                txtResponseMaskedTextBox.Text = ""
            End If

            If (row <= 0) Then
                If (getTheResponse = "Insufficient balance") Then
                    MsgBox("Insufficient sms balance. Wish not sent!", MsgBoxStyle.Exclamation)
                    txtResponseMaskedTextBox.Text = ""
                ElseIf (getTheResponse2 = "Successfully Sent") Then
                    MsgBox("Wish sent successfully", MsgBoxStyle.Information)
                    txtResponseMaskedTextBox.Text = ""
                End If
                'MsgBox("Wish sent successfully", MsgBoxStyle.Information)
            End If

        Catch ex As Exception
            Dim smsDialog As DialogResult = MessageBox.Show("An error occurred while sending 'SMS'.'Check your internet connection!'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
            If (smsDialog = DialogResult.Retry) Then
                sendWishAllSMS(memFirstName, membOtherName, membID, membNumber)
                '' btnAlertAll.PerformClick()
            End If
        Finally
            Cursor = Cursors.Default
            '' MsgBox("An error occurred: " & ex.Message, MsgBoxStyle.Critical)
        End Try

    End Sub
    Private Sub btnWishAll_Click(sender As Object, e As EventArgs) Handles btnWishAll.Click
        ' MsgBox(debtorsDataGridView.RowCount)
        Dim alertSmsDialog As DialogResult = MessageBox.Show("Wish all", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        Try
            If (alertSmsDialog = DialogResult.Yes) Then
                For row = 0 To birthdaysDataGridView.RowCount - 1
                    ' Rows(row).Cells(0).Value.ToString
                    defaultID = birthdaysDataGridView.Rows(row).Cells(1).Value.ToString
                    ' MsgBox(defaultID)
                    membID = birthdaysDataGridView.Rows(row).Cells(2).Value.ToString
                    memFirstName = birthdaysDataGridView.Rows(row).Cells(3).Value.ToString
                    membOtherName = birthdaysDataGridView.Rows(row).Cells(4).Value.ToString
                    membNumber = birthdaysDataGridView.Rows(row).Cells(5).Value.ToString
                    ' contributAmount = debtorsDataGridView.Rows(row).Cells(6).Value.ToString

                    '  getLastPaymentMonth(defaultID)

                    '' MsgBox(defaultID + ", " + membID + ", " + memFirstName + ", " + membOtherName + ", " + membNumber + ", " + theLastMonthOfPayment.ToString("MMMM") + "," + theLastMonthOfPayment.Year.ToString + ", " + DateTime.Now.ToString("MMMM") + "," + DateTime.Now.Year.ToString)
                    sendWishAllSMS(memFirstName, membOtherName, membID, membNumber)


                Next
            End If
        Catch ex As Exception

        End Try
    End Sub


    Private Sub birthdaysDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles birthdaysDataGridView.CellContentClick
        Try
            If (e.RowIndex >= 0 AndAlso e.ColumnIndex = birthdaysDataGridView.Columns("sendWish").Index) Then
                Dim alertSmsDialog As DialogResult = MessageBox.Show("Send wish", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If (alertSmsDialog = DialogResult.Yes) Then
                    ' Dim rowID As Integer = Convert.ToInt32(membersDataGridView.Rows(e.RowIndex).Cells("Id").Value)
                    Dim row As DataGridViewRow = birthdaysDataGridView.Rows(e.RowIndex)
                    defaultID = row.Cells(1).Value.ToString
                    ' MsgBox(defaultID)
                    membID = row.Cells(2).Value.ToString
                    memFirstName = row.Cells(3).Value.ToString
                    membOtherName = row.Cells(4).Value.ToString
                    membNumber = row.Cells(5).Value.ToString
                    '  contributAmount = row.Cells(6).Value.ToString

                    ' MsgBox(defaultID + ", " + membID + ", " + memFirstName + ", " + membOtherName + ", " + membNumber)
                    sendWishSMS(memFirstName, membOtherName, membID, membNumber)

                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    'Members report Sub
    Sub LoadMembersReport()
        Cursor = Cursors.WaitCursor

        Dim rptDS As ReportDataSource
        Print_Members.MembersReport.RefreshReport()
        Try

            With Print_Members.MembersReport.LocalReport
                .ReportPath = Application.StartupPath & "\Reports\MembersReport1.rdlc"
                .DataSources.Clear()
            End With
            Dim dss As New MembersDataSet2
            Dim da As New SqlDataAdapter

            Con.Open()
            Dim Queryy As String = "SELECT Staff_ID, Surname, Other_Names, Phone, Sex, House_No, Postal_Address, Marital_Status, Marriage_Type, Hometown, Birth_Date FROM MembersTbl"

            da.SelectCommand = New SqlCommand(Queryy, Con)
            'da.SelectCommand.Parameters.AddWithValue("@StartDate", fromDateTimePicker.Value)
            ' da.SelectCommand.Parameters.AddWithValue("@EndDate", toDateTimePicker2.Value)
            da.Fill(dss.Tables("MembersTbl"))
            Con.Close()
            rptDS = New ReportDataSource("DataSet1", dss.Tables("MembersTbl"))
            Print_Members.MembersReport.LocalReport.DataSources.Add(rptDS)
            Print_Members.MembersReport.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Print_Members.MembersReport.ZoomMode = ZoomMode.Percent
            Print_Members.MembersReport.ZoomPercent = 100
        Catch ex As SqlException
            Con.Close()
            MsgBox(ex.Message)
        End Try

        Print_Members.Show()

        Cursor = Cursors.Default
    End Sub
End Class