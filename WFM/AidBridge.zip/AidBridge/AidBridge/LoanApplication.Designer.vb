﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LoanApplication
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtApplicantID = New System.Windows.Forms.MaskedTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtApplicantPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtApplicantSex = New System.Windows.Forms.ComboBox()
        Me.txtApplicantSurname = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BackBtn = New FontAwesome.Sharp.IconButton()
        Me.RequestBtn = New FontAwesome.Sharp.IconButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.txtApplicantID)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtApplicantPhone)
        Me.GroupBox1.Controls.Add(Me.txtApplicantSex)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.txtApplicantSurname)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(17, 43)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(967, 146)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "PERSONAL DETAILS"
        '
        'txtApplicantID
        '
        Me.txtApplicantID.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtApplicantID.Location = New System.Drawing.Point(500, 46)
        Me.txtApplicantID.Name = "txtApplicantID"
        Me.txtApplicantID.Size = New System.Drawing.Size(138, 21)
        Me.txtApplicantID.TabIndex = 24
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(497, 29)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 15)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Staff ID:"
        '
        'txtApplicantPhone
        '
        Me.txtApplicantPhone.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtApplicantPhone.Location = New System.Drawing.Point(799, 47)
        Me.txtApplicantPhone.Name = "txtApplicantPhone"
        Me.txtApplicantPhone.Size = New System.Drawing.Size(148, 21)
        Me.txtApplicantPhone.TabIndex = 12
        '
        'txtApplicantSex
        '
        Me.txtApplicantSex.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtApplicantSex.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtApplicantSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtApplicantSex.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtApplicantSex.FormattingEnabled = True
        Me.txtApplicantSex.Items.AddRange(New Object() {"", "Male", "Female"})
        Me.txtApplicantSex.Location = New System.Drawing.Point(668, 46)
        Me.txtApplicantSex.Name = "txtApplicantSex"
        Me.txtApplicantSex.Size = New System.Drawing.Size(99, 23)
        Me.txtApplicantSex.TabIndex = 10
        '
        'txtApplicantSurname
        '
        Me.txtApplicantSurname.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtApplicantSurname.Location = New System.Drawing.Point(9, 46)
        Me.txtApplicantSurname.Multiline = True
        Me.txtApplicantSurname.Name = "txtApplicantSurname"
        Me.txtApplicantSurname.Size = New System.Drawing.Size(457, 21)
        Me.txtApplicantSurname.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(800, 29)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 15)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Phone:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(672, 28)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(26, 15)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Sex:"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Name:"
        '
        'BackBtn
        '
        Me.BackBtn.BackColor = System.Drawing.Color.White
        Me.BackBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BackBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.BackBtn.ForeColor = System.Drawing.Color.Black
        Me.BackBtn.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft
        Me.BackBtn.IconColor = System.Drawing.Color.DarkGreen
        Me.BackBtn.IconSize = 18
        Me.BackBtn.Location = New System.Drawing.Point(13, 5)
        Me.BackBtn.Name = "BackBtn"
        Me.BackBtn.Rotation = 0R
        Me.BackBtn.Size = New System.Drawing.Size(48, 23)
        Me.BackBtn.TabIndex = 7
        Me.BackBtn.UseVisualStyleBackColor = False
        '
        'RequestBtn
        '
        Me.RequestBtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RequestBtn.BackColor = System.Drawing.Color.SeaGreen
        Me.RequestBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RequestBtn.FlatAppearance.BorderSize = 0
        Me.RequestBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RequestBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.RequestBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RequestBtn.ForeColor = System.Drawing.Color.White
        Me.RequestBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.RequestBtn.IconColor = System.Drawing.Color.Black
        Me.RequestBtn.IconSize = 16
        Me.RequestBtn.Location = New System.Drawing.Point(426, 236)
        Me.RequestBtn.Name = "RequestBtn"
        Me.RequestBtn.Rotation = 0R
        Me.RequestBtn.Size = New System.Drawing.Size(153, 30)
        Me.RequestBtn.TabIndex = 8
        Me.RequestBtn.Text = "Send Request"
        Me.RequestBtn.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 85)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 15)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Amount:"
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox1.Location = New System.Drawing.Point(12, 104)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(176, 22)
        Me.TextBox1.TabIndex = 9
        '
        'LoanApplication
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(996, 531)
        Me.Controls.Add(Me.RequestBtn)
        Me.Controls.Add(Me.BackBtn)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "LoanApplication"
        Me.Text = "LoanApplication"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BackBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtApplicantID As MaskedTextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtApplicantPhone As MaskedTextBox
    Friend WithEvents txtApplicantSex As ComboBox
    Friend WithEvents txtApplicantSurname As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents RequestBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label3 As Label
End Class
