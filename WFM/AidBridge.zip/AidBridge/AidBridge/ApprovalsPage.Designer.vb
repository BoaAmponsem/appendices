﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LoansPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.membersDataGridView = New System.Windows.Forms.DataGridView()
        Me.IconButton3 = New FontAwesome.Sharp.IconButton()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.txtSearchItem = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.memberNotFoundFeedback = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.memberNoFTxt = New System.Windows.Forms.Label()
        Me.InformationTab = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtStaffID = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtPostalAddress = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtHouseNo = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtMaritalStatus = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtHomeTown = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtSex = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBirthDate = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtMemberOtherName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.makePaymentGroupBox = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtPaidIBy = New System.Windows.Forms.MaskedTextBox()
        Me.payBtn = New FontAwesome.Sharp.IconButton()
        Me.txtMonthOfPayment = New System.Windows.Forms.MaskedTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtAmount = New System.Windows.Forms.MaskedTextBox()
        Me.ContributionsGroupBox = New System.Windows.Forms.GroupBox()
        Me.memberContributionsDataGridView = New System.Windows.Forms.DataGridView()
        Me.selectIDType = New System.Windows.Forms.ComboBox()
        Me.searchBox = New System.Windows.Forms.TextBox()
        Me.QueryBtn = New FontAwesome.Sharp.IconButton()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.membersDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.memberNotFoundFeedback.SuspendLayout()
        Me.InformationTab.SuspendLayout()
        Me.makePaymentGroupBox.SuspendLayout()
        Me.ContributionsGroupBox.SuspendLayout()
        CType(Me.memberContributionsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(908, 492)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.IconButton2)
        Me.TabPage1.Controls.Add(Me.membersDataGridView)
        Me.TabPage1.Controls.Add(Me.IconButton3)
        Me.TabPage1.Controls.Add(Me.IconButton1)
        Me.TabPage1.Controls.Add(Me.txtSearchItem)
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(900, 464)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Borrowers"
        '
        'Panel1
        '
        Me.Panel1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.RadioButton4)
        Me.Panel1.Controls.Add(Me.RadioButton3)
        Me.Panel1.Controls.Add(Me.RadioButton2)
        Me.Panel1.Controls.Add(Me.RadioButton1)
        Me.Panel1.Location = New System.Drawing.Point(222, 76)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(475, 32)
        Me.Panel1.TabIndex = 16
        '
        'RadioButton4
        '
        Me.RadioButton4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Checked = True
        Me.RadioButton4.Location = New System.Drawing.Point(27, 7)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(76, 19)
        Me.RadioButton4.TabIndex = 3
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "Borrowers"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(355, 7)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(97, 19)
        Me.RadioButton3.TabIndex = 2
        Me.RadioButton3.Text = "Approved List"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(128, 7)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(85, 19)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.Text = "Pending List"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(243, 7)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(89, 19)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "Declined List"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'IconButton2
        '
        Me.IconButton2.BackColor = System.Drawing.Color.SeaGreen
        Me.IconButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton2.ForeColor = System.Drawing.Color.White
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.PlusCircle
        Me.IconButton2.IconColor = System.Drawing.Color.White
        Me.IconButton2.IconSize = 20
        Me.IconButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton2.Location = New System.Drawing.Point(14, 74)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(108, 35)
        Me.IconButton2.TabIndex = 15
        Me.IconButton2.Text = "New Applicant"
        Me.IconButton2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'membersDataGridView
        '
        Me.membersDataGridView.AllowUserToAddRows = False
        Me.membersDataGridView.AllowUserToDeleteRows = False
        Me.membersDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.membersDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.membersDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.membersDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.membersDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.membersDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.membersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.membersDataGridView.DefaultCellStyle = DataGridViewCellStyle1
        Me.membersDataGridView.Location = New System.Drawing.Point(9, 112)
        Me.membersDataGridView.MultiSelect = False
        Me.membersDataGridView.Name = "membersDataGridView"
        Me.membersDataGridView.ReadOnly = True
        Me.membersDataGridView.RowHeadersVisible = False
        Me.membersDataGridView.RowTemplate.Height = 32
        Me.membersDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.membersDataGridView.Size = New System.Drawing.Size(881, 342)
        Me.membersDataGridView.TabIndex = 14
        '
        'IconButton3
        '
        Me.IconButton3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton3.BackColor = System.Drawing.Color.White
        Me.IconButton3.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton3.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton3.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton3.IconColor = System.Drawing.Color.Black
        Me.IconButton3.IconSize = 16
        Me.IconButton3.Location = New System.Drawing.Point(8, 69)
        Me.IconButton3.Name = "IconButton3"
        Me.IconButton3.Rotation = 0R
        Me.IconButton3.Size = New System.Drawing.Size(884, 44)
        Me.IconButton3.TabIndex = 13
        Me.IconButton3.UseVisualStyleBackColor = False
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton1.BackColor = System.Drawing.Color.SeaGreen
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen
        Me.IconButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.ForestGreen
        Me.IconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.Search
        Me.IconButton1.IconColor = System.Drawing.Color.White
        Me.IconButton1.IconSize = 19
        Me.IconButton1.Location = New System.Drawing.Point(293, 14)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(41, 28)
        Me.IconButton1.TabIndex = 12
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'txtSearchItem
        '
        Me.txtSearchItem.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtSearchItem.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchItem.Location = New System.Drawing.Point(333, 14)
        Me.txtSearchItem.Multiline = True
        Me.txtSearchItem.Name = "txtSearchItem"
        Me.txtSearchItem.Size = New System.Drawing.Size(311, 28)
        Me.txtSearchItem.TabIndex = 11
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage2.Controls.Add(Me.memberNotFoundFeedback)
        Me.TabPage2.Controls.Add(Me.InformationTab)
        Me.TabPage2.Controls.Add(Me.makePaymentGroupBox)
        Me.TabPage2.Controls.Add(Me.ContributionsGroupBox)
        Me.TabPage2.Controls.Add(Me.selectIDType)
        Me.TabPage2.Controls.Add(Me.searchBox)
        Me.TabPage2.Controls.Add(Me.QueryBtn)
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(900, 464)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Loan Payment"
        '
        'memberNotFoundFeedback
        '
        Me.memberNotFoundFeedback.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.memberNotFoundFeedback.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.memberNotFoundFeedback.Controls.Add(Me.Label14)
        Me.memberNotFoundFeedback.Controls.Add(Me.memberNoFTxt)
        Me.memberNotFoundFeedback.Location = New System.Drawing.Point(747, 7)
        Me.memberNotFoundFeedback.Name = "memberNotFoundFeedback"
        Me.memberNotFoundFeedback.Size = New System.Drawing.Size(136, 40)
        Me.memberNotFoundFeedback.TabIndex = 36
        Me.memberNotFoundFeedback.Visible = False
        '
        'Label14
        '
        Me.Label14.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(123, -2)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(12, 15)
        Me.Label14.TabIndex = 22
        Me.Label14.Text = "x"
        '
        'memberNoFTxt
        '
        Me.memberNoFTxt.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.memberNoFTxt.AutoSize = True
        Me.memberNoFTxt.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.memberNoFTxt.ForeColor = System.Drawing.Color.White
        Me.memberNoFTxt.Location = New System.Drawing.Point(8, 11)
        Me.memberNoFTxt.Name = "memberNoFTxt"
        Me.memberNoFTxt.Size = New System.Drawing.Size(121, 20)
        Me.memberNoFTxt.TabIndex = 6
        Me.memberNoFTxt.Text = "Creditor not found"
        '
        'InformationTab
        '
        Me.InformationTab.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.InformationTab.BackColor = System.Drawing.Color.White
        Me.InformationTab.Controls.Add(Me.Label9)
        Me.InformationTab.Controls.Add(Me.txtStaffID)
        Me.InformationTab.Controls.Add(Me.Label11)
        Me.InformationTab.Controls.Add(Me.txtPhone)
        Me.InformationTab.Controls.Add(Me.Label12)
        Me.InformationTab.Controls.Add(Me.txtPostalAddress)
        Me.InformationTab.Controls.Add(Me.Label5)
        Me.InformationTab.Controls.Add(Me.txtHouseNo)
        Me.InformationTab.Controls.Add(Me.Label7)
        Me.InformationTab.Controls.Add(Me.txtMaritalStatus)
        Me.InformationTab.Controls.Add(Me.Label8)
        Me.InformationTab.Controls.Add(Me.txtHomeTown)
        Me.InformationTab.Controls.Add(Me.Label4)
        Me.InformationTab.Controls.Add(Me.txtSex)
        Me.InformationTab.Controls.Add(Me.Label3)
        Me.InformationTab.Controls.Add(Me.txtBirthDate)
        Me.InformationTab.Controls.Add(Me.Label2)
        Me.InformationTab.Controls.Add(Me.txtMemberOtherName)
        Me.InformationTab.Controls.Add(Me.Label1)
        Me.InformationTab.Controls.Add(Me.txtSurname)
        Me.InformationTab.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InformationTab.Location = New System.Drawing.Point(18, 65)
        Me.InformationTab.Name = "InformationTab"
        Me.InformationTab.Size = New System.Drawing.Size(859, 193)
        Me.InformationTab.TabIndex = 35
        Me.InformationTab.TabStop = False
        Me.InformationTab.Text = "Information"
        Me.InformationTab.Visible = False
        '
        'Label9
        '
        Me.Label9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(489, 82)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(23, 15)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "ID:"
        '
        'txtStaffID
        '
        Me.txtStaffID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtStaffID.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStaffID.Location = New System.Drawing.Point(489, 101)
        Me.txtStaffID.Multiline = True
        Me.txtStaffID.Name = "txtStaffID"
        Me.txtStaffID.ReadOnly = True
        Me.txtStaffID.Size = New System.Drawing.Size(146, 27)
        Me.txtStaffID.TabIndex = 20
        '
        'Label11
        '
        Me.Label11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(243, 134)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 15)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Phone No.:"
        '
        'txtPhone
        '
        Me.txtPhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPhone.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhone.Location = New System.Drawing.Point(243, 153)
        Me.txtPhone.Multiline = True
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.ReadOnly = True
        Me.txtPhone.Size = New System.Drawing.Size(188, 27)
        Me.txtPhone.TabIndex = 18
        '
        'Label12
        '
        Me.Label12.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(8, 134)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 15)
        Me.Label12.TabIndex = 17
        Me.Label12.Text = "Postal Address:"
        '
        'txtPostalAddress
        '
        Me.txtPostalAddress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPostalAddress.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPostalAddress.Location = New System.Drawing.Point(8, 153)
        Me.txtPostalAddress.Multiline = True
        Me.txtPostalAddress.Name = "txtPostalAddress"
        Me.txtPostalAddress.ReadOnly = True
        Me.txtPostalAddress.Size = New System.Drawing.Size(201, 27)
        Me.txtPostalAddress.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(682, 82)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 15)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "House No.:"
        '
        'txtHouseNo
        '
        Me.txtHouseNo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtHouseNo.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHouseNo.Location = New System.Drawing.Point(682, 101)
        Me.txtHouseNo.Multiline = True
        Me.txtHouseNo.Name = "txtHouseNo"
        Me.txtHouseNo.ReadOnly = True
        Me.txtHouseNo.Size = New System.Drawing.Size(152, 27)
        Me.txtHouseNo.TabIndex = 14
        '
        'Label7
        '
        Me.Label7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(240, 82)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 15)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Marital Status:"
        '
        'txtMaritalStatus
        '
        Me.txtMaritalStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMaritalStatus.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMaritalStatus.Location = New System.Drawing.Point(240, 101)
        Me.txtMaritalStatus.Multiline = True
        Me.txtMaritalStatus.Name = "txtMaritalStatus"
        Me.txtMaritalStatus.ReadOnly = True
        Me.txtMaritalStatus.Size = New System.Drawing.Size(188, 27)
        Me.txtMaritalStatus.TabIndex = 10
        '
        'Label8
        '
        Me.Label8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(8, 82)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 15)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Hometown:"
        '
        'txtHomeTown
        '
        Me.txtHomeTown.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtHomeTown.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHomeTown.Location = New System.Drawing.Point(8, 101)
        Me.txtHomeTown.Multiline = True
        Me.txtHomeTown.Name = "txtHomeTown"
        Me.txtHomeTown.ReadOnly = True
        Me.txtHomeTown.Size = New System.Drawing.Size(201, 27)
        Me.txtHomeTown.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(682, 29)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(26, 15)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Sex:"
        '
        'txtSex
        '
        Me.txtSex.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSex.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSex.Location = New System.Drawing.Point(682, 48)
        Me.txtSex.Multiline = True
        Me.txtSex.Name = "txtSex"
        Me.txtSex.ReadOnly = True
        Me.txtSex.Size = New System.Drawing.Size(152, 27)
        Me.txtSex.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(489, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Date of Birth:"
        '
        'txtBirthDate
        '
        Me.txtBirthDate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBirthDate.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBirthDate.Location = New System.Drawing.Point(489, 48)
        Me.txtBirthDate.Multiline = True
        Me.txtBirthDate.Name = "txtBirthDate"
        Me.txtBirthDate.ReadOnly = True
        Me.txtBirthDate.Size = New System.Drawing.Size(146, 27)
        Me.txtBirthDate.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(240, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Other Names:"
        '
        'txtMemberOtherName
        '
        Me.txtMemberOtherName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberOtherName.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMemberOtherName.Location = New System.Drawing.Point(240, 48)
        Me.txtMemberOtherName.Multiline = True
        Me.txtMemberOtherName.Name = "txtMemberOtherName"
        Me.txtMemberOtherName.ReadOnly = True
        Me.txtMemberOtherName.Size = New System.Drawing.Size(188, 27)
        Me.txtMemberOtherName.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Surname:"
        '
        'txtSurname
        '
        Me.txtSurname.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSurname.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSurname.Location = New System.Drawing.Point(8, 48)
        Me.txtSurname.Multiline = True
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.ReadOnly = True
        Me.txtSurname.Size = New System.Drawing.Size(201, 27)
        Me.txtSurname.TabIndex = 0
        '
        'makePaymentGroupBox
        '
        Me.makePaymentGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.makePaymentGroupBox.BackColor = System.Drawing.Color.White
        Me.makePaymentGroupBox.Controls.Add(Me.Label15)
        Me.makePaymentGroupBox.Controls.Add(Me.txtPaidIBy)
        Me.makePaymentGroupBox.Controls.Add(Me.payBtn)
        Me.makePaymentGroupBox.Controls.Add(Me.txtMonthOfPayment)
        Me.makePaymentGroupBox.Controls.Add(Me.Label10)
        Me.makePaymentGroupBox.Controls.Add(Me.txtAmount)
        Me.makePaymentGroupBox.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.makePaymentGroupBox.Location = New System.Drawing.Point(18, 261)
        Me.makePaymentGroupBox.Name = "makePaymentGroupBox"
        Me.makePaymentGroupBox.Size = New System.Drawing.Size(273, 176)
        Me.makePaymentGroupBox.TabIndex = 34
        Me.makePaymentGroupBox.TabStop = False
        Me.makePaymentGroupBox.Text = "Make Payment"
        Me.makePaymentGroupBox.Visible = False
        '
        'Label15
        '
        Me.Label15.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(111, 78)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(49, 15)
        Me.Label15.TabIndex = 87
        Me.Label15.Text = "Paid By:"
        '
        'txtPaidIBy
        '
        Me.txtPaidIBy.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPaidIBy.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPaidIBy.Location = New System.Drawing.Point(37, 96)
        Me.txtPaidIBy.Name = "txtPaidIBy"
        Me.txtPaidIBy.Size = New System.Drawing.Size(205, 21)
        Me.txtPaidIBy.TabIndex = 86
        Me.txtPaidIBy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'payBtn
        '
        Me.payBtn.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.payBtn.BackColor = System.Drawing.Color.OrangeRed
        Me.payBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.payBtn.FlatAppearance.BorderSize = 0
        Me.payBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.payBtn.ForeColor = System.Drawing.Color.White
        Me.payBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.payBtn.IconColor = System.Drawing.Color.Black
        Me.payBtn.IconSize = 16
        Me.payBtn.Location = New System.Drawing.Point(87, 131)
        Me.payBtn.Name = "payBtn"
        Me.payBtn.Rotation = 0R
        Me.payBtn.Size = New System.Drawing.Size(92, 29)
        Me.payBtn.TabIndex = 84
        Me.payBtn.Text = "Pay"
        Me.payBtn.UseVisualStyleBackColor = False
        '
        'txtMonthOfPayment
        '
        Me.txtMonthOfPayment.Location = New System.Drawing.Point(9, 147)
        Me.txtMonthOfPayment.Name = "txtMonthOfPayment"
        Me.txtMonthOfPayment.Size = New System.Drawing.Size(78, 21)
        Me.txtMonthOfPayment.TabIndex = 19
        Me.txtMonthOfPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtMonthOfPayment.Visible = False
        '
        'Label10
        '
        Me.Label10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(96, 28)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 15)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Amount(Ghc):"
        '
        'txtAmount
        '
        Me.txtAmount.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAmount.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAmount.Location = New System.Drawing.Point(37, 46)
        Me.txtAmount.Mask = "000000"
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(205, 21)
        Me.txtAmount.TabIndex = 0
        Me.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtAmount.ValidatingType = GetType(Integer)
        '
        'ContributionsGroupBox
        '
        Me.ContributionsGroupBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ContributionsGroupBox.BackColor = System.Drawing.Color.White
        Me.ContributionsGroupBox.Controls.Add(Me.memberContributionsDataGridView)
        Me.ContributionsGroupBox.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContributionsGroupBox.Location = New System.Drawing.Point(313, 264)
        Me.ContributionsGroupBox.Name = "ContributionsGroupBox"
        Me.ContributionsGroupBox.Size = New System.Drawing.Size(563, 174)
        Me.ContributionsGroupBox.TabIndex = 33
        Me.ContributionsGroupBox.TabStop = False
        Me.ContributionsGroupBox.Text = "Payments Made"
        Me.ContributionsGroupBox.Visible = False
        '
        'memberContributionsDataGridView
        '
        Me.memberContributionsDataGridView.AllowUserToAddRows = False
        Me.memberContributionsDataGridView.AllowUserToDeleteRows = False
        Me.memberContributionsDataGridView.AllowUserToResizeColumns = False
        Me.memberContributionsDataGridView.AllowUserToResizeRows = False
        Me.memberContributionsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.memberContributionsDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.memberContributionsDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.memberContributionsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.memberContributionsDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.memberContributionsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.memberContributionsDataGridView.DefaultCellStyle = DataGridViewCellStyle2
        Me.memberContributionsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.memberContributionsDataGridView.Location = New System.Drawing.Point(3, 17)
        Me.memberContributionsDataGridView.Name = "memberContributionsDataGridView"
        Me.memberContributionsDataGridView.ReadOnly = True
        Me.memberContributionsDataGridView.RowHeadersVisible = False
        Me.memberContributionsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.memberContributionsDataGridView.Size = New System.Drawing.Size(557, 154)
        Me.memberContributionsDataGridView.TabIndex = 0
        '
        'selectIDType
        '
        Me.selectIDType.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.selectIDType.BackColor = System.Drawing.Color.White
        Me.selectIDType.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.selectIDType.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.selectIDType.FormattingEnabled = True
        Me.selectIDType.Items.AddRange(New Object() {"Staff ID", "Phone"})
        Me.selectIDType.Location = New System.Drawing.Point(129, 15)
        Me.selectIDType.Name = "selectIDType"
        Me.selectIDType.Size = New System.Drawing.Size(131, 23)
        Me.selectIDType.TabIndex = 32
        Me.selectIDType.Text = "Staff ID"
        '
        'searchBox
        '
        Me.searchBox.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.searchBox.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.searchBox.Location = New System.Drawing.Point(271, 12)
        Me.searchBox.Multiline = True
        Me.searchBox.Name = "searchBox"
        Me.searchBox.Size = New System.Drawing.Size(384, 28)
        Me.searchBox.TabIndex = 30
        '
        'QueryBtn
        '
        Me.QueryBtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.QueryBtn.BackColor = System.Drawing.Color.SeaGreen
        Me.QueryBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.QueryBtn.FlatAppearance.BorderSize = 0
        Me.QueryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.QueryBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.QueryBtn.ForeColor = System.Drawing.Color.White
        Me.QueryBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.QueryBtn.IconColor = System.Drawing.Color.Black
        Me.QueryBtn.IconSize = 16
        Me.QueryBtn.Location = New System.Drawing.Point(667, 12)
        Me.QueryBtn.Name = "QueryBtn"
        Me.QueryBtn.Rotation = 0R
        Me.QueryBtn.Size = New System.Drawing.Size(67, 28)
        Me.QueryBtn.TabIndex = 31
        Me.QueryBtn.Text = "Query"
        Me.QueryBtn.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'LoansPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(908, 492)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "LoansPage"
        Me.Text = "ApprovalsPage"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.membersDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.memberNotFoundFeedback.ResumeLayout(False)
        Me.memberNotFoundFeedback.PerformLayout()
        Me.InformationTab.ResumeLayout(False)
        Me.InformationTab.PerformLayout()
        Me.makePaymentGroupBox.ResumeLayout(False)
        Me.makePaymentGroupBox.PerformLayout()
        Me.ContributionsGroupBox.ResumeLayout(False)
        CType(Me.memberContributionsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtSearchItem As TextBox
    Friend WithEvents memberNotFoundFeedback As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents memberNoFTxt As Label
    Friend WithEvents InformationTab As GroupBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtPostalAddress As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtHouseNo As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtMaritalStatus As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtHomeTown As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtSex As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtBirthDate As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtMemberOtherName As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtSurname As TextBox
    Friend WithEvents makePaymentGroupBox As GroupBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txtPaidIBy As MaskedTextBox
    Friend WithEvents payBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents txtMonthOfPayment As MaskedTextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtAmount As MaskedTextBox
    Friend WithEvents ContributionsGroupBox As GroupBox
    Friend WithEvents memberContributionsDataGridView As DataGridView
    Friend WithEvents selectIDType As ComboBox
    Friend WithEvents searchBox As TextBox
    Friend WithEvents QueryBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents membersDataGridView As DataGridView
    Friend WithEvents IconButton3 As FontAwesome.Sharp.IconButton
    Friend WithEvents Label9 As Label
    Friend WithEvents txtStaffID As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents Timer1 As Timer
End Class
