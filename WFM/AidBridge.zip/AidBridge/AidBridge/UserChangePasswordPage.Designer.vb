﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserChangePasswordPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.IconButton6 = New FontAwesome.Sharp.IconButton()
        Me.IconButton3 = New FontAwesome.Sharp.IconButton()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.IconButton4 = New FontAwesome.Sharp.IconButton()
        Me.txtConfirmNewPassword = New System.Windows.Forms.MaskedTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.IconButton5 = New FontAwesome.Sharp.IconButton()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtNewPassword = New System.Windows.Forms.TextBox()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtOldPassword = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnChangePassword = New FontAwesome.Sharp.IconButton()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label1.Location = New System.Drawing.Point(77, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(161, 17)
        Me.Label1.TabIndex = 68
        Me.Label1.Text = "CHANGE PASSWORD"
        '
        'IconButton6
        '
        Me.IconButton6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.IconButton6.BackColor = System.Drawing.Color.Transparent
        Me.IconButton6.FlatAppearance.BorderSize = 0
        Me.IconButton6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton6.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton6.ForeColor = System.Drawing.Color.SeaGreen
        Me.IconButton6.IconChar = FontAwesome.Sharp.IconChar.Eye
        Me.IconButton6.IconColor = System.Drawing.Color.SeaGreen
        Me.IconButton6.IconSize = 16
        Me.IconButton6.Location = New System.Drawing.Point(245, 191)
        Me.IconButton6.Name = "IconButton6"
        Me.IconButton6.Rotation = 0R
        Me.IconButton6.Size = New System.Drawing.Size(22, 14)
        Me.IconButton6.TabIndex = 67
        Me.IconButton6.UseVisualStyleBackColor = False
        '
        'IconButton3
        '
        Me.IconButton3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.IconButton3.BackColor = System.Drawing.Color.Transparent
        Me.IconButton3.FlatAppearance.BorderSize = 0
        Me.IconButton3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton3.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton3.ForeColor = System.Drawing.Color.SeaGreen
        Me.IconButton3.IconChar = FontAwesome.Sharp.IconChar.Eye
        Me.IconButton3.IconColor = System.Drawing.Color.SeaGreen
        Me.IconButton3.IconSize = 16
        Me.IconButton3.Location = New System.Drawing.Point(245, 135)
        Me.IconButton3.Name = "IconButton3"
        Me.IconButton3.Rotation = 0R
        Me.IconButton3.Size = New System.Drawing.Size(22, 14)
        Me.IconButton3.TabIndex = 66
        Me.IconButton3.UseVisualStyleBackColor = False
        '
        'IconButton2
        '
        Me.IconButton2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.IconButton2.BackColor = System.Drawing.Color.Transparent
        Me.IconButton2.FlatAppearance.BorderSize = 0
        Me.IconButton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.ForeColor = System.Drawing.Color.SeaGreen
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.Eye
        Me.IconButton2.IconColor = System.Drawing.Color.SeaGreen
        Me.IconButton2.IconSize = 16
        Me.IconButton2.Location = New System.Drawing.Point(245, 85)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(22, 14)
        Me.IconButton2.TabIndex = 65
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'IconButton4
        '
        Me.IconButton4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.IconButton4.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton4.FlatAppearance.BorderSize = 0
        Me.IconButton4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton4.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton4.IconChar = FontAwesome.Sharp.IconChar.Lock
        Me.IconButton4.IconColor = System.Drawing.Color.White
        Me.IconButton4.IconSize = 16
        Me.IconButton4.Location = New System.Drawing.Point(46, 187)
        Me.IconButton4.Name = "IconButton4"
        Me.IconButton4.Rotation = 0R
        Me.IconButton4.Size = New System.Drawing.Size(37, 21)
        Me.IconButton4.TabIndex = 64
        Me.IconButton4.UseVisualStyleBackColor = False
        '
        'txtConfirmNewPassword
        '
        Me.txtConfirmNewPassword.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtConfirmNewPassword.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtConfirmNewPassword.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtConfirmNewPassword.Location = New System.Drawing.Point(80, 187)
        Me.txtConfirmNewPassword.Name = "txtConfirmNewPassword"
        Me.txtConfirmNewPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtConfirmNewPassword.Size = New System.Drawing.Size(191, 21)
        Me.txtConfirmNewPassword.TabIndex = 63
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label6.Location = New System.Drawing.Point(43, 168)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(133, 15)
        Me.Label6.TabIndex = 62
        Me.Label6.Text = "Confirm New Password:"
        '
        'IconButton5
        '
        Me.IconButton5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.IconButton5.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton5.FlatAppearance.BorderSize = 0
        Me.IconButton5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton5.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton5.IconChar = FontAwesome.Sharp.IconChar.Lock
        Me.IconButton5.IconColor = System.Drawing.Color.White
        Me.IconButton5.IconSize = 16
        Me.IconButton5.Location = New System.Drawing.Point(44, 131)
        Me.IconButton5.Name = "IconButton5"
        Me.IconButton5.Rotation = 0R
        Me.IconButton5.Size = New System.Drawing.Size(37, 22)
        Me.IconButton5.TabIndex = 61
        Me.IconButton5.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label5.Location = New System.Drawing.Point(43, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 15)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "New Password:"
        '
        'txtNewPassword
        '
        Me.txtNewPassword.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtNewPassword.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNewPassword.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtNewPassword.Location = New System.Drawing.Point(80, 131)
        Me.txtNewPassword.Multiline = True
        Me.txtNewPassword.Name = "txtNewPassword"
        Me.txtNewPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtNewPassword.Size = New System.Drawing.Size(191, 22)
        Me.txtNewPassword.TabIndex = 59
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.IconButton1.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen
        Me.IconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.Lock
        Me.IconButton1.IconColor = System.Drawing.Color.White
        Me.IconButton1.IconSize = 16
        Me.IconButton1.Location = New System.Drawing.Point(44, 81)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(37, 22)
        Me.IconButton1.TabIndex = 58
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label2.Location = New System.Drawing.Point(43, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 15)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "Old Password:"
        '
        'txtOldPassword
        '
        Me.txtOldPassword.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtOldPassword.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOldPassword.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtOldPassword.Location = New System.Drawing.Point(80, 81)
        Me.txtOldPassword.Multiline = True
        Me.txtOldPassword.Name = "txtOldPassword"
        Me.txtOldPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtOldPassword.Size = New System.Drawing.Size(191, 22)
        Me.txtOldPassword.TabIndex = 56
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label4.Location = New System.Drawing.Point(292, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(15, 15)
        Me.Label4.TabIndex = 55
        Me.Label4.Text = "X"
        '
        'btnChangePassword
        '
        Me.btnChangePassword.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnChangePassword.BackColor = System.Drawing.Color.SeaGreen
        Me.btnChangePassword.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnChangePassword.FlatAppearance.BorderSize = 0
        Me.btnChangePassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnChangePassword.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnChangePassword.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnChangePassword.ForeColor = System.Drawing.Color.White
        Me.btnChangePassword.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnChangePassword.IconColor = System.Drawing.Color.Black
        Me.btnChangePassword.IconSize = 16
        Me.btnChangePassword.Location = New System.Drawing.Point(46, 223)
        Me.btnChangePassword.Name = "btnChangePassword"
        Me.btnChangePassword.Rotation = 0R
        Me.btnChangePassword.Size = New System.Drawing.Size(226, 36)
        Me.btnChangePassword.TabIndex = 54
        Me.btnChangePassword.Text = "Change"
        Me.btnChangePassword.UseVisualStyleBackColor = False
        '
        'UserChangePasswordPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(316, 281)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.IconButton6)
        Me.Controls.Add(Me.IconButton3)
        Me.Controls.Add(Me.IconButton2)
        Me.Controls.Add(Me.IconButton4)
        Me.Controls.Add(Me.txtConfirmNewPassword)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.IconButton5)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtNewPassword)
        Me.Controls.Add(Me.IconButton1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtOldPassword)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnChangePassword)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "UserChangePasswordPage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "UserChangePasswordPage"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents IconButton6 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton3 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton4 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtConfirmNewPassword As MaskedTextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents IconButton5 As FontAwesome.Sharp.IconButton
    Friend WithEvents Label5 As Label
    Friend WithEvents txtNewPassword As TextBox
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents Label2 As Label
    Friend WithEvents txtOldPassword As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnChangePassword As FontAwesome.Sharp.IconButton
End Class
