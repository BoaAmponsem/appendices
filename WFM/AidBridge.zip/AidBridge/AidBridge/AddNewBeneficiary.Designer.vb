﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AddNewBeneficiary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.addBtn = New FontAwesome.Sharp.IconButton()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.IconButton8 = New FontAwesome.Sharp.IconButton()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.beneficiariesDataGridView = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtBeneficiaryOneProportion = New System.Windows.Forms.MaskedTextBox()
        Me.txtBeneficiaryOneRelation = New System.Windows.Forms.ComboBox()
        Me.txtBeneficiaryOneAddress = New System.Windows.Forms.MaskedTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryOneDoB = New System.Windows.Forms.MaskedTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryOnePhone = New System.Windows.Forms.MaskedTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryOneName = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtBenficiaryID = New System.Windows.Forms.TextBox()
        Me.GroupBox5.SuspendLayout()
        CType(Me.beneficiariesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'addBtn
        '
        Me.addBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.addBtn.BackColor = System.Drawing.Color.SeaGreen
        Me.addBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.addBtn.FlatAppearance.BorderSize = 0
        Me.addBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.addBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addBtn.ForeColor = System.Drawing.Color.White
        Me.addBtn.IconChar = FontAwesome.Sharp.IconChar.PlusCircle
        Me.addBtn.IconColor = System.Drawing.Color.White
        Me.addBtn.IconSize = 16
        Me.addBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.addBtn.Location = New System.Drawing.Point(536, 153)
        Me.addBtn.Name = "addBtn"
        Me.addBtn.Rotation = 0R
        Me.addBtn.Size = New System.Drawing.Size(87, 26)
        Me.addBtn.TabIndex = 38
        Me.addBtn.Text = "Add"
        Me.addBtn.UseVisualStyleBackColor = False
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton1.BackColor = System.Drawing.Color.DarkGreen
        Me.IconButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton1.ForeColor = System.Drawing.Color.White
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton1.IconColor = System.Drawing.Color.White
        Me.IconButton1.IconSize = 16
        Me.IconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton1.Location = New System.Drawing.Point(439, 153)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(87, 26)
        Me.IconButton1.TabIndex = 37
        Me.IconButton1.Text = "Refresh"
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'IconButton8
        '
        Me.IconButton8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton8.BackColor = System.Drawing.Color.SaddleBrown
        Me.IconButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton8.FlatAppearance.BorderSize = 0
        Me.IconButton8.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton8.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton8.ForeColor = System.Drawing.Color.White
        Me.IconButton8.IconChar = FontAwesome.Sharp.IconChar.Upload
        Me.IconButton8.IconColor = System.Drawing.Color.White
        Me.IconButton8.IconSize = 16
        Me.IconButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton8.Location = New System.Drawing.Point(341, 152)
        Me.IconButton8.Name = "IconButton8"
        Me.IconButton8.Rotation = 0R
        Me.IconButton8.Size = New System.Drawing.Size(91, 27)
        Me.IconButton8.TabIndex = 35
        Me.IconButton8.Text = "Update"
        Me.IconButton8.UseVisualStyleBackColor = False
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.White
        Me.GroupBox5.Controls.Add(Me.beneficiariesDataGridView)
        Me.GroupBox5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(27, 198)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(924, 205)
        Me.GroupBox5.TabIndex = 34
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "BENEFICIARIES"
        '
        'beneficiariesDataGridView
        '
        Me.beneficiariesDataGridView.AllowUserToAddRows = False
        Me.beneficiariesDataGridView.AllowUserToDeleteRows = False
        Me.beneficiariesDataGridView.AllowUserToResizeRows = False
        Me.beneficiariesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.beneficiariesDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.beneficiariesDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.beneficiariesDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.beneficiariesDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.beneficiariesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.beneficiariesDataGridView.DefaultCellStyle = DataGridViewCellStyle1
        Me.beneficiariesDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.beneficiariesDataGridView.Location = New System.Drawing.Point(3, 17)
        Me.beneficiariesDataGridView.Name = "beneficiariesDataGridView"
        Me.beneficiariesDataGridView.ReadOnly = True
        Me.beneficiariesDataGridView.RowHeadersVisible = False
        Me.beneficiariesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.beneficiariesDataGridView.Size = New System.Drawing.Size(918, 185)
        Me.beneficiariesDataGridView.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneProportion)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneRelation)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneAddress)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneDoB)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOnePhone)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneName)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(23, 47)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(928, 100)
        Me.GroupBox1.TabIndex = 33
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "ADD/EDIT BENEFICIARY"
        '
        'txtBeneficiaryOneProportion
        '
        Me.txtBeneficiaryOneProportion.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.txtBeneficiaryOneProportion.Location = New System.Drawing.Point(837, 46)
        Me.txtBeneficiaryOneProportion.Mask = "000"
        Me.txtBeneficiaryOneProportion.Name = "txtBeneficiaryOneProportion"
        Me.txtBeneficiaryOneProportion.Size = New System.Drawing.Size(84, 21)
        Me.txtBeneficiaryOneProportion.TabIndex = 47
        '
        'txtBeneficiaryOneRelation
        '
        Me.txtBeneficiaryOneRelation.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.txtBeneficiaryOneRelation.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBeneficiaryOneRelation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtBeneficiaryOneRelation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtBeneficiaryOneRelation.FormattingEnabled = True
        Me.txtBeneficiaryOneRelation.Items.AddRange(New Object() {"", "Brother", "Cousin", "Daughter", "Father", "Father-In-Law", "Friend", "Husband/Wife", "Mother", "Mother-In-Law", "Nephew", "Sister", "Son"})
        Me.txtBeneficiaryOneRelation.Location = New System.Drawing.Point(493, 46)
        Me.txtBeneficiaryOneRelation.Name = "txtBeneficiaryOneRelation"
        Me.txtBeneficiaryOneRelation.Size = New System.Drawing.Size(162, 23)
        Me.txtBeneficiaryOneRelation.Sorted = True
        Me.txtBeneficiaryOneRelation.TabIndex = 46
        '
        'txtBeneficiaryOneAddress
        '
        Me.txtBeneficiaryOneAddress.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.txtBeneficiaryOneAddress.Location = New System.Drawing.Point(661, 47)
        Me.txtBeneficiaryOneAddress.Name = "txtBeneficiaryOneAddress"
        Me.txtBeneficiaryOneAddress.Size = New System.Drawing.Size(170, 21)
        Me.txtBeneficiaryOneAddress.TabIndex = 45
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(841, 28)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 15)
        Me.Label7.TabIndex = 44
        Me.Label7.Text = "Proportion%:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(496, 28)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 15)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "Relation:"
        '
        'txtBeneficiaryOneDoB
        '
        Me.txtBeneficiaryOneDoB.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.txtBeneficiaryOneDoB.Location = New System.Drawing.Point(368, 45)
        Me.txtBeneficiaryOneDoB.Name = "txtBeneficiaryOneDoB"
        Me.txtBeneficiaryOneDoB.Size = New System.Drawing.Size(119, 21)
        Me.txtBeneficiaryOneDoB.TabIndex = 42
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(372, 28)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 15)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "DoB(mm/dd/yyy):"
        '
        'txtBeneficiaryOnePhone
        '
        Me.txtBeneficiaryOnePhone.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.txtBeneficiaryOnePhone.Location = New System.Drawing.Point(259, 46)
        Me.txtBeneficiaryOnePhone.Name = "txtBeneficiaryOnePhone"
        Me.txtBeneficiaryOnePhone.Size = New System.Drawing.Size(100, 21)
        Me.txtBeneficiaryOnePhone.TabIndex = 40
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 28)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 15)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "Name:"
        '
        'txtBeneficiaryOneName
        '
        Me.txtBeneficiaryOneName.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.txtBeneficiaryOneName.Location = New System.Drawing.Point(4, 47)
        Me.txtBeneficiaryOneName.Multiline = True
        Me.txtBeneficiaryOneName.Name = "txtBeneficiaryOneName"
        Me.txtBeneficiaryOneName.Size = New System.Drawing.Size(247, 21)
        Me.txtBeneficiaryOneName.TabIndex = 39
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(663, 29)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 15)
        Me.Label12.TabIndex = 37
        Me.Label12.Text = "Postal Address:"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(263, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 15)
        Me.Label4.TabIndex = 38
        Me.Label4.Text = "Phone No:"
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(945, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(15, 14)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "X"
        '
        'txtBenficiaryID
        '
        Me.txtBenficiaryID.Location = New System.Drawing.Point(957, 156)
        Me.txtBenficiaryID.Name = "txtBenficiaryID"
        Me.txtBenficiaryID.Size = New System.Drawing.Size(100, 20)
        Me.txtBenficiaryID.TabIndex = 39
        Me.txtBenficiaryID.Visible = False
        '
        'AddNewBeneficiary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(981, 423)
        Me.Controls.Add(Me.txtBenficiaryID)
        Me.Controls.Add(Me.addBtn)
        Me.Controls.Add(Me.IconButton1)
        Me.Controls.Add(Me.IconButton8)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "AddNewBeneficiary"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AddNewBeneficiary"
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.beneficiariesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents addBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton8 As FontAwesome.Sharp.IconButton
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents beneficiariesDataGridView As DataGridView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtBeneficiaryOneProportion As MaskedTextBox
    Friend WithEvents txtBeneficiaryOneRelation As ComboBox
    Friend WithEvents txtBeneficiaryOneAddress As MaskedTextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtBeneficiaryOneDoB As MaskedTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtBeneficiaryOnePhone As MaskedTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtBeneficiaryOneName As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtBenficiaryID As TextBox
End Class
