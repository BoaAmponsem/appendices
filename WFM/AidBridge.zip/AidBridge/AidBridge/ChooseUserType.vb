﻿Imports System.Drawing.Drawing2D
Imports Newtonsoft.Json.Linq
Imports System.Net
Imports System.Data.SqlClient

Public Class ChooseUserType

    Private borderRadius As Integer = 20
    Private borderSize As Integer = 3
    Private borderColor As Color = Color.SeaGreen

    'Constractor
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Private Function GetRoundedPath(rect As Rectangle, radius As Single) As GraphicsPath
        Dim path As GraphicsPath = New GraphicsPath()
        Dim curveSize As Single = radius * 2.0F
        path.StartFigure()
        path.AddArc(rect.X, rect.Y, curveSize, curveSize, 180, 90)
        path.AddArc(rect.Right - curveSize, rect.Y, curveSize, curveSize, 270, 90)
        path.AddArc(rect.Right - curveSize, rect.Bottom - curveSize, curveSize, curveSize, 0, 90)
        path.AddArc(rect.X, rect.Bottom - curveSize, curveSize, curveSize, 90, 90)
        path.CloseFigure()
        Return path
    End Function

    Private Sub FormRegionAndBorder(form As Form, radius As Single, graph As Graphics, borderColor As Color, borderSize As Single)
        If Me.WindowState <> FormWindowState.Minimized Then
            Using roundPath As GraphicsPath = GetRoundedPath(form.ClientRectangle, radius)
                Using penBorder As Pen = New Pen(borderColor, borderSize)
                    Using transform As Matrix = New Matrix()

                        graph.SmoothingMode = SmoothingMode.AntiAlias
                        form.Region = New Region(roundPath)
                        If borderSize >= 1 Then
                            Dim rect As Rectangle = form.ClientRectangle
                            Dim scaleX As Single = 1.0F - ((borderSize + 1) / rect.Width)
                            Dim scaleY As Single = 1.0F - ((borderSize + 1) / rect.Height)
                            transform.Scale(scaleX, scaleY)
                            transform.Translate(borderSize / 1.6F, borderSize / 1.6F)
                            graph.Transform = transform
                            graph.DrawPath(penBorder, roundPath)
                        End If
                    End Using
                End Using
            End Using

        End If
    End Sub


    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Application.ExitThread()
    End Sub

    Private Sub dashboardBtnContributions_Click(sender As Object, e As EventArgs) Handles dashboardBtnContributions.Click
        Try
            Me.Hide()
            Dim nwAdminLoginFormPage = New AdminLoginFormPage
            nwAdminLoginFormPage.Show()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub PopulateBirthdays()
        Dim currentDay As Integer = DateTime.Now.Day
        Dim currentMonth As Integer = DateTime.Now.Month

        Try
            Con.Open()
            ' SQL query to select all records
            Dim query As String = "SELECT Id, Staff_ID, Surname, Other_Names, Phone, Sex, Birth_Date FROM MembersTbl"

            Using command As New SqlCommand(query, Con)
                ' Create a data adapter
                Using adaptor As New SqlDataAdapter(command)
                    Dim ds As New DataSet()
                    adaptor.Fill(ds)

                    ' Create a DataTable to hold valid date records
                    Dim filteredTable As New DataTable()
                    filteredTable.Columns.Add("Id", GetType(Integer))
                    filteredTable.Columns.Add("Staff_ID", GetType(String))
                    filteredTable.Columns.Add("Surname", GetType(String))
                    filteredTable.Columns.Add("Other_Names", GetType(String))
                    filteredTable.Columns.Add("Phone", GetType(String))
                    filteredTable.Columns.Add("Sex", GetType(String))
                    filteredTable.Columns.Add("Birth_Date", GetType(String))

                    ' Iterate through the records and parse the Birth_Date column
                    For Each row As DataRow In ds.Tables(0).Rows
                        Dim birthDateString As String = row("Birth_Date").ToString()
                        Dim birthDate As DateTime
                        If DateTime.TryParse(birthDateString, birthDate) Then
                            If birthDate.Day = currentDay AndAlso birthDate.Month = currentMonth Then
                                ' Add the valid and matching record to the filtered table
                                filteredTable.Rows.Add(row("Id"), row("Staff_ID"), row("Surname"), row("Other_Names"), row("Phone"), row("Sex"), row("Birth_Date"))
                            End If
                        End If
                    Next

                    ' Bind the filtered table to the DataGridView
                    UserMembersPage.birthdaysDataGridView.DataSource = filteredTable
                End Using
            End Using
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        ' Create and add the Send Alert button column
        Dim sendSmsButtonColumn As New DataGridViewButtonColumn()
        sendSmsButtonColumn.HeaderText = ""
        sendSmsButtonColumn.Text = "Send Wish"
        sendSmsButtonColumn.Name = "sendWish"
        sendSmsButtonColumn.UseColumnTextForButtonValue = True

        ' Add the button column to the DataGridView if it doesn't already exist
        If UserMembersPage.birthdaysDataGridView.Columns("sendWish") Is Nothing Then
            UserMembersPage.birthdaysDataGridView.Columns.Add(sendSmsButtonColumn)
        End If

    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        Try
            Cursor = Cursors.WaitCursor
            PopulateBirthdays()
            debtorsCount()
            Dim noBirthdays = UserMembersPage.birthdaysDataGridView.RowCount
            If (noBirthdays > 0) Then
                UserPage.txtNoBirthdays.Text = noBirthdays.ToString
                UserPage.txtNoBirthdays.Visible = True
                UserMembersPage.TabPage2.Text = "Birthdays " + noBirthdays.ToString
            Else
                UserPage.txtNoBirthdays.Visible = False
                UserPage.txtNoBirthdays.Text = noBirthdays.ToString
                UserMembersPage.TabPage2.Text = "Birthdays"
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
        End Try

        Try
            Cursor = Cursors.WaitCursor
            Me.Hide()
            Dim nwLoginForm = New LoginFormPage
            nwLoginForm.Show()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        Me.Hide()
        SecLoginForm.Show()
    End Sub

    Private Sub ChooseUserType_Paint(sender As Object, e As PaintEventArgs) Handles Me.Paint
        FormRegionAndBorder(Me, borderRadius, e.Graphics, borderColor, borderSize)
    End Sub


    ' Create a WebClient instance
    Dim client As New WebClient()

    ' Define the API endpoint
    Dim url As String = "http://worldtimeapi.org/api/timezone/Africa/Accra"

    Private Function dateTimeAPI()



        Try
            ' Make the request and get the response as a string
            Dim response As String = client.DownloadString(url)

            ' Parse the JSON response
            Dim jsonResponse As JObject = JObject.Parse(response)

            ' Extract desired information from the JSON object
            Dim abbreviation As String = jsonResponse("abbreviation")
            Dim onlinetime As DateTime = jsonResponse("datetime")
            Dim timezone As String = jsonResponse("timezone")
            Dim unixtime As Long = jsonResponse("unixtime")

            Dim getDateOnly As DateTime = onlinetime

            '  MsgBox(getDateOnly.Date)


            If (getDateOnly.Date <> DateTime.Now.Date) Then
                Dim dateTimeDialog As DialogResult = MessageBox.Show("Set your system 'Date and Time!", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                If (dateTimeDialog = DialogResult.OK) Then
                    Application.ExitThread()
                End If
            End If

        Catch ex As Exception
            ' Handle any exceptions
            Dim errMessage As DialogResult = MessageBox.Show("An error occurred while opening the application.'Please check your internet connection and retry' " + ex.Message, "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error)
            If (errMessage = DialogResult.Retry) Then
                refetchDateTimeAPI()
            Else
                Application.ExitThread()
            End If
        End Try
    End Function

    Private Function refetchDateTimeAPI()
        ' Create a WebClient instance
        Dim client As New WebClient()

        ' Define the API endpoint
        Dim url As String = "http://worldtimeapi.org/api/timezone/Africa/Accra"

        Try
            ' Make the request and get the response as a string
            Dim response As String = client.DownloadString(url)

            ' Parse the JSON response
            Dim jsonResponse As JObject = JObject.Parse(response)

            ' Extract desired information from the JSON object
            Dim abbreviation As String = jsonResponse("abbreviation")
            Dim onlinetime As String = jsonResponse("datetime")
            Dim timezone As String = jsonResponse("timezone")
            Dim unixtime As Long = jsonResponse("unixtime")

            Dim getDateOnly As DateTime = onlinetime


            If (getDateOnly.Date <> DateTime.Now.Date) Then
                Dim dateTimeDialog As DialogResult = MessageBox.Show("Set your system 'Date and Time!", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                If (dateTimeDialog = DialogResult.OK) Then
                    Application.ExitThread()
                End If
            End If

        Catch ex As Exception
            ' Handle any exceptions
            Dim errMessage As DialogResult = MessageBox.Show("An error occurred while opening the application. 'Please check your internet connection and retry'", "AidBridge", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error)
            If (errMessage = DialogResult.Retry) Then
                dateTimeAPI()
            Else
                Application.ExitThread()
            End If
        End Try
    End Function
    Private Sub ChooseUserType_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            dateTimeAPI()
        Catch ex As Exception
            'MsgBox("An error occurred: " & ex.Flatten().InnerException.Message)
        End Try
    End Sub
End Class