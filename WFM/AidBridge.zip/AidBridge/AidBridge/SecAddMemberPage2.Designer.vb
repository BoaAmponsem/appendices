﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SecAddMemberPage2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtFatherPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtMotherPhone = New System.Windows.Forms.MaskedTextBox()
        Me.motherLiveStatus = New System.Windows.Forms.Panel()
        Me.txtMotherAlive = New System.Windows.Forms.RadioButton()
        Me.txtMotherDead = New System.Windows.Forms.RadioButton()
        Me.fatherLiveStatus = New System.Windows.Forms.Panel()
        Me.txtFatherAlive = New System.Windows.Forms.RadioButton()
        Me.txtFatherDead = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtFatherName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtMotherName = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtAcceptAgreement = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtBeneficiaryFourDoBD = New System.Windows.Forms.DateTimePicker()
        Me.txtBeneficiaryThreeDoBC = New System.Windows.Forms.DateTimePicker()
        Me.txtBeneficiaryTwoDoBB = New System.Windows.Forms.DateTimePicker()
        Me.txtBeneficiaryOneDoBA = New System.Windows.Forms.DateTimePicker()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtNoBeneficiary = New System.Windows.Forms.RadioButton()
        Me.fourBeneficiary = New System.Windows.Forms.RadioButton()
        Me.threeBeneficiary = New System.Windows.Forms.RadioButton()
        Me.twoBeneficiary = New System.Windows.Forms.RadioButton()
        Me.oneBeneficiary = New System.Windows.Forms.RadioButton()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryFourProportion = New System.Windows.Forms.MaskedTextBox()
        Me.txtBeneficiaryFourRelation = New System.Windows.Forms.ComboBox()
        Me.txtBeneficiaryFourAddress = New System.Windows.Forms.MaskedTextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryFourDoB = New System.Windows.Forms.MaskedTextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryFourPhone = New System.Windows.Forms.MaskedTextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryFourName = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryThreeProportion = New System.Windows.Forms.MaskedTextBox()
        Me.txtBeneficiaryThreeRelation = New System.Windows.Forms.ComboBox()
        Me.txtBeneficiaryThreeAddress = New System.Windows.Forms.MaskedTextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryThreeDoB = New System.Windows.Forms.MaskedTextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryThreePhone = New System.Windows.Forms.MaskedTextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryThreeName = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryTwoProportion = New System.Windows.Forms.MaskedTextBox()
        Me.txtBeneficiaryTwoRelation = New System.Windows.Forms.ComboBox()
        Me.txtBeneficiaryTwoAddress = New System.Windows.Forms.MaskedTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryTwoDoB = New System.Windows.Forms.MaskedTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryTwoPhone = New System.Windows.Forms.MaskedTextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryTwoName = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryOneProportion = New System.Windows.Forms.MaskedTextBox()
        Me.txtBeneficiaryOneRelation = New System.Windows.Forms.ComboBox()
        Me.txtBeneficiaryOneAddress = New System.Windows.Forms.MaskedTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryOneDoB = New System.Windows.Forms.MaskedTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryOnePhone = New System.Windows.Forms.MaskedTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBeneficiaryOneName = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnAddMember = New FontAwesome.Sharp.IconButton()
        Me.previousBtn = New FontAwesome.Sharp.IconButton()
        Me.GroupBox2.SuspendLayout()
        Me.motherLiveStatus.SuspendLayout()
        Me.fatherLiveStatus.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.txtFatherPhone)
        Me.GroupBox2.Controls.Add(Me.txtMotherPhone)
        Me.GroupBox2.Controls.Add(Me.motherLiveStatus)
        Me.GroupBox2.Controls.Add(Me.fatherLiveStatus)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.txtFatherName)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.txtMotherName)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(15, 44)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(967, 134)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "DETAILS OF PARENTS(IF ANY)"
        '
        'txtFatherPhone
        '
        Me.txtFatherPhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFatherPhone.Location = New System.Drawing.Point(494, 98)
        Me.txtFatherPhone.Name = "txtFatherPhone"
        Me.txtFatherPhone.Size = New System.Drawing.Size(280, 21)
        Me.txtFatherPhone.TabIndex = 35
        '
        'txtMotherPhone
        '
        Me.txtMotherPhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMotherPhone.Location = New System.Drawing.Point(494, 39)
        Me.txtMotherPhone.Name = "txtMotherPhone"
        Me.txtMotherPhone.Size = New System.Drawing.Size(280, 21)
        Me.txtMotherPhone.TabIndex = 34
        '
        'motherLiveStatus
        '
        Me.motherLiveStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.motherLiveStatus.BackColor = System.Drawing.Color.WhiteSmoke
        Me.motherLiveStatus.Controls.Add(Me.txtMotherAlive)
        Me.motherLiveStatus.Controls.Add(Me.txtMotherDead)
        Me.motherLiveStatus.Location = New System.Drawing.Point(819, 35)
        Me.motherLiveStatus.Name = "motherLiveStatus"
        Me.motherLiveStatus.Size = New System.Drawing.Size(118, 25)
        Me.motherLiveStatus.TabIndex = 33
        '
        'txtMotherAlive
        '
        Me.txtMotherAlive.AutoSize = True
        Me.txtMotherAlive.Location = New System.Drawing.Point(58, 3)
        Me.txtMotherAlive.Name = "txtMotherAlive"
        Me.txtMotherAlive.Size = New System.Drawing.Size(51, 19)
        Me.txtMotherAlive.TabIndex = 1
        Me.txtMotherAlive.TabStop = True
        Me.txtMotherAlive.Text = "Alive"
        Me.txtMotherAlive.UseVisualStyleBackColor = True
        '
        'txtMotherDead
        '
        Me.txtMotherDead.AutoSize = True
        Me.txtMotherDead.Location = New System.Drawing.Point(5, 3)
        Me.txtMotherDead.Name = "txtMotherDead"
        Me.txtMotherDead.Size = New System.Drawing.Size(50, 19)
        Me.txtMotherDead.TabIndex = 0
        Me.txtMotherDead.TabStop = True
        Me.txtMotherDead.Text = "Dead"
        Me.txtMotherDead.UseVisualStyleBackColor = True
        '
        'fatherLiveStatus
        '
        Me.fatherLiveStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.fatherLiveStatus.BackColor = System.Drawing.Color.WhiteSmoke
        Me.fatherLiveStatus.Controls.Add(Me.txtFatherAlive)
        Me.fatherLiveStatus.Controls.Add(Me.txtFatherDead)
        Me.fatherLiveStatus.Location = New System.Drawing.Point(819, 94)
        Me.fatherLiveStatus.Name = "fatherLiveStatus"
        Me.fatherLiveStatus.Size = New System.Drawing.Size(118, 25)
        Me.fatherLiveStatus.TabIndex = 32
        '
        'txtFatherAlive
        '
        Me.txtFatherAlive.AutoSize = True
        Me.txtFatherAlive.Location = New System.Drawing.Point(58, 3)
        Me.txtFatherAlive.Name = "txtFatherAlive"
        Me.txtFatherAlive.Size = New System.Drawing.Size(51, 19)
        Me.txtFatherAlive.TabIndex = 1
        Me.txtFatherAlive.TabStop = True
        Me.txtFatherAlive.Text = "Alive"
        Me.txtFatherAlive.UseVisualStyleBackColor = True
        '
        'txtFatherDead
        '
        Me.txtFatherDead.AutoSize = True
        Me.txtFatherDead.Location = New System.Drawing.Point(5, 3)
        Me.txtFatherDead.Name = "txtFatherDead"
        Me.txtFatherDead.Size = New System.Drawing.Size(50, 19)
        Me.txtFatherDead.TabIndex = 0
        Me.txtFatherDead.TabStop = True
        Me.txtFatherDead.Text = "Dead"
        Me.txtFatherDead.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 79)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 15)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Father's Name:"
        '
        'txtFatherName
        '
        Me.txtFatherName.Location = New System.Drawing.Point(13, 98)
        Me.txtFatherName.Multiline = True
        Me.txtFatherName.Name = "txtFatherName"
        Me.txtFatherName.Size = New System.Drawing.Size(431, 21)
        Me.txtFatherName.TabIndex = 28
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(498, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 15)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Phone No:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(22, 20)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(85, 15)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Mother's Name:"
        '
        'txtMotherName
        '
        Me.txtMotherName.Location = New System.Drawing.Point(13, 39)
        Me.txtMotherName.Multiline = True
        Me.txtMotherName.Name = "txtMotherName"
        Me.txtMotherName.Size = New System.Drawing.Size(431, 21)
        Me.txtMotherName.TabIndex = 23
        '
        'Label11
        '
        Me.Label11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(497, 20)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(58, 15)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Phone No:"
        '
        'txtAcceptAgreement
        '
        Me.txtAcceptAgreement.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAcceptAgreement.AutoSize = True
        Me.txtAcceptAgreement.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAcceptAgreement.Location = New System.Drawing.Point(26, 469)
        Me.txtAcceptAgreement.Name = "txtAcceptAgreement"
        Me.txtAcceptAgreement.Size = New System.Drawing.Size(585, 18)
        Me.txtAcceptAgreement.TabIndex = 14
        Me.txtAcceptAgreement.Text = "I agree to be a member of the SDA Hospital Welfare Scheme and shall subscribe to " &
    "the constitution governing the Scheme"
        Me.txtAcceptAgreement.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryFourDoBD)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryThreeDoBC)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryTwoDoBB)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneDoBA)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Controls.Add(Me.Label31)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Controls.Add(Me.Label32)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryFourProportion)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryFourRelation)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryFourAddress)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.Label24)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryFourDoB)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryFourPhone)
        Me.GroupBox1.Controls.Add(Me.Label26)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryFourName)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryThreeProportion)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryThreeRelation)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryThreeAddress)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryThreeDoB)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryThreePhone)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryThreeName)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryTwoProportion)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryTwoRelation)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryTwoAddress)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryTwoDoB)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryTwoPhone)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryTwoName)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneProportion)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneRelation)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneAddress)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneDoB)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOnePhone)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtBeneficiaryOneName)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(15, 194)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(967, 266)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "BENEFICIARIES/NEXT OF KIN"
        '
        'txtBeneficiaryFourDoBD
        '
        Me.txtBeneficiaryFourDoBD.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryFourDoBD.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtBeneficiaryFourDoBD.Location = New System.Drawing.Point(396, 233)
        Me.txtBeneficiaryFourDoBD.Name = "txtBeneficiaryFourDoBD"
        Me.txtBeneficiaryFourDoBD.Size = New System.Drawing.Size(119, 21)
        Me.txtBeneficiaryFourDoBD.TabIndex = 87
        Me.txtBeneficiaryFourDoBD.Value = New Date(2023, 11, 11, 0, 0, 0, 0)
        '
        'txtBeneficiaryThreeDoBC
        '
        Me.txtBeneficiaryThreeDoBC.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryThreeDoBC.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtBeneficiaryThreeDoBC.Location = New System.Drawing.Point(396, 177)
        Me.txtBeneficiaryThreeDoBC.Name = "txtBeneficiaryThreeDoBC"
        Me.txtBeneficiaryThreeDoBC.Size = New System.Drawing.Size(119, 21)
        Me.txtBeneficiaryThreeDoBC.TabIndex = 86
        Me.txtBeneficiaryThreeDoBC.Value = New Date(2023, 11, 11, 0, 0, 0, 0)
        '
        'txtBeneficiaryTwoDoBB
        '
        Me.txtBeneficiaryTwoDoBB.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryTwoDoBB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtBeneficiaryTwoDoBB.Location = New System.Drawing.Point(396, 123)
        Me.txtBeneficiaryTwoDoBB.Name = "txtBeneficiaryTwoDoBB"
        Me.txtBeneficiaryTwoDoBB.Size = New System.Drawing.Size(119, 21)
        Me.txtBeneficiaryTwoDoBB.TabIndex = 85
        Me.txtBeneficiaryTwoDoBB.Value = New Date(2023, 11, 11, 0, 0, 0, 0)
        '
        'txtBeneficiaryOneDoBA
        '
        Me.txtBeneficiaryOneDoBA.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryOneDoBA.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtBeneficiaryOneDoBA.Location = New System.Drawing.Point(396, 72)
        Me.txtBeneficiaryOneDoBA.Name = "txtBeneficiaryOneDoBA"
        Me.txtBeneficiaryOneDoBA.Size = New System.Drawing.Size(119, 21)
        Me.txtBeneficiaryOneDoBA.TabIndex = 84
        Me.txtBeneficiaryOneDoBA.Value = New Date(2023, 11, 11, 0, 0, 0, 0)
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Controls.Add(Me.txtNoBeneficiary)
        Me.Panel1.Controls.Add(Me.fourBeneficiary)
        Me.Panel1.Controls.Add(Me.threeBeneficiary)
        Me.Panel1.Controls.Add(Me.twoBeneficiary)
        Me.Panel1.Controls.Add(Me.oneBeneficiary)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(3, 17)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(961, 30)
        Me.Panel1.TabIndex = 79
        '
        'txtNoBeneficiary
        '
        Me.txtNoBeneficiary.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtNoBeneficiary.AutoSize = True
        Me.txtNoBeneficiary.Checked = True
        Me.txtNoBeneficiary.Location = New System.Drawing.Point(368, 5)
        Me.txtNoBeneficiary.Name = "txtNoBeneficiary"
        Me.txtNoBeneficiary.Size = New System.Drawing.Size(31, 19)
        Me.txtNoBeneficiary.TabIndex = 13
        Me.txtNoBeneficiary.TabStop = True
        Me.txtNoBeneficiary.Text = "0"
        Me.txtNoBeneficiary.UseVisualStyleBackColor = True
        '
        'fourBeneficiary
        '
        Me.fourBeneficiary.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.fourBeneficiary.AutoSize = True
        Me.fourBeneficiary.Location = New System.Drawing.Point(561, 5)
        Me.fourBeneficiary.Name = "fourBeneficiary"
        Me.fourBeneficiary.Size = New System.Drawing.Size(31, 19)
        Me.fourBeneficiary.TabIndex = 12
        Me.fourBeneficiary.Text = "4"
        Me.fourBeneficiary.UseVisualStyleBackColor = True
        '
        'threeBeneficiary
        '
        Me.threeBeneficiary.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.threeBeneficiary.AutoSize = True
        Me.threeBeneficiary.Location = New System.Drawing.Point(512, 6)
        Me.threeBeneficiary.Name = "threeBeneficiary"
        Me.threeBeneficiary.Size = New System.Drawing.Size(31, 19)
        Me.threeBeneficiary.TabIndex = 11
        Me.threeBeneficiary.Text = "3"
        Me.threeBeneficiary.UseVisualStyleBackColor = True
        '
        'twoBeneficiary
        '
        Me.twoBeneficiary.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.twoBeneficiary.AutoSize = True
        Me.twoBeneficiary.Location = New System.Drawing.Point(464, 6)
        Me.twoBeneficiary.Name = "twoBeneficiary"
        Me.twoBeneficiary.Size = New System.Drawing.Size(31, 19)
        Me.twoBeneficiary.TabIndex = 10
        Me.twoBeneficiary.Text = "2"
        Me.twoBeneficiary.UseVisualStyleBackColor = True
        '
        'oneBeneficiary
        '
        Me.oneBeneficiary.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.oneBeneficiary.AutoSize = True
        Me.oneBeneficiary.Location = New System.Drawing.Point(414, 6)
        Me.oneBeneficiary.Name = "oneBeneficiary"
        Me.oneBeneficiary.Size = New System.Drawing.Size(31, 19)
        Me.oneBeneficiary.TabIndex = 9
        Me.oneBeneficiary.Text = "1"
        Me.oneBeneficiary.UseVisualStyleBackColor = True
        '
        'Label31
        '
        Me.Label31.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(14, 182)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(16, 13)
        Me.Label31.TabIndex = 78
        Me.Label31.Text = "3."
        '
        'Label30
        '
        Me.Label30.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(14, 128)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(16, 13)
        Me.Label30.TabIndex = 77
        Me.Label30.Text = "2."
        '
        'Label29
        '
        Me.Label29.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(15, 75)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(16, 13)
        Me.Label29.TabIndex = 76
        Me.Label29.Text = "1."
        '
        'Label32
        '
        Me.Label32.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(15, 236)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(16, 13)
        Me.Label32.TabIndex = 75
        Me.Label32.Text = "4."
        '
        'txtBeneficiaryFourProportion
        '
        Me.txtBeneficiaryFourProportion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryFourProportion.Location = New System.Drawing.Point(868, 233)
        Me.txtBeneficiaryFourProportion.Mask = "00"
        Me.txtBeneficiaryFourProportion.Name = "txtBeneficiaryFourProportion"
        Me.txtBeneficiaryFourProportion.ReadOnly = True
        Me.txtBeneficiaryFourProportion.Size = New System.Drawing.Size(84, 21)
        Me.txtBeneficiaryFourProportion.TabIndex = 71
        '
        'txtBeneficiaryFourRelation
        '
        Me.txtBeneficiaryFourRelation.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryFourRelation.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBeneficiaryFourRelation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtBeneficiaryFourRelation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtBeneficiaryFourRelation.FormattingEnabled = True
        Me.txtBeneficiaryFourRelation.Items.AddRange(New Object() {"", "Brother", "Cousin", "Daughter", "Father", "Father-In-Law", "Friend", "Husband/Wife", "Mother", "Mother-In-Law", "Nephew", "Sister", "Son"})
        Me.txtBeneficiaryFourRelation.Location = New System.Drawing.Point(524, 233)
        Me.txtBeneficiaryFourRelation.Name = "txtBeneficiaryFourRelation"
        Me.txtBeneficiaryFourRelation.Size = New System.Drawing.Size(162, 23)
        Me.txtBeneficiaryFourRelation.Sorted = True
        Me.txtBeneficiaryFourRelation.TabIndex = 70
        '
        'txtBeneficiaryFourAddress
        '
        Me.txtBeneficiaryFourAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryFourAddress.Location = New System.Drawing.Point(692, 234)
        Me.txtBeneficiaryFourAddress.Name = "txtBeneficiaryFourAddress"
        Me.txtBeneficiaryFourAddress.ReadOnly = True
        Me.txtBeneficiaryFourAddress.Size = New System.Drawing.Size(170, 21)
        Me.txtBeneficiaryFourAddress.TabIndex = 69
        '
        'Label23
        '
        Me.Label23.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(872, 215)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(76, 15)
        Me.Label23.TabIndex = 68
        Me.Label23.Text = "Proportion %:"
        '
        'Label24
        '
        Me.Label24.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(527, 215)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(50, 15)
        Me.Label24.TabIndex = 67
        Me.Label24.Text = "Relation:"
        '
        'txtBeneficiaryFourDoB
        '
        Me.txtBeneficiaryFourDoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryFourDoB.Location = New System.Drawing.Point(289, 191)
        Me.txtBeneficiaryFourDoB.Mask = "00/00/0000"
        Me.txtBeneficiaryFourDoB.Name = "txtBeneficiaryFourDoB"
        Me.txtBeneficiaryFourDoB.ReadOnly = True
        Me.txtBeneficiaryFourDoB.Size = New System.Drawing.Size(119, 21)
        Me.txtBeneficiaryFourDoB.TabIndex = 66
        Me.txtBeneficiaryFourDoB.ValidatingType = GetType(Date)
        Me.txtBeneficiaryFourDoB.Visible = False
        '
        'Label25
        '
        Me.Label25.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(403, 215)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(98, 15)
        Me.Label25.TabIndex = 65
        Me.Label25.Text = "DoB(mm/dd/yyy):"
        '
        'txtBeneficiaryFourPhone
        '
        Me.txtBeneficiaryFourPhone.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryFourPhone.Location = New System.Drawing.Point(290, 233)
        Me.txtBeneficiaryFourPhone.Mask = "(999) 000-0000"
        Me.txtBeneficiaryFourPhone.Name = "txtBeneficiaryFourPhone"
        Me.txtBeneficiaryFourPhone.ReadOnly = True
        Me.txtBeneficiaryFourPhone.Size = New System.Drawing.Size(100, 21)
        Me.txtBeneficiaryFourPhone.TabIndex = 64
        '
        'Label26
        '
        Me.Label26.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(43, 215)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(38, 15)
        Me.Label26.TabIndex = 60
        Me.Label26.Text = "Name:"
        '
        'txtBeneficiaryFourName
        '
        Me.txtBeneficiaryFourName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryFourName.Location = New System.Drawing.Point(34, 234)
        Me.txtBeneficiaryFourName.Multiline = True
        Me.txtBeneficiaryFourName.Name = "txtBeneficiaryFourName"
        Me.txtBeneficiaryFourName.ReadOnly = True
        Me.txtBeneficiaryFourName.Size = New System.Drawing.Size(247, 21)
        Me.txtBeneficiaryFourName.TabIndex = 63
        '
        'Label27
        '
        Me.Label27.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(694, 216)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(82, 15)
        Me.Label27.TabIndex = 61
        Me.Label27.Text = "Postal Address:"
        '
        'Label28
        '
        Me.Label28.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(294, 215)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(58, 15)
        Me.Label28.TabIndex = 62
        Me.Label28.Text = "Phone No:"
        '
        'txtBeneficiaryThreeProportion
        '
        Me.txtBeneficiaryThreeProportion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryThreeProportion.Location = New System.Drawing.Point(868, 178)
        Me.txtBeneficiaryThreeProportion.Mask = "00"
        Me.txtBeneficiaryThreeProportion.Name = "txtBeneficiaryThreeProportion"
        Me.txtBeneficiaryThreeProportion.ReadOnly = True
        Me.txtBeneficiaryThreeProportion.Size = New System.Drawing.Size(84, 21)
        Me.txtBeneficiaryThreeProportion.TabIndex = 59
        '
        'txtBeneficiaryThreeRelation
        '
        Me.txtBeneficiaryThreeRelation.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryThreeRelation.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBeneficiaryThreeRelation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtBeneficiaryThreeRelation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtBeneficiaryThreeRelation.FormattingEnabled = True
        Me.txtBeneficiaryThreeRelation.Items.AddRange(New Object() {"", "Brother", "Cousin", "Daughter", "Father", "Father-In-Law", "Friend", "Husband/Wife", "Mother", "Mother-In-Law", "Nephew", "Sister", "Son"})
        Me.txtBeneficiaryThreeRelation.Location = New System.Drawing.Point(524, 178)
        Me.txtBeneficiaryThreeRelation.Name = "txtBeneficiaryThreeRelation"
        Me.txtBeneficiaryThreeRelation.Size = New System.Drawing.Size(162, 23)
        Me.txtBeneficiaryThreeRelation.Sorted = True
        Me.txtBeneficiaryThreeRelation.TabIndex = 58
        '
        'txtBeneficiaryThreeAddress
        '
        Me.txtBeneficiaryThreeAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryThreeAddress.Location = New System.Drawing.Point(692, 179)
        Me.txtBeneficiaryThreeAddress.Name = "txtBeneficiaryThreeAddress"
        Me.txtBeneficiaryThreeAddress.ReadOnly = True
        Me.txtBeneficiaryThreeAddress.Size = New System.Drawing.Size(170, 21)
        Me.txtBeneficiaryThreeAddress.TabIndex = 57
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(872, 160)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(76, 15)
        Me.Label17.TabIndex = 56
        Me.Label17.Text = "Proportion %:"
        '
        'Label18
        '
        Me.Label18.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(527, 160)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(50, 15)
        Me.Label18.TabIndex = 55
        Me.Label18.Text = "Relation:"
        '
        'txtBeneficiaryThreeDoB
        '
        Me.txtBeneficiaryThreeDoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryThreeDoB.Location = New System.Drawing.Point(291, 139)
        Me.txtBeneficiaryThreeDoB.Mask = "00/00/0000"
        Me.txtBeneficiaryThreeDoB.Name = "txtBeneficiaryThreeDoB"
        Me.txtBeneficiaryThreeDoB.ReadOnly = True
        Me.txtBeneficiaryThreeDoB.Size = New System.Drawing.Size(119, 21)
        Me.txtBeneficiaryThreeDoB.TabIndex = 54
        Me.txtBeneficiaryThreeDoB.ValidatingType = GetType(Date)
        Me.txtBeneficiaryThreeDoB.Visible = False
        '
        'Label19
        '
        Me.Label19.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(403, 160)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(98, 15)
        Me.Label19.TabIndex = 53
        Me.Label19.Text = "DoB(mm/dd/yyy):"
        '
        'txtBeneficiaryThreePhone
        '
        Me.txtBeneficiaryThreePhone.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryThreePhone.Location = New System.Drawing.Point(290, 178)
        Me.txtBeneficiaryThreePhone.Mask = "(999) 000-0000"
        Me.txtBeneficiaryThreePhone.Name = "txtBeneficiaryThreePhone"
        Me.txtBeneficiaryThreePhone.ReadOnly = True
        Me.txtBeneficiaryThreePhone.Size = New System.Drawing.Size(100, 21)
        Me.txtBeneficiaryThreePhone.TabIndex = 52
        '
        'Label20
        '
        Me.Label20.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(43, 160)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(38, 15)
        Me.Label20.TabIndex = 48
        Me.Label20.Text = "Name:"
        '
        'txtBeneficiaryThreeName
        '
        Me.txtBeneficiaryThreeName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryThreeName.Location = New System.Drawing.Point(34, 179)
        Me.txtBeneficiaryThreeName.Multiline = True
        Me.txtBeneficiaryThreeName.Name = "txtBeneficiaryThreeName"
        Me.txtBeneficiaryThreeName.ReadOnly = True
        Me.txtBeneficiaryThreeName.Size = New System.Drawing.Size(247, 21)
        Me.txtBeneficiaryThreeName.TabIndex = 51
        '
        'Label21
        '
        Me.Label21.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(694, 161)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(82, 15)
        Me.Label21.TabIndex = 49
        Me.Label21.Text = "Postal Address:"
        '
        'Label22
        '
        Me.Label22.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(294, 160)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(58, 15)
        Me.Label22.TabIndex = 50
        Me.Label22.Text = "Phone No:"
        '
        'txtBeneficiaryTwoProportion
        '
        Me.txtBeneficiaryTwoProportion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryTwoProportion.Location = New System.Drawing.Point(868, 124)
        Me.txtBeneficiaryTwoProportion.Mask = "00"
        Me.txtBeneficiaryTwoProportion.Name = "txtBeneficiaryTwoProportion"
        Me.txtBeneficiaryTwoProportion.ReadOnly = True
        Me.txtBeneficiaryTwoProportion.Size = New System.Drawing.Size(84, 21)
        Me.txtBeneficiaryTwoProportion.TabIndex = 47
        '
        'txtBeneficiaryTwoRelation
        '
        Me.txtBeneficiaryTwoRelation.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryTwoRelation.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBeneficiaryTwoRelation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtBeneficiaryTwoRelation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtBeneficiaryTwoRelation.FormattingEnabled = True
        Me.txtBeneficiaryTwoRelation.Items.AddRange(New Object() {"", "Brother", "Cousin", "Daughter", "Father", "Father-In-Law", "Friend", "Husband/Wife", "Mother", "Mother-In-Law", "Nephew", "Sister", "Son"})
        Me.txtBeneficiaryTwoRelation.Location = New System.Drawing.Point(524, 124)
        Me.txtBeneficiaryTwoRelation.Name = "txtBeneficiaryTwoRelation"
        Me.txtBeneficiaryTwoRelation.Size = New System.Drawing.Size(162, 23)
        Me.txtBeneficiaryTwoRelation.Sorted = True
        Me.txtBeneficiaryTwoRelation.TabIndex = 46
        '
        'txtBeneficiaryTwoAddress
        '
        Me.txtBeneficiaryTwoAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryTwoAddress.Location = New System.Drawing.Point(692, 125)
        Me.txtBeneficiaryTwoAddress.Name = "txtBeneficiaryTwoAddress"
        Me.txtBeneficiaryTwoAddress.ReadOnly = True
        Me.txtBeneficiaryTwoAddress.Size = New System.Drawing.Size(170, 21)
        Me.txtBeneficiaryTwoAddress.TabIndex = 45
        '
        'Label8
        '
        Me.Label8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(872, 106)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 15)
        Me.Label8.TabIndex = 44
        Me.Label8.Text = "Proportion %:"
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(527, 106)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(50, 15)
        Me.Label9.TabIndex = 43
        Me.Label9.Text = "Relation:"
        '
        'txtBeneficiaryTwoDoB
        '
        Me.txtBeneficiaryTwoDoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryTwoDoB.Location = New System.Drawing.Point(292, 92)
        Me.txtBeneficiaryTwoDoB.Mask = "00/00/0000"
        Me.txtBeneficiaryTwoDoB.Name = "txtBeneficiaryTwoDoB"
        Me.txtBeneficiaryTwoDoB.ReadOnly = True
        Me.txtBeneficiaryTwoDoB.Size = New System.Drawing.Size(119, 21)
        Me.txtBeneficiaryTwoDoB.TabIndex = 42
        Me.txtBeneficiaryTwoDoB.ValidatingType = GetType(Date)
        Me.txtBeneficiaryTwoDoB.Visible = False
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(403, 106)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(98, 15)
        Me.Label10.TabIndex = 41
        Me.Label10.Text = "DoB(mm/dd/yyy):"
        '
        'txtBeneficiaryTwoPhone
        '
        Me.txtBeneficiaryTwoPhone.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryTwoPhone.Location = New System.Drawing.Point(290, 124)
        Me.txtBeneficiaryTwoPhone.Mask = "(999) 000-0000"
        Me.txtBeneficiaryTwoPhone.Name = "txtBeneficiaryTwoPhone"
        Me.txtBeneficiaryTwoPhone.ReadOnly = True
        Me.txtBeneficiaryTwoPhone.Size = New System.Drawing.Size(100, 21)
        Me.txtBeneficiaryTwoPhone.TabIndex = 40
        '
        'Label14
        '
        Me.Label14.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(43, 106)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(38, 15)
        Me.Label14.TabIndex = 36
        Me.Label14.Text = "Name:"
        '
        'txtBeneficiaryTwoName
        '
        Me.txtBeneficiaryTwoName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryTwoName.Location = New System.Drawing.Point(34, 125)
        Me.txtBeneficiaryTwoName.Multiline = True
        Me.txtBeneficiaryTwoName.Name = "txtBeneficiaryTwoName"
        Me.txtBeneficiaryTwoName.ReadOnly = True
        Me.txtBeneficiaryTwoName.Size = New System.Drawing.Size(247, 21)
        Me.txtBeneficiaryTwoName.TabIndex = 39
        '
        'Label15
        '
        Me.Label15.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(694, 107)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(82, 15)
        Me.Label15.TabIndex = 37
        Me.Label15.Text = "Postal Address:"
        '
        'Label16
        '
        Me.Label16.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(294, 106)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(58, 15)
        Me.Label16.TabIndex = 38
        Me.Label16.Text = "Phone No:"
        '
        'txtBeneficiaryOneProportion
        '
        Me.txtBeneficiaryOneProportion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryOneProportion.Location = New System.Drawing.Point(868, 72)
        Me.txtBeneficiaryOneProportion.Mask = "000"
        Me.txtBeneficiaryOneProportion.Name = "txtBeneficiaryOneProportion"
        Me.txtBeneficiaryOneProportion.ReadOnly = True
        Me.txtBeneficiaryOneProportion.Size = New System.Drawing.Size(84, 21)
        Me.txtBeneficiaryOneProportion.TabIndex = 35
        '
        'txtBeneficiaryOneRelation
        '
        Me.txtBeneficiaryOneRelation.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryOneRelation.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBeneficiaryOneRelation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtBeneficiaryOneRelation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtBeneficiaryOneRelation.FormattingEnabled = True
        Me.txtBeneficiaryOneRelation.Items.AddRange(New Object() {"", "Brother", "Cousin", "Daughter", "Father", "Father-In-Law", "Friend", "Husband/Wife", "Mother", "Mother-In-Law", "Nephew", "Sister", "Son"})
        Me.txtBeneficiaryOneRelation.Location = New System.Drawing.Point(524, 72)
        Me.txtBeneficiaryOneRelation.Name = "txtBeneficiaryOneRelation"
        Me.txtBeneficiaryOneRelation.Size = New System.Drawing.Size(162, 23)
        Me.txtBeneficiaryOneRelation.Sorted = True
        Me.txtBeneficiaryOneRelation.TabIndex = 34
        '
        'txtBeneficiaryOneAddress
        '
        Me.txtBeneficiaryOneAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryOneAddress.Location = New System.Drawing.Point(692, 73)
        Me.txtBeneficiaryOneAddress.Name = "txtBeneficiaryOneAddress"
        Me.txtBeneficiaryOneAddress.ReadOnly = True
        Me.txtBeneficiaryOneAddress.Size = New System.Drawing.Size(170, 21)
        Me.txtBeneficiaryOneAddress.TabIndex = 33
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(872, 54)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 15)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Proportion %:"
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(527, 54)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 15)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Relation:"
        '
        'txtBeneficiaryOneDoB
        '
        Me.txtBeneficiaryOneDoB.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryOneDoB.Location = New System.Drawing.Point(283, 60)
        Me.txtBeneficiaryOneDoB.Mask = "00/00/0000"
        Me.txtBeneficiaryOneDoB.Name = "txtBeneficiaryOneDoB"
        Me.txtBeneficiaryOneDoB.ReadOnly = True
        Me.txtBeneficiaryOneDoB.Size = New System.Drawing.Size(119, 21)
        Me.txtBeneficiaryOneDoB.TabIndex = 29
        Me.txtBeneficiaryOneDoB.ValidatingType = GetType(Date)
        Me.txtBeneficiaryOneDoB.Visible = False
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(403, 54)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 15)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "DoB(mm/dd/yyy):"
        '
        'txtBeneficiaryOnePhone
        '
        Me.txtBeneficiaryOnePhone.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryOnePhone.Location = New System.Drawing.Point(290, 72)
        Me.txtBeneficiaryOnePhone.Mask = "(999) 000-0000"
        Me.txtBeneficiaryOnePhone.Name = "txtBeneficiaryOnePhone"
        Me.txtBeneficiaryOnePhone.ReadOnly = True
        Me.txtBeneficiaryOnePhone.Size = New System.Drawing.Size(100, 21)
        Me.txtBeneficiaryOnePhone.TabIndex = 27
        '
        'Label3
        '
        Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(43, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 15)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Name:"
        '
        'txtBeneficiaryOneName
        '
        Me.txtBeneficiaryOneName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBeneficiaryOneName.Location = New System.Drawing.Point(34, 73)
        Me.txtBeneficiaryOneName.Multiline = True
        Me.txtBeneficiaryOneName.Name = "txtBeneficiaryOneName"
        Me.txtBeneficiaryOneName.ReadOnly = True
        Me.txtBeneficiaryOneName.Size = New System.Drawing.Size(247, 21)
        Me.txtBeneficiaryOneName.TabIndex = 23
        '
        'Label12
        '
        Me.Label12.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(694, 55)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 15)
        Me.Label12.TabIndex = 21
        Me.Label12.Text = "Postal Address:"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(294, 54)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 15)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Phone No:"
        '
        'btnAddMember
        '
        Me.btnAddMember.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAddMember.BackColor = System.Drawing.Color.SeaGreen
        Me.btnAddMember.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAddMember.FlatAppearance.BorderSize = 0
        Me.btnAddMember.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAddMember.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnAddMember.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddMember.ForeColor = System.Drawing.Color.White
        Me.btnAddMember.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnAddMember.IconColor = System.Drawing.Color.Black
        Me.btnAddMember.IconSize = 16
        Me.btnAddMember.Location = New System.Drawing.Point(855, 466)
        Me.btnAddMember.Name = "btnAddMember"
        Me.btnAddMember.Rotation = 0R
        Me.btnAddMember.Size = New System.Drawing.Size(75, 28)
        Me.btnAddMember.TabIndex = 15
        Me.btnAddMember.Text = "Add"
        Me.btnAddMember.UseVisualStyleBackColor = False
        '
        'previousBtn
        '
        Me.previousBtn.BackColor = System.Drawing.Color.White
        Me.previousBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.previousBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.previousBtn.ForeColor = System.Drawing.Color.Black
        Me.previousBtn.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft
        Me.previousBtn.IconColor = System.Drawing.Color.DarkGreen
        Me.previousBtn.IconSize = 18
        Me.previousBtn.Location = New System.Drawing.Point(10, 4)
        Me.previousBtn.Name = "previousBtn"
        Me.previousBtn.Rotation = 0R
        Me.previousBtn.Size = New System.Drawing.Size(48, 23)
        Me.previousBtn.TabIndex = 12
        Me.previousBtn.UseVisualStyleBackColor = False
        '
        'SecAddMemberPage2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(996, 531)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnAddMember)
        Me.Controls.Add(Me.txtAcceptAgreement)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.previousBtn)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "SecAddMemberPage2"
        Me.Text = "SecAddMemberPage2"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.motherLiveStatus.ResumeLayout(False)
        Me.motherLiveStatus.PerformLayout()
        Me.fatherLiveStatus.ResumeLayout(False)
        Me.fatherLiveStatus.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtFatherPhone As MaskedTextBox
    Friend WithEvents txtMotherPhone As MaskedTextBox
    Friend WithEvents motherLiveStatus As Panel
    Friend WithEvents txtMotherAlive As RadioButton
    Friend WithEvents txtMotherDead As RadioButton
    Friend WithEvents fatherLiveStatus As Panel
    Friend WithEvents txtFatherAlive As RadioButton
    Friend WithEvents txtFatherDead As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents txtFatherName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents txtMotherName As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents btnAddMember As FontAwesome.Sharp.IconButton
    Friend WithEvents txtAcceptAgreement As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtBeneficiaryFourDoBD As DateTimePicker
    Friend WithEvents txtBeneficiaryThreeDoBC As DateTimePicker
    Friend WithEvents txtBeneficiaryTwoDoBB As DateTimePicker
    Friend WithEvents txtBeneficiaryOneDoBA As DateTimePicker
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtNoBeneficiary As RadioButton
    Friend WithEvents fourBeneficiary As RadioButton
    Friend WithEvents threeBeneficiary As RadioButton
    Friend WithEvents twoBeneficiary As RadioButton
    Friend WithEvents oneBeneficiary As RadioButton
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents txtBeneficiaryFourProportion As MaskedTextBox
    Friend WithEvents txtBeneficiaryFourRelation As ComboBox
    Friend WithEvents txtBeneficiaryFourAddress As MaskedTextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents txtBeneficiaryFourDoB As MaskedTextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents txtBeneficiaryFourPhone As MaskedTextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents txtBeneficiaryFourName As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents txtBeneficiaryThreeProportion As MaskedTextBox
    Friend WithEvents txtBeneficiaryThreeRelation As ComboBox
    Friend WithEvents txtBeneficiaryThreeAddress As MaskedTextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents txtBeneficiaryThreeDoB As MaskedTextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents txtBeneficiaryThreePhone As MaskedTextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtBeneficiaryThreeName As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents txtBeneficiaryTwoProportion As MaskedTextBox
    Friend WithEvents txtBeneficiaryTwoRelation As ComboBox
    Friend WithEvents txtBeneficiaryTwoAddress As MaskedTextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtBeneficiaryTwoDoB As MaskedTextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtBeneficiaryTwoPhone As MaskedTextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtBeneficiaryTwoName As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents txtBeneficiaryOneProportion As MaskedTextBox
    Friend WithEvents txtBeneficiaryOneRelation As ComboBox
    Friend WithEvents txtBeneficiaryOneAddress As MaskedTextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtBeneficiaryOneDoB As MaskedTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtBeneficiaryOnePhone As MaskedTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtBeneficiaryOneName As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents previousBtn As FontAwesome.Sharp.IconButton
End Class
