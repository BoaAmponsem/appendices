﻿Imports System.Data.SqlClient
Public Class ExclusionListPage
    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Marriage_Type,Hometown,Removed_By from ExclusionTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Surname  like '%' +@parm1+ '%' "
            query &= " or Staff_ID like '%' +@parm1+ '%' "
            query &= " or Phone like '%' +@parm1+ '%' "
            query &= " or Other_Names like '%' +@parm1+ '%' "
            query &= " or Sex like '%' +@parm1+ '%' "

            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using


            Dim restoreButtonColumn As New DataGridViewButtonColumn()
            restoreButtonColumn.HeaderText = ""
            restoreButtonColumn.Text = "Restore"
            restoreButtonColumn.Name = "RestoreBtn"
            restoreButtonColumn.UseColumnTextForButtonValue = True




            ExclusionDataGridView.Columns.Add(restoreButtonColumn)


        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function

    Private Sub Populate()
        Try
            Con.Open()
            Dim query As String = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Marriage_Type,Hometown,Removed_By from ExclusionTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ExclusionDataGridView.DataSource = ds.Tables(0)


            Dim restoreButtonColumn As New DataGridViewButtonColumn()
            restoreButtonColumn.HeaderText = ""
            restoreButtonColumn.Text = "Restore"
            restoreButtonColumn.Name = "RestoreBtn"
            restoreButtonColumn.UseColumnTextForButtonValue = True
            ExclusionDataGridView.Columns.Add(restoreButtonColumn)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try

    End Sub
    Private Sub PopulateRefresh()
        Try
            Con.Open()
            Dim query As String = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Marriage_Type,Hometown,Removed_By from ExclusionTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ExclusionDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try

    End Sub

    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        ExclusionDataGridView.DataSource = Me.SearchItem
    End Sub
    Dim readTheRealID
    Private Function ReadMemberDetails(TheId)
        Try
            Con.Open()
            Dim query = "select * from ExclusionTbl where Staff_ID='" & TheId & "'"
            cmd = New SqlCommand(query, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            readTheRealID = myReader("Id")
            memberUserStaffID = myReader("Staff_ID")
            memberUserSurname = myReader("Surname")
            memberUserOthername = myReader("Other_Names")
            memberUserPhone = myReader("Phone")
            memberUserSex = myReader("Sex")
            memberUserHouseNo = myReader("House_No")
            memberUserPostalAddress = myReader("Postal_Address")
            memberUserDoB = myReader("Birth_Date")
            memberUserMaritalStatus = myReader("Marital_Status")
            memberUserTypeOfMarriage = myReader("Marriage_Type")
            memberUserHomeTown = myReader("Hometown")
            profilePicture = CType(myReader("Picture"), Byte())
            memberRegistrationDate = myReader("Registration_Date")
            memberUserOperator = myReader("Operator1")

        Catch ex As SqlException
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function
    Private Sub ExclusionListPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
    End Sub
    'Restore The Member
    Private Sub restoreTheMember()
        Try
            Con.Open()

            Dim query3 As String
            query3 = "INSERT INTO MembersTbl (Staff_ID, Surname, Other_Names, Phone, Sex, House_No, Postal_Address, Marital_Status, Marriage_Type, Hometown, Birth_Date, Picture, Registration_Date, Operator) " &
                 "VALUES (@Staff_ID, @Surname, @Other_Names, @Phone, @Sex, @House_No, @Postal_Address, @Marital_Status, @Marriage_Type, @Hometown, @Birth_Date, @ProfilePicture, @Registration_Date, @User_Operator)"

            cmd = New SqlCommand(query3, Con)

            cmd.Parameters.AddWithValue("@Staff_ID", memberUserStaffID)
            cmd.Parameters.AddWithValue("@Surname", memberUserSurname)
            cmd.Parameters.AddWithValue("@Other_Names", memberUserOthername)
            cmd.Parameters.AddWithValue("@Phone", memberUserPhone)
            cmd.Parameters.AddWithValue("@Sex", memberUserSex)
            cmd.Parameters.AddWithValue("@House_No", memberUserHouseNo)
            cmd.Parameters.AddWithValue("@Postal_Address", memberUserPostalAddress)
            cmd.Parameters.AddWithValue("@Marital_Status", memberUserMaritalStatus)
            cmd.Parameters.AddWithValue("@Marriage_Type", memberUserTypeOfMarriage)
            cmd.Parameters.AddWithValue("@Hometown", memberUserHomeTown)
            cmd.Parameters.AddWithValue("@Birth_Date", memberUserDoB)
            cmd.Parameters.AddWithValue("@ProfilePicture", profilePicture)
            cmd.Parameters.AddWithValue("@Registration_Date", memberRegistrationDate)
            cmd.Parameters.AddWithValue("@User_Operator", memberUserOperator)

            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    Private Sub deleteTheMember(theIDtoDelete)
        'Insert to MemberTbl
        Try
            Con.Open()
            Dim query3 As String
            query3 = "delete from ExclusionTbl where Id ='" & theIDtoDelete & "'"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()

            MessageBox.Show("Member restored successfully", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try


    End Sub
    Private Sub ExclusionDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles ExclusionDataGridView.CellContentClick
        Try
            If e.RowIndex >= 0 AndAlso e.ColumnIndex = ExclusionDataGridView.Columns("RestoreBtn").Index Then

                Dim row As DataGridViewRow = ExclusionDataGridView.Rows(e.RowIndex)

                getStaffIDToEdit = row.Cells(2).Value.ToString
                Dim theMembName = row.Cells(3).Value.ToString

                Dim restoreQuestion As DialogResult = MessageBox.Show("Restore " + theMembName + " with Staff_ID " + "(" + getStaffIDToEdit, "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If (restoreQuestion = DialogResult.Yes) Then
                    ReadMemberDetails(getStaffIDToEdit)

                    restoreTheMember()
                    deleteTheMember(readTheRealID)
                    PopulateRefresh()

                End If



            End If
        Catch ex As Exception

        End Try
    End Sub
End Class