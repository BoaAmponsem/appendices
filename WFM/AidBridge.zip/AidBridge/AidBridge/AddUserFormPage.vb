﻿Imports System.Data.SqlClient
Public Class AddUserFormPage
    Sub switchPages(ByVal pageSwitch1 As Form)
        Try

            Form1.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            Form1.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Clear()
        txtUsername.Text = ""
        txtPhone.Text = ""
        txtStaffID.Text = ""
        txtGmail.Text = ""
        txtPassword1.Text = ""
        txtPassword2.Text = ""
        txtAccountType.Text = ""
    End Sub
    Dim aa As Integer
    Dim aa2 As Integer
    Dim aa3 As Integer
    Dim aa4 As Integer

    Dim aa5 As Integer
    Dim aa6 As Integer
    Dim aa7 As Integer
    Dim aa8 As Integer

    Dim nullPreviousPassword = ""

    Dim first4 As String
    Dim last3 As String
    Dim checkForCorrectMail As String
    Private Sub btnCreateAccount_Click(sender As Object, e As EventArgs) Handles btnCreateAccount.Click
        Dim theDate = New MonthCalendar
        'Dim encryptUserName = Encrypt(txtUsername.Text)
        Dim encryptUserPassword = Encrypt(txtPassword1.Text)
        Dim encryptUserGmail = Encrypt(txtGmail.Text.ToLower)
        Dim encryptUserPhone = Encrypt(txtPhone.Text)
        '  Dim encryptUserStaffID = Encrypt(txtStaffID.Text)

        Dim AccountDate = theDate.TodayDate

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from UsersTbl where Username='" & txtUsername.Text & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from UsersTbl where Staff_ID ='" & txtStaffID.Text & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa2 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from UsersTbl where Phone ='" & encryptUserPhone & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa3 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from UsersTbl where Gmail ='" & encryptUserGmail & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa4 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        '
        '
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from AdminTbl where Username='" & txtUsername.Text & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa5 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from AdminTbl where Staff_ID ='" & txtStaffID.Text & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa6 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from AdminTbl where Phone ='" & encryptUserPhone & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa7 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from AdminTbl where Gmail ='" & encryptUserGmail & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa8 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        '

        Try
            If (txtGmail.Text.Length > 10) Then
                checkForCorrectMail = txtGmail.Text.Substring(txtGmail.Text.Length - 10)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        '

        Try
            If (txtStaffID.Text.Length = 4) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(0, 4)
            ElseIf (txtStaffID.Text.Length = 5) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 1)
            ElseIf (txtStaffID.Text.Length = 6) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 2)
            ElseIf (txtStaffID.Text.Length = 7) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 3)
            ElseIf (txtStaffID.Text.Length = 8) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 4)
            ElseIf (txtStaffID.Text.Length = 9) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 5)
            ElseIf (txtStaffID.Text.Length = 10) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 6)
            ElseIf (txtStaffID.Text.Length = 11) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 7)
            ElseIf (txtStaffID.Text.Length = 12) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 8)
            ElseIf (txtStaffID.Text.Length = 13) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 9)
            ElseIf (txtStaffID.Text.Length = 14) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 10)
            ElseIf (txtStaffID.Text.Length = 15) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 11)
            ElseIf (txtStaffID.Text.Length = 16) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 12)
            ElseIf (txtStaffID.Text.Length = 17) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 13)
            ElseIf (txtStaffID.Text.Length = 18) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 14)
            ElseIf (txtStaffID.Text.Length = 19) Then
                first4 = txtStaffID.Text.Substring(0, 4)
                last3 = txtStaffID.Text.Substring(txtStaffID.Text.Length - 15)
            End If
        Catch ex As Exception

        End Try

        '   Dim lastFive As String = txtStaffID.Text.Substring(txtStaffID.Text.Length - 5)
        Try
            If (txtUsername.Text = "" Or txtPhone.Text = "") Then
                MsgBox("Empty field(s)")
            ElseIf (txtPhone.Text = "") Then
                MsgBox("Enter the member's Phone number")
                txtPhone.Focus()
            ElseIf (txtPhone.Text.Length < 10 Or txtPhone.Text.Length > 10 Or IsNumeric(txtPhone.Text) = False) Then
                MsgBox("Invalid member's Phone number")
                txtPhone.Focus()
            ElseIf (txtGmail.Text = "") Then
                MsgBox("Enter your Gmail", MsgBoxStyle.Exclamation)
                txtGmail.Focus()
            ElseIf (txtGmail.Text.Length < 11) Then
                MsgBox("Enter a valid 'Gmail'", MsgBoxStyle.Exclamation)
                txtGmail.Focus()
            ElseIf (checkForCorrectMail.ToLower <> "@gmail.com") Then
                MsgBox("Enter a valid 'Gmail', e.g my@gmail.com ", MsgBoxStyle.Exclamation)
                txtGmail.Focus()
            ElseIf (txtPassword1.Text = "") Then
                MsgBox("Set a password", MsgBoxStyle.Exclamation)
                txtPassword1.Focus()
            ElseIf (txtPassword2.Text = "") Then
                MsgBox("Confirm password", MsgBoxStyle.Exclamation)
                txtPassword2.Focus()
            ElseIf ((txtPassword1.Text = txtPassword2.Text) = False) Then
                MsgBox("The password does not match")
            ElseIf (txtPassword2.Text.Length < 6) Then
                MsgBox("The password length must be 6 or more")
            ElseIf (txtAccountType.Text = "") Then
                MsgBox("Select an Account Type")
                txtAccountType.Focus()
            ElseIf (txtStaffID.Text = "") Then
                MessageBox.Show("Enter the member's Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length > 19 Or txtStaffID.Text.Length < 4) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 4 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 5 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 6 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 7 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 8 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 9 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 10 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 11 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 12 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 13 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 14 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 15 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 16 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 17 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 18 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtStaffID.Text.Length = 19 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf ((aa = 0) = False) Then
                MsgBox("Username already exist")
            ElseIf ((aa5 = 0) = False) Then
                MsgBox("Username already exist")
            ElseIf ((aa2 = 0) = False) Then
                MsgBox("Account already exist")
            ElseIf ((aa6 = 0) = False) Then
                MsgBox("Account already exist")
            ElseIf ((aa3 = 0) = False) Then
                MsgBox("Phone number already exist")
            ElseIf ((aa7 = 0) = False) Then
                MsgBox("Phone number already exist")
            ElseIf ((aa4 = 0) = False) Then
                MsgBox("Gmail already exist")
            ElseIf ((aa8 = 0) = False) Then
                MsgBox("Gmail already exist")
            ElseIf (first4.ToLower = "sno-" Or first4.ToLower = "gov-")
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query3 As String
                query3 = "insert into UsersTbl values('" & txtStaffID.Text & "','" & txtUsername.Text & "','" & encryptUserPhone & "','" & encryptUserGmail & "','" & encryptUserPassword & "','" & nullPreviousPassword & "','" & AccountDate & "','" & txtAccountType.Text & "')"
                cmd = New SqlCommand(query3, Con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Clear()

            ElseIf (IsNumeric(txtStaffID.Text) = True)
                '
                '
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query3 As String
                query3 = "insert into UsersTbl values('" & txtStaffID.Text & "','" & txtUsername.Text & "','" & encryptUserPhone & "','" & encryptUserGmail & "','" & encryptUserPassword & "','" & nullPreviousPassword & "','" & AccountDate & "','" & txtAccountType.Text & "')"
                cmd = New SqlCommand(query3, Con)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Clear()

                '
                '
                '
            Else
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

    End Sub

    Private Sub showPassword_CheckedChanged(sender As Object, e As EventArgs) Handles showPassword.CheckedChanged
        If (showPassword.Checked = True) Then
            txtPassword1.PasswordChar = ""
            txtPassword2.PasswordChar = ""
        Else
            txtPassword1.PasswordChar = "*"
            txtPassword2.PasswordChar = "*"
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Dim nwUsersPage = New UsersPage
        switchPages(nwUsersPage)
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub txtAccountType_KeyUp(sender As Object, e As KeyEventArgs) Handles txtAccountType.KeyUp
        'txtAccountType.Text = ""
    End Sub
End Class