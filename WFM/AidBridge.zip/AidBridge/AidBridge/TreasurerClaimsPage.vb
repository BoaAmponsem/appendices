﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Drawing.Imaging
Public Class TreasurerClaimsPage

    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select * from ClaimsTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Member_Name  like '%' +@parm1+ '%' "
            query &= " or Member_ID like '%' +@parm1+ '%' "
            query &= " or Amount_Given like '%' +@parm1+ '%' "
            query &= " or Reason like '%' +@parm1+ '%' "
            query &= " or Claimer like '%' +@parm1+ '%' "
            query &= " or Beneficiary_Name like '%' +@parm1+ '%' "
            query &= " or Claim_Date like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using
            '  End Using
        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function
    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select * from ClaimsTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ClaimsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub

    'Populate is Request is Approved
    Dim okButtonColumn As New DataGridViewButtonColumn()
    Dim doneButtonColumn As New DataGridViewButtonColumn()
    Private Sub PopulateApprovalDone(MemberIDNo)
        approvalsDataGridView.Refresh()
        Try
            Con.Open()
            Dim query = "select Id,Member_Name,Amount,Approval_Status,Approval_Date,Reason,Request_Date,Claimer from ApprovalStatusTbl where Member_ID = '" & MemberIDNo & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            approvalsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            '  End Using

            doneButtonColumn.HeaderText = ""
            doneButtonColumn.Text = "Done"
            doneButtonColumn.Name = "doneBtn"
            doneButtonColumn.UseColumnTextForButtonValue = True




            okButtonColumn.HeaderText = ""
            okButtonColumn.Text = "Ok"
            okButtonColumn.Name = "okBtn"
            okButtonColumn.UseColumnTextForButtonValue = True
            okButtonColumn.Visible = False



            If approvalsDataGridView.Columns("doneBtn") Is Nothing Then
                approvalsDataGridView.Columns.Add(doneButtonColumn)
            End If


            If approvalsDataGridView.Columns("okBtn") Is Nothing Then
                approvalsDataGridView.Columns.Add(okButtonColumn)
            End If



        Catch ex As Exception

        End Try






    End Sub
    'Populate when Request is cancelled
    Private Sub PopulateApprovalCancel(MemberIDNo)
        approvalsDataGridView.Refresh()
        Try
            Con.Open()
            Dim query = "select Id,Member_Name,Amount,Approval_Status,Approval_Date,Reason,Request_Date,Claimer from ApprovalStatusTbl where Member_ID = '" & MemberIDNo & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            approvalsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            '  End Using
            Dim okButtonColumn As New DataGridViewButtonColumn()
            okButtonColumn.HeaderText = ""
            okButtonColumn.Text = "Ok"
            okButtonColumn.Name = "okBtn"
            okButtonColumn.UseColumnTextForButtonValue = True

            doneButtonColumn.HeaderText = ""
            doneButtonColumn.Text = "Done"
            doneButtonColumn.Name = "doneBtn"
            doneButtonColumn.UseColumnTextForButtonValue = True




            '  okButtonColumn.Visible = False
            If approvalsDataGridView.Columns("okBtn") Is Nothing Then
                approvalsDataGridView.Columns.Add(okButtonColumn)
            End If

            If approvalsDataGridView.Columns("doneBtn") Is Nothing Then
                approvalsDataGridView.Columns.Add(doneButtonColumn)
            End If

        Catch ex As Exception

        End Try

    End Sub
    'Populate when Approval Status is on pending
    Private Sub PopulateApproval(MemberIDNo)
        approvalsDataGridView.Refresh()
        Try
            Con.Open()
            Dim query = "select Id,Member_Name,Amount,Approval_Status,Approval_Date,Reason,Request_Date,Claimer from ApprovalStatusTbl where Member_ID = '" & MemberIDNo & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            approvalsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        '  End Using

    End Sub

    Dim CheckOne As Integer = 0, CheckTwo As Integer = 0, CheckThree As Integer = 0
    Private Sub CheckApprovalStateOne(MemberIDNo)
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ApprovalStatusTbl where Member_ID = '" & MemberIDNo & "' And Approval_Status = 'Pending...'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            CheckOne = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub

    Private Sub CheckApprovalStateTwo(MemberIDNo)
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ApprovalStatusTbl where Member_ID = '" & MemberIDNo & "' And Approval_Status = 'Cancelled'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            CheckTwo = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub

    Private Sub CheckApprovalStateThree(MemberIDNo)
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ApprovalStatusTbl where Member_ID = '" & MemberIDNo & "' And Approval_Status = 'Approved'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            CheckThree = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub

    Dim aa2 As Integer
    Private Function ClaimsByMember(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ClaimsTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            MemberClaimsDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Function

    Private Function ClaimsByMemberPhone(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ClaimsTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            MemberClaimsDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Function


    ''Function to show member children on Profile Page
    Private Function ChildrenByMember(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ChildrenTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.childrenDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    ''Function to show member Parents on Profile Page
    Private Function MemberParents(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from ParentsTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.parentsDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    ''Function to show member Spouse on Profile Page
    Private Function MemberSpouse(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from SpouseTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.spouseDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    ''Function to show member Beneficiaries on Profile Page
    Private Function MemberBeneficiaries(theMemberID)
        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    Private Function MemberDetails(theMemberID)
        Try
            Con.Open()
            Dim query = "select Id,Staff_ID,Surname,Other_Names,Phone,Sex,House_No,Postal_Address,Marital_Status,Marriage_Type,Hometown,Birth_Date,Registration_Date,Operator from MembersTbl where Staff_ID='" & theMemberID & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ShowProfilePage.personalInfoDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

            Con.Close()
        End Try
    End Function

    Private Sub TreasurerClaimsPage_Load(sender As Object, e As EventArgs) Handles Me.Load
        Populate()
        AcceptButton = QueryBtn
    End Sub

    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        ClaimsDataGridView.DataSource = Me.SearchItem
    End Sub
    Dim MemberSurnamePrivate
    Private Sub QueryBtn_Click(sender As Object, e As EventArgs) Handles QueryBtn.Click
        ClaimStatus.Hide()
        TreasurerClaimStatus.Hide()
        ShowProfilePage.Hide()
        If (searchBox.Text = "") Then

            InformationTab.Visible = False
            ClaimsTab.Visible = False
            ClaimRequestTab.Visible = False
            showProfileBtn.Visible = False
            ClaimStatusBtn.Visible = False

            MessageBox.Show("Enter the member's ID/Phone", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

        ElseIf (selectIDType.Text = "") Then

            InformationTab.Visible = False
            ClaimsTab.Visible = False
            ClaimRequestTab.Visible = False
            showProfileBtn.Visible = False
            ClaimStatusBtn.Visible = False

            MessageBox.Show("Select the ID Type", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

        ElseIf (selectIDType.Text = "Staff ID") Then
            '
            '
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from MembersTbl where Staff_ID ='" & searchBox.Text & "' "
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count

                ' If aa2 <> "" Then
                ' memberUserPicture = Application.StartupPath & "\Profile pictures\" & dt.Rows(0).Item("Picture")
                'End If

            Catch ex As Exception
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
            '
            '
            'When member exist
            If ((aa2 = 0) = False) Then
                memberUserSurname = ""
                memberUserOthername = ""
                MemberSurnamePrivate = ""
                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Staff_ID='" & searchBox.Text & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUserStaffID = myReader("Staff_ID")
                    MemberSurnamePrivate = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")
                    profilePicture = CType(myReader("Picture"), Byte())

                    memberUserSurname = MemberSurnamePrivate + " " + memberUserOthername


                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                Try
                    txtSurname.Text = MemberSurnamePrivate.ToUpper
                    txtMemberOtherName.Text = memberUserOthername.ToUpper
                    txtBirthDate.Text = memberUserDoB
                    txtSex.Text = memberUserSex
                    txtHomeTown.Text = memberUserHomeTown.ToUpper
                    txtMaritalStatus.Text = memberUserMaritalStatus
                    txtMarriageType.Text = memberUserTypeOfMarriage
                    txtHouseNo.Text = memberUserHouseNo.ToUpper
                    txtPostalAddress.Text = memberUserPostalAddress.ToUpper
                    txtPhone.Text = memberUserPhone.ToUpper
                    txtStaffID.Text = memberUserStaffID

                    memberNotFoundFeedback.Visible = False

                    ClaimsByMember(txtStaffID.Text)

                    'Populate is Request is Approved
                    CheckApprovalStateOne(txtStaffID.Text)
                    'Populate is Request is Cancelled
                    CheckApprovalStateTwo(txtStaffID.Text)
                    'Populate is Request on Pending
                    CheckApprovalStateThree(txtStaffID.Text)

                    If (CheckOne <> 0) Then
                        'Populate is Request on Pending
                        PopulateApproval(txtStaffID.Text)

                    ElseIf (CheckTwo <> 0) Then
                        'Populate is Request is Cancelled  
                        ' MsgBox("Hmmmm")
                        PopulateApprovalCancel(txtStaffID.Text)

                        okButtonColumn.Visible = True
                        doneButtonColumn.Visible = False

                    ElseIf (CheckThree <> 0) Then
                        'Populate is Request is Approved
                        okButtonColumn.Visible = False
                        doneButtonColumn.Visible = True

                        PopulateApprovalDone(txtStaffID.Text)

                    Else

                        PopulateApproval(txtStaffID.Text)

                    End If

                    InformationTab.Visible = True
                    ClaimsTab.Visible = True
                    ClaimRequestTab.Visible = True
                    showProfileBtn.Visible = True
                    ClaimStatusBtn.Visible = True


                Catch ex As Exception

                End Try

            Else
                'When member doesn't exist
                InformationTab.Visible = False
                ClaimsTab.Visible = False
                ClaimRequestTab.Visible = False
                showProfileBtn.Visible = False
                ClaimStatusBtn.Visible = False

                memberNotFoundFeedback.Visible = True
                Timer1.Start()
            End If

        ElseIf (selectIDType.Text = "Phone") Then
            '
            'Check if member with Phone number entered exist
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim query22 = "select * from MembersTbl where Phone ='" & searchBox.Text & "' "
                cmd = New SqlCommand(query22, Con)
                adaptor = New SqlDataAdapter(cmd)
                ds = New DataSet()
                adaptor.Fill(ds)
                aa2 = ds.Tables(0).Rows.Count

            Catch ex As Exception
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try

            'When member exist
            If ((aa2 = 0) = False) Then
                memberUserSurname = ""
                memberUserOthername = ""
                MemberSurnamePrivate = ""
                Try
                    Con.Open()
                    Dim query = "select * from MembersTbl where Phone='" & searchBox.Text & "'"
                    cmd = New SqlCommand(query, Con)
                    myReader = cmd.ExecuteReader
                    myReader.Read()
                    memberUserStaffID = myReader("Staff_ID")
                    MemberSurnamePrivate = myReader("Surname")
                    memberUserOthername = myReader("Other_Names")
                    memberUserPhone = myReader("Phone")
                    memberUserSex = myReader("Sex")
                    memberUserHouseNo = myReader("House_No")
                    memberUserPostalAddress = myReader("Postal_Address")
                    memberUserDoB = myReader("Birth_Date")
                    memberUserMaritalStatus = myReader("Marital_Status")
                    memberUserTypeOfMarriage = myReader("Marriage_Type")
                    memberUserHomeTown = myReader("Hometown")
                    profilePicture = CType(myReader("Picture"), Byte())

                    memberUserSurname = MemberSurnamePrivate + " " + memberUserOthername

                    '     memberUserPicture = myReader("Picture")
                Catch ex As SqlException
                    MsgBox(ex.Message)
                Finally
                    Con.Close()
                End Try

                Try
                    txtSurname.Text = MemberSurnamePrivate.ToUpper
                    txtMemberOtherName.Text = memberUserOthername.ToUpper
                    txtBirthDate.Text = memberUserDoB
                    txtSex.Text = memberUserSex
                    txtHomeTown.Text = memberUserHomeTown.ToUpper
                    txtMaritalStatus.Text = memberUserMaritalStatus
                    txtMarriageType.Text = memberUserTypeOfMarriage
                    txtHouseNo.Text = memberUserHouseNo.ToUpper
                    txtPostalAddress.Text = memberUserPostalAddress.ToUpper
                    txtPhone.Text = memberUserPhone
                    txtStaffID.Text = memberUserStaffID.ToUpper

                    memberNotFoundFeedback.Visible = False

                    ClaimsByMember(txtStaffID.Text)

                    'Populate is Request is Approved
                    CheckApprovalStateOne(txtStaffID.Text)
                    'Populate is Request is Cancelled
                    CheckApprovalStateTwo(txtStaffID.Text)
                    'Populate is Request on Pending
                    CheckApprovalStateThree(txtStaffID.Text)

                    If (CheckOne <> 0) Then
                        'Populate is Request on Pending
                        PopulateApproval(txtStaffID.Text)
                    ElseIf (CheckTwo <> 0) Then
                        'Populate is Request is Cancelled
                        '  PopulateApprovalCancel(txtStaffID.Text)
                        PopulateApprovalCancel(txtStaffID.Text)
                        '  PopulateApprovalDone(txtStaffID.Text)
                        doneButtonColumn.Visible = False

                    ElseIf (CheckThree <> 0) Then
                        'Populate is Request is Approved
                        okButtonColumn.Visible = False
                        PopulateApprovalDone(txtStaffID.Text)
                    Else
                        PopulateApproval(txtStaffID.Text)

                    End If

                    InformationTab.Visible = True
                    ClaimsTab.Visible = True
                    ClaimRequestTab.Visible = True
                    showProfileBtn.Visible = True
                    ClaimStatusBtn.Visible = True
                Catch ex As Exception

                End Try
            Else
                ''Member doesn't exist message
                InformationTab.Visible = False
                ClaimsTab.Visible = False
                ClaimRequestTab.Visible = False
                showProfileBtn.Visible = False
                ClaimStatusBtn.Visible = False

                memberNotFoundFeedback.Visible = True
                Timer1.Start()
                ''member with Phone number exist End If
            End If


            'Main If
        End If
    End Sub

    Private Sub selectIDType_KeyUp(sender As Object, e As KeyEventArgs) Handles selectIDType.KeyUp
        selectIDType.Text = ""
    End Sub

    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click
        memberNotFoundFeedback.Visible = False
    End Sub

    Private Sub showProfileBtn_Click(sender As Object, e As EventArgs) Handles showProfileBtn.Click
        'Dim nwShowProfilePage = New ShowProfilePage

        ClaimStatus.Hide()
        TreasurerClaimStatus.Hide()

        ' Convert the byte array to an image
        Try
            Using ms As New MemoryStream(profilePicture)
                ShowProfilePage.MemberProfile.Image = Image.FromStream(ms)
            End Using
        Catch ex As Exception

        End Try


        MemberDetails(memberUserStaffID)
        MemberParents(memberUserStaffID)
        ChildrenByMember(memberUserStaffID)
        MemberSpouse(memberUserStaffID)
        MemberBeneficiaries(memberUserStaffID)

        ShowProfilePage.Show()
    End Sub

    Dim aa4 As Integer = 0, numberOFContribution As Integer = 0

    Dim counterr As Integer = 0

    Private Sub CompleteClaimProcess(Id, Name, Amount, Reason, Claimer, Beneficiary)
        Try
            '  Dim theDate = New MonthCalendar
            ' Dim ClaimDate = theDate.TodayDate

            Dim theDate = New DateTimePicker
            Dim ClaimDate As Date = theDate.Value.Date
            '  Dim changeTheDateFormat As Date = txtMonthOfPayment1.Value.Date
            Dim theCorrectFormat As String = ClaimDate.ToString("yyyy-MM-dd")

            Con.Open()
            Dim query3 As String
            query3 = "insert into ClaimsTbl values('" & Id & "','" & Name & "','" & Amount & "','" & Reason & "','" & Claimer & "','" & Beneficiary & "','" & theCorrectFormat & "','" & Uname & "','" & UStaffID & "')"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()
            '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim qury = "delete from ApprovalStatusTbl where Member_ID = '" & Id & "'"
            cmd = New SqlCommand(qury, Con)
            cmd.ExecuteNonQuery()
            MsgBox("Claim successful", MsgBoxStyle.Information)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub deleteClaimRequest(Id)
        Try
            Con.Open()
            Dim qury = "delete from ApprovalStatusTbl where Id = '" & Id & "'"
            cmd = New SqlCommand(qury, Con)
            cmd.ExecuteNonQuery()
            ' MsgBox("Claim successful", MsgBoxStyle.Information)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    'DeleteSpouse
    Private Function DeleteSpouse(spouseID)
        Try
            Con.Open()
            Dim query3 As String
            query3 = "delete from SpouseTbl where Member_ID = '" & spouseID & "'"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function


    'Read the mother or father ID for ParentsTbl
    Private Function ReadFatherOrMother(ParentType)
        Try
            Con.Open()
            Dim query = "select * from ParentsTbl where Member_ID='" & txtStaffID.Text & "'and Parent_Type = '" & ParentType & "'"
            cmd = New SqlCommand(query, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            AMotherOrFatherID = myReader("Id")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

    End Function


    'Function to Update parentsTbl
    Private Function UpdatePrentsTbl(parentID)
        Try
            Con.Open()
            Cursor = Cursors.WaitCursor
            Dim query As String
            query = "Update ParentsTbl set Live_Status='" & AMotherDeadStatus & "'  where Id =" & parentID & ""
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            '  
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    'Update member Marital Status to Married
    Private Sub UpdateMemberMaritalStatusToMarried()
        Try
            Con.Open()
            Cursor = Cursors.WaitCursor
            Dim query As String
            query = "Update MembersTbl set Marital_Status='" & theMemberMarried & "' where Staff_ID ='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            '  MessageBox.Show("Claim successfull", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub


    'Update member Marital Status to Single
    Private Sub UpdateMemberMaritalStatusToSingle()
        Try
            Con.Open()
            Cursor = Cursors.WaitCursor
            Dim query As String
            query = "Update MembersTbl set Marital_Status='" & theMemberSingle & "', Marriage_Type='" & nullMarriageStatus & "'   where Staff_ID ='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            '   MessageBox.Show("Claim successfull", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub

    Private Sub getClaimDetails(mmemberID)
        Try
            Con.Open()
            Dim query = "select * from ApprovalStatusTbl where Id='" & mmemberID & "'"
            cmd = New SqlCommand(query, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            memberUserStaffID = myReader("Member_ID")
            memberUserSurname = myReader("Member_Name")
            Amount = myReader("Amount")
            Reason = myReader("Reason")
            Claimer = myReader("Claimer")
            BeneficiaryName = myReader("Beneficiary_Name")
            '     memberUserPicture = myReader("Picture")

        Catch ex As SqlException
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub


    Dim getReasonForClaim As String



    Private Sub approvalsDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles approvalsDataGridView.CellContentClick
        Try

            If (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index) Then


                If (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Child Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString

                    ' MsgBox(getStaffIDToEdit) Departure

                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)
                    End If



                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Deceased Member") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)

                    End If



                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Self Medical Treatment") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)

                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Husband/Wife Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then

                        getClaimDetails(getStaffIDToEdit)

                        ''   MsgBox("Spouse Removed")
                        UpdateMemberMaritalStatusToSingle()
                        DeleteSpouse(txtStaffID.Text)


                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)

                    End If

                    ''''''''''''''

                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Departure") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    ''  getReasonForClaim = row.Cells(5).Value.ToString
                    ''MsgBox(row.Cells(5).Value.ToString)
                    ' MsgBox(getStaffIDToEdit)

                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then

                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)


                    End If

                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Retirement") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then

                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)

                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Mother Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)

                        'read the mother ID
                        ReadFatherOrMother(AMother)
                        'update the mother live Status using her ID Father Death
                        UpdatePrentsTbl(AMotherOrFatherID)

                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Father Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)

                        'read the mother ID
                        ReadFatherOrMother(AFather)
                        'update the mother live Status using her ID 
                        UpdatePrentsTbl(AMotherOrFatherID)

                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Husband/Wife & Father Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)


                        UpdateMemberMaritalStatusToSingle()
                        ''   Delete spouse
                        DeleteSpouse(txtStaffID.Text)

                        'read the mother ID
                        ReadFatherOrMother(AFather)
                        'update the mother live Status using her ID 
                        UpdatePrentsTbl(AMotherOrFatherID)
                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Husband/Wife & Mother Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)

                        UpdateMemberMaritalStatusToSingle()
                        ''   Delete spouse
                        DeleteSpouse(txtStaffID.Text)

                        'read the mother ID
                        ReadFatherOrMother(AMother)
                        'update the mother live Status using her ID  Father & Mother Death
                        UpdatePrentsTbl(AMotherOrFatherID)

                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Father & Mother Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)

                        'read the mother ID
                        ReadFatherOrMother(AMother)
                        'update the mother live Status using her ID  
                        UpdatePrentsTbl(AMotherOrFatherID)

                        'read the father ID
                        ReadFatherOrMother(AFather)
                        'update the father live Status using her ID Wedding
                        UpdatePrentsTbl(AMotherOrFatherID)

                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Wedding") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)


                        '    UpdateMemberMaritalStatus()
                        UpdateMemberMaritalStatusToMarried()


                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)

                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Husband/Wife & Child Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then

                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)


                        UpdateMemberMaritalStatusToSingle()
                        ''   Delete spouse
                        DeleteSpouse(txtStaffID.Text)

                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Child & Father Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then
                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)


                        'read the father ID
                        ReadFatherOrMother(AFather)
                        'update the father live Status using her ID Wedding
                        UpdatePrentsTbl(AMotherOrFatherID)

                    End If


                ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("doneBtn").Index And getReasonForClaim = "Child & Mother Death") Then

                    Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                    getStaffIDToEdit = row.Cells(2).Value.ToString


                    Dim doneDialoag As DialogResult = MessageBox.Show("Confirm", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If (doneDialoag = DialogResult.Yes) Then

                        getClaimDetails(getStaffIDToEdit)

                        CompleteClaimProcess(memberUserStaffID, memberUserSurname, Amount, Reason, Claimer, BeneficiaryName)
                        PopulateApproval(txtStaffID.Text)
                        ClaimsByMember(txtStaffID.Text)


                        'read the mother ID
                        ReadFatherOrMother(AMother)
                        'update the mother live Status using her ID  
                        UpdatePrentsTbl(AMotherOrFatherID)

                    End If

                End If




                '''''''''''''

            ElseIf (e.RowIndex >= 0 AndAlso e.ColumnIndex = approvalsDataGridView.Columns("okBtn").Index) Then
                ' MsgBox("Oduro")

                Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
                getStaffIDToEdit = row.Cells(2).Value.ToString
                '    MsgBox("Oduro")

                '  MsgBox(getStaffIDToEdit)

                deleteClaimRequest(getStaffIDToEdit)
                PopulateApproval(txtStaffID.Text)
                ClaimsByMember(txtStaffID.Text)

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click
        TreasurerClaimStatus.Hide()
    End Sub

    Private Sub TabControl1_Click(sender As Object, e As EventArgs) Handles TabControl1.Click
        TreasurerClaimStatus.Hide()
    End Sub

    Private Sub TabPage1_MouseHover(sender As Object, e As EventArgs) Handles TabPage1.MouseHover
        TreasurerClaimStatus.Hide()
    End Sub

    Private Sub ClaimsDataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles ClaimsDataGridView.CellClick
        TreasurerClaimStatus.Hide()
    End Sub

    Private Sub approvalsDataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles approvalsDataGridView.CellClick
        Try

            Dim row As DataGridViewRow = approvalsDataGridView.Rows(e.RowIndex)
            getReasonForClaim = row.Cells(7).Value.ToString
            ''  MsgBox(row.Cells(7).Value.ToString)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        counterr = counterr + 1
        If (counterr = 3) Then
            memberNotFoundFeedback.Visible = False
            counterr = 0
            Timer1.Stop()
        End If
    End Sub

    Private Sub TabPage2_Click(sender As Object, e As EventArgs) Handles TabPage2.Click
        ClaimStatus.Hide()
        TreasurerClaimStatus.Hide()
        ShowProfilePage.Hide()
    End Sub

    Private Sub ClaimStatusBtn_Clic(sender As Object, e As EventArgs) Handles ClaimStatusBtn.Click
        ' TreasurerClaimStatus.Hide()
        ShowProfilePage.Hide()
        Dim getCurrentDate = New DateTimePicker
        Dim currentDate = getCurrentDate.Value

        'Check if member has already made payment for the payment date selected
        Dim getMonth = getCurrentDate.Value.Month
        Dim getYear As Integer = getCurrentDate.Value.Year
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "SELECT DATEDIFF(MONTH, MAX(Month_Of_Payment), GETDATE()) AS MonthsSinceLastPayment FROM ContributionsTbl WHERE Member_ID = '" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query22, Con)
            monthsSinceLastPayment = Convert.ToInt32(cmd.ExecuteScalar())

        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
        '' Get the total claims by the user
        ' MsgBox(monthsSinceLastPayment)
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl where Member_ID='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            memberTotalClaim = ds.Tables(0).Rows.Count

        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        '' Get number Of Contributions
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl where Member_ID='" & txtStaffID.Text & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            numberOFContribution = ds.Tables(0).Rows.Count
        Catch ex As Exception
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try



        If (monthsSinceLastPayment > 2 Or numberOFContribution < 6) Then
            TreasurerClaimStatus.txtQualification.Text = "Not Qualified"
            TreasurerClaimStatus.txtQualification.IconChar = FontAwesome.Sharp.IconChar.Times
            TreasurerClaimStatus.txtQualification.BackColor = Color.Red
            TreasurerClaimStatus.txtQualification.ForeColor = Color.White
            TreasurerClaimStatus.txtQualification.FlatAppearance.MouseDownBackColor = Color.Red
            TreasurerClaimStatus.txtQualification.FlatAppearance.MouseOverBackColor = Color.Red
            TreasurerClaimStatus.btnProceed.Visible = False


            Try
                TreasurerClaimStatus.txtFullName.Text = memberUserSurname.ToUpper
                TreasurerClaimStatus.txtPhone.Text = memberUserPhone
                TreasurerClaimStatus.txtMemberId.Text = memberUserStaffID.ToUpper
                TreasurerClaimStatus.txtSex.Text = memberUserSex
                TreasurerClaimStatus.txtDoB.Text = memberUserDoB
                TreasurerClaimStatus.txtTotalClaims.Text = memberTotalClaim

                If (monthsSinceLastPayment > 0) Then
                    TreasurerClaimStatus.txtArreass.Text = "-" + monthsSinceLastPayment.ToString
                ElseIf (monthsSinceLastPayment < 0) Then
                    TreasurerClaimStatus.txtArreass.Text = (-1 * Convert.ToInt32(monthsSinceLastPayment)).ToString
                ElseIf (monthsSinceLastPayment = 0) Then
                    TreasurerClaimStatus.txtArreass.Text = "0"
                End If

                ' TreasurerClaimStatus.txtArreass.Text = monthsSinceLastPayment
                TreasurerClaimStatus.numOfContributions.Text = numberOFContribution
                TreasurerClaimStatus.monthAreasLabel.Visible = True
                TreasurerClaimStatus.txtArreass.Visible = True

                ' Convert the byte array to an image
                Using ms As New MemoryStream(profilePicture)
                    TreasurerClaimStatus.MemberProfile.Image = Image.FromStream(ms)
                End Using
                TreasurerClaimStatus.Show()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try


        Else
            TreasurerClaimStatus.txtQualification.Text = "Qualified"
            TreasurerClaimStatus.txtQualification.IconChar = FontAwesome.Sharp.IconChar.Check
            TreasurerClaimStatus.txtQualification.BackColor = Color.SeaGreen
            TreasurerClaimStatus.txtQualification.ForeColor = Color.White
            TreasurerClaimStatus.txtQualification.FlatAppearance.MouseDownBackColor = Color.SeaGreen
            TreasurerClaimStatus.txtQualification.FlatAppearance.MouseOverBackColor = Color.SeaGreen
            TreasurerClaimStatus.btnProceed.Visible = True


            Try
                TreasurerClaimStatus.txtFullName.Text = memberUserSurname.ToUpper
                TreasurerClaimStatus.txtPhone.Text = memberUserPhone
                TreasurerClaimStatus.txtMemberId.Text = memberUserStaffID.ToUpper
                TreasurerClaimStatus.txtSex.Text = memberUserSex
                TreasurerClaimStatus.txtDoB.Text = memberUserDoB
                TreasurerClaimStatus.txtTotalClaims.Text = memberTotalClaim

                If (monthsSinceLastPayment > 0) Then
                    TreasurerClaimStatus.txtArreass.Text = "-" + monthsSinceLastPayment.ToString
                ElseIf (monthsSinceLastPayment < 0) Then
                    TreasurerClaimStatus.txtArreass.Text = (-1 * Convert.ToInt32(monthsSinceLastPayment)).ToString
                ElseIf (monthsSinceLastPayment = 0) Then
                    TreasurerClaimStatus.txtArreass.Text = "0"
                End If
                ' TreasurerClaimStatus.txtArreass.Visible = True
                ''  TreasurerClaimStatus.txtArreass.Text = monthsSinceLastPayment
                TreasurerClaimStatus.numOfContributions.Text = numberOFContribution

                ' Convert the byte array to an image
                Using ms As New MemoryStream(profilePicture)
                    TreasurerClaimStatus.MemberProfile.Image = Image.FromStream(ms)
                End Using
                TreasurerClaimStatus.Show()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If


    End Sub
End Class