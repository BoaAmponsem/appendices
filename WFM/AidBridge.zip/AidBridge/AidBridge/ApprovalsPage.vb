﻿Imports System.Data.SqlClient
Public Class LoansPage

    Private Function SearchItemApproval() As DataTable
        Try
            Dim query As String = "select * from ApprovalTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Member_Name  like '%' +@parm1+ '%' "
            query &= " or Member_ID like '%' +@parm1+ '%' "
            query &= " or Amount like '%' +@parm1+ '%' "
            query &= " or Reason like '%' +@parm1+ '%' "
            query &= " or Claimer like '%' +@parm1+ '%' "
            query &= " or Beneficiary_Name like '%' +@parm1+ '%' "
            query &= " or Request_Date like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using
            '  End Using

            '  End Using
            Dim cancelButtonColumn As New DataGridViewButtonColumn()
            cancelButtonColumn.HeaderText = ""
            cancelButtonColumn.Text = "Cancel"
            cancelButtonColumn.Name = "cancelBtn"
            cancelButtonColumn.UseColumnTextForButtonValue = True

            Dim approveButtonColumn As New DataGridViewButtonColumn()
            approveButtonColumn.HeaderText = ""
            approveButtonColumn.Text = "Approve"
            approveButtonColumn.Name = "Approve"
            approveButtonColumn.UseColumnTextForButtonValue = True

            'approvalsDataGridView.Columns.Add(cancelButtonColumn)
            'approvalsDataGridView.Columns.Add(approveButtonColumn)

        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function

    Sub switchPages(ByVal pageSwitch1 As Form)

        Try

            Dim Pane As Panel = UserPage.pageSwitch


            Pane.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill

            Pane.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub PopulateApproval()

    End Sub

    Private Sub ApprovalsPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ReportViewer1_Load(sender As Object, e As EventArgs)

    End Sub

    Dim counterr As Integer = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        counterr = counterr + 1
        If (counterr = 3) Then
            memberNotFoundFeedback.Visible = False
            counterr = 0
            Timer1.Stop()
        End If
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        switchPages(LoanApplication)
    End Sub


End Class