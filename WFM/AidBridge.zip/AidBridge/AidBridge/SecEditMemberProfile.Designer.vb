﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SecEditMemberProfile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.childrenDataGridView = New System.Windows.Forms.DataGridView()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.txtSpousePhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtSpouseAddress = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtSpouseName = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.IconButton4 = New FontAwesome.Sharp.IconButton()
        Me.txtMemberDoB1 = New System.Windows.Forms.MaskedTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtMemberStaffID = New System.Windows.Forms.MaskedTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtImageName = New System.Windows.Forms.TextBox()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.txtTypeOfMarriage = New System.Windows.Forms.ComboBox()
        Me.txtMaritalStatus = New System.Windows.Forms.ComboBox()
        Me.txtMemberHometown = New System.Windows.Forms.TextBox()
        Me.typeOfMarriageText = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtMemberPostalAddress = New System.Windows.Forms.TextBox()
        Me.txtMemberHouseNo = New System.Windows.Forms.TextBox()
        Me.txtMemberPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtMemberSex = New System.Windows.Forms.ComboBox()
        Me.txtMemberOthername = New System.Windows.Forms.TextBox()
        Me.txtMemberSurname = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.IconButton5 = New FontAwesome.Sharp.IconButton()
        Me.IconButton6 = New FontAwesome.Sharp.IconButton()
        Me.updatePersonalDetails = New FontAwesome.Sharp.IconButton()
        Me.IconButton3 = New FontAwesome.Sharp.IconButton()
        Me.NextBtn = New FontAwesome.Sharp.IconButton()
        Me.GroupBox3.SuspendLayout()
        CType(Me.childrenDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.BackColor = System.Drawing.Color.White
        Me.GroupBox3.Controls.Add(Me.childrenDataGridView)
        Me.GroupBox3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(16, 383)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(967, 137)
        Me.GroupBox3.TabIndex = 26
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "CHILDREN"
        '
        'childrenDataGridView
        '
        Me.childrenDataGridView.AllowUserToAddRows = False
        Me.childrenDataGridView.AllowUserToDeleteRows = False
        Me.childrenDataGridView.AllowUserToResizeRows = False
        Me.childrenDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.childrenDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.childrenDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.childrenDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.childrenDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.childrenDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.childrenDataGridView.DefaultCellStyle = DataGridViewCellStyle1
        Me.childrenDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.childrenDataGridView.Location = New System.Drawing.Point(3, 17)
        Me.childrenDataGridView.Name = "childrenDataGridView"
        Me.childrenDataGridView.ReadOnly = True
        Me.childrenDataGridView.RowHeadersVisible = False
        Me.childrenDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.childrenDataGridView.Size = New System.Drawing.Size(961, 117)
        Me.childrenDataGridView.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.IconButton1)
        Me.GroupBox2.Controls.Add(Me.txtSpousePhone)
        Me.GroupBox2.Controls.Add(Me.txtSpouseAddress)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.txtSpouseName)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(16, 260)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(970, 82)
        Me.GroupBox2.TabIndex = 25
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "DETAILS OF SPOUSE(IF ANY)"
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton1.BackColor = System.Drawing.Color.Orange
        Me.IconButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton1.ForeColor = System.Drawing.Color.White
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.Edit
        Me.IconButton1.IconColor = System.Drawing.Color.Black
        Me.IconButton1.IconSize = 24
        Me.IconButton1.Location = New System.Drawing.Point(936, 9)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(28, 23)
        Me.IconButton1.TabIndex = 27
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'txtSpousePhone
        '
        Me.txtSpousePhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSpousePhone.Location = New System.Drawing.Point(377, 51)
        Me.txtSpousePhone.Name = "txtSpousePhone"
        Me.txtSpousePhone.ReadOnly = True
        Me.txtSpousePhone.Size = New System.Drawing.Size(267, 21)
        Me.txtSpousePhone.TabIndex = 24
        '
        'txtSpouseAddress
        '
        Me.txtSpouseAddress.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSpouseAddress.Location = New System.Drawing.Point(746, 51)
        Me.txtSpouseAddress.Multiline = True
        Me.txtSpouseAddress.Name = "txtSpouseAddress"
        Me.txtSpouseAddress.ReadOnly = True
        Me.txtSpouseAddress.Size = New System.Drawing.Size(197, 22)
        Me.txtSpouseAddress.TabIndex = 26
        '
        'Label13
        '
        Me.Label13.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(22, 33)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(38, 15)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Name:"
        '
        'txtSpouseName
        '
        Me.txtSpouseName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtSpouseName.Location = New System.Drawing.Point(13, 52)
        Me.txtSpouseName.Multiline = True
        Me.txtSpouseName.Name = "txtSpouseName"
        Me.txtSpouseName.ReadOnly = True
        Me.txtSpouseName.Size = New System.Drawing.Size(308, 21)
        Me.txtSpouseName.TabIndex = 23
        '
        'Label12
        '
        Me.Label12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(749, 33)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(90, 15)
        Me.Label12.TabIndex = 21
        Me.Label12.Text = "Contact Address:"
        '
        'Label11
        '
        Me.Label11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(380, 33)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(58, 15)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Phone No:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.IconButton4)
        Me.GroupBox1.Controls.Add(Me.txtMemberDoB1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtMemberStaffID)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtImageName)
        Me.GroupBox1.Controls.Add(Me.IconButton2)
        Me.GroupBox1.Controls.Add(Me.txtTypeOfMarriage)
        Me.GroupBox1.Controls.Add(Me.txtMaritalStatus)
        Me.GroupBox1.Controls.Add(Me.txtMemberHometown)
        Me.GroupBox1.Controls.Add(Me.typeOfMarriageText)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtMemberPostalAddress)
        Me.GroupBox1.Controls.Add(Me.txtMemberHouseNo)
        Me.GroupBox1.Controls.Add(Me.txtMemberPhone)
        Me.GroupBox1.Controls.Add(Me.txtMemberSex)
        Me.GroupBox1.Controls.Add(Me.txtMemberOthername)
        Me.GroupBox1.Controls.Add(Me.txtMemberSurname)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(16, 34)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(970, 183)
        Me.GroupBox1.TabIndex = 24
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "PERSONAL DETAILS"
        '
        'IconButton4
        '
        Me.IconButton4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton4.BackColor = System.Drawing.Color.Orange
        Me.IconButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton4.FlatAppearance.BorderSize = 0
        Me.IconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton4.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton4.ForeColor = System.Drawing.Color.White
        Me.IconButton4.IconChar = FontAwesome.Sharp.IconChar.Edit
        Me.IconButton4.IconColor = System.Drawing.Color.Black
        Me.IconButton4.IconSize = 24
        Me.IconButton4.Location = New System.Drawing.Point(936, 10)
        Me.IconButton4.Name = "IconButton4"
        Me.IconButton4.Rotation = 0R
        Me.IconButton4.Size = New System.Drawing.Size(28, 23)
        Me.IconButton4.TabIndex = 107
        Me.IconButton4.UseVisualStyleBackColor = False
        '
        'txtMemberDoB1
        '
        Me.txtMemberDoB1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemberDoB1.Location = New System.Drawing.Point(410, 136)
        Me.txtMemberDoB1.Name = "txtMemberDoB1"
        Me.txtMemberDoB1.ReadOnly = True
        Me.txtMemberDoB1.Size = New System.Drawing.Size(107, 21)
        Me.txtMemberDoB1.TabIndex = 104
        '
        'Label3
        '
        Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(410, 116)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 15)
        Me.Label3.TabIndex = 97
        Me.Label3.Text = "DoB(mm/dd/yyyy)"
        '
        'txtMemberStaffID
        '
        Me.txtMemberStaffID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemberStaffID.Location = New System.Drawing.Point(526, 135)
        Me.txtMemberStaffID.Name = "txtMemberStaffID"
        Me.txtMemberStaffID.ReadOnly = True
        Me.txtMemberStaffID.Size = New System.Drawing.Size(109, 21)
        Me.txtMemberStaffID.TabIndex = 24
        '
        'Label10
        '
        Me.Label10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(526, 118)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 15)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Staff ID:"
        '
        'txtImageName
        '
        Me.txtImageName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtImageName.Location = New System.Drawing.Point(748, 127)
        Me.txtImageName.Multiline = True
        Me.txtImageName.Name = "txtImageName"
        Me.txtImageName.ReadOnly = True
        Me.txtImageName.Size = New System.Drawing.Size(203, 29)
        Me.txtImageName.TabIndex = 21
        '
        'IconButton2
        '
        Me.IconButton2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.IconButton2.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.IconButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton2.FlatAppearance.BorderSize = 0
        Me.IconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.ForeColor = System.Drawing.Color.White
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton2.IconColor = System.Drawing.Color.Black
        Me.IconButton2.IconSize = 16
        Me.IconButton2.Location = New System.Drawing.Point(667, 127)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(81, 29)
        Me.IconButton2.TabIndex = 20
        Me.IconButton2.Text = "Add Picture"
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'txtTypeOfMarriage
        '
        Me.txtTypeOfMarriage.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtTypeOfMarriage.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTypeOfMarriage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtTypeOfMarriage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtTypeOfMarriage.FormattingEnabled = True
        Me.txtTypeOfMarriage.Items.AddRange(New Object() {"", "Marriage Ordinance", "Customary Marriage", "Marriage Of Mohammedans Ordinance"})
        Me.txtTypeOfMarriage.Location = New System.Drawing.Point(804, 90)
        Me.txtTypeOfMarriage.Name = "txtTypeOfMarriage"
        Me.txtTypeOfMarriage.Size = New System.Drawing.Size(155, 23)
        Me.txtTypeOfMarriage.TabIndex = 19
        Me.txtTypeOfMarriage.Visible = False
        '
        'txtMaritalStatus
        '
        Me.txtMaritalStatus.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtMaritalStatus.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtMaritalStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtMaritalStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtMaritalStatus.FormattingEnabled = True
        Me.txtMaritalStatus.Items.AddRange(New Object() {"", "Married", "Single"})
        Me.txtMaritalStatus.Location = New System.Drawing.Point(676, 91)
        Me.txtMaritalStatus.Name = "txtMaritalStatus"
        Me.txtMaritalStatus.Size = New System.Drawing.Size(108, 23)
        Me.txtMaritalStatus.TabIndex = 18
        '
        'txtMemberHometown
        '
        Me.txtMemberHometown.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemberHometown.Location = New System.Drawing.Point(8, 135)
        Me.txtMemberHometown.Multiline = True
        Me.txtMemberHometown.Name = "txtMemberHometown"
        Me.txtMemberHometown.ReadOnly = True
        Me.txtMemberHometown.Size = New System.Drawing.Size(384, 22)
        Me.txtMemberHometown.TabIndex = 17
        '
        'typeOfMarriageText
        '
        Me.typeOfMarriageText.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.typeOfMarriageText.AutoSize = True
        Me.typeOfMarriageText.Location = New System.Drawing.Point(806, 72)
        Me.typeOfMarriageText.Name = "typeOfMarriageText"
        Me.typeOfMarriageText.Size = New System.Drawing.Size(98, 15)
        Me.typeOfMarriageText.TabIndex = 16
        Me.typeOfMarriageText.Text = "Type Of Marriage:"
        Me.typeOfMarriageText.Visible = False
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(679, 73)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 15)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Marital Status:"
        '
        'txtMemberPostalAddress
        '
        Me.txtMemberPostalAddress.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtMemberPostalAddress.Location = New System.Drawing.Point(489, 88)
        Me.txtMemberPostalAddress.Multiline = True
        Me.txtMemberPostalAddress.Name = "txtMemberPostalAddress"
        Me.txtMemberPostalAddress.ReadOnly = True
        Me.txtMemberPostalAddress.Size = New System.Drawing.Size(174, 22)
        Me.txtMemberPostalAddress.TabIndex = 14
        '
        'txtMemberHouseNo
        '
        Me.txtMemberHouseNo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemberHouseNo.Location = New System.Drawing.Point(8, 87)
        Me.txtMemberHouseNo.Multiline = True
        Me.txtMemberHouseNo.Name = "txtMemberHouseNo"
        Me.txtMemberHouseNo.ReadOnly = True
        Me.txtMemberHouseNo.Size = New System.Drawing.Size(460, 22)
        Me.txtMemberHouseNo.TabIndex = 13
        '
        'txtMemberPhone
        '
        Me.txtMemberPhone.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtMemberPhone.Location = New System.Drawing.Point(823, 44)
        Me.txtMemberPhone.Name = "txtMemberPhone"
        Me.txtMemberPhone.ReadOnly = True
        Me.txtMemberPhone.Size = New System.Drawing.Size(117, 21)
        Me.txtMemberPhone.TabIndex = 12
        '
        'txtMemberSex
        '
        Me.txtMemberSex.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtMemberSex.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtMemberSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtMemberSex.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtMemberSex.FormattingEnabled = True
        Me.txtMemberSex.Items.AddRange(New Object() {"", "Male", "Female"})
        Me.txtMemberSex.Location = New System.Drawing.Point(695, 43)
        Me.txtMemberSex.Name = "txtMemberSex"
        Me.txtMemberSex.Size = New System.Drawing.Size(99, 23)
        Me.txtMemberSex.TabIndex = 10
        '
        'txtMemberOthername
        '
        Me.txtMemberOthername.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtMemberOthername.Location = New System.Drawing.Point(490, 43)
        Me.txtMemberOthername.Multiline = True
        Me.txtMemberOthername.Name = "txtMemberOthername"
        Me.txtMemberOthername.ReadOnly = True
        Me.txtMemberOthername.Size = New System.Drawing.Size(176, 22)
        Me.txtMemberOthername.TabIndex = 9
        '
        'txtMemberSurname
        '
        Me.txtMemberSurname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemberSurname.Location = New System.Drawing.Point(8, 43)
        Me.txtMemberSurname.Multiline = True
        Me.txtMemberSurname.Name = "txtMemberSurname"
        Me.txtMemberSurname.ReadOnly = True
        Me.txtMemberSurname.Size = New System.Drawing.Size(460, 21)
        Me.txtMemberSurname.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(491, 70)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(82, 15)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Postal Address:"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(828, 26)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 15)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Phone:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(698, 25)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(26, 15)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Sex:"
        '
        'Label5
        '
        Me.Label5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 69)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "House No."
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 117)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Hometown:"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(491, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Other Names:"
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Surname:"
        '
        'IconButton5
        '
        Me.IconButton5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton5.BackColor = System.Drawing.Color.Tomato
        Me.IconButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton5.FlatAppearance.BorderSize = 0
        Me.IconButton5.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton5.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton5.ForeColor = System.Drawing.Color.White
        Me.IconButton5.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton5.IconColor = System.Drawing.Color.White
        Me.IconButton5.IconSize = 16
        Me.IconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton5.Location = New System.Drawing.Point(469, 524)
        Me.IconButton5.Name = "IconButton5"
        Me.IconButton5.Rotation = 0R
        Me.IconButton5.Size = New System.Drawing.Size(113, 27)
        Me.IconButton5.TabIndex = 30
        Me.IconButton5.Text = "Update Page"
        Me.IconButton5.UseVisualStyleBackColor = False
        '
        'IconButton6
        '
        Me.IconButton6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton6.BackColor = System.Drawing.Color.SaddleBrown
        Me.IconButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton6.FlatAppearance.BorderSize = 0
        Me.IconButton6.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton6.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton6.ForeColor = System.Drawing.Color.White
        Me.IconButton6.IconChar = FontAwesome.Sharp.IconChar.Upload
        Me.IconButton6.IconColor = System.Drawing.Color.White
        Me.IconButton6.IconSize = 16
        Me.IconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton6.Location = New System.Drawing.Point(478, 348)
        Me.IconButton6.Name = "IconButton6"
        Me.IconButton6.Rotation = 0R
        Me.IconButton6.Size = New System.Drawing.Size(91, 27)
        Me.IconButton6.TabIndex = 29
        Me.IconButton6.Text = "Update"
        Me.IconButton6.UseVisualStyleBackColor = False
        '
        'updatePersonalDetails
        '
        Me.updatePersonalDetails.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.updatePersonalDetails.BackColor = System.Drawing.Color.SaddleBrown
        Me.updatePersonalDetails.Cursor = System.Windows.Forms.Cursors.Hand
        Me.updatePersonalDetails.FlatAppearance.BorderSize = 0
        Me.updatePersonalDetails.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.updatePersonalDetails.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.updatePersonalDetails.ForeColor = System.Drawing.Color.White
        Me.updatePersonalDetails.IconChar = FontAwesome.Sharp.IconChar.Upload
        Me.updatePersonalDetails.IconColor = System.Drawing.Color.White
        Me.updatePersonalDetails.IconSize = 16
        Me.updatePersonalDetails.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.updatePersonalDetails.Location = New System.Drawing.Point(478, 223)
        Me.updatePersonalDetails.Name = "updatePersonalDetails"
        Me.updatePersonalDetails.Rotation = 0R
        Me.updatePersonalDetails.Size = New System.Drawing.Size(91, 27)
        Me.updatePersonalDetails.TabIndex = 28
        Me.updatePersonalDetails.Text = "Update"
        Me.updatePersonalDetails.UseVisualStyleBackColor = False
        '
        'IconButton3
        '
        Me.IconButton3.BackColor = System.Drawing.Color.White
        Me.IconButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton3.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton3.ForeColor = System.Drawing.Color.Black
        Me.IconButton3.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft
        Me.IconButton3.IconColor = System.Drawing.Color.DarkGreen
        Me.IconButton3.IconSize = 18
        Me.IconButton3.Location = New System.Drawing.Point(8, 3)
        Me.IconButton3.Name = "IconButton3"
        Me.IconButton3.Rotation = 0R
        Me.IconButton3.Size = New System.Drawing.Size(48, 23)
        Me.IconButton3.TabIndex = 27
        Me.IconButton3.UseVisualStyleBackColor = False
        '
        'NextBtn
        '
        Me.NextBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NextBtn.BackColor = System.Drawing.Color.SeaGreen
        Me.NextBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NextBtn.FlatAppearance.BorderSize = 0
        Me.NextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.NextBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.NextBtn.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NextBtn.ForeColor = System.Drawing.Color.White
        Me.NextBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.NextBtn.IconColor = System.Drawing.Color.Black
        Me.NextBtn.IconSize = 16
        Me.NextBtn.Location = New System.Drawing.Point(900, 543)
        Me.NextBtn.Name = "NextBtn"
        Me.NextBtn.Rotation = 0R
        Me.NextBtn.Size = New System.Drawing.Size(67, 23)
        Me.NextBtn.TabIndex = 31
        Me.NextBtn.Text = "Next"
        Me.NextBtn.UseVisualStyleBackColor = False
        '
        'SecEditMemberProfile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(999, 604)
        Me.Controls.Add(Me.NextBtn)
        Me.Controls.Add(Me.IconButton5)
        Me.Controls.Add(Me.IconButton6)
        Me.Controls.Add(Me.updatePersonalDetails)
        Me.Controls.Add(Me.IconButton3)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "SecEditMemberProfile"
        Me.Text = "SecEditMemberProfile"
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.childrenDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents IconButton5 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton6 As FontAwesome.Sharp.IconButton
    Friend WithEvents updatePersonalDetails As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton3 As FontAwesome.Sharp.IconButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents childrenDataGridView As DataGridView
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtSpousePhone As MaskedTextBox
    Friend WithEvents txtSpouseAddress As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtSpouseName As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents IconButton4 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtMemberDoB1 As MaskedTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtMemberStaffID As MaskedTextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtImageName As TextBox
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtTypeOfMarriage As ComboBox
    Friend WithEvents txtMaritalStatus As ComboBox
    Friend WithEvents txtMemberHometown As TextBox
    Friend WithEvents typeOfMarriageText As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtMemberPostalAddress As TextBox
    Friend WithEvents txtMemberHouseNo As TextBox
    Friend WithEvents txtMemberPhone As MaskedTextBox
    Friend WithEvents txtMemberSex As ComboBox
    Friend WithEvents txtMemberOthername As TextBox
    Friend WithEvents txtMemberSurname As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents NextBtn As FontAwesome.Sharp.IconButton
End Class
