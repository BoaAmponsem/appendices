﻿Imports System.Data.SqlClient
Public Class SecEditAccount
    Private Sub SecEditAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UserChangePasswordPage.Hide()
        txtUserName.Text = Uname
        txtMemberStaffID.Text = UStaffID
        txtUserPhone.Text = Decrypt(Uphone)
        txtUserPassword.Text = Decrypt(Upassword)
        txtUserGmail.Text = Decrypt(Ugmail)
    End Sub

    Private Sub btnEditAccount_Click(sender As Object, e As EventArgs) Handles btnEditAccount.Click
        txtUserName.ReadOnly = False
        txtMemberStaffID.ReadOnly = False
        txtUserPhone.ReadOnly = False
        txtUserPassword.ReadOnly = False
        txtUserGmail.ReadOnly = False
        btnSaveChanges.Visible = True

        AcceptButton = btnSaveChanges
    End Sub

    Private Function Refresh(password)
        Try
            Con.Open()
            Dim query = "select * from UsersTbl where Username='" & txtUserName.Text & "'and Password = '" & password & "'"
            cmd = New SqlCommand(query, Con)
            myReader = cmd.ExecuteReader
            myReader.Read()
            Uname = myReader("Username")
            '  Uname2 = myReader("Username")
            Ugmail = myReader("Gmail")
            UStaffID = myReader("Staff_ID")
            Upassword = myReader("Password")
            Uphone = myReader("Phone")


        Catch ex As SqlException
            MsgBox(ex.Message)

        Finally
            Con.Close()

        End Try
    End Function

    Dim Datee As New DateTimePicker
    Dim theDate = Datee.Value
    Dim first4 As String
    Dim last3 As String
    Dim aa2 As Integer = 0
    Dim checkForCorrectMail As String
    Private Sub btnSaveChanges_Click(sender As Object, e As EventArgs) Handles btnSaveChanges.Click

        Try
            If (txtMemberStaffID.Text.Length = 4) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(0, 4)
            ElseIf (txtMemberStaffID.Text.Length = 5) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 1)
            ElseIf (txtMemberStaffID.Text.Length = 6) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 2)
            ElseIf (txtMemberStaffID.Text.Length = 7) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 3)
            ElseIf (txtMemberStaffID.Text.Length = 8) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 4)
            ElseIf (txtMemberStaffID.Text.Length = 9) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 5)
            ElseIf (txtMemberStaffID.Text.Length = 10) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 6)
            ElseIf (txtMemberStaffID.Text.Length = 11) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 7)
            ElseIf (txtMemberStaffID.Text.Length = 12) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 8)
            ElseIf (txtMemberStaffID.Text.Length = 13) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 9)
            ElseIf (txtMemberStaffID.Text.Length = 14) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 10)
            ElseIf (txtMemberStaffID.Text.Length = 15) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 11)
            ElseIf (txtMemberStaffID.Text.Length = 16) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 12)
            ElseIf (txtMemberStaffID.Text.Length = 17) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 13)
            ElseIf (txtMemberStaffID.Text.Length = 18) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 14)
            ElseIf (txtMemberStaffID.Text.Length = 19) Then
                first4 = txtMemberStaffID.Text.Substring(0, 4)
                last3 = txtMemberStaffID.Text.Substring(txtMemberStaffID.Text.Length - 15)
            End If
        Catch ex As Exception

        End Try


        '

        Try
            If (txtUserGmail.Text.Length > 10) Then
                checkForCorrectMail = txtUserGmail.Text.Substring(txtUserGmail.Text.Length - 10)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        '


        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from UsersTbl where Staff_ID ='" & txtMemberStaffID.Text & "' "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa2 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try


        ' MsgBox(txtUserName.Text + "  " + Uname)
        Try
            Cursor = Cursors.WaitCursor
            If ((txtUserName.Text = Uname) = True And (txtMemberStaffID.Text = UStaffID) = True And (Encrypt(txtUserPhone.Text) = Uphone) = True And (Encrypt(txtUserPassword.Text) = Upassword) = True And (Encrypt(txtUserGmail.Text.ToLower) = Ugmail) = True) Then
                MsgBox("No changes have been made", MsgBoxStyle.Information)
            ElseIf (txtUserPhone.Text = "") Then
                MsgBox("Enter the member's Phone number", MsgBoxStyle.Exclamation)
            ElseIf (txtUserPhone.Text.Length < 10 Or txtUserPhone.Text.Length > 10 Or IsNumeric(txtUserPhone.Text) = False) Then
                MsgBox("Invalid member's Phone number", MsgBoxStyle.Exclamation)
            ElseIf (txtUserGmail.Text = "") Then
                MsgBox("Enter your Gmail", MsgBoxStyle.Exclamation)
                txtUserGmail.Focus()
            ElseIf (txtUserGmail.Text.Length < 11) Then
                MsgBox("Enter a valid 'Gmail'", MsgBoxStyle.Exclamation)
                txtUserGmail.Focus()
            ElseIf (checkForCorrectMail <> "@gmail.com") Then
                MsgBox("Enter a valid 'Gmail', e.g my@gmail.com ", MsgBoxStyle.Exclamation)
                txtUserGmail.Focus()
            ElseIf (txtMemberStaffID.Text.Length > 19 Or txtMemberStaffID.Text.Length < 4) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 4 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 5 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 6 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 7 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 8 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 9 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 10 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 11 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 12 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 13 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 14 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 15 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 16 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 17 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 18 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (txtMemberStaffID.Text.Length = 19 And IsNumeric(last3) = False) Then
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()
            ElseIf (first4.ToLower = "sno-" Or first4.ToLower = "gov-") Then
                '  Dim encryptUserName = Encrypt(txtUserName.Text)
                Dim encryptUserPassword = Encrypt(txtUserPassword.Text)
                Dim encryptUserGmail = Encrypt(txtUserGmail.Text.ToLower)
                Dim encryptUserPhone = Encrypt(txtUserPhone.Text)
                ' Dim encryptUserStaffID = Encrypt(txtUserStaffID.Text)


                If (UStaffID = txtMemberStaffID.Text) Then
                    '
                    Try

                        Con.Open()
                        Dim query3 As String
                        query3 = "insert into AccountEditHistoryTbl values('" & UStaffID & "','" & txtMemberStaffID.Text.ToUpper & "','" & Uname & "','" & txtUserName.Text & "','" & Uphone & "','" & encryptUserPhone & "','" & Ugmail & "' ,'" & encryptUserGmail & "','" & Upassword & "','" & encryptUserPassword & "','" & theDate & "','" & Uname & "')"
                        cmd = New SqlCommand(query3, Con)
                        cmd.ExecuteNonQuery()
                        ' MsgBox("Account Created Successfully")
                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try


                    Try
                        Con.Open()

                        Dim query As String
                        query = "Update UsersTbl set Username='" & txtUserName.Text & "', Staff_ID='" & txtMemberStaffID.Text.ToUpper & " ',Phone='" & encryptUserPhone & "',Gmail='" & encryptUserGmail & "',Password='" & encryptUserPassword & "',Previous_Password='" & Upassword & "' where Id = '" & theUsRealID & "'"
                        cmd = New SqlCommand(query, Con)
                        cmd.ExecuteNonQuery()

                        txtUserName.ReadOnly = True
                        txtMemberStaffID.ReadOnly = True
                        txtUserPhone.ReadOnly = True
                        txtUserPassword.ReadOnly = True
                        txtUserGmail.ReadOnly = True

                        btnSaveChanges.Visible = False
                        SecretryForm.txtUsernameHomePage.Text = txtUserName.Text.ToUpper

                        MsgBox("Save successfull")

                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try

                    Refresh(encryptUserPassword)
                    txtUserName.Text = Uname
                    txtMemberStaffID.Text = UStaffID
                    txtUserPhone.Text = Decrypt(Uphone)
                    txtUserPassword.Text = Decrypt(Upassword)
                    txtUserGmail.Text = Decrypt(Ugmail)
                    '
                    '
                ElseIf (UStaffID <> txtMemberStaffID.Text And aa2 = 0) Then
                    '
                    '
                    '
                    Try

                        Con.Open()
                        Dim query3 As String
                        query3 = "insert into AccountEditHistoryTbl values('" & UStaffID & "','" & txtMemberStaffID.Text.ToUpper & "','" & Uname & "','" & txtUserName.Text & "','" & Uphone & "','" & encryptUserPhone & "','" & Ugmail & "' ,'" & encryptUserGmail & "','" & Upassword & "','" & encryptUserPassword & "','" & theDate & "','" & Uname & "')"
                        cmd = New SqlCommand(query3, Con)
                        cmd.ExecuteNonQuery()
                        ' MsgBox("Account Created Successfully")
                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try


                    Try
                        Con.Open()

                        Dim query As String
                        query = "Update UsersTbl set Username='" & txtUserName.Text & "', Staff_ID='" & txtMemberStaffID.Text.ToUpper & " ',Phone='" & encryptUserPhone & "',Gmail='" & encryptUserGmail & "',Password='" & encryptUserPassword & "',Previous_Password='" & Upassword & "' where Id = '" & theUsRealID & "'"
                        cmd = New SqlCommand(query, Con)
                        cmd.ExecuteNonQuery()

                        txtUserName.ReadOnly = True
                        txtMemberStaffID.ReadOnly = True
                        txtUserPhone.ReadOnly = True
                        txtUserPassword.ReadOnly = True
                        txtUserGmail.ReadOnly = True

                        btnSaveChanges.Visible = False
                        SecretryForm.txtUsernameHomePage.Text = txtUserName.Text.ToUpper

                        MsgBox("Save successfull")

                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try

                    Refresh(encryptUserPassword)
                    txtUserName.Text = Uname
                    txtMemberStaffID.Text = UStaffID
                    txtUserPhone.Text = Decrypt(Uphone)
                    txtUserPassword.Text = Decrypt(Upassword)
                    txtUserGmail.Text = Decrypt(Ugmail)
                    '
                    '

                Else
                    MsgBox("The new 'Staff ID' already exist", MsgBoxStyle.Exclamation)
                    txtMemberStaffID.Focus()
                End If



            ElseIf (IsNumeric(txtMemberStaffID.Text) = True) Then

                '
                '  Dim encryptUserName = Encrypt(txtUserName.Text)
                Dim encryptUserPassword = Encrypt(txtUserPassword.Text)
                Dim encryptUserGmail = Encrypt(txtUserGmail.Text.ToLower)
                Dim encryptUserPhone = Encrypt(txtUserPhone.Text)
                ' Dim encryptUserStaffID = Encrypt(txtUserStaffID.Text)
                If (UStaffID = txtMemberStaffID.Text) Then
                    '
                    Try

                        Con.Open()
                        Dim query3 As String
                        query3 = "insert into AccountEditHistoryTbl values('" & UStaffID & "','" & txtMemberStaffID.Text.ToUpper & "','" & Uname & "','" & txtUserName.Text & "','" & Uphone & "','" & encryptUserPhone & "','" & Ugmail & "' ,'" & encryptUserGmail & "','" & Upassword & "','" & encryptUserPassword & "','" & theDate & "','" & Uname & "')"
                        cmd = New SqlCommand(query3, Con)
                        cmd.ExecuteNonQuery()
                        ' MsgBox("Account Created Successfully")
                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try


                    Try
                        Con.Open()

                        Dim query As String
                        query = "Update UsersTbl set Username='" & txtUserName.Text & "', Staff_ID='" & txtMemberStaffID.Text.ToUpper & " ',Phone='" & encryptUserPhone & "',Gmail='" & encryptUserGmail & "',Password='" & encryptUserPassword & "',Previous_Password='" & Upassword & "' where Id = '" & theUsRealID & "'"
                        cmd = New SqlCommand(query, Con)
                        cmd.ExecuteNonQuery()

                        txtUserName.ReadOnly = True
                        txtMemberStaffID.ReadOnly = True
                        txtUserPhone.ReadOnly = True
                        txtUserPassword.ReadOnly = True
                        txtUserGmail.ReadOnly = True

                        btnSaveChanges.Visible = False
                        SecretryForm.txtUsernameHomePage.Text = txtUserName.Text.ToUpper

                        MsgBox("Save successfull")

                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try

                    Refresh(encryptUserPassword)
                    txtUserName.Text = Uname
                    txtMemberStaffID.Text = UStaffID
                    txtUserPhone.Text = Decrypt(Uphone)
                    txtUserPassword.Text = Decrypt(Upassword)
                    txtUserGmail.Text = Decrypt(Ugmail)
                    '
                    '
                ElseIf (UStaffID <> txtMemberStaffID.Text And aa2 = 0) Then
                    '
                    '
                    '
                    Try

                        Con.Open()
                        Dim query3 As String
                        query3 = "insert into AccountEditHistoryTbl values('" & UStaffID & "','" & txtMemberStaffID.Text.ToUpper & "','" & Uname & "','" & txtUserName.Text & "','" & Uphone & "','" & encryptUserPhone & "','" & Ugmail & "' ,'" & encryptUserGmail & "','" & Upassword & "','" & encryptUserPassword & "','" & theDate & "','" & Uname & "')"
                        cmd = New SqlCommand(query3, Con)
                        cmd.ExecuteNonQuery()
                        ' MsgBox("Account Created Successfully")
                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try


                    Try
                        Con.Open()

                        Dim query As String
                        query = "Update UsersTbl set Username='" & txtUserName.Text & "', Staff_ID='" & txtMemberStaffID.Text.ToUpper & " ',Phone='" & encryptUserPhone & "',Gmail='" & encryptUserGmail & "',Password='" & encryptUserPassword & "',Previous_Password='" & Upassword & "' where Id = '" & theUsRealID & "'"
                        cmd = New SqlCommand(query, Con)
                        cmd.ExecuteNonQuery()

                        txtUserName.ReadOnly = True
                        txtMemberStaffID.ReadOnly = True
                        txtUserPhone.ReadOnly = True
                        txtUserPassword.ReadOnly = True
                        txtUserGmail.ReadOnly = True

                        btnSaveChanges.Visible = False
                        SecretryForm.txtUsernameHomePage.Text = txtUserName.Text.ToUpper

                        MsgBox("Save successfull")

                    Catch ex As SqlException
                        MsgBox(ex.Message)
                    Finally
                        Con.Close()
                    End Try

                    Refresh(encryptUserPassword)
                    txtUserName.Text = Uname
                    txtMemberStaffID.Text = UStaffID
                    txtUserPhone.Text = Decrypt(Uphone)
                    txtUserPassword.Text = Decrypt(Upassword)
                    txtUserGmail.Text = Decrypt(Ugmail)
                    '
                    '

                Else
                    MsgBox("The new 'Staff ID' already exist", MsgBoxStyle.Exclamation)
                    txtMemberStaffID.Focus()
                End If

            Else
                MessageBox.Show("Invalid Staff-ID'", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                txtMemberStaffID.Focus()

            End If
        Catch ex As Exception
        Finally
            Cursor = Cursors.Default

        End Try
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        SecChangePassword.txtConfirmNewPassword.Text = ""
        SecChangePassword.txtNewPassword.Text = ""
        SecChangePassword.txtOldPassword.Text = ""
        SecChangePassword.Show()
    End Sub
End Class