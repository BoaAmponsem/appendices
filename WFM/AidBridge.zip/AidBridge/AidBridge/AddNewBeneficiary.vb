﻿Imports System.Data.SqlClient
Imports System.Drawing.Drawing2D
Imports System.Runtime.InteropServices

Public Class AddNewBeneficiary
    Private borderRadius As Integer = 20
    Private borderSize As Integer = 3
    Private borderColor As Color = Color.SeaGreen

    'Constractor
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Private Function GetRoundedPath(rect As Rectangle, radius As Single) As GraphicsPath
        Dim path As GraphicsPath = New GraphicsPath()
        Dim curveSize As Single = radius * 2.0F
        path.StartFigure()
        path.AddArc(rect.X, rect.Y, curveSize, curveSize, 180, 90)
        path.AddArc(rect.Right - curveSize, rect.Y, curveSize, curveSize, 270, 90)
        path.AddArc(rect.Right - curveSize, rect.Bottom - curveSize, curveSize, curveSize, 0, 90)
        path.AddArc(rect.X, rect.Bottom - curveSize, curveSize, curveSize, 90, 90)
        path.CloseFigure()
        Return path
    End Function

    Private Sub FormRegionAndBorder(form As Form, radius As Single, graph As Graphics, borderColor As Color, borderSize As Single)
        If Me.WindowState <> FormWindowState.Minimized Then
            Using roundPath As GraphicsPath = GetRoundedPath(form.ClientRectangle, radius)
                Using penBorder As Pen = New Pen(borderColor, borderSize)
                    Using transform As Matrix = New Matrix()

                        graph.SmoothingMode = SmoothingMode.AntiAlias
                        form.Region = New Region(roundPath)
                        If borderSize >= 1 Then
                            Dim rect As Rectangle = form.ClientRectangle
                            Dim scaleX As Single = 1.0F - ((borderSize + 1) / rect.Width)
                            Dim scaleY As Single = 1.0F - ((borderSize + 1) / rect.Height)
                            transform.Scale(scaleX, scaleY)
                            transform.Translate(borderSize / 1.6F, borderSize / 1.6F)
                            graph.Transform = transform
                            graph.DrawPath(penBorder, roundPath)
                        End If
                    End Using
                End Using
            End Using

        End If
    End Sub

    Private Function MemberBeneficiaries()
        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            UserEditMemberProfile2.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            EditMemberProfile2.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Me.Hide()
    End Sub

    Private Sub UpdateBeneficieary()
        Try
            Con.Open()
            Dim query3 As String
            query3 = "update BeneficiariesTbl set  Name ='" & txtBeneficiaryOneName.Text & "',Phone = '" & txtBeneficiaryOnePhone.Text & "',Birth_Date = '" & txtBeneficiaryOneDoB.Text & "',Relation = '" & txtBeneficiaryOneRelation.Text & "',Postal_Address = '" & txtBeneficiaryOneAddress.Text & "',Proportion = '" & txtBeneficiaryOneProportion.Text & "' where Id ='" & txtBenficiaryID.Text & "'"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Beneficiary Details updated successfully", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

    End Sub
    Dim theSumOfProportion As Integer = 0
    Private Sub SumProportions()
        Try
            Con.Open()
            Dim ProportionTotal
            Dim query2 = "select sum(Proportion) from BeneficiariesTbl where Member_ID ='" & getStaffIDToEdit & "'"
            cmd = New SqlCommand(query2, Con)
            ProportionTotal = cmd.ExecuteScalar
            If (IsDBNull(ProportionTotal) = True) Then
                theSumOfProportion = 0
            Else
                theSumOfProportion = Convert.ToInt32(ProportionTotal)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Dim NOBeneficiary As Integer = 0
    Public Function checkNoOfBeneficiaries(Id)
        Try
            ' Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from BeneficiariesTbl where Member_ID = '" & Id & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            NOBeneficiary = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            'Cursor = Cursors.Default
            Con.Close()
        End Try
    End Function
    'Check If the member is dead
    Dim aa5 As Integer = 0
    Private Sub CheckDeceasedMember()
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 = "select * from ClaimsTbl where Member_ID ='" & getStaffIDToEdit & "' And  Claimer='" & txtClaimByBeneficiary & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            aa5 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
    End Sub
    Private Sub IconButton8_Click(sender As Object, e As EventArgs) Handles IconButton8.Click

        Try
            'Check If the member is dead
            CheckDeceasedMember()
            checkNoOfBeneficiaries(getStaffIDToEdit)
            SumProportions()
        Catch ex As Exception

        End Try

        '''''''

        Try
            If (aa5 <> 0) Then
                MsgBox("No modification can be done since the member is dead", MsgBoxStyle.Exclamation)
            ElseIf (txtBenficiaryID.Text = "") Then
                MsgBox("Select the beneficiary and update his/her details", MsgBoxStyle.Exclamation)
            ElseIf (txtBeneficiaryOnePhone.Text = "") Then
                MsgBox("Select the beneficiary and update his/her details", MsgBoxStyle.Exclamation)
            ElseIf (txtBeneficiaryOneDoB.Text = "") Then
                MsgBox("Select the beneficiary and update his/her details", MsgBoxStyle.Exclamation)
            ElseIf (txtBeneficiaryOneRelation.Text = "") Then
                MsgBox("Select the beneficiary and update his/her details", MsgBoxStyle.Exclamation)
            ElseIf (txtBeneficiaryOneProportion.Text = "") Then
                MsgBox("Select the beneficiary and update his/her details", MsgBoxStyle.Exclamation)
                '
                ' ElseIf (Convert.ToInt32(txtBeneficiaryOneProportion.Text) + theSumOfProportion > 100) Then
                '    MsgBox("The sum of the Beneficiaries' Proportion is morethan 100%", MsgBoxStyle.Exclamation)
                'txtBenficiaryID
            ElseIf (txtBeneficiaryOneAddress.Text = "") Then
                MsgBox("Select the beneficiary and update his/her details", MsgBoxStyle.Exclamation)
            ElseIf (txtBeneficiaryOneName.Text = "") Then
                MsgBox("Select the beneficiary and update his/her details", MsgBoxStyle.Exclamation)
            ElseIf (NOBeneficiary = 1) Then
                '
                If (Convert.ToInt32(txtBeneficiaryOneProportion.Text) > 100) Then
                    MsgBox("The Beneficiary's Proportion is more than 100%", MsgBoxStyle.Exclamation)
                Else
                    UpdateBeneficieary()
                    MemberBeneficiaries2()
                    refreshPage()
                End If
                '
            ElseIf (NOBeneficiary > 1) Then
                '
                If (Convert.ToInt32(txtBeneficiaryOneProportion.Text) + theSumOfProportion > 100) Then
                    MsgBox("The sum of the Beneficiaries' Proportion is morethan 100%", MsgBoxStyle.Exclamation)

                ElseIf (Convert.ToInt32(txtBeneficiaryOneProportion.Text) + theSumOfProportion <= 100)
                    UpdateBeneficieary()
                    MemberBeneficiaries2()
                    refreshPage()
                End If
                '

            End If

        Catch ex As Exception

        End Try

    End Sub

    Dim Key = 0
    Private Sub beneficiariesDataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles beneficiariesDataGridView.CellClick
        Try
            Dim row As DataGridViewRow = beneficiariesDataGridView.Rows(e.RowIndex)

            txtBenficiaryID.Text = row.Cells(0).Value.ToString
            txtBeneficiaryOneName.Text = row.Cells(2).Value.ToString
            txtBeneficiaryOnePhone.Text = row.Cells(3).Value.ToString
            txtBeneficiaryOneDoB.Text = row.Cells(4).Value.ToString
            txtBeneficiaryOneRelation.Text = row.Cells(5).Value.ToString
            txtBeneficiaryOneAddress.Text = row.Cells(6).Value.ToString
            txtBeneficiaryOneProportion.Text = row.Cells(7).Value.ToString


            If txtBeneficiaryOneName.Text = "" Or txtBeneficiaryOnePhone.Text = "" Then
                Key = 0
            Else
                Key = Convert.ToInt32(row.Cells(0).Value.ToString)
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Function MemberBeneficiaries2()
        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            UserEditMemberProfile2.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            SecEditMemberProfile2.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try

        Try
            Con.Open()
            Dim query = "select * from BeneficiariesTbl where Member_ID='" & getStaffIDToEdit & "'"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            EditMemberProfile2.beneficiariesDataGridView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Function

    Private Sub AddBeneficiary()
        Try
            Con.Open()
            Dim query3 As String
            query3 = "insert into BeneficiariesTbl values('" & getStaffIDToEdit & "','" & txtBeneficiaryOneName.Text & "','" & txtBeneficiaryOnePhone.Text & "','" & txtBeneficiaryOneDoB.Text & "','" & txtBeneficiaryOneRelation.Text & "','" & txtBeneficiaryOneAddress.Text & "','" & txtBeneficiaryOneProportion.Text & "')"
            cmd = New SqlCommand(query3, Con)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Beneficiary added successfully", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub AddNewBeneficiary_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MemberBeneficiaries2()
    End Sub
    Private Sub refreshPage()
        txtBeneficiaryOneName.Text = ""
        txtBeneficiaryOnePhone.Text = ""
        txtBeneficiaryOneDoB.Text = ""
        txtBeneficiaryOneRelation.Text = ""
        txtBeneficiaryOneProportion.Text = ""
        txtBeneficiaryOneAddress.Text = ""
        txtBenficiaryID.Text = ""
    End Sub
    Private Sub addBtn_Click_1(sender As Object, e As EventArgs) Handles addBtn.Click
        Try
            'Check If the member is dead
            CheckDeceasedMember()
            SumProportions()
        Catch ex As Exception

        End Try



        Try
            If (aa5 <> 0) Then
                MsgBox("No modification can be done since the member is dead", MsgBoxStyle.Exclamation)
            ElseIf (txtBeneficiaryOneName.Text = "") Then
                MessageBox.Show("Enter benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtBeneficiaryOnePhone.Text = "") Then
                MessageBox.Show("Enter benefiary's", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtBeneficiaryOneDoB.Text = "") Then
                MessageBox.Show("Enter the beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtBeneficiaryOneRelation.Text = "") Then
                MessageBox.Show("Select the beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtBeneficiaryOneProportion.Text = "") Then
                MessageBox.Show("Enter the beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            ElseIf (txtBeneficiaryOneAddress.Text = "") Then
                MessageBox.Show("Enter the beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                '
                '
            ElseIf (Convert.ToInt32(txtBeneficiaryOneProportion.Text) + theSumOfProportion > 100) Then
                MsgBox("The sum of the Beneficiaries' Proportion is morethan 100%", MsgBoxStyle.Exclamation)
                '
                '
            ElseIf (txtBenficiaryID.Text <> "") Then
                MsgBox("Select the beneficiary and update his/her details/Refresh the page and add a new beneficiary", MsgBoxStyle.Exclamation)
                '  refreshPage()
            Else

                AddBeneficiary()
                MemberBeneficiaries2()
                refreshPage()
            End If
        Catch ex As Exception

        End Try


    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        MemberBeneficiaries2()
        refreshPage()
    End Sub

    Private Sub AddNewBeneficiary_Paint(sender As Object, e As PaintEventArgs) Handles MyBase.Paint
        FormRegionAndBorder(Me, borderRadius, e.Graphics, borderColor, borderSize)
    End Sub

    'Drag Form

    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub
    Private Sub PanelTitleBar_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseDown
        ReleaseCapture()
        SendMessage(Me.Handle, &H112, &HF012, 0)
        '   btnMaximize.Visible = True
        '  btnNormal.Visible = False
    End Sub

    ' Private Sub AddNewChild_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown

    ' End Sub

    Protected Overrides ReadOnly Property CreateParams As CreateParams
        Get
            Dim cp As CreateParams = MyBase.CreateParams
            cp.Style = cp.Style Or &H20000
            Return cp
        End Get
    End Property
End Class