﻿Imports System.Data.SqlClient
Imports System.IO
Public Class SecAddMemberPage2
    Sub switchPages(ByVal pageSwitch1 As Form)
        Try

            SecretryForm.pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            SecretryForm.pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try
    End Sub

    'Dim aa2 As Integer, aa3 As Integer
    Dim aa2 As Integer, aa3 As Integer
    Dim MonthCalenda As New DateTimePicker
    Dim getTheDate = MonthCalenda.Value



    Private Sub InsertMemberDetailToDB()

        If (memberAPicture <> "") Then

            Dim profilePicture As Byte() = File.ReadAllBytes(memberAPicture)
            Try
                Con.Open()
                Dim query3 As String
                query3 = "INSERT INTO MembersTbl (Staff_ID, Surname, Other_Names, Phone, Sex, House_No, Postal_Address, Marital_Status, Marriage_Type, Hometown, Birth_Date, Picture, Registration_Date, Operator) " &
                     "VALUES (@Staff_ID, @Surname, @Other_Names, @Phone, @Sex, @House_No, @Postal_Address, @Marital_Status, @Marriage_Type, @Hometown, @Birth_Date, @ProfilePicture, @Registration_Date, @Admin_Name)"

                cmd = New SqlCommand(query3, Con)

                cmd.Parameters.AddWithValue("@Staff_ID", memberAStaffID)
                cmd.Parameters.AddWithValue("@Surname", memberASurname)
                cmd.Parameters.AddWithValue("@Other_Names", memberAOthername)
                cmd.Parameters.AddWithValue("@Phone", memberAPhone)
                cmd.Parameters.AddWithValue("@Sex", memberASex)
                cmd.Parameters.AddWithValue("@House_No", memberAHouseNo)
                cmd.Parameters.AddWithValue("@Postal_Address", memberAPostalAddress)
                cmd.Parameters.AddWithValue("@Marital_Status", memberAMaritalStatus)
                cmd.Parameters.AddWithValue("@Marriage_Type", memberATypeOfMarriage)
                cmd.Parameters.AddWithValue("@Hometown", memberAHomeTown)
                cmd.Parameters.AddWithValue("@Birth_Date", memberADoB)
                cmd.Parameters.AddWithValue("@ProfilePicture", profilePicture)
                cmd.Parameters.AddWithValue("@Registration_Date", getTheDate)
                cmd.Parameters.AddWithValue("@Admin_Name", Uname)

                cmd.ExecuteNonQuery()

            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try

        ElseIf (memberAPicture = "") Then
            Dim profilePicture As Byte() = File.ReadAllBytes(Application.StartupPath & "\Profile pictures\Default.jpg")

            Try
                Con.Open()
                Dim query3 As String
                query3 = "INSERT INTO MembersTbl (Staff_ID, Surname, Other_Names, Phone, Sex, House_No, Postal_Address, Marital_Status, Marriage_Type, Hometown, Birth_Date, Picture, Registration_Date, Operator) " &
                     "VALUES (@Staff_ID, @Surname, @Other_Names, @Phone, @Sex, @House_No, @Postal_Address, @Marital_Status, @Marriage_Type, @Hometown, @Birth_Date, @ProfilePicture, @Registration_Date, @Admin_Name)"

                cmd = New SqlCommand(query3, Con)

                cmd.Parameters.AddWithValue("@Staff_ID", memberAStaffID)
                cmd.Parameters.AddWithValue("@Surname", memberASurname)
                cmd.Parameters.AddWithValue("@Other_Names", memberAOthername)
                cmd.Parameters.AddWithValue("@Phone", memberAPhone)
                cmd.Parameters.AddWithValue("@Sex", memberASex)
                cmd.Parameters.AddWithValue("@House_No", memberAHouseNo)
                cmd.Parameters.AddWithValue("@Postal_Address", memberAPostalAddress)
                cmd.Parameters.AddWithValue("@Marital_Status", memberAMaritalStatus)
                cmd.Parameters.AddWithValue("@Marriage_Type", memberATypeOfMarriage)
                cmd.Parameters.AddWithValue("@Hometown", memberAHomeTown)
                cmd.Parameters.AddWithValue("@Birth_Date", memberADoB)
                cmd.Parameters.AddWithValue("@ProfilePicture", profilePicture)
                cmd.Parameters.AddWithValue("@Registration_Date", getTheDate)
                cmd.Parameters.AddWithValue("@Admin_Name", Uname)

                cmd.ExecuteNonQuery()

            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try

        End If

    End Sub

    Dim containsNumber As Boolean, containsNumber2 As Boolean, containsNumber3 As Boolean, containsNumber4 As Boolean, containsNumber5 As Boolean, containsNumber6 As Boolean
    Private Sub btnAddMember_Click(sender As Object, e As EventArgs) Handles btnAddMember.Click
        ''Mother Info
        Cursor = Cursors.WaitCursor

        'Mother & Father
        If (txtMotherName.Text IsNot "") Then
            containsNumber = txtMotherName.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtFatherName.Text IsNot "") Then

            containsNumber2 = txtFatherName.Text.Any(Function(c) Char.IsDigit(c))

        End If

        ''Beneficiary Name
        If (txtBeneficiaryOneName.Text IsNot "") Then
            containsNumber3 = txtBeneficiaryOneName.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtBeneficiaryTwoName.Text IsNot "") Then

            containsNumber4 = txtBeneficiaryTwoName.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtBeneficiaryThreeName.Text IsNot "") Then
            containsNumber5 = txtBeneficiaryThreeName.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtBeneficiaryFourName.Text IsNot "") Then

            containsNumber6 = txtBeneficiaryFourName.Text.Any(Function(c) Char.IsDigit(c))

        End If

        If (txtMotherName.Text = "") Then
            MessageBox.Show("Enter the Mother's name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMotherName.Focus()
        ElseIf (txtMotherPhone.Text = "") Then
            MsgBox("Enter mother's phone number", MsgBoxStyle.Exclamation)
            txtMotherPhone.Focus()
        ElseIf (IsNumeric(txtMotherName.Text) = True Or containsNumber) Then
            MsgBox("Invalid mother's name", MsgBoxStyle.Exclamation)
            txtMotherName.Focus()
        ElseIf ((txtMotherPhone.Text = "") = False And IsNumeric(txtMotherPhone.Text) = False) Then
            MsgBox("Invalid mother's Phone number", MsgBoxStyle.Exclamation)
            txtMotherPhone.Focus()
        ElseIf ((txtMotherPhone.Text = "") = False And txtMotherPhone.Text.Length < 10) Then
            MsgBox("Invalid mother's Phone number", MsgBoxStyle.Exclamation)
            txtMotherPhone.Focus()
        ElseIf ((txtMotherPhone.Text = "") = False And txtMotherPhone.Text.Length > 10) Then
            MsgBox("Invalid mother's Phone number", MsgBoxStyle.Exclamation)
            txtMotherPhone.Focus()
        ElseIf (txtMotherDead.Checked = False And txtMotherAlive.Checked = False) Then
            MessageBox.Show("Select mother's live status", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtMotherDead.Focus()
        ElseIf (txtFatherName.Text = "") Then
            MessageBox.Show("Enter ther Father's name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            txtFatherName.Focus()
        ElseIf (IsNumeric(txtFatherName.Text) = True Or containsNumber2) Then
            MsgBox("Invalid father's name", MsgBoxStyle.Exclamation)
            txtFatherName.Focus()
        ElseIf (txtFatherPhone.Text = "") Then
            MsgBox("Enter father's phone number", MsgBoxStyle.Exclamation)
            txtFatherPhone.Focus()
        ElseIf ((txtFatherPhone.Text = "") = False And IsNumeric(txtFatherPhone.Text) = False) Then
            MsgBox("Invalid father's Phone number", MsgBoxStyle.Exclamation)
            txtFatherPhone.Focus()
        ElseIf ((txtFatherPhone.Text = "") = False And txtFatherPhone.Text.Length < 10) Then
            MsgBox("Invalid father's Phone number", MsgBoxStyle.Exclamation)
            txtFatherPhone.Focus()
        ElseIf ((txtFatherPhone.Text = "") = False And txtFatherPhone.Text.Length > 10) Then
            MsgBox("Invalid father's Phone number", MsgBoxStyle.Exclamation)
            txtFatherPhone.Focus()
        ElseIf (txtFatherDead.Checked = False And txtFatherAlive.Checked = False) Then
            MessageBox.Show("Select father's live status", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        ElseIf (txtAcceptAgreement.Checked = False) Then
            MessageBox.Show("Accept the membership agreement", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Else
            'Mother's Info

            memberAMothername = txtMotherName.Text
            memberAMotherPhone = txtMotherPhone.Text
            If (txtMotherDead.Checked = True) Then
                memberAMotherLiveStatus = txtMotherDead.Text
            ElseIf (txtMotherAlive.Checked = True) Then
                memberAMotherLiveStatus = txtMotherAlive.Text
                'Mother End If
            End If

            'Father Info
            memberAFathername = txtFatherName.Text
            memberAFatherPhone = txtFatherPhone.Text
            If (txtFatherDead.Checked = True) Then
                memberAFatherLiveStatus = txtFatherDead.Text
            ElseIf (txtFatherAlive.Checked = True) Then
                memberAFatherLiveStatus = txtFatherAlive.Text
                'Father End If
            End If
            '
            '
            If (txtNoBeneficiary.Checked = True) Then

                'Add the member
                '
                If (SecAddMemberPage1.txtMaritalStatus.Text = "Single") Then

                    If (SecAddMemberPage1.noChild.Checked = True) Then
                        'No Child

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally Insert to Database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else

                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If
                        '
                        '
                    ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                        'One Child

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert into MemberTbl
                            InsertMemberDetailToDB()


                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If

                    ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                        'Two Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If


                    ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                        'Three Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Third Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If



                    ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                        'Four Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Third Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl fourth Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If


                    ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                        'Five Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()


                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Three Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Four Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Five Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If


                    ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                        'Six Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Three Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Four Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Five Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Six Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If



                    ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                        'Seven Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Three Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Four Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Five Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Six Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Seven Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If


                    ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                        'Child Eight
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Three Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Four Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Five Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Six Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Seven Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Eight Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If

                    End If

                ElseIf (SecAddMemberPage1.txtMaritalStatus.Text = "Married") Then
                    If (SecAddMemberPage1.noChild.Checked = True) Then
                        'No Child
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally Insert to Database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to SpouseTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If

                    ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                        'One Child
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()


                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to SpouseTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If

                    ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                        'Two Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else


                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to SpouseTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If

                    ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                        'Three Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Third Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to SpouseTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If

                    ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                        'Four Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Third Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl fourth Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to SpouseTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If


                    ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                        'Five Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else

                            'Insert to MemberTbl
                            InsertMemberDetailToDB()


                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Three Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Four Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Five Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try


                            'Insert to SpouseTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If


                    ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                        'Six Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()


                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Three Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Four Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Five Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Six Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to SpouseTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If

                    ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                        'Seven Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Three Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Four Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Five Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Six Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Seven Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to SpouseTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If

                    ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                        'Eight Children
                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa2 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Check if member is Already registered
                        Try
                            Cursor = Cursors.WaitCursor
                            Con.Open()
                            Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                            cmd = New SqlCommand(query22, Con)
                            adaptor = New SqlDataAdapter(cmd)
                            ds = New DataSet()
                            adaptor.Fill(ds)
                            aa3 = ds.Tables(0).Rows.Count
                        Catch ex As Exception
                        Finally
                            Cursor = Cursors.Default
                            Con.Close()
                        End Try

                        'Finally insert to database
                        If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                            MessageBox.Show("Member already registered")
                        Else
                            'Insert to MemberTbl
                            InsertMemberDetailToDB()

                            'Insert to ParentsTbl Mother
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ParentsTbl Father
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl First Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Second Child
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Three Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Four Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Five Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Six Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Seven Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to ChildrenTbl Eight Children
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            'Insert to SpouseTbl
                            Try
                                Con.Open()
                                Dim query3 As String
                                query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                cmd = New SqlCommand(query3, Con)
                                cmd.ExecuteNonQuery()
                                MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            Finally
                                Con.Close()
                            End Try

                            resetAllMemberFormsSec()
                            switchPages(SecAddMemberPage1)

                        End If

                    End If
                End If


                '
                '
            ElseIf (oneBeneficiary.Checked = True) Then
                If (txtBeneficiaryOneName.Text = "") Then
                    MessageBox.Show("Enter benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryOneName.Text) = True Or containsNumber3) Then
                    MessageBox.Show("The beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneName.Focus()
                ElseIf (txtBeneficiaryOneDoB.Text.Length < 7) Then
                    MessageBox.Show("Set the beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneDoB.Focus()
                ElseIf (txtBeneficiaryOneRelation.Text = "") Then
                    MessageBox.Show("Select the beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneRelation.Focus()
                ElseIf (txtBeneficiaryOneProportion.Text = "") Then
                    MessageBox.Show("Enter the beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneProportion.Focus()
                ElseIf (Convert.ToInt32(txtBeneficiaryOneProportion.Text) > 100) Then
                    MessageBox.Show("The maximum proportion is 100%", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneProportion.Focus()
                ElseIf (txtBeneficiaryOneAddress.Text = "") Then
                    MessageBox.Show("Enter the beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneAddress.Focus()
                Else
                    memberABeneficiary1 = txtBeneficiaryOneName.Text
                    memberABeneficiary1Phone = txtBeneficiaryOnePhone.Text
                    memberABeneficiary1DoB = txtBeneficiaryOneDoBA.Value
                    memberABeneficiary1Relation = txtBeneficiaryOneRelation.Text
                    memberABeneficiary1Proportion = txtBeneficiaryOneProportion.Text
                    memberABeneficiary1Address = txtBeneficiaryOneAddress.Text

                    'Add Member
                    If (SecAddMemberPage1.txtMaritalStatus.Text = "Single") Then
                        If (SecAddMemberPage1.noChild.Checked = True) Then
                            'No Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally Insert to Database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                            'One Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                            'Two Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                            'Three Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()



                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                            'Four Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl fourth Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                            'Five Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                            'Six Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                            'Seven Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()



                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                            'Eight Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Eight Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        End If

                    ElseIf (SecAddMemberPage1.txtMaritalStatus.Text = "Married") Then
                        If (SecAddMemberPage1.noChild.Checked = True) Then
                            'No Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally Insert to Database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                            'One Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                            'Two Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                            'Three Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                            'Four Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl fourth Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                            'Five Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()




                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                            'Six Children
                            '
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()



                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If
                            '
                            '
                        ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                            'Seven Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()



                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                            'Eight Beneficiaries
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Eight Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl One
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                            '
                            '
                        End If
                    End If
                    'One Beneficiary End If
                End If

                'Two Beneficiaries
            ElseIf (twoBeneficiary.Checked = True) Then
                If (txtBeneficiaryOneName.Text = "") Then
                    MessageBox.Show("Enter first benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryOneName.Text) = True Or containsNumber3) Then
                    MessageBox.Show("The first beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneName.Focus()
                ElseIf (txtBeneficiaryOneDoB.Text.Length < 7) Then
                    MessageBox.Show("Set the first beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneDoB.Focus()
                ElseIf (txtBeneficiaryOneRelation.Text = "") Then
                    MessageBox.Show("Select the first beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneRelation.Focus()
                ElseIf (txtBeneficiaryOneProportion.Text = "") Then
                    MessageBox.Show("Enter the first beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneProportion.Focus()
                ElseIf (txtBeneficiaryOneAddress.Text = "") Then
                    MessageBox.Show("Enter the first beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneAddress.Focus()
                ElseIf (txtBeneficiaryTwoName.Text = "") Then
                    MessageBox.Show("Enter the second benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryTwoName.Text) = True Or containsNumber4) Then
                    MessageBox.Show("The second beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoName.Focus()
                ElseIf (txtBeneficiaryTwoDoB.Text.Length < 7) Then
                    MessageBox.Show("Set second beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoDoB.Focus()
                ElseIf (txtBeneficiaryTwoRelation.Text = "") Then
                    MessageBox.Show("Select the second beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoRelation.Focus()
                ElseIf (txtBeneficiaryTwoProportion.Text = "") Then
                    MessageBox.Show("Enter the second beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoProportion.Focus()
                    ''
                    ''
                ElseIf (Convert.ToInt32(txtBeneficiaryTwoProportion.Text) + Convert.ToInt32(txtBeneficiaryOneProportion.Text) > 100) Then
                    MessageBox.Show("The sum of the Beneficiarys' Proportions is morethan 100%", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoProportion.Focus()
                    '
                    '
                ElseIf (txtBeneficiaryTwoAddress.Text = "") Then
                    MessageBox.Show("Enter the second beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoAddress.Focus()
                Else
                    memberABeneficiary1 = txtBeneficiaryOneName.Text
                    memberABeneficiary1Phone = txtBeneficiaryOnePhone.Text
                    memberABeneficiary1DoB = txtBeneficiaryOneDoBA.Value
                    memberABeneficiary1Relation = txtBeneficiaryOneRelation.Text
                    memberABeneficiary1Proportion = txtBeneficiaryOneProportion.Text
                    memberABeneficiary1Address = txtBeneficiaryOneAddress.Text

                    memberABeneficiary2 = txtBeneficiaryTwoName.Text
                    memberABeneficiary2Phone = txtBeneficiaryTwoPhone.Text
                    memberABeneficiary2DoB = txtBeneficiaryTwoDoBB.Value
                    memberABeneficiary2Relation = txtBeneficiaryTwoRelation.Text
                    memberABeneficiary2Proportion = txtBeneficiaryTwoProportion.Text
                    memberABeneficiary2Address = txtBeneficiaryTwoAddress.Text

                    'Add Member
                    If (SecAddMemberPage1.txtMaritalStatus.Text = "Single") Then
                        If (SecAddMemberPage1.noChild.Checked = True) Then
                            'No Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally Insert to Database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                            'One Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()



                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                            'Two Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                            'Three Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert intoBeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                            'Four Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()



                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl fourth Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                            'Five Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                            'Six Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTblvalues('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                            'Seven Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                            'Eight Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()



                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Eight Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        End If

                    ElseIf (SecAddMemberPage1.txtMaritalStatus.Text = "Married") Then
                        If (SecAddMemberPage1.noChild.Checked = True) Then
                            'No Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally Insert to Database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()



                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert intoBeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                            'One Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                            'Two Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTblvalues('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                            'Three Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                            'Four Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl fourth Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                            'Five Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                            'Six Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                            'Seven Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                            'Eight Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Eight Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    'MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        End If
                        '
                        '
                    End If
                    'Two Beneficiary End If
                End If

                'Three Beneficiaries
            ElseIf (threeBeneficiary.Checked = True) Then
                If (txtBeneficiaryOneName.Text = "") Then
                    MessageBox.Show("Enter the first benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryOneName.Text) = True Or containsNumber3) Then
                    MessageBox.Show("The first beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneName.Focus()
                ElseIf (txtBeneficiaryOneDoB.Text.Length < 7) Then
                    MessageBox.Show("Set the first beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneDoB.Focus()
                ElseIf (txtBeneficiaryOneRelation.Text = "") Then
                    MessageBox.Show("Select the first beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneRelation.Focus()
                ElseIf (txtBeneficiaryOneProportion.Text = "") Then
                    MessageBox.Show("Enter the first beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneProportion.Focus()
                ElseIf (txtBeneficiaryOneAddress.Text = "") Then
                    MessageBox.Show("Enter the first beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneAddress.Focus()
                ElseIf (txtBeneficiaryTwoName.Text = "") Then
                    MessageBox.Show("Enter the second benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryTwoName.Text) = True Or containsNumber4) Then
                    MessageBox.Show("The second beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoName.Focus()
                ElseIf (txtBeneficiaryTwoDoB.Text.Length < 7) Then
                    MessageBox.Show("Set the second beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoDoB.Focus()
                ElseIf (txtBeneficiaryTwoRelation.Text = "") Then
                    MessageBox.Show("Select the second beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoRelation.Focus()
                ElseIf (txtBeneficiaryTwoProportion.Text = "") Then
                    MessageBox.Show("Enter the second beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoProportion.Focus()
                ElseIf (txtBeneficiaryTwoAddress.Text = "") Then
                    MessageBox.Show("Enter the second beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoAddress.Focus()
                ElseIf (txtBeneficiaryThreeName.Text = "") Then
                    MessageBox.Show("Enter the third benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryThreeName.Text) = True Or containsNumber5) Then
                    MessageBox.Show("The third beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeName.Focus()
                ElseIf (txtBeneficiaryThreeDoB.Text.Length < 7) Then
                    MessageBox.Show("Set the third beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeDoB.Focus()
                ElseIf (txtBeneficiaryThreeRelation.Text = "") Then
                    MessageBox.Show("Select the third beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeRelation.Focus()
                ElseIf (txtBeneficiaryThreeProportion.Text = "") Then
                    MessageBox.Show("Enter the third beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeProportion.Focus()
                    '
                    '
                ElseIf (Convert.ToInt32(txtBeneficiaryTwoProportion.Text) + Convert.ToInt32(txtBeneficiaryOneProportion.Text) + Convert.ToInt32(txtBeneficiaryThreeProportion.Text) > 100) Then
                    MessageBox.Show("The sum of the beneficiarys' Proportion is morethan 100%", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeProportion.Focus()
                    '
                ElseIf (txtBeneficiaryThreeAddress.Text = "") Then
                    MessageBox.Show("Enter the third beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeAddress.Focus()
                Else
                    memberABeneficiary1 = txtBeneficiaryOneName.Text
                    memberABeneficiary1Phone = txtBeneficiaryOnePhone.Text
                    memberABeneficiary1DoB = txtBeneficiaryOneDoBA.Value
                    memberABeneficiary1Relation = txtBeneficiaryOneRelation.Text
                    memberABeneficiary1Proportion = txtBeneficiaryOneProportion.Text
                    memberABeneficiary1Address = txtBeneficiaryOneAddress.Text

                    memberABeneficiary2 = txtBeneficiaryTwoName.Text
                    memberABeneficiary2Phone = txtBeneficiaryTwoPhone.Text
                    memberABeneficiary2DoB = txtBeneficiaryTwoDoBB.Value
                    memberABeneficiary2Relation = txtBeneficiaryTwoRelation.Text
                    memberABeneficiary2Proportion = txtBeneficiaryTwoProportion.Text
                    memberABeneficiary2Address = txtBeneficiaryTwoAddress.Text

                    memberABeneficiary3 = txtBeneficiaryThreeName.Text
                    memberABeneficiary3Phone = txtBeneficiaryThreePhone.Text
                    memberABeneficiary3DoB = txtBeneficiaryThreeDoBC.Value
                    memberABeneficiary3Relation = txtBeneficiaryThreeRelation.Text
                    memberABeneficiary3Proportion = txtBeneficiaryThreeProportion.Text
                    memberABeneficiary3Address = txtBeneficiaryThreeAddress.Text

                    'Add Member
                    If (SecAddMemberPage1.txtMaritalStatus.Text = "Single") Then
                        If (SecAddMemberPage1.noChild.Checked = True) Then
                            'No Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally Insert to Database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)


                            End If

                        ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                            'One Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)


                            End If

                        ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                            'Two Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                            'Three Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)


                            End If

                        ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                            'Four Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl fourth Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)


                            End If


                        ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                            'Five Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                            'Six Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                            'Seven Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                            'Eight Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Eight Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        End If

                    ElseIf (SecAddMemberPage1.txtMaritalStatus.Text = "Married") Then
                        If (SecAddMemberPage1.noChild.Checked = True) Then
                            'No Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally Insert to Database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                            'One Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                            'Two Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''       MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                            'Three Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                            'Four Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl fourth Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                            'Five Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                            'Six Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''        MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                            'Seven Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                            'Eight Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Eight Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        End If
                    End If
                    'Three Beneficiary End If
                End If

                'Four Beneficiaried
            ElseIf (fourBeneficiary.Checked = True) Then
                If (txtBeneficiaryOneName.Text = "") Then
                    MessageBox.Show("Enter the first benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryOneName.Text) = True Or containsNumber3) Then
                    MessageBox.Show("The first beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneName.Focus()
                ElseIf (txtBeneficiaryOneDoB.Text.Length < 7) Then
                    MessageBox.Show("Set the first beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneDoB.Focus()
                ElseIf (txtBeneficiaryOneRelation.Text = "") Then
                    MessageBox.Show("Select the first beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneRelation.Focus()
                ElseIf (txtBeneficiaryOneProportion.Text = "") Then
                    MessageBox.Show("Enter the first beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneProportion.Focus()
                ElseIf (txtBeneficiaryOneAddress.Text = "") Then
                    MessageBox.Show("Enter the first beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryOneAddress.Focus()
                ElseIf (txtBeneficiaryTwoName.Text = "") Then
                    MessageBox.Show("Enter the second benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryTwoName.Text) = True Or containsNumber4) Then
                    MessageBox.Show("The second beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoName.Focus()
                ElseIf (txtBeneficiaryTwoDoB.Text.Length < 7) Then
                    MessageBox.Show("Set the second beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoDoB.Focus()
                ElseIf (txtBeneficiaryTwoRelation.Text = "") Then
                    MessageBox.Show("Select the second beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoRelation.Focus()
                ElseIf (txtBeneficiaryTwoProportion.Text = "") Then
                    MessageBox.Show("Enter the second beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoProportion.Focus()
                ElseIf (txtBeneficiaryTwoAddress.Text = "") Then
                    MessageBox.Show("Enter the second beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryTwoAddress.Focus()
                ElseIf (txtBeneficiaryThreeName.Text = "") Then
                    MessageBox.Show("Enter the third benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryThreeName.Text) = True Or containsNumber5) Then
                    MessageBox.Show("The third beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeName.Focus()
                ElseIf (txtBeneficiaryThreeDoB.Text.Length < 7) Then
                    MessageBox.Show("Set the third beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeDoB.Focus()
                ElseIf (txtBeneficiaryThreeRelation.Text = "") Then
                    MessageBox.Show("Select the third beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeRelation.Focus()
                ElseIf (txtBeneficiaryThreeProportion.Text = "") Then
                    MessageBox.Show("Enter the third beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeProportion.Focus()
                ElseIf (txtBeneficiaryThreeAddress.Text = "") Then
                    MessageBox.Show("Enter the third beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryThreeAddress.Focus()
                ElseIf (txtBeneficiaryFourName.Text = "") Then
                    MessageBox.Show("Enter the fourth benefiary's Name", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryFourName.Focus()
                ElseIf (IsNumeric(txtBeneficiaryFourName.Text) = True Or containsNumber6) Then
                    MessageBox.Show("The fourth beneficiary's name is invalid", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryFourName.Focus()
                ElseIf (txtBeneficiaryFourDoB.Text.Length < 7) Then
                    MessageBox.Show("Set the fourth beneficiary's Date Of Birth(DoB)", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryFourDoB.Focus()
                ElseIf (txtBeneficiaryFourRelation.Text = "") Then
                    MessageBox.Show("Select the fourth beneficiary's Relation", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryFourRelation.Focus()
                ElseIf (txtBeneficiaryFourProportion.Text = "") Then
                    MessageBox.Show("Enter the fourth beneficiary's Proportion", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryFourProportion.Focus()
                    '
                    '
                ElseIf (Convert.ToInt32(txtBeneficiaryTwoProportion.Text) + Convert.ToInt32(txtBeneficiaryOneProportion.Text) + Convert.ToInt32(txtBeneficiaryThreeProportion.Text) + Convert.ToInt32(txtBeneficiaryFourProportion.Text) > 100) Then
                    MessageBox.Show("The sum of the beneficiarys' Proportion is morethan 100%", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryFourProportion.Focus()
                    '
                ElseIf (txtBeneficiaryFourAddress.Text = "") Then
                    MessageBox.Show("Enter the fourth beneficiary's Address", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                    txtBeneficiaryFourAddress.Focus()
                Else
                    memberABeneficiary1 = txtBeneficiaryOneName.Text
                    memberABeneficiary1Phone = txtBeneficiaryOnePhone.Text
                    memberABeneficiary1DoB = txtBeneficiaryOneDoBA.Value
                    memberABeneficiary1Relation = txtBeneficiaryOneRelation.Text
                    memberABeneficiary1Proportion = txtBeneficiaryOneProportion.Text
                    memberABeneficiary1Address = txtBeneficiaryOneAddress.Text

                    memberABeneficiary2 = txtBeneficiaryTwoName.Text
                    memberABeneficiary2Phone = txtBeneficiaryTwoPhone.Text
                    memberABeneficiary2DoB = txtBeneficiaryTwoDoBB.Value
                    memberABeneficiary2Relation = txtBeneficiaryTwoRelation.Text
                    memberABeneficiary2Proportion = txtBeneficiaryTwoProportion.Text
                    memberABeneficiary2Address = txtBeneficiaryTwoAddress.Text

                    memberABeneficiary3 = txtBeneficiaryThreeName.Text
                    memberABeneficiary3Phone = txtBeneficiaryThreePhone.Text
                    memberABeneficiary3DoB = txtBeneficiaryThreeDoBC.Value
                    memberABeneficiary3Relation = txtBeneficiaryThreeRelation.Text
                    memberABeneficiary3Proportion = txtBeneficiaryThreeProportion.Text
                    memberABeneficiary3Address = txtBeneficiaryThreeAddress.Text

                    memberABeneficiary4 = txtBeneficiaryFourName.Text
                    memberABeneficiary4Phone = txtBeneficiaryFourPhone.Text
                    memberABeneficiary4DoB = txtBeneficiaryFourDoBD.Value
                    memberABeneficiary4Relation = txtBeneficiaryFourRelation.Text
                    memberABeneficiary4Proportion = txtBeneficiaryFourProportion.Text
                    memberABeneficiary4Address = txtBeneficiaryFourAddress.Text
                    'Add Member
                    If (SecAddMemberPage1.txtMaritalStatus.Text = "Single") Then
                        If (SecAddMemberPage1.noChild.Checked = True) Then
                            'No Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally Insert to Database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                            'One Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                            'Two Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                            'Three Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                            'Four Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl fourth Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)


                            End If


                        ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                            'Five Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)


                            End If

                        ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                            'Six Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)


                            End If

                        ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                            'Seven Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                            'Eight Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Eight Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        End If

                    ElseIf (SecAddMemberPage1.txtMaritalStatus.Text = "Married") Then
                        If (SecAddMemberPage1.noChild.Checked = True) Then
                            'No Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally Insert to Database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.oneChild.Checked = True) Then
                            'One Child
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()


                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.twoChildren.Checked = True) Then
                            'Two Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.threeChildren.Checked = True) Then
                            'Three Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.fourChildren.Checked = True) Then
                            'Four Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Third Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl fourth Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If


                        ElseIf (SecAddMemberPage1.fiveChildren.Checked = True) Then
                            'Five Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sixChildren.Checked = True) Then
                            'Six Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.sevenChildren.Checked = True) Then
                            'Seven Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBridge", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        ElseIf (SecAddMemberPage1.eightChildren.Checked = True) Then
                            'Eight Children
                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Staff_ID ='" & memberAStaffID & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa2 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try

                            'Check if member is Already registered
                            Try
                                Cursor = Cursors.WaitCursor
                                Con.Open()
                                Dim query22 = "select * from MembersTbl where Phone ='" & memberAPhone & "' "
                                cmd = New SqlCommand(query22, Con)
                                adaptor = New SqlDataAdapter(cmd)
                                ds = New DataSet()
                                adaptor.Fill(ds)
                                aa3 = ds.Tables(0).Rows.Count
                            Catch ex As Exception
                            Finally
                                Cursor = Cursors.Default
                                Con.Close()
                            End Try
                            'Finally insert to database
                            If ((aa2 = 0) = False Or (aa3 = 0) = False) Then
                                MessageBox.Show("Member already registered")
                            Else
                                'Insert to MemberTbl
                                InsertMemberDetailToDB()

                                'Insert to ParentsTbl Mother
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAMothername & "','" & memberAMotherPhone & "','" & memberAMotherLiveStatus & "','" & nullMotherStatus & "','" & nullMotherClaimDate & "','" & AMother & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Account created successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ParentsTbl Father
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ParentsTbl values('" & memberAStaffID & "','" & memberAFathername & "','" & memberAFatherPhone & "','" & memberAFatherLiveStatus & "','" & nullFatherStatus & "','" & nullMotherClaimDate & "','" & AFather & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl First Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild1name & "','" & memberAChild1DoB & "','" & nullChildOneStatus & "','" & nullChildOneClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Second Child
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild2name & "','" & memberAChild2DoB & "','" & nullChildTwoStatus & "','" & nullChildTwoClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Three Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild3name & "','" & memberAChild3DoB & "','" & nullChildThreeStatus & "','" & nullChildThreeClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''   MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Four Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild4name & "','" & memberAChild4DoB & "','" & nullChildFourStatus & "','" & nullChildFourClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Five Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild5name & "','" & memberAChild5DoB & "','" & nullChildFiveStatus & "','" & nullChildFiveClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Six Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild6name & "','" & memberAChild6DoB & "','" & nullChildSixStatus & "','" & nullChildSixClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Seven Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild7name & "','" & memberAChild7DoB & "','" & nullChildSevenStatus & "','" & nullChildSevenClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to ChildrenTbl Eight Children
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into ChildrenTbl values('" & memberAStaffID & "','" & memberAChild8name & "','" & memberAChild8DoB & "','" & nullChildEightStatus & "','" & nullChildEightClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to SpouseTbl
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into SpouseTbl values('" & memberAStaffID & "','" & memberASpouseName & "','" & memberASpousePhone & "','" & memberASpouseAddress & "','" & nullSpouseStatus & "','" & nullSpouseClaimDate & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl OneBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary1 & "','" & memberABeneficiary1Phone & "','" & memberABeneficiary1DoB & "','" & memberABeneficiary1Relation & "','" & memberABeneficiary1Address & "','" & memberABeneficiary1Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ''  MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try


                                'Insert to BeneficiaryTbl TwoBene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary2 & "','" & memberABeneficiary2Phone & "','" & memberABeneficiary2DoB & "','" & memberABeneficiary2Relation & "','" & memberABeneficiary2Address & "','" & memberABeneficiary2Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    ' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Three Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary3 & "','" & memberABeneficiary3Phone & "','" & memberABeneficiary3DoB & "','" & memberABeneficiary3Relation & "','" & memberABeneficiary3Address & "','" & memberABeneficiary3Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    '' MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                'Insert to BeneficiaryTbl Four Bene
                                Try
                                    Con.Open()
                                    Dim query3 As String
                                    query3 = "insert into BeneficiariesTbl values('" & memberAStaffID & "','" & memberABeneficiary4 & "','" & memberABeneficiary4Phone & "','" & memberABeneficiary4DoB & "','" & memberABeneficiary4Relation & "','" & memberABeneficiary4Address & "','" & memberABeneficiary4Proportion & "')"
                                    cmd = New SqlCommand(query3, Con)
                                    cmd.ExecuteNonQuery()
                                    MessageBox.Show("Member added successfully", "AidBrige", MessageBoxButtons.OK, MessageBoxIcon.None)
                                Catch ex As Exception
                                    MsgBox(ex.Message)
                                Finally
                                    Con.Close()
                                End Try

                                resetAllMemberFormsSec()
                                switchPages(SecAddMemberPage1)

                            End If

                        End If

                    End If
                    'Four Beneficiaries End If
                End If
                'Checked beneficiaries End If
            End If

            'Main End If
        End If
        Cursor = Cursors.Default


    End Sub

    Private Sub txtNoBeneficiary_CheckedChanged(sender As Object, e As EventArgs) Handles txtNoBeneficiary.CheckedChanged
        txtBeneficiaryOneName.ReadOnly = True
        txtBeneficiaryOneDoB.ReadOnly = True
        txtBeneficiaryOnePhone.ReadOnly = True
        txtBeneficiaryOneAddress.ReadOnly = True
        txtBeneficiaryOneProportion.ReadOnly = True

        txtBeneficiaryTwoName.ReadOnly = True
        txtBeneficiaryTwoDoB.ReadOnly = True
        txtBeneficiaryTwoPhone.ReadOnly = True
        txtBeneficiaryTwoAddress.ReadOnly = True
        txtBeneficiaryTwoProportion.ReadOnly = True

        txtBeneficiaryThreeName.ReadOnly = True
        txtBeneficiaryThreeDoB.ReadOnly = True
        txtBeneficiaryThreePhone.ReadOnly = True
        txtBeneficiaryThreeAddress.ReadOnly = True
        txtBeneficiaryThreeProportion.ReadOnly = True

        txtBeneficiaryFourName.ReadOnly = True
        txtBeneficiaryFourDoB.ReadOnly = True
        txtBeneficiaryFourPhone.ReadOnly = True
        txtBeneficiaryFourAddress.ReadOnly = True
        txtBeneficiaryFourProportion.ReadOnly = True

        '' Clear text
        txtBeneficiaryOneName.Text = ""
        txtBeneficiaryOneRelation.Text = ""
        txtBeneficiaryOneDoB.Text = ""
        txtBeneficiaryOnePhone.Text = ""
        txtBeneficiaryOneRelation.Text = ""
        txtBeneficiaryOneAddress.Text = ""
        txtBeneficiaryOneProportion.Text = ""

        txtBeneficiaryTwoName.Text = ""
        txtBeneficiaryTwoDoB.Text = ""
        txtBeneficiaryTwoPhone.Text = ""
        txtBeneficiaryTwoRelation.Text = ""
        txtBeneficiaryTwoAddress.Text = ""
        txtBeneficiaryTwoProportion.Text = ""

        txtBeneficiaryThreeName.Text = ""
        txtBeneficiaryThreeDoB.Text = ""
        txtBeneficiaryThreePhone.Text = ""
        txtBeneficiaryThreeRelation.Text = ""
        txtBeneficiaryThreeAddress.Text = ""
        txtBeneficiaryThreeProportion.Text = ""

        txtBeneficiaryFourName.Text = ""
        txtBeneficiaryFourDoB.Text = ""
        txtBeneficiaryFourPhone.Text = ""
        txtBeneficiaryFourRelation.Text = ""
        txtBeneficiaryFourAddress.Text = ""
        txtBeneficiaryFourProportion.Text = ""
    End Sub

    Private Sub oneBeneficiary_CheckedChanged(sender As Object, e As EventArgs) Handles oneBeneficiary.CheckedChanged
        txtBeneficiaryOneName.ReadOnly = False
        txtBeneficiaryOneDoB.ReadOnly = False
        txtBeneficiaryOnePhone.ReadOnly = False
        txtBeneficiaryOneAddress.ReadOnly = False
        txtBeneficiaryOneProportion.ReadOnly = False

        ' Deactivate the other buttons
        txtBeneficiaryTwoName.ReadOnly = True
        txtBeneficiaryTwoDoB.ReadOnly = True
        txtBeneficiaryTwoPhone.ReadOnly = True
        txtBeneficiaryTwoAddress.ReadOnly = True
        txtBeneficiaryTwoProportion.ReadOnly = True

        txtBeneficiaryThreeName.ReadOnly = True
        txtBeneficiaryThreeDoB.ReadOnly = True
        txtBeneficiaryThreePhone.ReadOnly = True
        txtBeneficiaryThreeAddress.ReadOnly = True
        txtBeneficiaryThreeProportion.ReadOnly = True

        txtBeneficiaryFourName.ReadOnly = True
        txtBeneficiaryFourDoB.ReadOnly = True
        txtBeneficiaryFourPhone.ReadOnly = True
        txtBeneficiaryFourAddress.ReadOnly = True
        txtBeneficiaryFourProportion.ReadOnly = True


        txtBeneficiaryTwoName.Text = ""
        txtBeneficiaryTwoDoB.Text = ""
        txtBeneficiaryTwoPhone.Text = ""
        txtBeneficiaryTwoRelation.Text = ""
        txtBeneficiaryTwoAddress.Text = ""
        txtBeneficiaryTwoProportion.Text = ""

        txtBeneficiaryThreeName.Text = ""
        txtBeneficiaryThreeDoB.Text = ""
        txtBeneficiaryThreePhone.Text = ""
        txtBeneficiaryThreeRelation.Text = ""
        txtBeneficiaryThreeAddress.Text = ""
        txtBeneficiaryThreeProportion.Text = ""

        txtBeneficiaryFourName.Text = ""
        txtBeneficiaryFourDoB.Text = ""
        txtBeneficiaryFourPhone.Text = ""
        txtBeneficiaryFourRelation.Text = ""
        txtBeneficiaryFourAddress.Text = ""
        txtBeneficiaryFourProportion.Text = ""
    End Sub

    Private Sub twoBeneficiary_CheckedChanged(sender As Object, e As EventArgs) Handles twoBeneficiary.CheckedChanged
        ''Activate the other buttons
        txtBeneficiaryOneName.ReadOnly = False
        txtBeneficiaryOneDoB.ReadOnly = False
        txtBeneficiaryOnePhone.ReadOnly = False
        txtBeneficiaryOneAddress.ReadOnly = False
        txtBeneficiaryOneProportion.ReadOnly = False

        txtBeneficiaryTwoName.ReadOnly = False
        txtBeneficiaryTwoDoB.ReadOnly = False
        txtBeneficiaryTwoPhone.ReadOnly = False
        txtBeneficiaryTwoAddress.ReadOnly = False
        txtBeneficiaryTwoProportion.ReadOnly = False

        ''DeActivate the other buttons
        txtBeneficiaryThreeName.ReadOnly = True
        txtBeneficiaryThreeDoB.ReadOnly = True
        txtBeneficiaryThreePhone.ReadOnly = True
        txtBeneficiaryThreeAddress.ReadOnly = True
        txtBeneficiaryThreeProportion.ReadOnly = True

        txtBeneficiaryFourName.ReadOnly = True
        txtBeneficiaryFourDoB.ReadOnly = True
        txtBeneficiaryFourPhone.ReadOnly = True
        txtBeneficiaryFourAddress.ReadOnly = True
        txtBeneficiaryFourProportion.ReadOnly = True

        txtBeneficiaryThreeName.Text = ""
        txtBeneficiaryThreeDoB.Text = ""
        txtBeneficiaryThreePhone.Text = ""
        txtBeneficiaryThreeRelation.Text = ""
        txtBeneficiaryThreeAddress.Text = ""
        txtBeneficiaryThreeProportion.Text = ""

        txtBeneficiaryFourName.Text = ""
        txtBeneficiaryFourDoB.Text = ""
        txtBeneficiaryFourPhone.Text = ""
        txtBeneficiaryFourRelation.Text = ""
        txtBeneficiaryFourAddress.Text = ""
        txtBeneficiaryFourProportion.Text = ""
    End Sub

    Private Sub threeBeneficiary_CheckedChanged(sender As Object, e As EventArgs) Handles threeBeneficiary.CheckedChanged
        txtBeneficiaryOneName.ReadOnly = False
        txtBeneficiaryOneDoB.ReadOnly = False
        txtBeneficiaryOnePhone.ReadOnly = False
        txtBeneficiaryOneAddress.ReadOnly = False
        txtBeneficiaryOneProportion.ReadOnly = False

        txtBeneficiaryTwoName.ReadOnly = False
        txtBeneficiaryTwoDoB.ReadOnly = False
        txtBeneficiaryTwoPhone.ReadOnly = False
        txtBeneficiaryTwoAddress.ReadOnly = False
        txtBeneficiaryTwoProportion.ReadOnly = False

        txtBeneficiaryThreeName.ReadOnly = False
        txtBeneficiaryThreeDoB.ReadOnly = False
        txtBeneficiaryThreePhone.ReadOnly = False
        txtBeneficiaryThreeAddress.ReadOnly = False
        txtBeneficiaryThreeProportion.ReadOnly = False

        ''DeActivate the other buttons
        txtBeneficiaryFourName.ReadOnly = True
        txtBeneficiaryFourDoB.ReadOnly = True
        txtBeneficiaryFourPhone.ReadOnly = True
        txtBeneficiaryFourAddress.ReadOnly = True
        txtBeneficiaryFourProportion.ReadOnly = True


        txtBeneficiaryFourName.Text = ""
        txtBeneficiaryFourDoB.Text = ""
        txtBeneficiaryFourPhone.Text = ""
        txtBeneficiaryFourRelation.Text = ""
        txtBeneficiaryFourAddress.Text = ""
        txtBeneficiaryFourProportion.Text = ""
    End Sub

    Private Sub txtBeneficiaryOneDoBA_ValueChanged(sender As Object, e As EventArgs) Handles txtBeneficiaryOneDoBA.ValueChanged
        txtBeneficiaryOneDoB.Text = txtBeneficiaryOneDoBA.Value
    End Sub

    Private Sub txtBeneficiaryTwoDoBB_ValueChanged(sender As Object, e As EventArgs) Handles txtBeneficiaryTwoDoBB.ValueChanged
        txtBeneficiaryTwoDoB.Text = txtBeneficiaryTwoDoBB.Value
    End Sub

    Private Sub txtBeneficiaryThreeDoBC_ValueChanged(sender As Object, e As EventArgs) Handles txtBeneficiaryThreeDoBC.ValueChanged
        txtBeneficiaryThreeDoB.Text = txtBeneficiaryThreeDoBC.Value
    End Sub

    Private Sub txtBeneficiaryFourDoBD_ValueChanged(sender As Object, e As EventArgs) Handles txtBeneficiaryFourDoBD.ValueChanged
        txtBeneficiaryFourDoB.Text = txtBeneficiaryFourDoBD.Value
    End Sub

    Private Sub txtBeneficiaryOneDoBA_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBeneficiaryOneDoBA.KeyUp
        txtBeneficiaryOneDoB.Text = txtBeneficiaryOneDoBA.Value
    End Sub

    Private Sub txtBeneficiaryTwoDoBB_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBeneficiaryTwoDoBB.KeyUp
        txtBeneficiaryTwoDoB.Text = txtBeneficiaryTwoDoBB.Value
    End Sub

    Private Sub txtBeneficiaryThreeDoBC_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBeneficiaryThreeDoBC.KeyUp
        txtBeneficiaryThreeDoB.Text = txtBeneficiaryThreeDoBC.Value
    End Sub

    Private Sub txtBeneficiaryFourDoBD_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBeneficiaryFourDoBD.KeyUp
        txtBeneficiaryFourDoB.Text = txtBeneficiaryFourDoBD.Value
    End Sub

    Private Sub txtBeneficiaryFourAddress_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBeneficiaryFourAddress.KeyUp
        txtBeneficiaryFourRelation.Text = ""
    End Sub

    Private Sub txtBeneficiaryThreeAddress_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBeneficiaryThreeAddress.KeyUp
        txtBeneficiaryThreeRelation.Text = ""
    End Sub

    Private Sub txtBeneficiaryTwoAddress_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBeneficiaryTwoAddress.KeyUp
        txtBeneficiaryTwoRelation.Text = ""
    End Sub

    Private Sub txtBeneficiaryOneAddress_KeyUp(sender As Object, e As KeyEventArgs) Handles txtBeneficiaryOneAddress.KeyUp
        txtBeneficiaryOneRelation.Text = ""
    End Sub

    Private Sub previousBtn_Click(sender As Object, e As EventArgs) Handles previousBtn.Click
        switchPages(SecAddMemberPage1)
    End Sub

    Private Sub fourBeneficiary_CheckedChanged(sender As Object, e As EventArgs) Handles fourBeneficiary.CheckedChanged
        txtBeneficiaryOneName.ReadOnly = False
        txtBeneficiaryOneDoB.ReadOnly = False
        txtBeneficiaryOnePhone.ReadOnly = False
        txtBeneficiaryOneAddress.ReadOnly = False
        txtBeneficiaryOneProportion.ReadOnly = False

        txtBeneficiaryTwoName.ReadOnly = False
        txtBeneficiaryTwoDoB.ReadOnly = False
        txtBeneficiaryTwoPhone.ReadOnly = False
        txtBeneficiaryTwoAddress.ReadOnly = False
        txtBeneficiaryTwoProportion.ReadOnly = False

        txtBeneficiaryThreeName.ReadOnly = False
        txtBeneficiaryThreeDoB.ReadOnly = False
        txtBeneficiaryThreePhone.ReadOnly = False
        txtBeneficiaryThreeAddress.ReadOnly = False
        txtBeneficiaryThreeProportion.ReadOnly = False

        txtBeneficiaryFourName.ReadOnly = False
        txtBeneficiaryFourDoB.ReadOnly = False
        txtBeneficiaryFourPhone.ReadOnly = False
        txtBeneficiaryFourAddress.ReadOnly = False
        txtBeneficiaryFourProportion.ReadOnly = False
    End Sub
End Class