﻿Imports System.Data.SqlClient
Imports System.Runtime.InteropServices
Imports FontAwesome.Sharp
Public Class SecretryForm
    Private currentBtn As IconButton
    Private leftBorderBtn As Panel
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        leftBorderBtn = New Panel()
        leftBorderBtn.Size = New Size(7, 42)
        PanelMenu.Controls.Add(leftBorderBtn)

    End Sub

    Private Sub ActivationButton(senderBtn As Object, customColor As Color)

        Try
            If senderBtn IsNot Nothing Then
                DisableButton()
                'Button'
                currentBtn = CType(senderBtn, IconButton)
                currentBtn.BackColor = Color.FromArgb(37, 36, 81)
                currentBtn.ForeColor = customColor
                currentBtn.IconColor = customColor
                currentBtn.TextAlign = ContentAlignment.MiddleCenter
                currentBtn.ImageAlign = ContentAlignment.MiddleRight
                currentBtn.TextImageRelation = TextImageRelation.TextBeforeImage


                'leftBorder'
                leftBorderBtn.BackColor = customColor
                leftBorderBtn.Location = New Point(0, currentBtn.Location.Y)
                leftBorderBtn.Visible = True
                leftBorderBtn.BringToFront()

                adminText.IconChar = currentBtn.IconChar
                adminText.Text = currentBtn.Text

            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub DisableButton()
        Try
            If currentBtn IsNot Nothing Then

                currentBtn.BackColor = Color.SeaGreen
                currentBtn.ForeColor = Color.White
                currentBtn.IconColor = Color.White
                currentBtn.TextAlign = ContentAlignment.MiddleLeft
                currentBtn.ImageAlign = ContentAlignment.MiddleLeft
                currentBtn.TextImageRelation = TextImageRelation.ImageBeforeText

            End If
        Catch ex As Exception

        End Try
    End Sub

    Sub switchPages(ByVal pageSwitch1 As Form)
        Try
            pageSwitch.Controls.Clear()
            pageSwitch1.TopLevel = False
            pageSwitch1.Dock = DockStyle.Fill
            pageSwitch.Controls.Add(pageSwitch1)
            pageSwitch1.Show()
        Catch ex As Exception

        End Try


    End Sub

    Private Sub btnMembers_Click(sender As Object, e As EventArgs) Handles btnMembers.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        HomeToolStripMenuItem.Checked = False
        '   ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = True
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False

        Try
            Cursor = Cursors.WaitCursor
            ActivationButton(sender, Color.DarkSeaGreen)
            adminText.IconColor = Color.DarkSeaGreen
            Dim nwSecMembers = New SecMembers
            switchPages(nwSecMembers)


        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        '' Get the total members 
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from MembersTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            totalMembers = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        Dim checknul1 As Integer = 0, checknull2 As Integer = 0
        '' Get the total contribtions check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknul1 = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try

        'Total Contributions
        If (checknul1 <> 0) Then
            Try
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount) AS YearlyContributionSum FROM ContributionsTbl WHERE YEAR(Month_Of_Payment) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                ' Assuming connection is your SqlConnection object
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalContributions = 0
                Else
                    totalContributions = toTotal
                End If
                ' Process or display yearly sum for the current year here
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Con.Close()
            End Try
        End If

        '' Get the total claims amount check
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            checknull2 = ds.Tables(0).Rows.Count
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try
        If (checknull2 <> 0) Then
            'Total Amount Claimed
            Try
                Cursor = Cursors.WaitCursor
                Con.Open()
                Dim queryYearly As String = "SELECT sum(Amount_Given) AS YearlyContributionSum FROM ClaimsTbl WHERE YEAR(Claim_Date) = '" & currentYear & "'"
                cmd = New SqlCommand(queryYearly, Con)
                '   Dim toTotal = cmd.ExecuteScalar
                cmd.Parameters.AddWithValue("@CurrentYear", currentYear)
                Dim toTotal = Convert.ToDecimal(cmd.ExecuteScalar())
                If (IsDBNull(toTotal) = True) Then
                    totalMoneyGivenOut = 0
                Else
                    totalMoneyGivenOut = toTotal
                End If
            Catch ex As Exception
                '   MsgBox(ex.Message)
            Finally
                Cursor = Cursors.Default
                Con.Close()
            End Try
        End If


        '' Get the total claims 
        Try
            Cursor = Cursors.WaitCursor
            Con.Open()
            Dim query22 As String = "select * from ClaimsTbl "
            cmd = New SqlCommand(query22, Con)
            adaptor = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adaptor.Fill(ds)
            totalClaims = ds.Tables(0).Rows.Count

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
            Con.Close()
        End Try


        HomeToolStripMenuItem.Checked = True
        '  ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False

        Try
            Cursor = Cursors.WaitCursor
            ActivationButton(sender, Color.DarkSeaGreen)
            adminText.IconColor = Color.DarkSeaGreen
            Dim nwSecretaryHome = New SecretaryHome
            switchPages(nwSecretaryHome)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub SecretryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnHome.PerformClick()
        txtUsernameHomePage.Text = theUsername.ToUpper()
    End Sub

    Private Sub btnEditAccount_Click(sender As Object, e As EventArgs) Handles btnEditAccount.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        HomeToolStripMenuItem.Checked = False
        ' ContributionsToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = True
        LogOutToolStripMenuItem.Checked = False


        Try
            Cursor = Cursors.WaitCursor
            ActivationButton(sender, Color.DarkSeaGreen)
            adminText.IconColor = Color.DarkSeaGreen
            Dim nwSecEditAccount = New SecEditAccount
            switchPages(nwSecEditAccount)


        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub IogoutTime()
        Try
            Dim currentDataNTim As New DateTimePicker
            Dim theTimeNDate = currentDataNTim.Value
            Con.Open()
            Dim query5 As String
            query5 = "insert into ViewlogsTbl values('" & UStaffID & "','" & Uname & "','" & Uphone & "','" & Ugmail & "','" & lognullDate & "','" & theTimeNDate & "')"
            cmd = New SqlCommand(query5, Con)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
        Try
            Dim logOutDialog As DialogResult = MessageBox.Show("LogOut", "AidBridge", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If (logOutDialog = DialogResult.Yes) Then
                IogoutTime()
                Dim nwSecLoginForm = New SecLoginForm

                btnHome.PerformClick()
                Me.Hide()
                nwSecLoginForm.Show()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
        AddNewBeneficiary.Hide()
        AddNewChild.Hide()
    End Sub

    '
    'Drag Form
    <DllImport("user32.DLL", EntryPoint:="ReleaseCapture")>
    Private Shared Sub ReleaseCapture()
    End Sub
    <DllImport("user32.DLL", EntryPoint:="SendMessage")>
    Private Shared Sub SendMessage(ByVal hWnd As System.IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer)
    End Sub
    Private Sub PanelTitleBar_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Panel1.MouseDown
        ReleaseCapture()
        SendMessage(Me.Handle, &H112, &HF012, 0)
        btnMaximize.Visible = True
        btnNormal.Visible = False

        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = False
        RestoreToolStripMenuItem.Checked = True
    End Sub

    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        btnHome.PerformClick()
        HomeToolStripMenuItem.Checked = True
        MembersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False

    End Sub

    Private Sub MembersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MembersToolStripMenuItem.Click
        btnMembers.PerformClick()
        HomeToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = True
        EditAccountToolStripMenuItem.Checked = False
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub EditAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditAccountToolStripMenuItem.Click
        btnEditAccount.PerformClick()
        HomeToolStripMenuItem.Checked = False
        MembersToolStripMenuItem.Checked = False
        EditAccountToolStripMenuItem.Checked = True
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        btnLogOut.PerformClick()
        LogOutToolStripMenuItem.Checked = False
    End Sub

    Private Sub MinimizeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MinimizeToolStripMenuItem.Click
        Me.WindowState = FormWindowState.Minimized
        ' MinimizeToolStripMenuItem.Checked = True
        MaximizeToolStripMenuItem.Checked = False
        RestoreToolStripMenuItem.Checked = False
    End Sub

    Private Sub MaximizeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MaximizeToolStripMenuItem.Click
        Me.WindowState = FormWindowState.Maximized
        btnMaximize.Visible = False
        btnNormal.Visible = True

        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = True
        RestoreToolStripMenuItem.Checked = False
    End Sub

    Private Sub RestoreToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RestoreToolStripMenuItem.Click
        Me.WindowState = FormWindowState.Normal
        btnMaximize.Visible = True
        btnNormal.Visible = False

        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = False
        RestoreToolStripMenuItem.Checked = True
    End Sub

    Private Sub btnNormal_Click(sender As Object, e As EventArgs) Handles btnNormal.Click
        Me.WindowState = FormWindowState.Normal
        btnMaximize.Visible = True
        btnNormal.Visible = False

        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = False
        RestoreToolStripMenuItem.Checked = True
    End Sub

    Private Sub btnMaximize_Click(sender As Object, e As EventArgs) Handles btnMaximize.Click
        Me.WindowState = FormWindowState.Maximized
        btnMaximize.Visible = False
        btnNormal.Visible = True

        MinimizeToolStripMenuItem.Checked = False
        MaximizeToolStripMenuItem.Checked = True
        RestoreToolStripMenuItem.Checked = False
    End Sub

    Private Sub btnMinimize_Click(sender As Object, e As EventArgs) Handles btnMinimize.Click
        Me.WindowState = FormWindowState.Minimized

    End Sub

    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click
        FileToolStripMenuItem.ForeColor = Color.Black
        ViewToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub ViewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewToolStripMenuItem.Click
        FileToolStripMenuItem.ForeColor = Color.White
        ViewToolStripMenuItem.ForeColor = Color.Black
    End Sub

    Private Sub ViewToolStripMenuItem_MouseHover(sender As Object, e As EventArgs) Handles ViewToolStripMenuItem.MouseHover
        FileToolStripMenuItem.ForeColor = Color.White

        ViewToolStripMenuItem.ForeColor = Color.White
        '  ViewToolStripMenuItem.BackColor = Color.DarkSeaGreen
    End Sub

    Private Sub FileToolStripMenuItem_MouseHover(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.MouseHover
        FileToolStripMenuItem.ForeColor = Color.White
        ' FileToolStripMenuItem.BackColor = Color.DarkSeaGreen

        ViewToolStripMenuItem.ForeColor = Color.White

    End Sub

    Private Sub PanelMenu_MouseHover(sender As Object, e As EventArgs) Handles PanelMenu.MouseHover
        FileToolStripMenuItem.ForeColor = Color.White
        ' FileToolStripMenuItem.BackColor = Color.DarkSeaGreen

        ViewToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub Panel2_MouseHover(sender As Object, e As EventArgs) Handles Panel2.MouseHover
        FileToolStripMenuItem.ForeColor = Color.White
        ' FileToolStripMenuItem.BackColor = Color.DarkSeaGreen

        ViewToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub PictureBox1_MouseHover(sender As Object, e As EventArgs) Handles PictureBox1.MouseHover
        FileToolStripMenuItem.ForeColor = Color.White
        ' FileToolStripMenuItem.BackColor = Color.DarkSeaGreen

        ViewToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub MenuStrip1_MouseHover(sender As Object, e As EventArgs) Handles MenuStrip1.MouseHover
        FileToolStripMenuItem.ForeColor = Color.White
        ' FileToolStripMenuItem.BackColor = Color.DarkSeaGreen

        ViewToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub btnHome_MouseHover(sender As Object, e As EventArgs) Handles btnHome.MouseHover
        FileToolStripMenuItem.ForeColor = Color.White
        ' FileToolStripMenuItem.BackColor = Color.DarkSeaGreen

        ViewToolStripMenuItem.ForeColor = Color.White
    End Sub

    Private Sub btnMembers_MouseHover(sender As Object, e As EventArgs) Handles btnMembers.MouseHover
        FileToolStripMenuItem.ForeColor = Color.White
        ' FileToolStripMenuItem.BackColor = Color.DarkSeaGreen

        ViewToolStripMenuItem.ForeColor = Color.White
    End Sub
End Class