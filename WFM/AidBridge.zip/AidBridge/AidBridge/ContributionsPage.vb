﻿Imports System.Data.SqlClient
Public Class ContributionsPage
    Private Function SearchItem() As DataTable
        Try
            Dim query As String = "select * from ContributionsTbl"
            query &= " where Id like '%' +@parm1+ '%' "
            query &= " or Surname  like '%' +@parm1+ '%' "
            query &= " or Member_ID like '%' +@parm1+ '%' "
            query &= " or Phone like '%' +@parm1+ '%' "
            query &= " or Amount like '%' +@parm1+ '%' "
            query &= " or Other_Names like '%' +@parm1+ '%' "
            query &= " or Month_Of_Payment like '%' +@parm1+ '%' "
            query &= " or Date like '%' +@parm1+ '%' "
            query &= " or Operator like '%' +@parm1+ '%' "
            query &= " or Payees_Name like '%' +@parm1+ '%' "
            query &= " or Operator_ID like '%' +@parm1+ '%' "
            query &= " or @parm1 = '' "
            ' Dim con1 As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\MySales\MySalesDb.mdf;Integrated Security=True;Connect Timeout=30"

            '  Using conn As SqlConnection = New SqlConnection(con1)
            Using cmd As SqlCommand = New SqlCommand(query, Con)
                cmd.Parameters.AddWithValue("@parm1", txtSearchItem.Text.Trim())
                Using sda As SqlDataAdapter = New SqlDataAdapter(cmd)
                    dt = New DataTable
                    sda.Fill(dt)

                    Return dt

                End Using
            End Using
            '  End Using
        Catch ex As SqlException
            MsgBox(ex.Message)

        End Try


    End Function
    Private Sub Populate()
        Try
            Con.Open()
            Dim query = "select * from ContributionsTbl"
            adaptor = New SqlDataAdapter(query, Con)
            builder = New SqlCommandBuilder(adaptor)
            ds = New DataSet
            adaptor.Fill(ds)
            ContributionsDataGridView.DataSource = ds.Tables(0)

        Catch ex As Exception
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub ContributionsPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
    End Sub

    Private Sub txtSearchItem_KeyUp(sender As Object, e As KeyEventArgs) Handles txtSearchItem.KeyUp
        ContributionsDataGridView.DataSource = Me.SearchItem
    End Sub

    Private Sub TabControl1_Click(sender As Object, e As EventArgs) Handles TabControl1.Click
        Populate()
    End Sub
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If (CheckBox1.Checked = True) Then
            txtDuesAmount.ReadOnly = False
        Else
            txtDuesAmount.ReadOnly = True
        End If
    End Sub
    Private Sub UpdateDuesAmount()
        Try
            Con.Open()
            Dim query = "update SetValuesTbl set Dues = '" & txtDuesAmount.Text & "',Initial_Dues = '" & DuesAmount & "'"
            cmd = New SqlCommand(query, Con)
            cmd.ExecuteNonQuery()
            MsgBox("Dues 'Amount' updated successfully", MsgBoxStyle.Information)
            txtDuesAmount.ReadOnly = True
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Con.Close()
        End Try
    End Sub
    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        If (Convert.ToDouble(txtDuesAmount.Text) < DuesAmount) Then
            MsgBox("The new 'Dues' amount cannot be less than the old amount", MsgBoxStyle.Exclamation)
        ElseIf (Convert.ToDouble(txtDuesAmount.Text) = DuesAmount) Then
            MsgBox("The new 'Dues' amount should be more than the old amount", MsgBoxStyle.Exclamation)
        Else
            UpdateDuesAmount()
            CheckBox1.Checked = False

            GetGiftAmount()
            txtDuesAmount.Text = DuesAmount
            '  MaskedTextBox1.Text = InitialDues
        End If

    End Sub
End Class