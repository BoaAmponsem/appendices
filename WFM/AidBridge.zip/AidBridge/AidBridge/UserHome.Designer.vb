﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class UserHome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim ChartArea17 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend17 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series17 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea18 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend18 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series18 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.txtYear = New System.Windows.Forms.Label()
        Me.txtTotalContributions = New System.Windows.Forms.Label()
        Me.txtTotalMembers = New System.Windows.Forms.Label()
        Me.txtYear2 = New System.Windows.Forms.Label()
        Me.txtTotalClaims = New System.Windows.Forms.Label()
        Me.txtAccountBalance = New System.Windows.Forms.Label()
        Me.txtTotalWithdrawal = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.IconButton3 = New FontAwesome.Sharp.IconButton()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.dashBoardBtnClaims = New FontAwesome.Sharp.IconButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.btnUserDashboardContributions = New FontAwesome.Sharp.IconButton()
        Me.btnCheck = New FontAwesome.Sharp.IconButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.fromLabel = New System.Windows.Forms.Label()
        Me.FromDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.toLabel = New System.Windows.Forms.Label()
        Me.ToDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.btnYear = New FontAwesome.Sharp.IconButton()
        Me.btnThisMonth = New FontAwesome.Sharp.IconButton()
        Me.btnCustom = New FontAwesome.Sharp.IconButton()
        Me.Chart2 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.IconButton4 = New FontAwesome.Sharp.IconButton()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtYear
        '
        Me.txtYear.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtYear.AutoSize = True
        Me.txtYear.BackColor = System.Drawing.Color.White
        Me.txtYear.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYear.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtYear.Location = New System.Drawing.Point(60, 163)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(25, 19)
        Me.txtYear.TabIndex = 2
        Me.txtYear.Text = "34"
        '
        'txtTotalContributions
        '
        Me.txtTotalContributions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalContributions.AutoSize = True
        Me.txtTotalContributions.BackColor = System.Drawing.Color.White
        Me.txtTotalContributions.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalContributions.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtTotalContributions.Location = New System.Drawing.Point(26, 114)
        Me.txtTotalContributions.Name = "txtTotalContributions"
        Me.txtTotalContributions.Size = New System.Drawing.Size(22, 17)
        Me.txtTotalContributions.TabIndex = 1
        Me.txtTotalContributions.Text = "56"
        '
        'txtTotalMembers
        '
        Me.txtTotalMembers.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalMembers.AutoSize = True
        Me.txtTotalMembers.BackColor = System.Drawing.Color.White
        Me.txtTotalMembers.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalMembers.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtTotalMembers.Location = New System.Drawing.Point(334, 113)
        Me.txtTotalMembers.Name = "txtTotalMembers"
        Me.txtTotalMembers.Size = New System.Drawing.Size(15, 17)
        Me.txtTotalMembers.TabIndex = 1
        Me.txtTotalMembers.Text = "7"
        '
        'txtYear2
        '
        Me.txtYear2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtYear2.AutoSize = True
        Me.txtYear2.BackColor = System.Drawing.Color.White
        Me.txtYear2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYear2.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtYear2.Location = New System.Drawing.Point(717, 163)
        Me.txtYear2.Name = "txtYear2"
        Me.txtYear2.Size = New System.Drawing.Size(25, 19)
        Me.txtYear2.TabIndex = 4
        Me.txtYear2.Text = "56"
        '
        'txtTotalClaims
        '
        Me.txtTotalClaims.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalClaims.AutoSize = True
        Me.txtTotalClaims.BackColor = System.Drawing.Color.White
        Me.txtTotalClaims.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalClaims.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtTotalClaims.Location = New System.Drawing.Point(681, 112)
        Me.txtTotalClaims.Name = "txtTotalClaims"
        Me.txtTotalClaims.Size = New System.Drawing.Size(22, 17)
        Me.txtTotalClaims.TabIndex = 1
        Me.txtTotalClaims.Text = "34"
        '
        'txtAccountBalance
        '
        Me.txtAccountBalance.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAccountBalance.AutoSize = True
        Me.txtAccountBalance.BackColor = System.Drawing.Color.White
        Me.txtAccountBalance.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAccountBalance.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtAccountBalance.Location = New System.Drawing.Point(331, 465)
        Me.txtAccountBalance.Name = "txtAccountBalance"
        Me.txtAccountBalance.Size = New System.Drawing.Size(22, 17)
        Me.txtAccountBalance.TabIndex = 1
        Me.txtAccountBalance.Text = "34"
        '
        'txtTotalWithdrawal
        '
        Me.txtTotalWithdrawal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotalWithdrawal.AutoSize = True
        Me.txtTotalWithdrawal.BackColor = System.Drawing.Color.White
        Me.txtTotalWithdrawal.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalWithdrawal.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtTotalWithdrawal.Location = New System.Drawing.Point(24, 467)
        Me.txtTotalWithdrawal.Name = "txtTotalWithdrawal"
        Me.txtTotalWithdrawal.Size = New System.Drawing.Size(22, 17)
        Me.txtTotalWithdrawal.TabIndex = 1
        Me.txtTotalWithdrawal.Text = "34"
        '
        'Label8
        '
        Me.Label8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label8.Location = New System.Drawing.Point(23, 162)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 19)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Year"
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.White
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label10.Location = New System.Drawing.Point(678, 162)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 19)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = "Year"
        '
        'PictureBox5
        '
        Me.PictureBox5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox5.BackColor = System.Drawing.Color.White
        Me.PictureBox5.Image = Global.AidBridge.My.Resources.Resources._2721122
        Me.PictureBox5.Location = New System.Drawing.Point(484, 425)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(171, 94)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 19
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox4.BackColor = System.Drawing.Color.White
        Me.PictureBox4.Image = Global.AidBridge.My.Resources.Resources._5067067
        Me.PictureBox4.Location = New System.Drawing.Point(160, 423)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(149, 96)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 18
        Me.PictureBox4.TabStop = False
        '
        'IconButton2
        '
        Me.IconButton2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton2.BackColor = System.Drawing.Color.White
        Me.IconButton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.Font = New System.Drawing.Font("Times New Roman", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton2.ForeColor = System.Drawing.Color.DarkGreen
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton2.IconColor = System.Drawing.Color.SeaGreen
        Me.IconButton2.IconSize = 120
        Me.IconButton2.Location = New System.Drawing.Point(323, 404)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(341, 121)
        Me.IconButton2.TabIndex = 0
        Me.IconButton2.Text = "ACCOUNT BALANCE"
        Me.IconButton2.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'IconButton3
        '
        Me.IconButton3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton3.BackColor = System.Drawing.Color.White
        Me.IconButton3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton3.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton3.Font = New System.Drawing.Font("Times New Roman", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton3.ForeColor = System.Drawing.Color.DarkGreen
        Me.IconButton3.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton3.IconColor = System.Drawing.Color.SeaGreen
        Me.IconButton3.IconSize = 120
        Me.IconButton3.Location = New System.Drawing.Point(16, 404)
        Me.IconButton3.Name = "IconButton3"
        Me.IconButton3.Rotation = 0R
        Me.IconButton3.Size = New System.Drawing.Size(301, 121)
        Me.IconButton3.TabIndex = 0
        Me.IconButton3.Text = "WITHDRAWALS"
        Me.IconButton3.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.IconButton3.UseVisualStyleBackColor = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.BackColor = System.Drawing.Color.White
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox3.Image = Global.AidBridge.My.Resources.Resources.images
        Me.PictureBox3.Location = New System.Drawing.Point(803, 46)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(172, 144)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 16
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.BackColor = System.Drawing.Color.White
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.Image = Global.AidBridge.My.Resources.Resources._6543820
        Me.PictureBox2.Location = New System.Drawing.Point(449, 48)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(206, 142)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 15
        Me.PictureBox2.TabStop = False
        '
        'dashBoardBtnClaims
        '
        Me.dashBoardBtnClaims.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dashBoardBtnClaims.BackColor = System.Drawing.Color.White
        Me.dashBoardBtnClaims.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.dashBoardBtnClaims.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.dashBoardBtnClaims.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.dashBoardBtnClaims.Font = New System.Drawing.Font("Times New Roman", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dashBoardBtnClaims.ForeColor = System.Drawing.Color.DarkGreen
        Me.dashBoardBtnClaims.IconChar = FontAwesome.Sharp.IconChar.None
        Me.dashBoardBtnClaims.IconColor = System.Drawing.Color.SeaGreen
        Me.dashBoardBtnClaims.IconSize = 120
        Me.dashBoardBtnClaims.Location = New System.Drawing.Point(670, 40)
        Me.dashBoardBtnClaims.Name = "dashBoardBtnClaims"
        Me.dashBoardBtnClaims.Rotation = 0R
        Me.dashBoardBtnClaims.Size = New System.Drawing.Size(312, 157)
        Me.dashBoardBtnClaims.TabIndex = 0
        Me.dashBoardBtnClaims.Text = "CLAIMS"
        Me.dashBoardBtnClaims.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.dashBoardBtnClaims.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Image = Global.AidBridge.My.Resources.Resources._5520944
        Me.PictureBox1.Location = New System.Drawing.Point(150, 66)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(158, 125)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 13
        Me.PictureBox1.TabStop = False
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton1.BackColor = System.Drawing.Color.White
        Me.IconButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.Font = New System.Drawing.Font("Times New Roman", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton1.ForeColor = System.Drawing.Color.DarkGreen
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton1.IconColor = System.Drawing.Color.White
        Me.IconButton1.IconSize = 120
        Me.IconButton1.Location = New System.Drawing.Point(323, 39)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(341, 159)
        Me.IconButton1.TabIndex = 0
        Me.IconButton1.Text = "MEMBERS"
        Me.IconButton1.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'btnUserDashboardContributions
        '
        Me.btnUserDashboardContributions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUserDashboardContributions.BackColor = System.Drawing.Color.White
        Me.btnUserDashboardContributions.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.btnUserDashboardContributions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.btnUserDashboardContributions.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnUserDashboardContributions.Font = New System.Drawing.Font("Times New Roman", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUserDashboardContributions.ForeColor = System.Drawing.Color.DarkGreen
        Me.btnUserDashboardContributions.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnUserDashboardContributions.IconColor = System.Drawing.Color.White
        Me.btnUserDashboardContributions.IconSize = 120
        Me.btnUserDashboardContributions.Location = New System.Drawing.Point(16, 40)
        Me.btnUserDashboardContributions.Name = "btnUserDashboardContributions"
        Me.btnUserDashboardContributions.Rotation = 0R
        Me.btnUserDashboardContributions.Size = New System.Drawing.Size(301, 158)
        Me.btnUserDashboardContributions.TabIndex = 0
        Me.btnUserDashboardContributions.Text = "CONTRIBUTIONS"
        Me.btnUserDashboardContributions.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnUserDashboardContributions.UseVisualStyleBackColor = False
        '
        'btnCheck
        '
        Me.btnCheck.BackColor = System.Drawing.Color.DarkSlateGray
        Me.btnCheck.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(81, Byte), Integer))
        Me.btnCheck.FlatAppearance.BorderSize = 2
        Me.btnCheck.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.btnCheck.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleGoldenrod
        Me.btnCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCheck.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnCheck.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheck.ForeColor = System.Drawing.Color.Gray
        Me.btnCheck.IconChar = FontAwesome.Sharp.IconChar.Check
        Me.btnCheck.IconColor = System.Drawing.Color.White
        Me.btnCheck.IconSize = 24
        Me.btnCheck.Location = New System.Drawing.Point(248, 6)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Rotation = 0R
        Me.btnCheck.Size = New System.Drawing.Size(33, 28)
        Me.btnCheck.TabIndex = 65
        Me.btnCheck.UseVisualStyleBackColor = False
        Me.btnCheck.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label3.Location = New System.Drawing.Point(116, 10)
        Me.Label3.MinimumSize = New System.Drawing.Size(15, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(15, 20)
        Me.Label3.TabIndex = 64
        Me.Label3.Text = "-"
        '
        'fromLabel
        '
        Me.fromLabel.AutoSize = True
        Me.fromLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.fromLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.fromLabel.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fromLabel.ForeColor = System.Drawing.Color.Gray
        Me.fromLabel.Location = New System.Drawing.Point(15, 9)
        Me.fromLabel.MaximumSize = New System.Drawing.Size(95, 20)
        Me.fromLabel.MinimumSize = New System.Drawing.Size(95, 20)
        Me.fromLabel.Name = "fromLabel"
        Me.fromLabel.Size = New System.Drawing.Size(95, 20)
        Me.fromLabel.TabIndex = 63
        Me.fromLabel.Text = "1/25/2024"
        Me.fromLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FromDateTimePicker
        '
        Me.FromDateTimePicker.CalendarForeColor = System.Drawing.Color.DarkGreen
        Me.FromDateTimePicker.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke
        Me.FromDateTimePicker.CalendarTitleBackColor = System.Drawing.Color.WhiteSmoke
        Me.FromDateTimePicker.CalendarTitleForeColor = System.Drawing.Color.DarkGreen
        Me.FromDateTimePicker.Checked = False
        Me.FromDateTimePicker.CustomFormat = "yyyy-MM-dd"
        Me.FromDateTimePicker.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FromDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.FromDateTimePicker.Location = New System.Drawing.Point(16, 9)
        Me.FromDateTimePicker.Name = "FromDateTimePicker"
        Me.FromDateTimePicker.Size = New System.Drawing.Size(95, 21)
        Me.FromDateTimePicker.TabIndex = 62
        '
        'toLabel
        '
        Me.toLabel.AutoSize = True
        Me.toLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.toLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.toLabel.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.toLabel.ForeColor = System.Drawing.Color.Gray
        Me.toLabel.Location = New System.Drawing.Point(136, 10)
        Me.toLabel.MaximumSize = New System.Drawing.Size(95, 20)
        Me.toLabel.MinimumSize = New System.Drawing.Size(95, 20)
        Me.toLabel.Name = "toLabel"
        Me.toLabel.Size = New System.Drawing.Size(95, 20)
        Me.toLabel.TabIndex = 61
        Me.toLabel.Text = "1/25/2024"
        Me.toLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ToDateTimePicker
        '
        Me.ToDateTimePicker.CalendarForeColor = System.Drawing.Color.DarkGreen
        Me.ToDateTimePicker.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke
        Me.ToDateTimePicker.CalendarTitleBackColor = System.Drawing.Color.WhiteSmoke
        Me.ToDateTimePicker.CalendarTitleForeColor = System.Drawing.Color.DarkGreen
        Me.ToDateTimePicker.Checked = False
        Me.ToDateTimePicker.CustomFormat = "yyyy-MM-dd"
        Me.ToDateTimePicker.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.ToDateTimePicker.Location = New System.Drawing.Point(136, 10)
        Me.ToDateTimePicker.Name = "ToDateTimePicker"
        Me.ToDateTimePicker.Size = New System.Drawing.Size(95, 21)
        Me.ToDateTimePicker.TabIndex = 60
        '
        'btnYear
        '
        Me.btnYear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(81, Byte), Integer))
        Me.btnYear.FlatAppearance.BorderSize = 2
        Me.btnYear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.btnYear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleGoldenrod
        Me.btnYear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnYear.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnYear.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnYear.ForeColor = System.Drawing.Color.Gray
        Me.btnYear.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnYear.IconColor = System.Drawing.Color.SeaGreen
        Me.btnYear.IconSize = 29
        Me.btnYear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnYear.Location = New System.Drawing.Point(495, 6)
        Me.btnYear.Name = "btnYear"
        Me.btnYear.Rotation = 0R
        Me.btnYear.Size = New System.Drawing.Size(110, 28)
        Me.btnYear.TabIndex = 59
        Me.btnYear.Text = "This Year"
        Me.btnYear.UseVisualStyleBackColor = True
        '
        'btnThisMonth
        '
        Me.btnThisMonth.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(81, Byte), Integer))
        Me.btnThisMonth.FlatAppearance.BorderSize = 2
        Me.btnThisMonth.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.btnThisMonth.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleGoldenrod
        Me.btnThisMonth.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnThisMonth.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnThisMonth.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnThisMonth.ForeColor = System.Drawing.Color.Gray
        Me.btnThisMonth.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnThisMonth.IconColor = System.Drawing.Color.SeaGreen
        Me.btnThisMonth.IconSize = 29
        Me.btnThisMonth.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnThisMonth.Location = New System.Drawing.Point(387, 6)
        Me.btnThisMonth.Name = "btnThisMonth"
        Me.btnThisMonth.Rotation = 0R
        Me.btnThisMonth.Size = New System.Drawing.Size(110, 28)
        Me.btnThisMonth.TabIndex = 58
        Me.btnThisMonth.Text = "This month"
        Me.btnThisMonth.UseVisualStyleBackColor = True
        '
        'btnCustom
        '
        Me.btnCustom.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(81, Byte), Integer))
        Me.btnCustom.FlatAppearance.BorderSize = 2
        Me.btnCustom.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.btnCustom.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleGoldenrod
        Me.btnCustom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCustom.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnCustom.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCustom.ForeColor = System.Drawing.Color.Gray
        Me.btnCustom.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnCustom.IconColor = System.Drawing.Color.SeaGreen
        Me.btnCustom.IconSize = 29
        Me.btnCustom.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCustom.Location = New System.Drawing.Point(279, 6)
        Me.btnCustom.Name = "btnCustom"
        Me.btnCustom.Rotation = 0R
        Me.btnCustom.Size = New System.Drawing.Size(110, 28)
        Me.btnCustom.TabIndex = 57
        Me.btnCustom.Text = "Custom"
        Me.btnCustom.UseVisualStyleBackColor = True
        '
        'Chart2
        '
        Me.Chart2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        ChartArea17.Name = "ChartArea1"
        Me.Chart2.ChartAreas.Add(ChartArea17)
        Legend17.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top
        Legend17.Name = "Legend1"
        Legend17.Title = "TURNOUTS"
        Legend17.TitleAlignment = System.Drawing.StringAlignment.Near
        Legend17.TitleFont = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend17.TitleForeColor = System.Drawing.Color.DarkGreen
        Me.Chart2.Legends.Add(Legend17)
        Me.Chart2.Location = New System.Drawing.Point(670, 204)
        Me.Chart2.Name = "Chart2"
        Me.Chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Series17.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom
        Series17.BackSecondaryColor = System.Drawing.Color.DarkGreen
        Series17.BorderColor = System.Drawing.Color.White
        Series17.BorderWidth = 10
        Series17.ChartArea = "ChartArea1"
        Series17.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut
        Series17.Color = System.Drawing.Color.Transparent
        Series17.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Series17.IsValueShownAsLabel = True
        Series17.LabelForeColor = System.Drawing.Color.White
        Series17.Legend = "Legend1"
        Series17.Name = "Series1"
        Series17.ShadowColor = System.Drawing.Color.White
        Me.Chart2.Series.Add(Series17)
        Me.Chart2.Size = New System.Drawing.Size(312, 321)
        Me.Chart2.TabIndex = 56
        Me.Chart2.Text = "Chart2"
        '
        'Chart1
        '
        Me.Chart1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        ChartArea18.AxisX.IsLabelAutoFit = False
        ChartArea18.AxisX.IsMarginVisible = False
        ChartArea18.AxisX.LabelStyle.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ChartArea18.AxisX.LabelStyle.ForeColor = System.Drawing.Color.DarkSlateGray
        ChartArea18.AxisX.LineColor = System.Drawing.Color.Maroon
        ChartArea18.AxisX.LineWidth = 0
        ChartArea18.AxisX.MajorGrid.LineColor = System.Drawing.Color.White
        ChartArea18.AxisX.MajorGrid.LineWidth = 0
        ChartArea18.AxisX.MajorTickMark.LineColor = System.Drawing.Color.DarkSlateGray
        ChartArea18.AxisX.MajorTickMark.LineWidth = 2
        ChartArea18.AxisX.MajorTickMark.Size = 3.0!
        ChartArea18.AxisY.IsLabelAutoFit = False
        ChartArea18.AxisY.LabelStyle.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ChartArea18.AxisY.LabelStyle.ForeColor = System.Drawing.Color.DarkSlateGray
        ChartArea18.AxisY.LabelStyle.Format = "Ghc(0.0.)"
        ChartArea18.AxisY.MajorGrid.LineColor = System.Drawing.Color.DarkSlateGray
        ChartArea18.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDotDot
        ChartArea18.AxisY.MajorTickMark.LineColor = System.Drawing.Color.DarkSlateGray
        ChartArea18.AxisY.MajorTickMark.LineWidth = 2
        ChartArea18.BackColor = System.Drawing.Color.White
        ChartArea18.BackSecondaryColor = System.Drawing.Color.White
        ChartArea18.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea18)
        Legend18.Name = "Legend1"
        Legend18.Title = "TRANSACTIONS"
        Legend18.TitleFont = New System.Drawing.Font("Times", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Legend18.TitleForeColor = System.Drawing.Color.DarkGreen
        Me.Chart1.Legends.Add(Legend18)
        Me.Chart1.Location = New System.Drawing.Point(15, 204)
        Me.Chart1.Name = "Chart1"
        Series18.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.LeftRight
        Series18.BackSecondaryColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Series18.BorderColor = System.Drawing.Color.Purple
        Series18.BorderWidth = 2
        Series18.ChartArea = "ChartArea1"
        Series18.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.SplineArea
        Series18.Color = System.Drawing.Color.SeaGreen
        Series18.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Series18.IsValueShownAsLabel = True
        Series18.Legend = "Legend1"
        Series18.MarkerColor = System.Drawing.Color.DarkSlateGray
        Series18.MarkerSize = 4
        Series18.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle
        Series18.Name = "Series1"
        Me.Chart1.Series.Add(Series18)
        Me.Chart1.Size = New System.Drawing.Size(649, 194)
        Me.Chart1.TabIndex = 55
        Me.Chart1.Text = "Chart1"
        '
        'IconButton4
        '
        Me.IconButton4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(81, Byte), Integer))
        Me.IconButton4.FlatAppearance.BorderSize = 2
        Me.IconButton4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(36, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.IconButton4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleGoldenrod
        Me.IconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton4.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton4.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton4.ForeColor = System.Drawing.Color.Gray
        Me.IconButton4.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton4.IconColor = System.Drawing.Color.SeaGreen
        Me.IconButton4.IconSize = 29
        Me.IconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton4.Location = New System.Drawing.Point(603, 6)
        Me.IconButton4.Name = "IconButton4"
        Me.IconButton4.Rotation = 0R
        Me.IconButton4.Size = New System.Drawing.Size(110, 28)
        Me.IconButton4.TabIndex = 66
        Me.IconButton4.Text = "Default"
        Me.IconButton4.UseVisualStyleBackColor = True
        '
        'UserHome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(996, 531)
        Me.Controls.Add(Me.IconButton4)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.fromLabel)
        Me.Controls.Add(Me.FromDateTimePicker)
        Me.Controls.Add(Me.toLabel)
        Me.Controls.Add(Me.ToDateTimePicker)
        Me.Controls.Add(Me.btnYear)
        Me.Controls.Add(Me.btnThisMonth)
        Me.Controls.Add(Me.btnCustom)
        Me.Controls.Add(Me.Chart2)
        Me.Controls.Add(Me.Chart1)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.txtAccountBalance)
        Me.Controls.Add(Me.txtTotalWithdrawal)
        Me.Controls.Add(Me.IconButton2)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.IconButton3)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.txtYear2)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.txtTotalClaims)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.dashBoardBtnClaims)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtTotalMembers)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.IconButton1)
        Me.Controls.Add(Me.txtTotalContributions)
        Me.Controls.Add(Me.btnUserDashboardContributions)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "UserHome"
        Me.Text = "UserHome"
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtTotalContributions As Label
    Friend WithEvents btnUserDashboardContributions As FontAwesome.Sharp.IconButton
    Friend WithEvents txtTotalMembers As Label
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtTotalClaims As Label
    Friend WithEvents dashBoardBtnClaims As FontAwesome.Sharp.IconButton
    Friend WithEvents txtYear As Label
    Friend WithEvents txtYear2 As Label
    Friend WithEvents txtAccountBalance As Label
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtTotalWithdrawal As Label
    Friend WithEvents IconButton3 As FontAwesome.Sharp.IconButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label10 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents btnCheck As FontAwesome.Sharp.IconButton
    Friend WithEvents Label3 As Label
    Friend WithEvents fromLabel As Label
    Friend WithEvents FromDateTimePicker As DateTimePicker
    Friend WithEvents toLabel As Label
    Friend WithEvents ToDateTimePicker As DateTimePicker
    Friend WithEvents btnYear As FontAwesome.Sharp.IconButton
    Friend WithEvents btnThisMonth As FontAwesome.Sharp.IconButton
    Friend WithEvents btnCustom As FontAwesome.Sharp.IconButton
    Friend WithEvents Chart2 As DataVisualization.Charting.Chart
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
    Friend WithEvents IconButton4 As FontAwesome.Sharp.IconButton
End Class
