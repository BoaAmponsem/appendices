﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserMembersPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.LeftClickOptionsForMembersPageDAtaGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.DeleteMemberToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtMemberIDBox = New System.Windows.Forms.TextBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.membersDataGridView = New System.Windows.Forms.DataGridView()
        Me.IconButton3 = New FontAwesome.Sharp.IconButton()
        Me.IconButton1 = New FontAwesome.Sharp.IconButton()
        Me.txtSearchItem = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txtResponseMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.btnWishAll = New FontAwesome.Sharp.IconButton()
        Me.birthdaysDataGridView = New System.Windows.Forms.DataGridView()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LeftClickOptionsForMembersPageDAtaGrid.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.membersDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.birthdaysDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LeftClickOptionsForMembersPageDAtaGrid
        '
        Me.LeftClickOptionsForMembersPageDAtaGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteMemberToolStripMenuItem, Me.EditToolStripMenuItem})
        Me.LeftClickOptionsForMembersPageDAtaGrid.Name = "LeftClickOptionsForMembersPageDAtaGrid"
        Me.LeftClickOptionsForMembersPageDAtaGrid.Size = New System.Drawing.Size(108, 48)
        '
        'DeleteMemberToolStripMenuItem
        '
        Me.DeleteMemberToolStripMenuItem.Name = "DeleteMemberToolStripMenuItem"
        Me.DeleteMemberToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.DeleteMemberToolStripMenuItem.Text = "Delete"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'txtMemberIDBox
        '
        Me.txtMemberIDBox.Location = New System.Drawing.Point(589, -3)
        Me.txtMemberIDBox.Name = "txtMemberIDBox"
        Me.txtMemberIDBox.Size = New System.Drawing.Size(100, 20)
        Me.txtMemberIDBox.TabIndex = 19
        Me.txtMemberIDBox.Visible = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(657, 465)
        Me.TabControl1.TabIndex = 20
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.LinkLabel1)
        Me.TabPage1.Controls.Add(Me.IconButton2)
        Me.TabPage1.Controls.Add(Me.membersDataGridView)
        Me.TabPage1.Controls.Add(Me.IconButton3)
        Me.TabPage1.Controls.Add(Me.IconButton1)
        Me.TabPage1.Controls.Add(Me.txtSearchItem)
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(649, 437)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Members"
        '
        'IconButton2
        '
        Me.IconButton2.BackColor = System.Drawing.Color.SeaGreen
        Me.IconButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IconButton2.ForeColor = System.Drawing.Color.White
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.UserPlus
        Me.IconButton2.IconColor = System.Drawing.Color.White
        Me.IconButton2.IconSize = 20
        Me.IconButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.IconButton2.Location = New System.Drawing.Point(7, 61)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(100, 35)
        Me.IconButton2.TabIndex = 22
        Me.IconButton2.Text = "Add Member"
        Me.IconButton2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'membersDataGridView
        '
        Me.membersDataGridView.AllowUserToAddRows = False
        Me.membersDataGridView.AllowUserToDeleteRows = False
        Me.membersDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.membersDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.membersDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.membersDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.membersDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.membersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.membersDataGridView.DefaultCellStyle = DataGridViewCellStyle3
        Me.membersDataGridView.Location = New System.Drawing.Point(0, 99)
        Me.membersDataGridView.MultiSelect = False
        Me.membersDataGridView.Name = "membersDataGridView"
        Me.membersDataGridView.ReadOnly = True
        Me.membersDataGridView.RowHeadersVisible = False
        Me.membersDataGridView.RowTemplate.Height = 32
        Me.membersDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.membersDataGridView.Size = New System.Drawing.Size(647, 340)
        Me.membersDataGridView.TabIndex = 21
        '
        'IconButton3
        '
        Me.IconButton3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.IconButton3.BackColor = System.Drawing.Color.White
        Me.IconButton3.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke
        Me.IconButton3.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton3.IconChar = FontAwesome.Sharp.IconChar.None
        Me.IconButton3.IconColor = System.Drawing.Color.Black
        Me.IconButton3.IconSize = 16
        Me.IconButton3.Location = New System.Drawing.Point(-1, 56)
        Me.IconButton3.Name = "IconButton3"
        Me.IconButton3.Rotation = 0R
        Me.IconButton3.Size = New System.Drawing.Size(650, 44)
        Me.IconButton3.TabIndex = 20
        Me.IconButton3.UseVisualStyleBackColor = False
        '
        'IconButton1
        '
        Me.IconButton1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton1.BackColor = System.Drawing.Color.SeaGreen
        Me.IconButton1.FlatAppearance.BorderSize = 0
        Me.IconButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen
        Me.IconButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.ForestGreen
        Me.IconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton1.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton1.IconChar = FontAwesome.Sharp.IconChar.Search
        Me.IconButton1.IconColor = System.Drawing.Color.White
        Me.IconButton1.IconSize = 19
        Me.IconButton1.Location = New System.Drawing.Point(172, 11)
        Me.IconButton1.Name = "IconButton1"
        Me.IconButton1.Rotation = 0R
        Me.IconButton1.Size = New System.Drawing.Size(41, 27)
        Me.IconButton1.TabIndex = 19
        Me.IconButton1.UseVisualStyleBackColor = False
        '
        'txtSearchItem
        '
        Me.txtSearchItem.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtSearchItem.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchItem.Location = New System.Drawing.Point(212, 11)
        Me.txtSearchItem.Multiline = True
        Me.txtSearchItem.Name = "txtSearchItem"
        Me.txtSearchItem.Size = New System.Drawing.Size(311, 27)
        Me.txtSearchItem.TabIndex = 18
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.txtResponseMaskedTextBox)
        Me.TabPage2.Controls.Add(Me.btnWishAll)
        Me.TabPage2.Controls.Add(Me.birthdaysDataGridView)
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(649, 437)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Birthdays"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txtResponseMaskedTextBox
        '
        Me.txtResponseMaskedTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtResponseMaskedTextBox.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtResponseMaskedTextBox.Location = New System.Drawing.Point(639, 4)
        Me.txtResponseMaskedTextBox.Name = "txtResponseMaskedTextBox"
        Me.txtResponseMaskedTextBox.Size = New System.Drawing.Size(205, 21)
        Me.txtResponseMaskedTextBox.TabIndex = 88
        Me.txtResponseMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtResponseMaskedTextBox.Visible = False
        '
        'btnWishAll
        '
        Me.btnWishAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnWishAll.BackColor = System.Drawing.Color.ForestGreen
        Me.btnWishAll.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnWishAll.FlatAppearance.BorderSize = 0
        Me.btnWishAll.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnWishAll.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWishAll.ForeColor = System.Drawing.Color.White
        Me.btnWishAll.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnWishAll.IconColor = System.Drawing.Color.Black
        Me.btnWishAll.IconSize = 16
        Me.btnWishAll.Location = New System.Drawing.Point(552, 6)
        Me.btnWishAll.Name = "btnWishAll"
        Me.btnWishAll.Rotation = 0R
        Me.btnWishAll.Size = New System.Drawing.Size(84, 29)
        Me.btnWishAll.TabIndex = 87
        Me.btnWishAll.Text = "Wish all"
        Me.btnWishAll.UseVisualStyleBackColor = False
        '
        'birthdaysDataGridView
        '
        Me.birthdaysDataGridView.AllowUserToAddRows = False
        Me.birthdaysDataGridView.AllowUserToDeleteRows = False
        Me.birthdaysDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.birthdaysDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.birthdaysDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.birthdaysDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.birthdaysDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.birthdaysDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.birthdaysDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.birthdaysDataGridView.DefaultCellStyle = DataGridViewCellStyle4
        Me.birthdaysDataGridView.Location = New System.Drawing.Point(4, 43)
        Me.birthdaysDataGridView.MultiSelect = False
        Me.birthdaysDataGridView.Name = "birthdaysDataGridView"
        Me.birthdaysDataGridView.ReadOnly = True
        Me.birthdaysDataGridView.RowHeadersVisible = False
        Me.birthdaysDataGridView.RowTemplate.Height = 32
        Me.birthdaysDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.birthdaysDataGridView.Size = New System.Drawing.Size(641, 387)
        Me.birthdaysDataGridView.TabIndex = 86
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.SeaGreen
        Me.LinkLabel1.Location = New System.Drawing.Point(112, 74)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(77, 15)
        Me.LinkLabel1.TabIndex = 23
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Print members"
        '
        'UserMembersPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(657, 465)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.txtMemberIDBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "UserMembersPage"
        Me.Text = "UserMembersPage"
        Me.LeftClickOptionsForMembersPageDAtaGrid.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.membersDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.birthdaysDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LeftClickOptionsForMembersPageDAtaGrid As ContextMenuStrip
    Friend WithEvents DeleteMemberToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents txtMemberIDBox As TextBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents membersDataGridView As DataGridView
    Friend WithEvents IconButton3 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconButton1 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtSearchItem As TextBox
    Friend WithEvents btnWishAll As FontAwesome.Sharp.IconButton
    Friend WithEvents birthdaysDataGridView As DataGridView
    Friend WithEvents txtResponseMaskedTextBox As MaskedTextBox
    Friend WithEvents LinkLabel1 As LinkLabel
End Class
