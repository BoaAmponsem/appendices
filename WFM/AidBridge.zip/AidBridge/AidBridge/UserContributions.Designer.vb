﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class UserContributions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UserContributions))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.ContributionsDataGridView = New System.Windows.Forms.DataGridView()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.txtSearchItem = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.memberNotFoundFeedback = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.memberNoFTxt = New System.Windows.Forms.Label()
        Me.InformationTab = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtStaffID = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtPostalAddress = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtHouseNo = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtMarriageType = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtMaritalStatus = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtHomeTown = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtSex = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBirthDate = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtMemberOtherName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.makePaymentGroupBox = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtPaidIBy = New System.Windows.Forms.MaskedTextBox()
        Me.txtMonthOfPayment1 = New System.Windows.Forms.DateTimePicker()
        Me.payBtn = New FontAwesome.Sharp.IconButton()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtMonthOfPayment = New System.Windows.Forms.MaskedTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtAmount = New System.Windows.Forms.MaskedTextBox()
        Me.ContributionsGroupBox = New System.Windows.Forms.GroupBox()
        Me.memberContributionsDataGridView = New System.Windows.Forms.DataGridView()
        Me.selectIDType = New System.Windows.Forms.ComboBox()
        Me.searchBox = New System.Windows.Forms.TextBox()
        Me.QueryBtn = New FontAwesome.Sharp.IconButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.addDepositBtn = New FontAwesome.Sharp.IconButton()
        Me.depositDataGridView = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtWithdrawalPurpose = New System.Windows.Forms.ComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtTrasactionType = New System.Windows.Forms.ComboBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtBank = New System.Windows.Forms.ComboBox()
        Me.txtDepositedAmount = New System.Windows.Forms.MaskedTextBox()
        Me.txtTeller = New System.Windows.Forms.TextBox()
        Me.txtReferenceNO = New System.Windows.Forms.TextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.contributionReportViewer = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtStatementType = New System.Windows.Forms.ComboBox()
        Me.btnQueryContributionStatement = New FontAwesome.Sharp.IconButton()
        Me.txtSearchType = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.toDateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.fromDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.txtMemID = New System.Windows.Forms.TextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.txtResponseMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.btnAlertAll = New FontAwesome.Sharp.IconButton()
        Me.debtorsDataGridView = New System.Windows.Forms.DataGridView()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.ContributionsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.memberNotFoundFeedback.SuspendLayout()
        Me.InformationTab.SuspendLayout()
        Me.makePaymentGroupBox.SuspendLayout()
        Me.ContributionsGroupBox.SuspendLayout()
        CType(Me.memberContributionsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.depositDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.debtorsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(925, 467)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.ContributionsDataGridView)
        Me.TabPage1.Controls.Add(Me.IconButton2)
        Me.TabPage1.Controls.Add(Me.txtSearchItem)
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(917, 439)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Contributions"
        '
        'ContributionsDataGridView
        '
        Me.ContributionsDataGridView.AllowUserToAddRows = False
        Me.ContributionsDataGridView.AllowUserToDeleteRows = False
        Me.ContributionsDataGridView.AllowUserToResizeColumns = False
        Me.ContributionsDataGridView.AllowUserToResizeRows = False
        Me.ContributionsDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ContributionsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.ContributionsDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.ContributionsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ContributionsDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.ContributionsDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.ContributionsDataGridView.ColumnHeadersHeight = 25
        Me.ContributionsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ContributionsDataGridView.DefaultCellStyle = DataGridViewCellStyle1
        Me.ContributionsDataGridView.Location = New System.Drawing.Point(5, 80)
        Me.ContributionsDataGridView.Name = "ContributionsDataGridView"
        Me.ContributionsDataGridView.ReadOnly = True
        Me.ContributionsDataGridView.RowHeadersVisible = False
        Me.ContributionsDataGridView.RowTemplate.Height = 32
        Me.ContributionsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ContributionsDataGridView.Size = New System.Drawing.Size(906, 356)
        Me.ContributionsDataGridView.TabIndex = 7
        '
        'IconButton2
        '
        Me.IconButton2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.IconButton2.BackColor = System.Drawing.Color.SeaGreen
        Me.IconButton2.FlatAppearance.BorderSize = 0
        Me.IconButton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen
        Me.IconButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.ForestGreen
        Me.IconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.IconButton2.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.Search
        Me.IconButton2.IconColor = System.Drawing.Color.White
        Me.IconButton2.IconSize = 19
        Me.IconButton2.Location = New System.Drawing.Point(292, 11)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Rotation = 0R
        Me.IconButton2.Size = New System.Drawing.Size(41, 28)
        Me.IconButton2.TabIndex = 6
        Me.IconButton2.UseVisualStyleBackColor = False
        '
        'txtSearchItem
        '
        Me.txtSearchItem.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtSearchItem.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchItem.Location = New System.Drawing.Point(332, 11)
        Me.txtSearchItem.Multiline = True
        Me.txtSearchItem.Name = "txtSearchItem"
        Me.txtSearchItem.Size = New System.Drawing.Size(311, 28)
        Me.txtSearchItem.TabIndex = 5
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage2.Controls.Add(Me.memberNotFoundFeedback)
        Me.TabPage2.Controls.Add(Me.InformationTab)
        Me.TabPage2.Controls.Add(Me.makePaymentGroupBox)
        Me.TabPage2.Controls.Add(Me.ContributionsGroupBox)
        Me.TabPage2.Controls.Add(Me.selectIDType)
        Me.TabPage2.Controls.Add(Me.searchBox)
        Me.TabPage2.Controls.Add(Me.QueryBtn)
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(917, 439)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Add Contribution"
        '
        'memberNotFoundFeedback
        '
        Me.memberNotFoundFeedback.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.memberNotFoundFeedback.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.memberNotFoundFeedback.Controls.Add(Me.Label14)
        Me.memberNotFoundFeedback.Controls.Add(Me.memberNoFTxt)
        Me.memberNotFoundFeedback.Location = New System.Drawing.Point(738, 3)
        Me.memberNotFoundFeedback.Name = "memberNotFoundFeedback"
        Me.memberNotFoundFeedback.Size = New System.Drawing.Size(136, 40)
        Me.memberNotFoundFeedback.TabIndex = 22
        Me.memberNotFoundFeedback.Visible = False
        '
        'Label14
        '
        Me.Label14.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(123, -2)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(12, 15)
        Me.Label14.TabIndex = 22
        Me.Label14.Text = "x"
        '
        'memberNoFTxt
        '
        Me.memberNoFTxt.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.memberNoFTxt.AutoSize = True
        Me.memberNoFTxt.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.memberNoFTxt.ForeColor = System.Drawing.Color.White
        Me.memberNoFTxt.Location = New System.Drawing.Point(8, 11)
        Me.memberNoFTxt.Name = "memberNoFTxt"
        Me.memberNoFTxt.Size = New System.Drawing.Size(120, 20)
        Me.memberNoFTxt.TabIndex = 6
        Me.memberNoFTxt.Text = "Member not found"
        '
        'InformationTab
        '
        Me.InformationTab.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.InformationTab.BackColor = System.Drawing.Color.White
        Me.InformationTab.Controls.Add(Me.Label9)
        Me.InformationTab.Controls.Add(Me.txtStaffID)
        Me.InformationTab.Controls.Add(Me.Label11)
        Me.InformationTab.Controls.Add(Me.txtPhone)
        Me.InformationTab.Controls.Add(Me.Label12)
        Me.InformationTab.Controls.Add(Me.txtPostalAddress)
        Me.InformationTab.Controls.Add(Me.Label5)
        Me.InformationTab.Controls.Add(Me.txtHouseNo)
        Me.InformationTab.Controls.Add(Me.Label6)
        Me.InformationTab.Controls.Add(Me.txtMarriageType)
        Me.InformationTab.Controls.Add(Me.Label7)
        Me.InformationTab.Controls.Add(Me.txtMaritalStatus)
        Me.InformationTab.Controls.Add(Me.Label8)
        Me.InformationTab.Controls.Add(Me.txtHomeTown)
        Me.InformationTab.Controls.Add(Me.Label4)
        Me.InformationTab.Controls.Add(Me.txtSex)
        Me.InformationTab.Controls.Add(Me.Label3)
        Me.InformationTab.Controls.Add(Me.txtBirthDate)
        Me.InformationTab.Controls.Add(Me.Label2)
        Me.InformationTab.Controls.Add(Me.txtMemberOtherName)
        Me.InformationTab.Controls.Add(Me.Label1)
        Me.InformationTab.Controls.Add(Me.txtSurname)
        Me.InformationTab.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InformationTab.Location = New System.Drawing.Point(9, 61)
        Me.InformationTab.Name = "InformationTab"
        Me.InformationTab.Size = New System.Drawing.Size(900, 193)
        Me.InformationTab.TabIndex = 21
        Me.InformationTab.TabStop = False
        Me.InformationTab.Text = "Information"
        Me.InformationTab.Visible = False
        '
        'Label9
        '
        Me.Label9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(530, 134)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 15)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Staff ID:"
        '
        'txtStaffID
        '
        Me.txtStaffID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtStaffID.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStaffID.Location = New System.Drawing.Point(530, 153)
        Me.txtStaffID.Multiline = True
        Me.txtStaffID.Name = "txtStaffID"
        Me.txtStaffID.ReadOnly = True
        Me.txtStaffID.Size = New System.Drawing.Size(146, 27)
        Me.txtStaffID.TabIndex = 20
        '
        'Label11
        '
        Me.Label11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(284, 134)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 15)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Phone No.:"
        '
        'txtPhone
        '
        Me.txtPhone.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPhone.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhone.Location = New System.Drawing.Point(284, 153)
        Me.txtPhone.Multiline = True
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.ReadOnly = True
        Me.txtPhone.Size = New System.Drawing.Size(188, 27)
        Me.txtPhone.TabIndex = 18
        '
        'Label12
        '
        Me.Label12.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(8, 134)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 15)
        Me.Label12.TabIndex = 17
        Me.Label12.Text = "Postal Address:"
        '
        'txtPostalAddress
        '
        Me.txtPostalAddress.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPostalAddress.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPostalAddress.Location = New System.Drawing.Point(8, 153)
        Me.txtPostalAddress.Multiline = True
        Me.txtPostalAddress.Name = "txtPostalAddress"
        Me.txtPostalAddress.ReadOnly = True
        Me.txtPostalAddress.Size = New System.Drawing.Size(242, 27)
        Me.txtPostalAddress.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(723, 82)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 15)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "House No.:"
        '
        'txtHouseNo
        '
        Me.txtHouseNo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtHouseNo.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHouseNo.Location = New System.Drawing.Point(723, 101)
        Me.txtHouseNo.Multiline = True
        Me.txtHouseNo.Name = "txtHouseNo"
        Me.txtHouseNo.ReadOnly = True
        Me.txtHouseNo.Size = New System.Drawing.Size(152, 27)
        Me.txtHouseNo.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(530, 82)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(95, 15)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Type of Marriage:"
        '
        'txtMarriageType
        '
        Me.txtMarriageType.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMarriageType.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMarriageType.Location = New System.Drawing.Point(530, 101)
        Me.txtMarriageType.Multiline = True
        Me.txtMarriageType.Name = "txtMarriageType"
        Me.txtMarriageType.ReadOnly = True
        Me.txtMarriageType.Size = New System.Drawing.Size(146, 27)
        Me.txtMarriageType.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(281, 82)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 15)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Marital Status:"
        '
        'txtMaritalStatus
        '
        Me.txtMaritalStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMaritalStatus.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMaritalStatus.Location = New System.Drawing.Point(281, 101)
        Me.txtMaritalStatus.Multiline = True
        Me.txtMaritalStatus.Name = "txtMaritalStatus"
        Me.txtMaritalStatus.ReadOnly = True
        Me.txtMaritalStatus.Size = New System.Drawing.Size(188, 27)
        Me.txtMaritalStatus.TabIndex = 10
        '
        'Label8
        '
        Me.Label8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(8, 82)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 15)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Hometown:"
        '
        'txtHomeTown
        '
        Me.txtHomeTown.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtHomeTown.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHomeTown.Location = New System.Drawing.Point(8, 101)
        Me.txtHomeTown.Multiline = True
        Me.txtHomeTown.Name = "txtHomeTown"
        Me.txtHomeTown.ReadOnly = True
        Me.txtHomeTown.Size = New System.Drawing.Size(242, 27)
        Me.txtHomeTown.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(723, 29)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(26, 15)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Sex:"
        '
        'txtSex
        '
        Me.txtSex.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSex.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSex.Location = New System.Drawing.Point(723, 48)
        Me.txtSex.Multiline = True
        Me.txtSex.Name = "txtSex"
        Me.txtSex.ReadOnly = True
        Me.txtSex.Size = New System.Drawing.Size(152, 27)
        Me.txtSex.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(530, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Date of Birth:"
        '
        'txtBirthDate
        '
        Me.txtBirthDate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBirthDate.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBirthDate.Location = New System.Drawing.Point(530, 48)
        Me.txtBirthDate.Multiline = True
        Me.txtBirthDate.Name = "txtBirthDate"
        Me.txtBirthDate.ReadOnly = True
        Me.txtBirthDate.Size = New System.Drawing.Size(146, 27)
        Me.txtBirthDate.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(281, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Other Names:"
        '
        'txtMemberOtherName
        '
        Me.txtMemberOtherName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMemberOtherName.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMemberOtherName.Location = New System.Drawing.Point(281, 48)
        Me.txtMemberOtherName.Multiline = True
        Me.txtMemberOtherName.Name = "txtMemberOtherName"
        Me.txtMemberOtherName.ReadOnly = True
        Me.txtMemberOtherName.Size = New System.Drawing.Size(188, 27)
        Me.txtMemberOtherName.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Surname:"
        '
        'txtSurname
        '
        Me.txtSurname.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSurname.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSurname.Location = New System.Drawing.Point(8, 48)
        Me.txtSurname.Multiline = True
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.ReadOnly = True
        Me.txtSurname.Size = New System.Drawing.Size(242, 27)
        Me.txtSurname.TabIndex = 0
        '
        'makePaymentGroupBox
        '
        Me.makePaymentGroupBox.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.makePaymentGroupBox.BackColor = System.Drawing.Color.White
        Me.makePaymentGroupBox.Controls.Add(Me.Label15)
        Me.makePaymentGroupBox.Controls.Add(Me.txtPaidIBy)
        Me.makePaymentGroupBox.Controls.Add(Me.txtMonthOfPayment1)
        Me.makePaymentGroupBox.Controls.Add(Me.payBtn)
        Me.makePaymentGroupBox.Controls.Add(Me.Label13)
        Me.makePaymentGroupBox.Controls.Add(Me.txtMonthOfPayment)
        Me.makePaymentGroupBox.Controls.Add(Me.Label10)
        Me.makePaymentGroupBox.Controls.Add(Me.txtAmount)
        Me.makePaymentGroupBox.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.makePaymentGroupBox.Location = New System.Drawing.Point(9, 257)
        Me.makePaymentGroupBox.Name = "makePaymentGroupBox"
        Me.makePaymentGroupBox.Size = New System.Drawing.Size(273, 176)
        Me.makePaymentGroupBox.TabIndex = 20
        Me.makePaymentGroupBox.TabStop = False
        Me.makePaymentGroupBox.Text = "Make Payment"
        Me.makePaymentGroupBox.Visible = False
        '
        'Label15
        '
        Me.Label15.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(111, 54)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(49, 15)
        Me.Label15.TabIndex = 87
        Me.Label15.Text = "Paid By:"
        '
        'txtPaidIBy
        '
        Me.txtPaidIBy.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPaidIBy.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPaidIBy.Location = New System.Drawing.Point(37, 72)
        Me.txtPaidIBy.Name = "txtPaidIBy"
        Me.txtPaidIBy.Size = New System.Drawing.Size(205, 21)
        Me.txtPaidIBy.TabIndex = 86
        Me.txtPaidIBy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtMonthOfPayment1
        '
        Me.txtMonthOfPayment1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMonthOfPayment1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMonthOfPayment1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txtMonthOfPayment1.Location = New System.Drawing.Point(67, 115)
        Me.txtMonthOfPayment1.Name = "txtMonthOfPayment1"
        Me.txtMonthOfPayment1.Size = New System.Drawing.Size(147, 21)
        Me.txtMonthOfPayment1.TabIndex = 85
        Me.txtMonthOfPayment1.Value = New Date(2023, 11, 8, 0, 0, 0, 0)
        '
        'payBtn
        '
        Me.payBtn.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.payBtn.BackColor = System.Drawing.Color.OrangeRed
        Me.payBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.payBtn.FlatAppearance.BorderSize = 0
        Me.payBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.payBtn.ForeColor = System.Drawing.Color.White
        Me.payBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.payBtn.IconColor = System.Drawing.Color.Black
        Me.payBtn.IconSize = 16
        Me.payBtn.Location = New System.Drawing.Point(87, 141)
        Me.payBtn.Name = "payBtn"
        Me.payBtn.Rotation = 0R
        Me.payBtn.Size = New System.Drawing.Size(92, 29)
        Me.payBtn.TabIndex = 84
        Me.payBtn.Text = "Pay"
        Me.payBtn.UseVisualStyleBackColor = False
        '
        'Label13
        '
        Me.Label13.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(81, 97)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(109, 15)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Contribution Month:"
        '
        'txtMonthOfPayment
        '
        Me.txtMonthOfPayment.Location = New System.Drawing.Point(9, 147)
        Me.txtMonthOfPayment.Name = "txtMonthOfPayment"
        Me.txtMonthOfPayment.Size = New System.Drawing.Size(78, 21)
        Me.txtMonthOfPayment.TabIndex = 19
        Me.txtMonthOfPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtMonthOfPayment.Visible = False
        '
        'Label10
        '
        Me.Label10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(96, 12)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 15)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Amount(Ghc):"
        '
        'txtAmount
        '
        Me.txtAmount.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtAmount.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAmount.Location = New System.Drawing.Point(37, 30)
        Me.txtAmount.Mask = "00000"
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.ReadOnly = True
        Me.txtAmount.Size = New System.Drawing.Size(205, 21)
        Me.txtAmount.TabIndex = 0
        Me.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtAmount.ValidatingType = GetType(Integer)
        '
        'ContributionsGroupBox
        '
        Me.ContributionsGroupBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ContributionsGroupBox.BackColor = System.Drawing.Color.White
        Me.ContributionsGroupBox.Controls.Add(Me.memberContributionsDataGridView)
        Me.ContributionsGroupBox.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContributionsGroupBox.Location = New System.Drawing.Point(304, 260)
        Me.ContributionsGroupBox.Name = "ContributionsGroupBox"
        Me.ContributionsGroupBox.Size = New System.Drawing.Size(605, 174)
        Me.ContributionsGroupBox.TabIndex = 19
        Me.ContributionsGroupBox.TabStop = False
        Me.ContributionsGroupBox.Text = "Contributions Made"
        Me.ContributionsGroupBox.Visible = False
        '
        'memberContributionsDataGridView
        '
        Me.memberContributionsDataGridView.AllowUserToAddRows = False
        Me.memberContributionsDataGridView.AllowUserToDeleteRows = False
        Me.memberContributionsDataGridView.AllowUserToResizeColumns = False
        Me.memberContributionsDataGridView.AllowUserToResizeRows = False
        Me.memberContributionsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.memberContributionsDataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.memberContributionsDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.memberContributionsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.memberContributionsDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.memberContributionsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.memberContributionsDataGridView.DefaultCellStyle = DataGridViewCellStyle2
        Me.memberContributionsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.memberContributionsDataGridView.Location = New System.Drawing.Point(3, 17)
        Me.memberContributionsDataGridView.Name = "memberContributionsDataGridView"
        Me.memberContributionsDataGridView.ReadOnly = True
        Me.memberContributionsDataGridView.RowHeadersVisible = False
        Me.memberContributionsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.memberContributionsDataGridView.Size = New System.Drawing.Size(599, 154)
        Me.memberContributionsDataGridView.TabIndex = 0
        '
        'selectIDType
        '
        Me.selectIDType.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.selectIDType.BackColor = System.Drawing.Color.White
        Me.selectIDType.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.selectIDType.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.selectIDType.FormattingEnabled = True
        Me.selectIDType.Items.AddRange(New Object() {"Staff ID", "Phone"})
        Me.selectIDType.Location = New System.Drawing.Point(120, 11)
        Me.selectIDType.Name = "selectIDType"
        Me.selectIDType.Size = New System.Drawing.Size(131, 23)
        Me.selectIDType.TabIndex = 15
        Me.selectIDType.Text = "Staff ID"
        '
        'searchBox
        '
        Me.searchBox.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.searchBox.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.searchBox.Location = New System.Drawing.Point(262, 8)
        Me.searchBox.Multiline = True
        Me.searchBox.Name = "searchBox"
        Me.searchBox.Size = New System.Drawing.Size(384, 28)
        Me.searchBox.TabIndex = 13
        '
        'QueryBtn
        '
        Me.QueryBtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.QueryBtn.BackColor = System.Drawing.Color.SeaGreen
        Me.QueryBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.QueryBtn.FlatAppearance.BorderSize = 0
        Me.QueryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.QueryBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.QueryBtn.ForeColor = System.Drawing.Color.White
        Me.QueryBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.QueryBtn.IconColor = System.Drawing.Color.Black
        Me.QueryBtn.IconSize = 16
        Me.QueryBtn.Location = New System.Drawing.Point(658, 8)
        Me.QueryBtn.Name = "QueryBtn"
        Me.QueryBtn.Rotation = 0R
        Me.QueryBtn.Size = New System.Drawing.Size(67, 28)
        Me.QueryBtn.TabIndex = 14
        Me.QueryBtn.Text = "Query"
        Me.QueryBtn.UseVisualStyleBackColor = False
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage3.Controls.Add(Me.addDepositBtn)
        Me.TabPage3.Controls.Add(Me.depositDataGridView)
        Me.TabPage3.Controls.Add(Me.GroupBox1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 24)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(917, 439)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Deposits/Withdrawals"
        '
        'addDepositBtn
        '
        Me.addDepositBtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.addDepositBtn.BackColor = System.Drawing.Color.SeaGreen
        Me.addDepositBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.addDepositBtn.FlatAppearance.BorderSize = 0
        Me.addDepositBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.addDepositBtn.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.addDepositBtn.ForeColor = System.Drawing.Color.White
        Me.addDepositBtn.IconChar = FontAwesome.Sharp.IconChar.None
        Me.addDepositBtn.IconColor = System.Drawing.Color.Black
        Me.addDepositBtn.IconSize = 16
        Me.addDepositBtn.Location = New System.Drawing.Point(394, 112)
        Me.addDepositBtn.Name = "addDepositBtn"
        Me.addDepositBtn.Rotation = 0R
        Me.addDepositBtn.Size = New System.Drawing.Size(139, 28)
        Me.addDepositBtn.TabIndex = 15
        Me.addDepositBtn.Text = "Add"
        Me.addDepositBtn.UseVisualStyleBackColor = False
        '
        'depositDataGridView
        '
        Me.depositDataGridView.AllowUserToAddRows = False
        Me.depositDataGridView.AllowUserToDeleteRows = False
        Me.depositDataGridView.AllowUserToResizeColumns = False
        Me.depositDataGridView.AllowUserToResizeRows = False
        Me.depositDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.depositDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.depositDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.depositDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.depositDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.depositDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.depositDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.depositDataGridView.DefaultCellStyle = DataGridViewCellStyle3
        Me.depositDataGridView.Location = New System.Drawing.Point(4, 160)
        Me.depositDataGridView.Name = "depositDataGridView"
        Me.depositDataGridView.ReadOnly = True
        Me.depositDataGridView.RowHeadersVisible = False
        Me.depositDataGridView.RowTemplate.Height = 32
        Me.depositDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.depositDataGridView.Size = New System.Drawing.Size(909, 271)
        Me.depositDataGridView.TabIndex = 8
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.Label24)
        Me.GroupBox1.Controls.Add(Me.txtWithdrawalPurpose)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.txtTrasactionType)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.txtBank)
        Me.GroupBox1.Controls.Add(Me.txtDepositedAmount)
        Me.GroupBox1.Controls.Add(Me.txtTeller)
        Me.GroupBox1.Controls.Add(Me.txtReferenceNO)
        Me.GroupBox1.Location = New System.Drawing.Point(4, 15)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(908, 90)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "DEPOSIT SLIP INFO"
        '
        'Label24
        '
        Me.Label24.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(443, 19)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(50, 15)
        Me.Label24.TabIndex = 20
        Me.Label24.Text = "Purpose:"
        '
        'txtWithdrawalPurpose
        '
        Me.txtWithdrawalPurpose.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtWithdrawalPurpose.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtWithdrawalPurpose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtWithdrawalPurpose.FormattingEnabled = True
        Me.txtWithdrawalPurpose.Items.AddRange(New Object() {"", "Claims", "Loans"})
        Me.txtWithdrawalPurpose.Location = New System.Drawing.Point(440, 37)
        Me.txtWithdrawalPurpose.Name = "txtWithdrawalPurpose"
        Me.txtWithdrawalPurpose.Size = New System.Drawing.Size(131, 23)
        Me.txtWithdrawalPurpose.Sorted = True
        Me.txtWithdrawalPurpose.TabIndex = 19
        '
        'Label16
        '
        Me.Label16.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(8, 19)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(96, 15)
        Me.Label16.TabIndex = 18
        Me.Label16.Text = "Transaction Type:"
        '
        'txtTrasactionType
        '
        Me.txtTrasactionType.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTrasactionType.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTrasactionType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtTrasactionType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtTrasactionType.FormattingEnabled = True
        Me.txtTrasactionType.Items.AddRange(New Object() {"", "Deposit", "Withdrawal"})
        Me.txtTrasactionType.Location = New System.Drawing.Point(6, 37)
        Me.txtTrasactionType.Name = "txtTrasactionType"
        Me.txtTrasactionType.Size = New System.Drawing.Size(131, 23)
        Me.txtTrasactionType.Sorted = True
        Me.txtTrasactionType.TabIndex = 17
        '
        'Label23
        '
        Me.Label23.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(751, 19)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(37, 15)
        Me.Label23.TabIndex = 16
        Me.Label23.Text = "Teller:"
        '
        'Label22
        '
        Me.Label22.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(153, 19)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(35, 15)
        Me.Label22.TabIndex = 15
        Me.Label22.Text = "Bank:"
        '
        'Label20
        '
        Me.Label20.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(584, 19)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(48, 15)
        Me.Label20.TabIndex = 13
        Me.Label20.Text = "Ref NO:"
        '
        'Label18
        '
        Me.Label18.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(358, 19)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(50, 15)
        Me.Label18.TabIndex = 11
        Me.Label18.Text = "Amount:"
        '
        'txtBank
        '
        Me.txtBank.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtBank.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtBank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtBank.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.txtBank.FormattingEnabled = True
        Me.txtBank.Items.AddRange(New Object() {"", "Abosomankotre Co-op Credit Union", "Absa ", "ADB Bank", "ARB APEX Bank", "ASA Savings and Loans", "Baduman Rural Bank", "Bank of Ghana", "Best Point Savings and Loan", "Dalex Finance", "Ecobank", "Fidelity Bank - Sunyani Main", "Fidelity Bank - Sunyani Post", "GCB Bank", "Ghana Commercial Bank(GCB)", "GT Bank", "HFC Bank", "Nkoranman Rural Bank", "Nsoatreman Rural Bank", "Oportunity International", "Prudential Bank", "Savelife Ghana", "SG Bank", "Sinapi Aba Savings and Loan", "Societe General Ghana", "Stanbic Bank", "Sunyani Christian's Co-operative Credit Union L", "The Royal Bank", "uniBank", "Universal Merchant Bank", "Wenchi Rural Bank", "Zeneth Bank"})
        Me.txtBank.Location = New System.Drawing.Point(148, 38)
        Me.txtBank.Name = "txtBank"
        Me.txtBank.Size = New System.Drawing.Size(201, 23)
        Me.txtBank.Sorted = True
        Me.txtBank.TabIndex = 8
        '
        'txtDepositedAmount
        '
        Me.txtDepositedAmount.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtDepositedAmount.Location = New System.Drawing.Point(355, 38)
        Me.txtDepositedAmount.Name = "txtDepositedAmount"
        Me.txtDepositedAmount.Size = New System.Drawing.Size(76, 21)
        Me.txtDepositedAmount.TabIndex = 7
        '
        'txtTeller
        '
        Me.txtTeller.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTeller.Location = New System.Drawing.Point(748, 37)
        Me.txtTeller.Name = "txtTeller"
        Me.txtTeller.ReadOnly = True
        Me.txtTeller.Size = New System.Drawing.Size(148, 21)
        Me.txtTeller.TabIndex = 5
        '
        'txtReferenceNO
        '
        Me.txtReferenceNO.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtReferenceNO.Location = New System.Drawing.Point(581, 37)
        Me.txtReferenceNO.Name = "txtReferenceNO"
        Me.txtReferenceNO.ReadOnly = True
        Me.txtReferenceNO.Size = New System.Drawing.Size(155, 21)
        Me.txtReferenceNO.TabIndex = 3
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage4.Controls.Add(Me.contributionReportViewer)
        Me.TabPage4.Controls.Add(Me.GroupBox2)
        Me.TabPage4.Location = New System.Drawing.Point(4, 24)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(917, 439)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Statements"
        '
        'contributionReportViewer
        '
        Me.contributionReportViewer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.contributionReportViewer.Location = New System.Drawing.Point(3, 78)
        Me.contributionReportViewer.Name = "contributionReportViewer"
        Me.contributionReportViewer.Size = New System.Drawing.Size(907, 357)
        Me.contributionReportViewer.TabIndex = 12
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.txtStatementType)
        Me.GroupBox2.Controls.Add(Me.btnQueryContributionStatement)
        Me.GroupBox2.Controls.Add(Me.txtSearchType)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.toDateTimePicker2)
        Me.GroupBox2.Controls.Add(Me.fromDateTimePicker)
        Me.GroupBox2.Controls.Add(Me.txtMemID)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(911, 66)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Search"
        '
        'Label21
        '
        Me.Label21.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(14, 29)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(84, 15)
        Me.Label21.TabIndex = 26
        Me.Label21.Text = "Statement Type"
        '
        'txtStatementType
        '
        Me.txtStatementType.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtStatementType.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtStatementType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtStatementType.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtStatementType.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStatementType.FormattingEnabled = True
        Me.txtStatementType.Items.AddRange(New Object() {"", "Contributions", "Member Contributions", "Deposits/Withdrawals"})
        Me.txtStatementType.Location = New System.Drawing.Point(104, 27)
        Me.txtStatementType.Name = "txtStatementType"
        Me.txtStatementType.Size = New System.Drawing.Size(131, 23)
        Me.txtStatementType.TabIndex = 25
        '
        'btnQueryContributionStatement
        '
        Me.btnQueryContributionStatement.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnQueryContributionStatement.BackColor = System.Drawing.Color.SeaGreen
        Me.btnQueryContributionStatement.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnQueryContributionStatement.FlatAppearance.BorderSize = 0
        Me.btnQueryContributionStatement.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnQueryContributionStatement.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnQueryContributionStatement.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQueryContributionStatement.ForeColor = System.Drawing.Color.White
        Me.btnQueryContributionStatement.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnQueryContributionStatement.IconColor = System.Drawing.Color.Black
        Me.btnQueryContributionStatement.IconSize = 16
        Me.btnQueryContributionStatement.Location = New System.Drawing.Point(713, 22)
        Me.btnQueryContributionStatement.Name = "btnQueryContributionStatement"
        Me.btnQueryContributionStatement.Rotation = 0R
        Me.btnQueryContributionStatement.Size = New System.Drawing.Size(67, 27)
        Me.btnQueryContributionStatement.TabIndex = 24
        Me.btnQueryContributionStatement.Text = "Query"
        Me.btnQueryContributionStatement.UseVisualStyleBackColor = False
        '
        'txtSearchType
        '
        Me.txtSearchType.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtSearchType.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtSearchType.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.txtSearchType.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchType.FormattingEnabled = True
        Me.txtSearchType.Items.AddRange(New Object() {"Staff ID", "Phone"})
        Me.txtSearchType.Location = New System.Drawing.Point(501, 26)
        Me.txtSearchType.Name = "txtSearchType"
        Me.txtSearchType.Size = New System.Drawing.Size(79, 23)
        Me.txtSearchType.TabIndex = 23
        Me.txtSearchType.Text = "Staff ID"
        '
        'Label19
        '
        Me.Label19.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(376, 30)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(20, 15)
        Me.Label19.TabIndex = 22
        Me.Label19.Text = "To"
        '
        'Label17
        '
        Me.Label17.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(238, 31)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(33, 15)
        Me.Label17.TabIndex = 21
        Me.Label17.Text = "From"
        '
        'toDateTimePicker2
        '
        Me.toDateTimePicker2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.toDateTimePicker2.CustomFormat = "yyyy-MM-dd"
        Me.toDateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.toDateTimePicker2.Location = New System.Drawing.Point(399, 27)
        Me.toDateTimePicker2.Name = "toDateTimePicker2"
        Me.toDateTimePicker2.Size = New System.Drawing.Size(93, 21)
        Me.toDateTimePicker2.TabIndex = 20
        '
        'fromDateTimePicker
        '
        Me.fromDateTimePicker.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.fromDateTimePicker.CustomFormat = "yyyy-MM-dd"
        Me.fromDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.fromDateTimePicker.Location = New System.Drawing.Point(277, 27)
        Me.fromDateTimePicker.Name = "fromDateTimePicker"
        Me.fromDateTimePicker.Size = New System.Drawing.Size(93, 21)
        Me.fromDateTimePicker.TabIndex = 19
        '
        'txtMemID
        '
        Me.txtMemID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtMemID.Location = New System.Drawing.Point(587, 23)
        Me.txtMemID.Multiline = True
        Me.txtMemID.Name = "txtMemID"
        Me.txtMemID.ReadOnly = True
        Me.txtMemID.Size = New System.Drawing.Size(117, 26)
        Me.txtMemID.TabIndex = 18
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.txtResponseMaskedTextBox)
        Me.TabPage5.Controls.Add(Me.btnAlertAll)
        Me.TabPage5.Controls.Add(Me.debtorsDataGridView)
        Me.TabPage5.Location = New System.Drawing.Point(4, 24)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(917, 439)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Debtors"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'txtResponseMaskedTextBox
        '
        Me.txtResponseMaskedTextBox.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtResponseMaskedTextBox.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtResponseMaskedTextBox.Location = New System.Drawing.Point(906, -12)
        Me.txtResponseMaskedTextBox.Name = "txtResponseMaskedTextBox"
        Me.txtResponseMaskedTextBox.Size = New System.Drawing.Size(205, 21)
        Me.txtResponseMaskedTextBox.TabIndex = 87
        Me.txtResponseMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtResponseMaskedTextBox.Visible = False
        '
        'btnAlertAll
        '
        Me.btnAlertAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAlertAll.BackColor = System.Drawing.Color.ForestGreen
        Me.btnAlertAll.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAlertAll.FlatAppearance.BorderSize = 0
        Me.btnAlertAll.Flip = FontAwesome.Sharp.FlipOrientation.Normal
        Me.btnAlertAll.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAlertAll.ForeColor = System.Drawing.Color.White
        Me.btnAlertAll.IconChar = FontAwesome.Sharp.IconChar.None
        Me.btnAlertAll.IconColor = System.Drawing.Color.Black
        Me.btnAlertAll.IconSize = 16
        Me.btnAlertAll.Location = New System.Drawing.Point(808, 6)
        Me.btnAlertAll.Name = "btnAlertAll"
        Me.btnAlertAll.Rotation = 0R
        Me.btnAlertAll.Size = New System.Drawing.Size(92, 29)
        Me.btnAlertAll.TabIndex = 85
        Me.btnAlertAll.Text = "Alert all"
        Me.btnAlertAll.UseVisualStyleBackColor = False
        '
        'debtorsDataGridView
        '
        Me.debtorsDataGridView.AllowUserToAddRows = False
        Me.debtorsDataGridView.AllowUserToDeleteRows = False
        Me.debtorsDataGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.debtorsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.debtorsDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.debtorsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.debtorsDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.debtorsDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.debtorsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.debtorsDataGridView.DefaultCellStyle = DataGridViewCellStyle4
        Me.debtorsDataGridView.Location = New System.Drawing.Point(0, 41)
        Me.debtorsDataGridView.MultiSelect = False
        Me.debtorsDataGridView.Name = "debtorsDataGridView"
        Me.debtorsDataGridView.ReadOnly = True
        Me.debtorsDataGridView.RowHeadersVisible = False
        Me.debtorsDataGridView.RowTemplate.Height = 32
        Me.debtorsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.debtorsDataGridView.Size = New System.Drawing.Size(914, 395)
        Me.debtorsDataGridView.TabIndex = 18
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'PrintDocument1
        '
        '
        'UserContributions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(925, 467)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "UserContributions"
        Me.Text = "UserContributions"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.ContributionsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.memberNotFoundFeedback.ResumeLayout(False)
        Me.memberNotFoundFeedback.PerformLayout()
        Me.InformationTab.ResumeLayout(False)
        Me.InformationTab.PerformLayout()
        Me.makePaymentGroupBox.ResumeLayout(False)
        Me.makePaymentGroupBox.PerformLayout()
        Me.ContributionsGroupBox.ResumeLayout(False)
        CType(Me.memberContributionsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        CType(Me.depositDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.debtorsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents ContributionsDataGridView As DataGridView
    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents txtSearchItem As TextBox
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents selectIDType As ComboBox
    Friend WithEvents QueryBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents searchBox As TextBox
    Friend WithEvents InformationTab As GroupBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtStaffID As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtPostalAddress As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtHouseNo As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtMarriageType As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtMaritalStatus As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtHomeTown As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtSex As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtBirthDate As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtMemberOtherName As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtSurname As TextBox
    Friend WithEvents makePaymentGroupBox As GroupBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txtPaidIBy As MaskedTextBox
    Friend WithEvents txtMonthOfPayment1 As DateTimePicker
    Friend WithEvents payBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents Label13 As Label
    Friend WithEvents txtMonthOfPayment As MaskedTextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtAmount As MaskedTextBox
    Friend WithEvents ContributionsGroupBox As GroupBox
    Friend WithEvents memberContributionsDataGridView As DataGridView
    Friend WithEvents Timer1 As Timer
    Friend WithEvents memberNotFoundFeedback As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents memberNoFTxt As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents depositDataGridView As DataGridView
    Friend WithEvents txtTeller As TextBox
    Friend WithEvents txtReferenceNO As TextBox
    Friend WithEvents txtDepositedAmount As MaskedTextBox
    Friend WithEvents txtBank As ComboBox
    Friend WithEvents addDepositBtn As FontAwesome.Sharp.IconButton
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtSearchType As ComboBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents toDateTimePicker2 As DateTimePicker
    Friend WithEvents fromDateTimePicker As DateTimePicker
    Friend WithEvents txtMemID As TextBox
    Friend WithEvents btnQueryContributionStatement As FontAwesome.Sharp.IconButton
    Friend WithEvents Label16 As Label
    Friend WithEvents txtTrasactionType As ComboBox
    Friend WithEvents txtStatementType As ComboBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents txtWithdrawalPurpose As ComboBox
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents debtorsDataGridView As DataGridView
    Friend WithEvents btnAlertAll As FontAwesome.Sharp.IconButton
    Friend WithEvents txtResponseMaskedTextBox As MaskedTextBox
    Private WithEvents contributionReportViewer As Microsoft.Reporting.WinForms.ReportViewer
End Class
